<?php
require_once('../configmenu.php');
require_once('../configadm.php');

