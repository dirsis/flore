<?php
class ControllerDirsiscreditoCoeficientecuota extends Controller {
	private $error = array();
	

	public function index() {
		
		$this->load->language('dirsiscredito/coeficientecuota');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/coeficientecuota');

		$this->getList();
	}

	public function add() {
		$this->load->language('dirsiscredito/coeficientecuota');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/coeficientecuota');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsiscredito_coeficientecuota->addCoeficientecuota($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsiscredito/coeficientecuota');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/coeficientecuota');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsiscredito_coeficientecuota->editCoeficientecuota($this->request->get['coeficientecuota_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsiscredito/coeficientecuota');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/coeficientecuota');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $coeficientecuota_id) {
				$this->model_dirsiscredito_coeficientecuota->deleteCoeficientecuota($coeficientecuota_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'cuotas';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsiscredito/coeficientecuota/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsiscredito/coeficientecuota/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['coeficientecuotas'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$coeficientecuota_total = $this->model_dirsiscredito_coeficientecuota->getTotalCoeficientecuotas();

		$results = $this->model_dirsiscredito_coeficientecuota->getCoeficientecuotas($filter_data);

		foreach ($results as $result) {
			$data['coeficientecuotas'][] = array(
				'coeficientecuota_id' => $result['coeficientecuota_id'],
				'cuotas'          => $result['cuotas'],
				'coef'          => $result['coef'],							
				'edit'          => $this->url->link('dirsiscredito/coeficientecuota/edit', 'user_token=' . $this->session->data['user_token'] . '&coeficientecuota_id=' . $result['coeficientecuota_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_cuotas'] = $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . '&sort=cuotas' . $url, true);
		$data['sort_estado'] = $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $coeficientecuota_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($coeficientecuota_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($coeficientecuota_total - $this->config->get('config_limit_admin'))) ? $coeficientecuota_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $coeficientecuota_total, ceil($coeficientecuota_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscredito/coeficientecuota_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['coeficientecuota_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['cuotas'])) {
			$data['error_cuotas'] = $this->error['cuotas'];
		} else {
			$data['error_cuotas'] = '';
		}
		
		if (isset($this->error['coef'])) {
			$data['error_coef'] = $this->error['coef'];
		} else {
			$data['error_coef'] = '';
		}		
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['coeficientecuota_id'])) {
			$data['action'] = $this->url->link('dirsiscredito/coeficientecuota/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscredito/coeficientecuota/edit', 'user_token=' . $this->session->data['user_token'] . '&coeficientecuota_id=' . $this->request->get['coeficientecuota_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['coeficientecuota_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$coeficientecuota_info = $this->model_dirsiscredito_coeficientecuota->getCoeficientecuota($this->request->get['coeficientecuota_id']);
		}

		if (isset($this->request->post['cuotas'])) {
			$data['cuotas'] = $this->request->post['cuotas'];
		} elseif (!empty($coeficientecuota_info)) {
			$data['cuotas'] = $coeficientecuota_info['cuotas'];
		} else {
			$data['cuotas'] = 1;
		}
		
		if (isset($this->request->post['coef'])) {
			$data['coef'] = $this->request->post['coef'];
		} elseif (!empty($coeficientecuota_info)) {
			$data['coef'] = $coeficientecuota_info['coef'];
		} else {
			$data['coef'] = 0;
		}			

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscredito/coeficientecuota_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsiscredito/coeficientecuota')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['cuotas']) <1) {
			$this->error['cuotas'] = $this->language->get('error_cuotas');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsiscredito/coeficientecuota')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $coeficientecuota_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($coeficientecuota_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_cuotas'])) {
			if (isset($this->request->get['filter_cuotas'])) {
				$filter_cuotas = $this->request->get['filter_cuotas'];
			} else {
				$filter_cuotas = '';
			}

			$this->load->model('dirsiscredito/coeficientecuota');

			$filter_data = array(
				'filter_cuotas'      => $filter_cuotas,
				'start'            => 0,
				'limit'            => 15
			);

			$results = $this->model_dirsiscredito_coeficientecuota->getCoeficientecuotas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'coeficientecuota_id' => $result['coeficientecuota_id'],
					'cuotas'     => $result['cuotas'],
					'coef'    => $result['coef']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['cuotas'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}