<?php
class ControllerDirsiscreditoConsultafinanciero extends Controller {
	private $error = array();
	public function index() {
		
		$this->load->language('dirsiscredito/consultafinanciero');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/consultafinanciero');
		
		$this->getList();
		
	}
	
	
	public function add() {
		$this->load->language('dirsiscredito/consultafinanciero');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/consultafinanciero');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->load->model('customer/customer');
			$results = $this->model_customer_customer->getCustomerxdni($this->request->post['cuit']);
			if (!$results){
				$data=array("cuit" => $this->request->post['cuit'],
							 "firstname" => $this->request->post['firstname'],
							"lastname" => '(provisorio)',
							"email" => $this->request->post['email'],
							"telephone" => $this->request->post['telephone'],
							"password" => '',
							"safe" => 0,
							"newsletter" => 0,
							"affiliate" => 0,
							"status" => 1);
				$customer_id = $this->model_customer_customer->addCustomer($data);
			}else{
				$customer_id = $results['customer_id'];
			}
			
			$this->model_dirsiscredito_consultafinanciero->addConsultafinanciero($this->request->post,$customer_id);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsiscredito/consultafinanciero');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/consultafinanciero');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			
			$this->load->model('customer/customer');
			$results = $this->model_customer_customer->getCustomerxdni($this->request->post['cuit']);
			if (!$results){
				
				$data=array("cuit" => $this->request->post['cuit'],
							 "firstname" => $this->request->post['firstname'],
							"lastname" => '(provisorio)',
							"email" => $this->request->post['email'],
							"telephone" => $this->request->post['telephone'],
							"password" => '',
							"safe" => 0,
							"newsletter" => 0,
							"affiliate" => 0,
							"status" => 1);
			
				
				$customer_id = $this->model_customer_customer->addCustomer($data);
			}else{
				$customer_id = $results['customer_id'];
			}
			$this->model_dirsiscredito_consultafinanciero->editConsultafinanciero($this->request->get['consultafinanciero_id'], $this->request->post,$customer_id);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsiscredito/consultafinanciero');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscredito/consultafinanciero');


		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $consultafinanciero_id) {
				$this->model_dirsiscredito_consultafinanciero->deleteConsultafinanciero($consultafinanciero_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		//LISTAR
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}
		if (isset($this->request->get['filter_monto'])) {
			$filter_monto = $this->request->get['filter_monto'];
		} else {
			$filter_monto = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}			
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}				
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$data['limit'] = $this->request->get['limit'];
		} else {
			$data['limit'] = $this->config->get('config_limit_admin');
		}
		

		$url = '';
		
	

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_monto'])) {
			$url .= '&filter_monto=' . urlencode(html_entity_decode($this->request->get['filter_monto'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}		

		$data['consultafinancieros'] = array();
		
		$filter_data = array(
			'filter_customer'	     => $filter_customer,
			'filter_monto'	     	 => $filter_monto,
			'filter_date_added'      => $filter_date_added,
			'filter_status'			 => $filter_status,
			'sort'                   => $sort,
			'order'                  => $order,
			'start'                  => ($page - 1) * $data['limit'],
			'limit'                  => $data['limit']
		);

		$consultafinanciero_total = $this->model_dirsiscredito_consultafinanciero->getTotalConsultafinanciero($filter_data);
		
		
		
		$results = $this->model_dirsiscredito_consultafinanciero->getConsultafinancieros($filter_data);
		
		
		if (isset($results)){
			foreach ($results as $result) {
				$verurl="&filter_customer_id=".$result['customer_id']."&filter_customer=".$result['customer'];
				$data['consultafinancieros'][] = array(
				'consultafinanciero_id' => $result['consultafinanciero_id'],
				'date_added'   => $result['date_added'],
				'customer_id'   => $result['customer_id'],
				'customer'      => $result['customer'],
				'email'      	=> $result['email'],
				'telephone'     => $result['telephone'],
				'monto'         => number_format($result['monto'], '2'),
				'cuotas'         => $result['cuotas'],
				'coef'         => $result['coef'],
				'status'     	=> $result['status'] ? 'Pendiente':'Resuelto',					
				'editar'		=> $this->url->link('dirsiscredito/consultafinanciero/edit','user_token=' . $this->session->data['user_token'] . '&consultafinanciero_id='.$result['consultafinanciero_id'],true),
				'verurl'		=> $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . $verurl, true),
				'verrec'		=> $this->url->link('admdirsis/debcre', 'user_token=' . $this->session->data['user_token'] . $verurl, true)
				);

			}
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_monto'])) {
			$url .= '&filter_monto=' . urlencode(html_entity_decode($this->request->get['filter_monto'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}		
		$data['sort_date_added'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.date_added' . $url, true);
		$data['sort_status'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.customer_id' . $url, true);		
		$data['sort_customer'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.customer' . $url, true);
		$data['sort_monto'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.monto' . $url, true);
		$data['sort_cuotas'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.cuotas' . $url, true);
		$data['sort_email'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_telephone'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=c.telephone' . $url, true);		
$data['sort_coef'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . '&sort=x.coef' . $url, true);		

		$url = '';

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_monto'])) {
			$url .= '&filter_monto=' . urlencode(html_entity_decode($this->request->get['filter_monto'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		$data['add'] = $this->url->link('dirsiscredito/consultafinanciero/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsiscredito/consultafinanciero/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$pagination = new Pagination();
		$pagination->total = $consultafinanciero_total;
		$pagination->page = $page;
		$pagination->limit = $data['limit'];
		$pagination->url = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}'. '&limit='.$data['limit'], true);
		
		

		$data['pagination'] = $pagination->render();
		
		//print_r($consultafinanciero_total);
		

		$data['results'] = sprintf($this->language->get('text_pagination'), ($consultafinanciero_total) ? (($page - 1) * $data['limit']) + 1 : 0, ((($page - 1) * $data['limit']) > ($consultafinanciero_total - $data['limit'])) ? $consultafinanciero_total : ((($page - 1) * $data['limit']) + $data['limit']), $consultafinanciero_total, ceil($consultafinanciero_total / $data['limit']));

		$data['filter_customer'] = $filter_customer;
		$data['filter_monto'] = $filter_monto;
		$data['filter_date_added'] = $filter_date_added;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
//FIN LISTAR		
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->load->model('user/api');
		
		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));
		if ($api_info && $this->user->hasPermission('modify', 'dirsiscredito/consultafinanciero')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);
			$session->start();
			$this->model_user_api->deleteApiSessionBySessonId($session->getId());
			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
			$session->data['api_id'] = $api_info['api_id'];
			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
/*DIRSIS*/		
		$this->load->model('user/user');
		
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			
			$data['firstname'] = $user_info['firstname'];
			$data['lastname'] = $user_info['lastname'];
			$data['username']  = $user_info['username'];
			$data['user_group'] = $user_info['user_group'];		
			$data['user_group_id'] = $user_info['user_group_id'];	
			$data['user_group_nivel'] = $user_info['user_group_nivel'];
			//$data['nivel'] = $user_info['nivel'];		
		}
		
		$data['mask'] = $this->config->get('config_valor_pp');
		$data['mask2'] = $this->config->get('config_valor_adm');
		$data['mask3'] = $this->config->get('config_valor_fecha');	
		
		
		if (empty($filter_date_added)){
			$data['filter_date_added']=date("Y-m-d");
		}
		
/*DIRSIS*/		
		$this->response->setOutput($this->load->view('dirsiscredito/consultafinanciero_list', $data));
	}
	
	
	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['consultafinanciero_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['cuotas'])) {
			$data['error_cuotas'] = $this->error['cuotas'];
		} else {
			$data['error_cuotas'] = '';
		}
		
		if (isset($this->error['coef'])) {
			$data['error_coef'] = $this->error['coef'];
		} else {
			$data['error_coef'] = '';
		}		
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['consultafinanciero_id'])) {
			$data['action'] = $this->url->link('dirsiscredito/consultafinanciero/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscredito/consultafinanciero/edit', 'user_token=' . $this->session->data['user_token'] . '&consultafinanciero_id=' . $this->request->get['consultafinanciero_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['consultafinanciero_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$consultafinanciero_info = $this->model_dirsiscredito_consultafinanciero->getConsultafinanciero($this->request->get['consultafinanciero_id']);
		}

		if (isset($this->request->post['firstname'])) {
			$data['firstname'] = $this->request->post['firstname'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['firstname'] = $consultafinanciero_info['firstname'];
		} else {
			$data['firstname'] = '';
		}
		
		if (isset($this->request->post['cuit'])) {
			$data['cuit'] = $this->request->post['cuit'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['cuit'] = $consultafinanciero_info['cuit'];
		} else {
			$data['cuit'] = '';
		}
		
		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['email'] = $consultafinanciero_info['email'];
		} else {
			$data['email'] = '';
		}
		
		if (isset($this->request->post['cuotas'])) {
			$data['cuotas'] = $this->request->post['cuotas'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['cuotas'] = $consultafinanciero_info['cuotas'];
		} else {
			$data['cuotas'] = 1;
		}
		
		if (isset($this->request->post['monto'])) {
			$data['monto'] = $this->request->post['monto'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['monto'] = $consultafinanciero_info['monto'];
		} else {
			$data['monto'] = 0;
		}		
		
		if (isset($this->request->post['coef'])) {
			$data['coef'] = $this->request->post['coef'];
		} elseif (!empty($consultafinanciero_info)) {
			$data['coef'] = $consultafinanciero_info['coef'];
		} else {
			$data['coef'] = 0;
		}			

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscredito/consultafinanciero_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsiscredito/consultafinanciero')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['cuotas']) <1) {
			$this->error['cuotas'] = $this->language->get('error_cuotas');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsiscredito/consultafinanciero')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}
	
	
	public function generar_csv() {
		$json = array();
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}
		if (isset($this->request->get['filter_monto'])) {
			$filter_monto = $this->request->get['filter_monto'];
		} else {
			$filter_monto = '';
		}		
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
			
		$this->load->model('dirsiscredito/consultafinanciero');

		$filter_data = array(
			'filter_customer'   => $filter_customer,
			'filter_monto'   => $filter_monto,
			'filter_date_added' => $filter_date_added,
			'start'            	=> 0,
			'limit'            	=> 5
		);
		
		

		$results = $this->model_dirsiscredito_consultafinanciero->generar_csv($filter_data);

		$archivo = "consultafinancieros_".uniqid().".csv";
		$outputBuffer = fopen($archivo, 'w');
		$linea="ID,Denominacion,Consultafinanciero";
		fwrite($outputBuffer, $linea . PHP_EOL);	
		foreach ($results as $result) {
			$linea=$result['customer_id'].",".strip_tags(html_entity_decode($result['customer'], ENT_QUOTES, 'UTF-8')).",".number_format($result['monto'], 2, '.', '');
			fwrite($outputBuffer, $linea . PHP_EOL);	
		}
		fclose($outputBuffer);
		$this->response->setOutput($archivo);
/*		
		foreach ($results as $result) {
			$json[] = array(
				'customer_id'       => $result['customer_id'],
				'customer'          => strip_tags(html_entity_decode($result['customer'], ENT_QUOTES, 'UTF-8')),
				'total'    			=> $result['total']
			);
		}
		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['customer'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
*/
	}
}
