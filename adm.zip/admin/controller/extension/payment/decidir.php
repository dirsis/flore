<?php
class ControllerExtensionPaymentDecidir extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/decidir');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_decidir', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/decidir', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/decidir', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->post['payment_decidir_total'])) {
			$data['payment_decidir_total'] = $this->request->post['payment_decidir_total'];
		} else {
			$data['payment_decidir_total'] = $this->config->get('payment_decidir_total');
		}

		if (isset($this->request->post['payment_decidir_order_status_id'])) {
			$data['payment_decidir_order_status_id'] = $this->request->post['payment_decidir_order_status_id'];
		} else {
			$data['payment_decidir_order_status_id'] = $this->config->get('payment_decidir_order_status_id');
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['payment_decidir_geo_zone_id'])) {
			$data['payment_decidir_geo_zone_id'] = $this->request->post['payment_decidir_geo_zone_id'];
		} else {
			$data['payment_decidir_geo_zone_id'] = $this->config->get('payment_decidir_geo_zone_id');
		}

		$this->load->model('localisation/geo_zone');

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		if (isset($this->request->post['payment_decidir_status'])) {
			$data['payment_decidir_status'] = $this->request->post['payment_decidir_status'];
		} else {
			$data['payment_decidir_status'] = $this->config->get('payment_decidir_status');
		}

		if (isset($this->request->post['payment_decidir_id'])) {
			$data['payment_decidir_id'] = $this->request->post['payment_decidir_id'];
		} else {
			$data['payment_decidir_id'] = $this->config->get('payment_decidir_id');
		}
		
		if (isset($this->request->post['payment_decidir_template'])) {
			$data['payment_decidir_template'] = $this->request->post['payment_decidir_template'];
		} else {
			$data['payment_decidir_template'] = $this->config->get('payment_decidir_template');
		}
		
		if (isset($this->request->post['payment_decidir_keypub'])) {
			$data['payment_decidir_keypub'] = $this->request->post['payment_decidir_keypub'];
		} else {
			$data['payment_decidir_keypub'] = $this->config->get('payment_decidir_keypub');
		}
		
		if (isset($this->request->post['payment_decidir_keypri'])) {
			$data['payment_decidir_keypri'] = $this->request->post['payment_decidir_keypri'];
		} else {
			$data['payment_decidir_keypri'] = $this->config->get('payment_decidir_keypri');
		}
		
		if (isset($this->request->post['payment_decidir_cuota'])) {
			$data['payment_decidir_cuota'] = $this->request->post['payment_decidir_cuota'];
		} else {
			$data['payment_decidir_cuota'] = $this->config->get('payment_decidir_cuota');
		}
		
		
		$data['cuotas'][] = array ("cuota" => '1', "name" => '1 cta');
		$data['cuotas'][] = array ("cuota" => '3', "name" => '1,3 ctas');
		$data['cuotas'][] = array ("cuota" => '6', "name" => '1,3,6 ctas');
		$data['cuotas'][] = array ("cuota" => '9', "name" => '1,3,6,9 ctas');
		$data['cuotas'][] = array ("cuota" => '12', "name" => '1,3,6,9,12 ctas');
		$data['cuotas'][] = array ("cuota" => '13', "name" => '1,Ahora3 ctas');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/decidir', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/decidir')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}