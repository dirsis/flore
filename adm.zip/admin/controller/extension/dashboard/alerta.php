<?php
class ControllerExtensionDashboardAlerta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/alerta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_alerta', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/dashboard/alerta', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/dashboard/alerta', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		if (isset($this->request->post['dashboard_alerta_width'])) {
			$data['dashboard_alerta_width'] = $this->request->post['dashboard_alerta_width'];
		} else {
			$data['dashboard_alerta_width'] = $this->config->get('dashboardalerta_width');
		}
	
		$data['columns'] = array();
		
		for ($i = 3; $i <= 12; $i++) {
			$data['columns'][] = $i;
		}
				
		if (isset($this->request->post['dashboard_alerta_status'])) {
			$data['dashboard_alerta_status'] = $this->request->post['dashboard_alerta_status'];
		} else {
			$data['dashboard_alerta_status'] = $this->config->get('dashboard_alerta_status');
		}

		if (isset($this->request->post['dashboard_alerta_sort_order'])) {
			$data['dashboard_alerta_sort_order'] = $this->request->post['dashboard_alerta_sort_order'];
		} else {
			$data['dashboard_alerta_sort_order'] = $this->config->get('dashboard_alerta_sort_order');
		}

		if (isset($this->request->post['dashboard_alerta_sort_panel'])) {
			$data['dashboard_alerta_sort_panel'] = $this->request->post['dashboard_alerta_sort_panel'];
		} else {
			$data['dashboard_alerta_sort_panel'] = $this->config->get('dashboard_alerta_sort_panel');
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/dashboard/alerta_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/alerta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	
	public function dashboard() {
		$this->load->language('extension/dashboard/alerta');
		
		$data['abc'] = $this->load->controller('extension/dashboard/alerta/abc');
		
		$data['user_token'] = $this->session->data['user_token'];

		return $this->load->view('extension/dashboard/alerta_info', $data);
	}
	
	public function estadi() {
		$this->load->language('extension/dashboard/alerta');
		$this->load->model('extension/dashboard/alerta');
		$alertaxdias = $this->model_extension_dashboard_alerta->getAlertaxDia();
		$estadigraph2 = array ();
		foreach ($alertaxdias as $alertaxdia){
			$data['alertaxdias'][] = array (
				"name" => $alertaxdia['dia'],
				"valor" => $alertaxdia['cantidad']
			);
			$estadigraph2[] = array (
				"dato" => (string)$alertaxdia['dia'],
				"valor" => (int)$alertaxdia['cantidad']
			);			
		}
		$data['estadigraph2']=json_encode($estadigraph2);
		
		$estadigraph = array ();
		$alertaxstatuss = $this->model_extension_dashboard_alerta->getAlertaxStatus();
		foreach ($alertaxstatuss as $alertaxstatus){
			$estadigraph[] = array (
				"dato" => $this->questatus($alertaxstatus['status']),
				"valor" => $alertaxstatus['cantidad']
			);
		}		
		$data['estadigraph']=json_encode($estadigraph);
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('extension/dashboard/alerta_estadi', $data));
	}	

	public function abc() {

		$this->load->language('extension/dashboard/alerta');
		$this->load->model('customer/customer');
		$filter_data=array();
		$data['customers'] = $this->model_customer_customer->getCustomers($filter_data);
		$data['vence'] = date("d-m-Y");
		
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('extension/dashboard/alerta_abc', $data));
	}	
	
	public function addalerta() {
		$json = $this->request->post;
		
		$this->load->model('extension/dashboard/alerta');
		$this->model_extension_dashboard_alerta->addAlerta($this->request->post);
		$json['envio']=array("result" => isset($this->request->post['envia'])?1:0);
		if ($json['envio']=='1'){
			$this->load->model('customer/customer');
			$customer=$this->model_customer_customer->getCustomer($this->request->post['customer_id']);
			$status="";
			switch ($this->request->post['status']) {
    		case 1:
        		$status="Pendiente";
        		break;
    		case 2:
        		$status="Terminado";
        		break;
    		case 3:
        		$status="Informado";
        		break;
    		case 3:
        		$status="Cancelado";
        		break;
			}
			$mensaje="Dpto.Programacion<hr>";
			$mensaje.="Cliente:<b>(".$this->request->post['customer_id'].") ";
			$mensaje.=$customer['firstname'].",".$customer['lastname']."</b><br>";
			$mensaje.="Motivo:<b>".$this->request->post['tema']."</b><br>";
			$mensaje.="Resultado:<b>".$this->request->post['notifica']."<b><br>";
			$mensaje.="Fecha:<b>".date("d-m-Y")."</b>";
			$data = array (
				"email" => $customer['email'],
				"asunto" => "Actualizacion de Software",
				"mensaje" => $mensaje,
				"status" => $status
			);
			$this->load->controller('mail/notifica/enviaNotifica',$data);
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	public function elimina() {
		$this->load->language('extension/dashboard/alerta');
		$json = array();
		$this->load->model('extension/dashboard/alerta');
		if (isset($this->request->get['alerta_id'])) {
			$this->model_extension_dashboard_alerta->eliminaStatus($this->request->get['alerta_id']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	

	public function edit() {
		$json=array();
		$this->load->model('extension/dashboard/alerta');
		if (isset($this->request->get['alerta_id'])) {
			$result = $this->model_extension_dashboard_alerta->getAlerta($this->request->get['alerta_id']);
			$json = array (
				"alerta_id" => $result['alerta_id'],
				"date_added" => date("d-m-Y",strtotime($result['date_added'])),
				"notifica" => $result['notifica'],
				"tema" => $result['tema'],
				"vence" => date("d-m-Y",strtotime($result['vence'])),
				"customer_id" => $result['customer_id'],
				"customer" => $result['customer'],
				"status" => $result['status'],
			);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function alerta() {
		$this->load->language('extension/dashboard/alerta');
		//$json = array();
		$this->load->model('extension/dashboard/alerta');
		if (isset($this->request->get['status'])) {
			$status = $this->request->get['status'];
		} else {
			$status = '1';
		}
		if (isset($this->request->get['search'])) {
			$search = $this->request->get['search'];
		} else {
			$search = '';
		}		
		$results = $this->model_extension_dashboard_alerta->getAlertas($status,$search);
		$data['agendas']=array();
		foreach ($results as $result){
			switch ($result['status']) {
				default:
					$up='';
					$down='';
				case 1:
					$up=array("accion" => 4,"titulo" => 'Cancela');
					$down=array("accion" => 2,"titulo" => 'Termina');
					$color='#e6ce06';
					break;
				case 2:
					$up=array("accion" => 1,"titulo" => 'Pendiente');
					$down=array("accion" => 3,"titulo" => 'Informa');
					$color='#0c9658';
					break;
				case 3:
					$up=array("accion" => 2,"titulo" => 'Termina');
					$down=array("accion" => 3,"titulo" => 'Informa');
					$color='#007de9';
					break;				
				case 4:
					$up=array("accion" => 1,"titulo" => 'Pendiente');
					$down='';
					$color='#f61901';

					break;				
			}			
			$data['agendas'][]=array(
						'alerta_id' => $result['alerta_id'],
						'date_added' => date("d-m-Y H:i",strtotime($result['date_added'])),
						'vence' => date("d-m-Y",strtotime($result['vence'])),
						'tema' => nl2br($result['tema']),
						'notifica' => nl2br($result['notifica']),
						'customer_id' => $result['customer_id'],
						'customer' => $result['customer'],
						'status' => $result['status'],
						'envia' => $result['envia']>$result['date_added']?date("d-m-Y h:i",strtotime($result['envia'])):"",
						'color' => $color,
						'up' => $up,
						'down' => $down,
			);		
		}		
		
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('extension/dashboard/alerta_grilla', $data));
		

		/*
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
		*/
	}
	
	
	
	public function questatus($status) {
		$return=$status;
		switch ($status) {
			case 1:
				$return="Pendiente";
				break;
			case 2:
				$return="Terminado";
				break;
			case 3:
				$return="Informado";
				break;				
			case 4:
				$return="Cancelado";
				break;				
		}			
		return $return;
	}
	

}