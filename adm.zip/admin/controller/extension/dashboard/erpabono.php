<?php
class ControllerExtensionDashboardErpabono extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/erpabono');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('dashboard_erpabono', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/dashboard/erpabono', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/dashboard/erpabono', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		if (isset($this->request->post['dashboard_erpabono_width'])) {
			$data['dashboard_erpabono_width'] = $this->request->post['dashboard_erpabono_width'];
		} else {
			$data['dashboard_erpabono_width'] = $this->config->get('dashboard_erpabono_width');
		}
	
		$data['columns'] = array();
		
		for ($i = 3; $i <= 12; $i++) {
			$data['columns'][] = $i;
		}
				
		if (isset($this->request->post['dashboard_erpabono_status'])) {
			$data['dashboard_erpabono_status'] = $this->request->post['dashboard_erpabono_status'];
		} else {
			$data['dashboard_erpabono_status'] = $this->config->get('dashboard_erpabono_status');
		}

		if (isset($this->request->post['dashboard_erpabono_sort_order'])) {
			$data['dashboard_erpabono_sort_order'] = $this->request->post['dashboard_erpabono_sort_order'];
		} else {
			$data['dashboard_erpabono_sort_order'] = $this->config->get('dashboard_erpabono_sort_order');
		}

		if (isset($this->request->post['dashboard_erpabono_sort_panel'])) {
			$data['dashboard_erpabono_sort_panel'] = $this->request->post['dashboard_erpabono_sort_panel'];
		} else {
			$data['dashboard_erpabono_sort_panel'] = $this->config->get('dashboard_erpabono_sort_panel');
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/dashboard/erpabono_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/erpabono')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function dashboard() {
		$this->load->language('extension/dashboard/erpabono');

		$data['user_token'] = $this->session->data['user_token'];

		// Total Orders
		$this->load->model('extension/dashboard/erpabono');

		// Customers Ecoonline
		if ($this->config->get('config_customer_abonoxdom')){
			$resultado = $this->model_extension_dashboard_erpabono->getTotal2();
		}else{
			$resultado = $this->model_extension_dashboard_erpabono->getTotal1();
		}
		
		$data['cantidad'] = $this->medida($resultado['cantidad']);
		$data['promedio'] = $this->medida($resultado['promedio']);
		$data['total'] = $this->medida($resultado['total']);
		$data['max']   = $this->medida($resultado['max']);
		$data['min']   = $this->medida($resultado['min']);

		$data['erpabono'] = $this->url->link('report/erpabono', 'user_token=' . $this->session->data['user_token'], true);

		return $this->load->view('extension/dashboard/erpabono_info', $data);
	}
	public function medida($valor) {
		if ($valor > 1000000000000) {
			$result = round($valor / 1000000000000, 1) . 'T';
		} elseif ($valor > 1000000000) {
			$result = round($valor / 1000000000, 1) . 'B';
		} elseif ($valor > 1000000) {
			$result = round($valor / 1000000, 1) . 'M';
		} elseif ($valor > 1000) {
			$result = round($valor / 1000, 1) . 'K';
		} else {
			$result = round($valor,0);
		}
		return $result;
	}

}
