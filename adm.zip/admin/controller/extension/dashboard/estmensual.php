<?php
class ControllerExtensionDashboardEstmensual extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/dashboard/estmensual');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
		//print_r($this->request->post);
		//die;
			$this->model_setting_setting->editSetting('dashboard_estmensual', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/dashboard/estmensual', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/dashboard/estmensual', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=dashboard', true);

		if (isset($this->request->post['dashboard_estmensual_width'])) {
			$data['dashboard_estmensual_width'] = $this->request->post['dashboard_estmensual_width'];
		} else {
			$data['dashboard_estmensual_width'] = $this->config->get('dashboard_estmensual_width');
		}
	
		$data['columns'] = array();
		
		for ($i = 3; $i <= 12; $i++) {
			$data['columns'][] = $i;
		}
				
		if (isset($this->request->post['dashboard_estmensual_status'])) {
			$data['dashboard_estmensual_status'] = $this->request->post['dashboard_estmensual_status'];
		} else {
			$data['dashboard_estmensual_status'] = $this->config->get('dashboard_estmensual_status');
		}

		if (isset($this->request->post['dashboard_estmensual_sort_order'])) {
			$data['dashboard_estmensual_sort_order'] = $this->request->post['dashboard_estmensual_sort_order'];
		} else {
			$data['dashboard_estmensual_sort_order'] = $this->config->get('dashboard_estmensual_sort_order');
		}
		
		
		if (isset($this->request->post['dashboard_estmensual_sort_panel'])) {
			$data['dashboard_estmensual_sort_panel'] = $this->request->post['dashboard_estmensual_sort_panel'];
		} else {
			$data['dashboard_estmensual_sort_panel'] = $this->config->get('dashboard_estmensual_sort_panel');
		}			

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/dashboard/estmensual_form', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/dashboard/estmensual')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	
	public function dashboard() {
		//LENGUAJE
		$this->load->language('extension/dashboard/estmensual');
		//MODEL
		$this->load->model('extension/dashboard/estmensual');
		$this->load->model('extension/dashboard/contab');
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date('Y-m-d', strtotime($this->request->get['filter_date_desde']));
			$desde			   = date('d-m-Y', strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde 	= date('Y-m-d',strtotime('first day of January', time()));
			$desde 				= date('d-m-Y',strtotime('first day of January', time()));
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date('Y-m-d', strtotime($this->request->get['filter_date_hasta']));
			$hasta 				= date('d-m-Y', strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date('Y-m-d', strtotime('now'));
			$hasta 				= date('d-m-Y', strtotime('now'));
		}
		
		if (isset($this->request->get['filter_usuario'])) {
			$filter_usuario = $this->request->get['filter_usuario'];
		}else{
			$filter_usuario = '';
		}
		if (isset($this->request->get['filter_sucursal'])) {
			$filter_sucursal = $this->request->get['filter_sucursal'];
		}else{
			$filter_sucursal = '';
		}
		if (isset($this->request->get['filter_grupo'])) {
			$filter_grupo = $this->request->get['filter_grupo'];
		}else{
			$filter_grupo = '';
		}
		if (isset($this->request->get['filter_sgrupo'])) {
			$filter_sgrupo = $this->request->get['filter_sgrupo'];
		}else{
			$filter_sgrupo = '';
		}		
		if (isset($this->request->get['filter_ssgrupo'])) {
			$filter_ssgrupo = $this->request->get['filter_ssgrupo'];
		}else{
			$filter_ssgrupo = '';
		}		
		if (isset($this->request->get['filter_sssgrupo'])) {
			$filter_sssgrupo = $this->request->get['filter_sssgrupo'];
		}else{
			$filter_sssgrupo = '';
		}		
		if (isset($this->request->get['filter_prov'])) {
			$filter_prov = $this->request->get['filter_prov'];
		}else{
			$filter_prov = '';
		}		
		if (isset($this->request->get['filter_serie'])) {
			$filter_serie 	= $this->request->get['filter_serie'];
		} else {
			$filter_serie 	= '';
		}		
		$datafiltro = array (
			'filtro_serie' => $filter_serie,
			'filtro_desde' => $filter_date_desde,
			'filtro_hasta' => $filter_date_hasta,
			'filtro_sucursal' => $filter_sucursal,
			'filtro_usuario' => $filter_usuario,
			'filtro_grupo' => $filter_grupo,
			'filtro_sgrupo' => $filter_sgrupo,
			'filtro_ssgrupo' => $filter_ssgrupo,
			'filtro_sssgrupo' => $filter_sssgrupo,
			'filtro_prov' => $filter_prov
		);

		
		
		$data['periodo']=$desde." al ".$hasta;	
		//OBJETO MODEL
		
		$results = $this->model_extension_dashboard_estmensual->getInfo($datafiltro);
		$resultado = array();
		foreach ($results as $result) {
			$resultado[] = array(
		        'dato' => $result['dato'],
		        'valor' => $result['valor']);
		}
	    $data['resultado'] = json_encode($resultado);
			

		return $this->load->view('extension/dashboard/estmensual_info', $data);
	}
}