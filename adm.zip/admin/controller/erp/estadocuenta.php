<?php
class ControllerErpEstadocuenta extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('erp/estadocuenta');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/estadocuenta');
		//CREA LA TABLA SI NO EXISTE
		//
		$this->model_erp_estadocuenta->creaEstadocuenta();
		
		//			
		$this->getList();
	}
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/estadocuenta');
		$this->load->model('erp/estadocuenta');
		
		$this->model_erp_estadocuenta->traeEstadocuenta();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get);
		$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		
	}
	
	public function reinicia(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/estadocuenta');
		$this->load->model('erp/estadocuenta');
		
		$this->model_erp_estadocuenta->bajaEstadocuenta();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get);
		$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		
	}
	
	public function filtrar($get){
		
		$url1=$url2=$url3='';

		if (isset($get['filter_status'])) {
			$url1 .= '&filter_status=' . $get['filter_status'];
		}
		
		$url2=$url1;

		if (isset($get['sort'])) {
			$url1 .= '&sort=' . $get['sort'];
			
		}

		if (isset($get['order'])) {
			$url1 .= '&order=' . $get['order'];
			if (isset($get['sort'])) {
			$url2 .= '&sort=' . $get['sort'];
			}
		}
		
		$url3=$url2;

		if (isset($get['page'])) {
			$url1 .= '&page=' . $get['page'];
			$url2 .= '&page=' . $get['page'];
		}
		
		if (isset($get['limit'])) {
			$url1 .= '&limit=' . $get['limit'];
			$url2 .= '&limit=' . $get['limit'];
			$url3 .= '&limit=' . $get['limit'];
		}else{
			$url1 .= '&limit=' . $this->config->get('config_limit_admin');
			$url2 .= '&limit=' . $this->config->get('config_limit_admin');
			$url3 .= '&limit=' . $this->config->get('config_limit_admin');
		}	
		
		
		return array("url1" => $url1,"url2" => $url2,"url3" => $url3);
	}

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/estadocuenta');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/estadocuenta');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$periodo=(int)$this->request->post['periodo'];
			$anio=(int)$this->request->post['anio'];
			$cuotas=(float)$this->request->post['cuota'];
			$total=((float)$this->request->post['total']*(float)$this->request->post['cantidad']);
			$debit=$this->request->post['date_debit'];
			$date1 = new DateTime($this->request->post['date_debit']);
			$date2 = new DateTime($this->request->post['date_vto']);
			$diff = $date1->diff($date2);
			$dias=$diff->days;
			if ((int)$this->request->post['cuota1']>0){
				if ($cuotas!=1){
					$saldo=$total-(float)$this->request->post['cuota1'];
					$saldo=$saldo/($cuotas-1);
				}else{
					$saldo=$total;
				}
			}else{
				$saldo=$total/($cuotas);
			}
			for ($i = 1; $i <= $cuotas; $i++) {
				
				$date_future = strtotime('+'.$dias.' day', strtotime($debit));
				$vto = date('d-m-Y', $date_future);
				
				//$vto= strtotime('+ 5 days', strtotime(date("Y-m-d")));
				if (($this->request->post['cuota1']!=0) and ($i==1)){
					$total=(float)$this->request->post['cuota1'];
				}else{
					$total=$saldo;
				}
				$result = array (
					"persona_id" => $this->request->post['persona_id'],
					"concepto_id" => $this->request->post['concepto_id'],
					"periodo" =>  $periodo,
					"anio" =>  $anio,
					"cantidad" => $this->request->post['cantidad'],
					"total" => $total,
					"cuota" => $i,
					"recibo" => 0,
					"date_debit"  => date("Y-m-d",strtotime( $debit)),
					"date_vto" => date("Y-m-d",strtotime( $vto))
				);
				
				$this->model_erp_estadocuenta->addEstadocuenta($result);
				
				$periodo=$periodo+1;
				if ($periodo==13){
					$periodo=1;
					$anio++;
				}
				$debit=$anio."-".$periodo."-".date("d",strtotime( $debit));
				/*
				echo "<pre>";
				print_r($result);
				echo "</pre>";
				*/
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('erp/estadocuenta');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/estadocuenta');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_erp_estadocuenta->editEstadocuenta($this->request->get['estadocuenta_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		}
		$this->getForm();
	}
	
	public function delete() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$this->load->language('erp/estadocuenta');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/estadocuenta');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $estadocuenta_id) {
				$this->model_erp_estadocuenta->deleteEstadocuenta($estadocuenta_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		}
		$this->getList();
	}
	
	protected function getList() {
		
		$data['info_matricula']=array();
		$data['info_persona']=array();
		if (isset($this->request->get['filter_matricula_id'])) {
			$filter_matricula_id = $this->request->get['filter_matricula_id'];
			$data['info_matricula']=array();
			$data['info_matricula']=$this->info_matricula($this->request->get['filter_matricula_id']);
		} else {
			$filter_matricula_id = '';
		}		

		if (isset($this->request->get['filter_persona_id'])) {
			$filter_persona_id = $this->request->get['filter_persona_id'];
		} else {
			$filter_persona_id = '0';
		}
		if (isset($this->request->get['filter_recibo'])) {
			$filter_recibo = $this->request->get['filter_recibo'];
		} else {
			$filter_recibo = '0';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'persona';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true)
		);

		$data['add'] = $this->url->link('erp/estadocuenta/add', 'user_token=' . $this->session->data['user_token'] . $url['url1']."&matricula_id=". $filter_matricula_id, true);
		$data['delete'] = $this->url->link('erp/estadocuenta/delete', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true);

		$data['estadocuentas'] = array();

		if (empty($filter_matricula_id) and empty($filter_persona_id)){
			$estadocuenta_total=0;
		}else{
//DEVEGADOS
			$filter_data = array(
				'filter_matricula_id'      => $filter_matricula_id,
				'filter_persona_id'        => $filter_persona_id,
				'filter_recibo'            => $filter_recibo,
				'filter_status'            => $filter_status,
				'sort'                     => $sort,
				'order'                    => $order,
				'start'                    => ($page - 1) * $limit,
				'limit'                    => $limit
			);
			$estadocuenta_total = $this->model_erp_estadocuenta->getTotalEstadocuentas($filter_data);
			$this->load->model('user/user');
			
			$acum=0;
			$results = $this->model_erp_estadocuenta->getEstadocuentas($filter_data);
			foreach ($results as $result) {
				$user_id_added=$this->model_user_user->getUser($result['user_id_added']);

				$user_id_added=$user_id_added['username'];
				if ($result['user_id_modified']!=0){
					$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
					$user_id_modified=$user_id_modified['username'];
				}else{
					$user_id_modified="";
				}
				if ($result['user_id_delete']!=0){
					$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
					$user_id_delete=$user_id_delete['username'];
				}else{
					$user_id_delete="";
				}

				$acum=$acum+$result['total'];

				if (!$result['recibo']){
					$edit=$this->url->link('erp/estadocuenta/edit', 'user_token=' . $this->session->data['user_token'] . '&estadocuenta_id=' . $result['estadocuenta_id'] . $url['url1']."&matricula_id=".$result['matricula_id'], true);
				}else{
					$edit="";
				}
				$data['estadocuentas'][] = array(
					'estadocuenta_id'    		=> $result['estadocuenta_id'],
					'concepto'           => $result['concepto'],
					'matricula_id'           => $result['matricula_id'],
					'persona'           => $result['persona'],
					'persona_id'           => $result['persona_id'],
					'pautogestion_id'           => $result['pautogestion_id'],
					'total'           => $result['total'],
					'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
					  "concepto_id" => $result['concepto_id'],
					  "periodo" => $result['periodo'],
					  "anio"  => $result['anio'],
					  "total"  => $result['total'],
					  "acum"  => $acum,
					  "cuota"  => $result['cuota'],
					  "cantidad"  => $result['cantidad'],
					  "recibo"  => $result['recibo'],
					  "debit" => $result['debit'],
					  "bancor " => $result['bancor'],
					  "circulo"  => $result['circulo'],
					'date_added'     	=> date('d-m-Y', strtotime($result['date_added'])),
					'date_vto'     => $result['date_vto']==""?"":date('d-m-Y', strtotime($result['date_vto'])),
					'date_debit'     	=> $result['date_debit']==""?"":date('d-m-Y', strtotime($result['date_debit'])),
					'user_id_added'		=> $user_id_added,
					'user_id_modified'	=> $user_id_modified,
					'user_id_delete'	=> $user_id_delete,
					'edit'           	=> $edit
				);
			}
		}
		
		
//AGENDADOS
		$data['persona_conceptos'] = array();
		$filter_data = array(
			'filter_persona_id'        => $filter_persona_id,
			'filter_status'            => "",
		);
		$results = $this->model_erp_estadocuenta->getPersona_conceptos($filter_data);
		foreach ($results as $result) {
			$data['persona_conceptos'][] = array(
					'persona_concepto_id' => $result['persona_concepto_id'],
					'concepto_id'    	=> $result['concepto_id'],
					'concepto'          => $result['concepto'],
					'date_added'        => $result['date_added'],
					'date_debit'        => $result['date_debit'],
					'baja'           	=> $result['baja'],
					'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled'))
			);
		}
//FIN AGENDADOS

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get);
		
		$data['sort_id_estadocuenta'] = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . '&sort=id_estadocuenta' . $url['url2'], true);
		$data['sort_apellido'] = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . '&sort=apellido' . $url['url2'], true);
		$data['sort_status'] = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url['url2'], true);
		$data['sort_date_added'] = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url['url2'], true);

		$pagination = new Pagination();
		$pagination->total = $estadocuenta_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url3'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($estadocuenta_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($estadocuenta_total -  $limit)) ? $estadocuenta_total : ((($page - 1) *  $limit) +  $limit), $estadocuenta_total, ceil($estadocuenta_total /  $limit));

		$data['filter_persona_id'] = $filter_persona_id;
		$data['filter_matricula_id'] = $filter_matricula_id;
		$data['filter_recibo'] = $filter_recibo;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/estadocuenta_list', $data));
	}

	public function info_matricula($filter_matricula_id){
		$info_matricula=array();
		$this->load->model('erp/matricula');
		$resul=$this->model_erp_matricula->getMatricula($filter_matricula_id);
		if ($resul){ 
			$info_matricula=array(
				'matricula_id' => $resul['matricula_id'],
				'persona_id'=> 	$resul['persona_id'],
				'categoria_id' => $resul['categoria_id'],
				'ncategoria' => $resul['ncategoria'],
				'dcategoria' => $resul['dcategoria'],
				'motivo_id'=> 	$resul['motivo_id'],
				'fecha_act' => date("d-m-Y",strtotime($resul['fecha_act'])),
				'fecha_def' =>	$resul['fecha_def']?date("d-m-Y",strtotime($resul['fecha_def'])):"",
				'fecha_mat' => date("d-m-Y",strtotime($resul['fecha_mat'])),
				'fecha_vto' => $resul['fecha_vto'],
				'fecha_vto_cat' => $resul['fecha_vto_cat'],
				'titulooriginal' => $resul['titulooriginal'],
				'titulocopia' => $resul['titulocopia'] ,
				'documento' =>  $resul['documento'] ,
				'foto' =>  $resul['foto'] ,
				'trabaja' => $resul['trabaja'] ,
				'tituloprovisorio' => $resul['tituloprovisorio'] ,
				'fecha_nvo' => $resul['fecha_nvo'],
				'status' => $resul['status'],
				'persona' => $resul['persona'],

				'tipodoc_id' =>  $resul['tipodoc_id'],
				'doc' => $resul['doc'],
				'cuit' => $resul['cuit'],
				'resolmuni' => $resul['resolmuni'],
				'cuil' => $resul['cuil'],
				'nacionalidad_id' =>$resul['nacionalidad_id'],
				'sexo_id' => $resul['sexo_id'],
				'ecivil_id' => $resul['ecivil_id'],
				'fecha_nac' => $resul['fecha_nac'],
				'localidad_nac_id' => $resul['localidad_nac_id'],
				'domicilio' => $resul['domicilio'],
				'dpto' => $resul['dpto'],
				'piso' => $resul['piso'],
				'barrio' => $resul['barrio'],
				'cp' => $resul['cp'],
				'localidad_id' =>  $resul['localidad_id'],
				'prefijo' =>  $resul['prefijo'],
				'telefono' =>  $resul['telefono'],
				'mprefijo' => $resul['mprefijo'],
				'mtelefono' =>  $resul['mtelefono'],
				'correo' =>  $resul['correo'],
				'comentario' => $resul['comentario'],
				'cuenta_id' => $resul['cuenta_id'],
				'nlocalidad' => $resul['nlocalidad'],
				'nprovincia' => $resul['nprovincia'],
				'localidadnac' => $resul['localidadnac'],
				'provincianac' => $resul['provincianac'],
				'nnacionalidad' => $resul['nnacionalidad'],
				'nsexo' => $resul['nsexo'],
				'ntipodoc' => $resul['ntipodoc'],
				'necivil' => $resul['necivil']
			);
		}
		return $info_matricula;
	}
	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['estadocuenta_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['user_token'] = $this->session->data['user_token'];
		$data['info_matricula']=array();
		if (!isset($this->request->get['matricula_id']) and !isset($this->request->get['persona_id'])) {
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true));
		}else{
			if (isset($this->request->get['matricula_id'])) {
				$data['info_matricula']=$this->info_matricula($this->request->get['matricula_id']);
				$data['persona_id']=$data['info_matricula']['persona_id'];
			}elseif(isset($this->request->get['persona_id'])) { 		
				$data['persona_id']=$this->request->get['persona_id'];
			}
			$this->load->model('erp/persona');
			$data['info_persona'] = $this->model_erp_persona->getPersona($data['persona_id']);		
		
		

			//DEFINE SI ES ADD O EDIT
			if (isset($this->request->get['estadocuenta_id'])) {
				$data['estadocuenta_id'] = $this->request->get['estadocuenta_id'];
			} else {
				$data['estadocuenta_id'] = 0;
			}
			//ERRORES
			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->error['apellido'])) {
				$data['error_apellido'] = $this->error['apellido'];
			} else {
				$data['error_apellido'] = '';
			}

			if (isset($this->error['nombre'])) {
				$data['error_nombre'] = $this->error['nombre'];
			} else {
				$data['error_nombre'] = '';
			}		

			$url = $this->filtrar($this->request->get);
			$data['breadcrumbs'] = array();
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true)
			);

			if (!isset($this->request->get['estadocuenta_id'])) {
				$data['action'] = $this->url->link('erp/estadocuenta/add', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true);
			} else {
				$data['action'] = $this->url->link('erp/estadocuenta/edit', 'user_token=' . $this->session->data['user_token'] . '&estadocuenta_id=' . $this->request->get['estadocuenta_id'] . $url['url1'], true);
			}

			$data['cancel'] = $this->url->link('erp/estadocuenta', 'user_token=' . $this->session->data['user_token'] . $url['url1'], true);

			if (isset($this->request->get['estadocuenta_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
				$estadocuenta_info = $this->model_erp_estadocuenta->getEstadocuenta($this->request->get['estadocuenta_id']);
			}		



			if (isset($this->request->post['concepto_id'])) {
				$data['concepto_id'] = $this->request->post['concepto_id'];
			} elseif (!empty($estadocuenta_info)) {
				$data['concepto_id'] = $estadocuenta_info['concepto_id'];
			} else {
				$data['concepto_id'] = '';
			}

			if (isset($this->request->post['date_added'])) {
				$data['date_added'] = $this->request->post['date_added'];
			} elseif (!empty($estadocuenta_info)) {
				$data['date_added'] = $estadocuenta_info['date_added'];
			} else {
				$data['date_added'] = date("d-m-Y");
			}
			if (isset($this->request->post['date_debit'])) {
				$data['date_debit'] = $this->request->post['date_debit'];
			} elseif (!empty($estadocuenta_info)) {
				$data['date_debit'] = $estadocuenta_info['date_debit'];
			} else {
				$data['date_debit'] = date("d-m-Y");
			}		
			if (isset($this->request->post['date_vto'])) {
				$data['date_vto'] = $this->request->post['date_vto'];
			} elseif (!empty($estadocuenta_info)) {
				$data['date_vto'] = $estadocuenta_info['date_vto'];
			} else {
				$data['date_vto'] = date("d-m-Y");
			}	

			if (isset($this->request->post['cantidad'])) {
				$data['cantidad'] = $this->request->post['cantidad'];
			} elseif (!empty($estadocuenta_info)) {
				$data['cantidad'] = $estadocuenta_info['cantidad'];
			} else {
				$data['cantidad'] = '1';
			}
			if (isset($this->request->post['cuota'])) {
				$data['cuota'] = $this->request->post['cuota'];
			} elseif (!empty($estadocuenta_info)) {
				$data['cuota'] = $estadocuenta_info['cuota'];
			} else {
				$data['cuota'] = "1";
			}	
			$data['cuota1'] = "0";

			if (isset($this->request->post['periodo'])) {
				$data['periodo'] = $this->request->post['periodo'];
			} elseif (!empty($estadocuenta_info)) {
				$data['periodo'] = $estadocuenta_info['periodo'];
			} else {
				$data['periodo'] = date("m");
			}			

			if (isset($this->request->post['anio'])) {
				$data['anio'] = $this->request->post['anio'];
			} elseif (!empty($estadocuenta_info)) {
				$data['anio'] = $estadocuenta_info['anio'];
			} else {
				$data['anio'] = date("Y");
			}
			if (isset($this->request->post['total'])) {
				$data['total'] = $this->request->post['total'];
			} elseif (!empty($estadocuenta_info)) {
				$data['total'] = $estadocuenta_info['total'];
			} else {
				$data['total'] = '0';
			}
			if (isset($this->request->post['recibo'])) {
				$data['recibo'] = $this->request->post['recibo'];
			} elseif (!empty($estadocuenta_info)) {
				$data['recibo'] = $estadocuenta_info['recibo'];
			} else {
				$data['recibo'] = '';
			}

			if (isset($this->request->post['debit'])) {
				$data['debit'] = $this->request->post['debit'];
			} elseif (!empty($estadocuenta_info)) {
				$data['debit'] = $estadocuenta_info['debit'];
			} else {
				$data['debit'] = '1';
			}		
			$data['debits']=array(
				array("descrip" => "debito","value" => 1),
				array("descrip" => "TN","value" => 2),
				array("descrip" => "Bancor","value" => 3),
				array("descrip" => "Circulo","value" => 4));

			$data['periodos']=array(
				array("descrip" => "ENE","value" => 1),
				array("descrip" => "FEB","value" => 2),
				array("descrip" => "MAR","value" => 3),
				array("descrip" => "ABR","value" => 4),
				array("descrip" => "MAY","value" => 5),
				array("descrip" => "JUN","value" => 6),
				array("descrip" => "JUN","value" => 7),
				array("descrip" => "AGO","value" => 8),
				array("descrip" => "SEP","value" => 9),
				array("descrip" => "OCT","value" => 10),
				array("descrip" => "NOV","value" => 11),
				array("descrip" => "DIC","value" => 12));

			$anio=date("Y");
			$data['anios']=array(
				array("descrip" => $anio-2,"value" => $anio-2),
				array("descrip" => $anio-1,"value" => $anio-1),
				array("descrip" => $anio,"value" => $anio),
				array("descrip" => $anio+1,"value" => $anio+1),
				array("descrip" => $anio+2,"value" => $anio+2),
				array("descrip" => $anio+3,"value" => $anio+3)
			);		

			$data['debits'][]=array(
				array("descrip" => "TN","value" => 2),
				array("descrip" => "Bancor","value" => 3),
				array("descrip" => "Circulo","value" => 4));

	/*		
			if (isset($this->request->post['bancor'])) {
				$data['bancor'] = $this->request->post['bancor'];
			} elseif (!empty($estadocuenta_info)) {
				$data['bancor'] = $estadocuenta_info['bancor'];
			} else {
				$data['bancor'] = '0';
			}

			if (isset($this->request->post['circulo'])) {
				$data['circulo'] = $this->request->post['circulo'];
			} elseif (!empty($estadocuenta_info)) {
				$data['circulo'] = $estadocuenta_info['circulo'];
			} else {
				$data['circulo'] = '0';
			}
			if (isset($this->request->post['tn'])) {
				$data['tn'] = $this->request->post['tn'];
			} elseif (!empty($estadocuenta_info)) {
				$data['tn'] = $estadocuenta_info['tn'];
			} else {
				$data['tn'] = '0';
			}
	*/		

			if (isset($this->request->post['date_modified'])) {
				$data['date_modified'] = $this->request->post['date_modified'];
			} elseif (!empty($estadocuenta_info)) {
				$data['date_modified'] = $estadocuenta_info['date_modified']==""?"":date("d-m-Y",strtotime($estadocuenta_info['date_modified']));
			} else {
				$data['date_modified'] = "";
			}
			if (isset($this->request->post['date_delete'])) {
				$data['date_delete'] = $this->request->post['date_delete'];
			} elseif (!empty($estadocuenta_info)) {
				$data['date_delete'] = $estadocuenta_info['date_delete']==""?"":date("d-m-Y",strtotime($estadocuenta_info['date_delete']));
			} else {
				$data['date_delete'] = "";
			}	

			if (isset($this->request->post['user_id_added'])) {
				$data['user_id_added'] = $this->request->post['user_id_added'];
			} elseif (!empty($estadocuenta_info)) {
				$data['user_id_added'] = $estadocuenta_info['user_id_added'];
			} else {
				$data['user_id_added'] = $this->user->getId();
			}		
			if (isset($this->request->post['user_id_modified'])) {
				$data['user_id_modified'] = $this->request->post['user_id_modified'];
			} elseif (!empty($estadocuenta_info)) {
				$data['user_id_modified'] = $estadocuenta_info['user_id_modified'];
			} else {
				$data['user_id_modified'] = "";
			}
			if (isset($this->request->post['user_id_delete'])) {
				$data['user_id_delete'] = $this->request->post['user_id_delete'];
			} elseif (!empty($estadocuenta_info)) {
				$data['user_id_delete'] = $estadocuenta_info['user_id_delete'];
			} else {
				$data['user_id_delete'] = "";
			}


			if (isset($this->request->post['status'])) {
				$data['status'] = $this->request->post['status'];
			} elseif (!empty($estadocuenta_info)) {
				$data['status'] = $estadocuenta_info['status'];
			} else {
				$data['status'] = true;
			}

			$this->load->model('ctb/concepto');
			$data['conceptos'] = $this->model_ctb_concepto->getConceptos(array());

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('erp/estadocuenta_form', $data));
		}
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/estadocuenta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->request->post['total']<=0) {
			$this->error['total'] = $this->language->get('error_total');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/estadocuenta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	
	
	public function autocomplete() {
		$json = array();
		$filter_nombre = '';
		if (isset($this->request->get['filter_nombre'])) {
			if (isset($this->request->get['filter_nombre'])) {
				$filter_nombre = $this->request->get['filter_nombre'];
			}
		}
		$this->load->model('erp/estadocuenta');
		$filter_data = array(
			'filter_nombre'      => $filter_nombre,
			'start'            => 0,
			'limit'            => 20
		);
		$results = $this->model_erp_estadocuenta->getEstadocuentas($filter_data);
		foreach ($results as $result) {
			$json[] = array(
				'estadocuenta_id'       => $result['estadocuenta_id'],
				'apellido'       => strip_tags(html_entity_decode($result['apellido'])),
				'nombre'       => strip_tags(html_entity_decode($result['nombre'])),
				'estadocuenta'       => strip_tags(html_entity_decode($result['descrip'])),
				'tipodoc_id'       => $result['tipodoc_id'],
				'doc'       => strip_tags(html_entity_decode($result['doc'])),
				'cuit'       => $result['cuit'],
				'resolmuni'       => $result['resolmuni'],
				'cuil'       => $result['cuil'],
				'nacionalidad_id'       => $result['nacionalidad_id'],
				'sexo_id'       => $result['sexo_id'],
				'ecivil_id'       => $result['ecivil_id'],
				'fecha_nac'       => date("d/m/Y",strtotime($result['fecha_nac'])),
				'localidad_nac_id'       => $result['localidad_nac_id'],
  				'domicilio'       => strip_tags(html_entity_decode($result['domicilio'])),
  				'dpto'       => strip_tags(html_entity_decode($result['dpto'])),
				'piso'       => strip_tags(html_entity_decode($result['piso'])),
  				'barrio'       => strip_tags(html_entity_decode($result['barrio'])),
  				'cp'       => strip_tags(html_entity_decode($result['cp'])),
				'localidad_id'       => $result['localidad_id'],
  				'prefijo'       => strip_tags(html_entity_decode($result['prefijo'])),
  				'telefono'       => strip_tags(html_entity_decode($result['telefono'])),
  				'mprefijo'       => strip_tags(html_entity_decode($result['mprefijo'])),
  				'mtelefono'       => strip_tags(html_entity_decode($result['mtelefono'])),
				'correo'       => strip_tags(html_entity_decode($result['correo']))
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['estadocuenta'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_nombre'])) {
			$filter_nombre = $this->request->get['filter_nombre'];
		} else {
			$filter_nombre = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'apellido';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['estadocuentas'] = array();
		$filter_data = array(
			'filter_nombre'            => $filter_nombre,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/estadocuenta');
		$results = $this->model_erp_estadocuenta->getEstadocuentas($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['estadocuenta_id'])
					->setCellValue('B'.$row,  $result['apellido'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/estadocuenta');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"apellido" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_estadocuenta->editEstadocuenta($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_estadocuenta->addEstadocuenta($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	
	
	
		
}