<?php
class ControllerErpPersona extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('erp/persona');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/persona');
		//CREA LA TABLA SI NO EXISTE
		//
		$this->model_erp_persona->creaPersona();
		//			
		$this->getList();
	}
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/persona');
		$this->load->model('erp/persona');
		if (isset($this->request->get['ini'])){
			$ini=$this->request->get['ini'];	
		}else{
			$ini=0;
		}
		$result=$this->model_erp_persona->traePersona($ini);
		if ($result['recorrido']!=0){
			$ini=$ini+500;
			$url=$this->url->link('erp/persona/sincro', 'user_token=' . $this->session->data['user_token'] . '&ini='.$ini."&recorrido=".$result['recorrido'],true);
			$this->response->redirect($url);
		}
		print_r($result);
		
	}
	
	public function reinicia(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->model('erp/persona');
		$this->model_erp_persona->bajaPersona();
		$this->model_erp_persona->creaPersona();
		
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.persona_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_persona_id'])) {
			$url .= '&filter_persona_id=' . $get['filter_persona_id'];
		}
		if (isset($get['filter_nombre'])) {
			$url .= '&filter_nombre=' . urlencode(html_entity_decode($get['filter_nombre'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}

	public function add() {
		

		//		
		$this->load->language('erp/persona');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/persona');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			 
			
			$this->model_erp_persona->addPersona($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('erp/persona');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/persona');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_erp_persona->editPersona($this->request->get['persona_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('erp/persona');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/persona');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $persona_id) {
				$this->model_erp_persona->deletePersona($persona_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		if (isset($this->request->get['filter_numero'])) {
			$filter_numero = $this->request->get['filter_numero'];
		} else {
			$filter_numero = '';
		}		

		if (isset($this->request->get['filter_nombre'])) {
			$filter_nombre = $this->request->get['filter_nombre'];
		} else {
			$filter_nombre = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'persona_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/persona/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('erp/persona/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['personas'] = array();

		$filter_data = array(
			'filter_numero'           => $filter_numero,
			'filter_nombre'           => $filter_nombre,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);

		$persona_total = $this->model_erp_persona->getTotalPersonas($filter_data);
		
		$data['persona_total'] = $persona_total;

		$this->load->model('user/user');
			
		
		
		$results = $this->model_erp_persona->getPersonas($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['personas'][] = array(
				'persona_id'    		=> $result['persona_id'],
				'autogestion_id'   => $result['autogestion_id'],
				'doc'           => $result['doc'],
				'numero'           => $result['numero']?$result['numero']:"",
				'nombre'           => $result['nombre'],
				'apellido'           => $result['apellido'],
				'domicilio'           => $result['domicilio'],
				'dpto'           => $result['dpto'],
				'piso'           => $result['piso'],
				'telefono'           => $result['telefono'],
				'prefijo'           => $result['prefijo'],
				'mtelefono'           => $result['mtelefono'],
				'mprefijo'           => $result['mprefijo'],
				'localidad'        	=> $result['localidad'],
				'correo'           => $result['correo'],
				'comentario'           => $result['comentario'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'     	=> date('d-m-Y', strtotime($result['date_added'])),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('erp/persona/edit', 'user_token=' . $this->session->data['user_token'] . '&persona_id=' . $result['persona_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		
		$data['sort_persona_id'] = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . '&sort=e.persona_id' . $url, true);
		$data['sort_apellido'] = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . '&sort=eapellido' . $url, true);
		$data['sort_status'] = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . '&sort=estatus' . $url, true);
		$data['sort_date_added'] = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);

		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $persona_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($persona_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($persona_total -  $limit)) ? $persona_total : ((($page - 1) *  $limit) +  $limit), $persona_total, ceil($persona_total /  $limit));

		$data['filter_numero'] = $filter_numero;
		$data['filter_nombre'] = $filter_nombre;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/persona_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['persona_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//DEFINE SI ES ADD O EDIT
		if (isset($this->request->get['persona_id'])) {
			$data['persona_id'] = $this->request->get['persona_id'];
		} else {
			$data['persona_id'] = 0;
		}
		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['apellido'])) {
			$data['error_apellido'] = $this->error['apellido'];
		} else {
			$data['error_apellido'] = '';
		}
		
		if (isset($this->error['nombre'])) {
			$data['error_nombre'] = $this->error['nombre'];
		} else {
			$data['error_nombre'] = '';
		}		

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['persona_id'])) {
			$data['action'] = $this->url->link('erp/persona/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('erp/persona/edit', 'user_token=' . $this->session->data['user_token'] . '&persona_id=' . $this->request->get['persona_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('erp/persona', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['persona_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$persona_info = $this->model_erp_persona->getPersona($this->request->get['persona_id']);
		}		
		
		
		 
		if (isset($this->request->post['apellido'])) {
			$data['apellido'] = $this->request->post['apellido'];
		} elseif (!empty($persona_info)) {
			$data['apellido'] = $persona_info['apellido'];
		} else {
			$data['apellido'] = '';
		}
		if (isset($this->request->post['nombre'])) {
			$data['nombre'] = $this->request->post['nombre'];
		} elseif (!empty($persona_info)) {
			$data['nombre'] = $persona_info['nombre'];
		} else {
			$data['nombre'] = '';
		}		
		if (isset($this->request->post['tipodoc_id'])) {
			$data['tipodoc_id'] = $this->request->post['tipodoc_id'];
		} elseif (!empty($persona_info)) {
			$data['tipodoc_id'] = $persona_info['tipodoc_id'];
		} else {
			$data['tipodoc_id'] = '';
		}
		if (isset($this->request->post['doc'])) {
			$data['doc'] = $this->request->post['doc'];
		} elseif (!empty($persona_info)) {
			$data['doc'] = $persona_info['doc'];
		} else {
			$data['doc'] = '';
		}
		if (isset($this->request->post['fecha_nac'])) {
			$data['fecha_nac'] = $this->request->post['fecha_nac'];
		} elseif (!empty($persona_info)) {
			$data['fecha_nac'] = date("d-m-Y",strtotime($persona_info['fecha_nac']));
		} else {
			$data['fecha_nac'] = "";
		}		
		if (isset($this->request->post['fecha_def'])) {
			$data['fecha_def'] = $this->request->post['fecha_def'];
		} elseif (!empty($persona_info)) {
			$data['fecha_def'] = date("d-m-Y",strtotime($persona_info['fecha_def']));
		} else {
			$data['fecha_def'] = "";
		}			
		
		if (isset($this->request->post['sexo_id'])) {
			$data['sexo_id'] = $this->request->post['sexo_id'];
		} elseif (!empty($persona_info)) {
			$data['sexo_id'] = $persona_info['sexo_id'];
		} else {
			$data['sexo_id'] = '';
		}
		if (isset($this->request->post['ecivil_id'])) {
			$data['ecivil_id'] = $this->request->post['ecivil_id'];
		} elseif (!empty($persona_info)) {
			$data['ecivil_id'] = $persona_info['ecivil_id'];
		} else {
			$data['ecivil_id'] = '';
		}
		if (isset($this->request->post['localidad_nac_id'])) {
			$data['localidad_nac_id'] = $this->request->post['localidad_nac_id'];
		} elseif (!empty($persona_info)) {
			$data['localidad_nac_id'] = $persona_info['localidad_nac_id'];
		} else {
			$data['localidad_nac_id'] = '';
		}
		if (isset($this->request->post['nacionalidad_id'])) {
			$data['nacionalidad_id'] = $this->request->post['nacionalidad_id'];
		} elseif (!empty($persona_info)) {
			$data['nacionalidad_id'] = $persona_info['nacionalidad_id'];
		} else {
			$data['nacionalidad_id'] = '';
		}
		
		if (isset($this->request->post['domicilio'])) {
			$data['domicilio'] = $this->request->post['domicilio'];
		} elseif (!empty($persona_info)) {
			$data['domicilio'] = $persona_info['domicilio'];
		} else {
			$data['domicilio'] = '';
		}
		if (isset($this->request->post['dpto'])) {
			$data['dpto'] = $this->request->post['dpto'];
		} elseif (!empty($persona_info)) {
			$data['dpto'] = $persona_info['dpto'];
		} else {
			$data['dpto'] = '';
		}
		if (isset($this->request->post['piso'])) {
			$data['piso'] = $this->request->post['piso'];
		} elseif (!empty($persona_info)) {
			$data['piso'] = $persona_info['piso'];
		} else {
			$data['piso'] = '';
		}		
		if (isset($this->request->post['barrio'])) {
			$data['barrio'] = $this->request->post['barrio'];
		} elseif (!empty($persona_info)) {
			$data['barrio'] = $persona_info['barrio'];
		} else {
			$data['barrio'] = '';
		}		
		if (isset($this->request->post['cp'])) {
			$data['cp'] = $this->request->post['cp'];
		} elseif (!empty($persona_info)) {
			$data['cp'] = $persona_info['cp'];
		} else {
			$data['cp'] = '';
		}
		if (isset($this->request->post['localidad_id'])) {
			$data['localidad_id'] = $this->request->post['localidad_id'];
		} elseif (!empty($persona_info)) {
			$data['localidad_id'] = $persona_info['localidad_id'];
		} else {
			$data['localidad_id'] = '';
		}
		if (isset($this->request->post['prefijo'])) {
			$data['prefijo'] = $this->request->post['prefijo'];
		} elseif (!empty($persona_info)) {
			$data['prefijo'] = $persona_info['prefijo'];
		} else {
			$data['prefijo'] = '';
		}
		if (isset($this->request->post['telefono'])) {
			$data['telefono'] = $this->request->post['telefono'];
		} elseif (!empty($persona_info)) {
			$data['telefono'] = $persona_info['telefono'];
		} else {
			$data['telefono'] = '';
		}		
		if (isset($this->request->post['mprefijo'])) {
			$data['mprefijo'] = $this->request->post['mprefijo'];
		} elseif (!empty($persona_info)) {
			$data['mprefijo'] = $persona_info['mprefijo'];
		} else {
			$data['mprefijo'] = '';
		}
		if (isset($this->request->post['mtelefono'])) {
			$data['mtelefono'] = $this->request->post['mtelefono'];
		} elseif (!empty($persona_info)) {
			$data['mtelefono'] = $persona_info['mtelefono'];
		} else {
			$data['mtelefono'] = '';
		}		
		if (isset($this->request->post['correo'])) {
			$data['correo'] = $this->request->post['correo'];
		} elseif (!empty($persona_info)) {
			$data['correo'] = $persona_info['correo'];
		} else {
			$data['correo'] = '';
		}				
		if (isset($this->request->post['comentario'])) {
			$data['comentario'] = $this->request->post['comentario'];
		} elseif (!empty($persona_info)) {
			$data['comentario'] = $persona_info['comentario'];
		} else {
			$data['comentario'] = '';
		}		
		
	
		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($persona_info)) {
			$data['date_added'] = date("d-m-Y",strtotime($persona_info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($persona_info)) {
			$data['date_modified'] = $persona_info['date_modified']==""?"":date("d-m-Y",strtotime($persona_info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($persona_info)) {
			$data['date_delete'] = $persona_info['date_delete']==""?"":date("d-m-Y",strtotime($persona_info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($persona_info)) {
			$data['user_id_added'] = $persona_info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($persona_info)) {
			$data['user_id_modified'] = $persona_info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($persona_info)) {
			$data['user_id_delete'] = $persona_info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($persona_info)) {
			$data['status'] = $persona_info['status'];
		} else {
			$data['status'] = true;
		}
		
		if (isset($this->request->post['cuenta_id'])) {
			$data['cuenta_id'] = $this->request->post['cuenta_id'];
		} elseif (!empty($persona_info)) {
			$data['cuenta_id'] = $persona_info['cuenta_id'];
		} else {
			$data['cuenta_id'] = true;
		}		
		
		$this->load->model('ctb/cuenta');
		$filter_data = array(
			'filter_imputable'	=> '1',
			'sort'                     => 'code',
			'order'                    => 'ASC',
			'start'                    => 1,
			'limit'                    => 100000
		);		
		$data['cuentas'] = $this->model_ctb_cuenta->getCuentas($filter_data);
		
		
		$this->load->model('erp/localidad');
		$data['localidads'] = $this->model_erp_localidad->getLocalidads(array());
		
		$this->load->model('erp/tipodoc');
		$data['tipodocs'] = $this->model_erp_tipodoc->getTipodocs(array());	
		
		$this->load->model('erp/nacionalidad');
		$data['nacionalidads'] = $this->model_erp_nacionalidad->getNacionalidads(array());
		
		$this->load->model('erp/ecivil');
		$data['ecivils'] = $this->model_erp_ecivil->getEcivils(array());		
		
		$this->load->model('erp/sexo');
		$data['sexos'] = $this->model_erp_sexo->getSexos(array());		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('erp/persona_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/persona')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['apellido']) < 1) || (utf8_strlen(trim($this->request->post['apellido'])) > 200)) {
			$this->error['apellido'] = $this->language->get('error_apellido');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/persona')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function getPersona() {
		$json = array();
		if (isset($this->request->get['persona_id'])) {
			$this->load->model('erp/persona');
			$json = $this->model_erp_persona->getPersona($this->request->get['persona_id']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	public function autocomplete() {
		$json = array();
		$filter_numero = $filter_nombre = '';
		if (isset($this->request->get['filter_nombre'])) {
			if (isset($this->request->get['filter_nombre'])) {
				if (is_numeric($this->request->get['filter_nombre'])){
					$filter_numero = $this->request->get['filter_nombre'];
				}else{
					$filter_nombre = $this->request->get['filter_nombre'];
				}
			}
		}
		$this->load->model('erp/persona');
		$filter_data = array(
			'filter_nombre'      => $filter_nombre,
			'filter_numero'  	=> $filter_numero,
			'start'            => 0,
			'limit'            => 20
		);
		$results = $this->model_erp_persona->getPersonas($filter_data);
		foreach ($results as $result) {
			$json[] = array(
				'persona_id'       => $result['persona_id'],
				'matricula_id'       => $result['matricula_id'],
				'apellido'       => strip_tags(html_entity_decode($result['apellido'])),
				'nombre'       => strip_tags(html_entity_decode($result['nombre'])),
				'persona'       => strip_tags(html_entity_decode($result['descrip'])),
				'tipodoc_id'       => $result['tipodoc_id'],
				'doc'       => strip_tags(html_entity_decode($result['doc'])),
				'cuit'       => $result['cuit'],
				'resolmuni'       => $result['resolmuni'],
				'cuil'       => $result['cuil'],
				'nacionalidad_id'       => $result['nacionalidad_id'],
				'sexo_id'       => $result['sexo_id'],
				'ecivil_id'       => $result['ecivil_id'],
				'fecha_nac'       => date("d/m/Y",strtotime($result['fecha_nac'])),
				'localidad_nac_id'       => $result['localidad_nac_id'],
  				'domicilio'       => strip_tags(html_entity_decode($result['domicilio'])),
  				'dpto'       => strip_tags(html_entity_decode($result['dpto'])),
				'piso'       => strip_tags(html_entity_decode($result['piso'])),
  				'barrio'       => strip_tags(html_entity_decode($result['barrio'])),
  				'cp'       => strip_tags(html_entity_decode($result['cp'])),
				'localidad_id'       => $result['localidad_id'],
  				'prefijo'       => strip_tags(html_entity_decode($result['prefijo'])),
  				'telefono'       => strip_tags(html_entity_decode($result['telefono'])),
  				'mprefijo'       => strip_tags(html_entity_decode($result['mprefijo'])),
  				'mtelefono'       => strip_tags(html_entity_decode($result['mtelefono'])),
				'correo'       => strip_tags(html_entity_decode($result['correo']))
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['persona'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_nombre'])) {
			$filter_nombre = $this->request->get['filter_nombre'];
		} else {
			$filter_nombre = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'apellido';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['personas'] = array();
		$filter_data = array(
			'filter_nombre'            => $filter_nombre,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/persona');
		$results = $this->model_erp_persona->getPersonas($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['persona_id'])
					->setCellValue('B'.$row,  $result['apellido'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/persona');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"apellido" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_persona->editPersona($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_persona->addPersona($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	
	
	
		
}