<?php
class ControllerErpMesaentrada extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('erp/mesaentrada');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/mesaentrada');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_erp_mesaentrada->bajaMesaentrada();
		$this->model_erp_mesaentrada->creaMesaentrada();
		//			
		$this->getList();
	}
	public function filtrar($get){
		$url = '';
		if (isset($get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_program'])) {
			$url .= '&filter_program=' . urlencode(html_entity_decode($get['filter_program'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}

		if (isset($get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $get['filter_date_added'];
		}

		if (isset($get['sort'])) {
			$url .= '&sort=' . $get['sort'];
		}

		if (isset($get['order'])) {
			$url .= '&order=' . $get['order'];
		}

		if (isset($get['page'])) {
			$url .= '&page=' . $get['page'];
		}
		
		if (isset($get['limit'])) {
			$url .= '&limit=' . $get['limit'];
		}else{
			$url .= '&limit=' . $this->config->get('config_limit_admin');
		}		
		
		return $url;
	}

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/mesaentrada');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/mesaentrada');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_erp_mesaentrada->addMesaentrada($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('erp/mesaentrada');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/mesaentrada');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_erp_mesaentrada->editMesaentrada($this->request->get['mesaentrada_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('erp/mesaentrada');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/mesaentrada');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $mesaentrada_id) {
				$this->model_erp_mesaentrada->deleteMesaentrada($mesaentrada_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		if (isset($this->request->get['filter_program'])) {
			$filter_program = $this->request->get['filter_program'];
		} else {
			$filter_program = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = date("d-m-Y",strtotime($this->request->get['filter_date_init']));
		} else {
			$filter_date_init = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/mesaentrada/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('erp/mesaentrada/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->load->model('admdirsis/codiva');
		
		$this->load->model('setting/store');

		$stores = $this->model_setting_store->getStores();
		
		$data['mesaentradas'] = array();

		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_program'           => $filter_program,
			'filter_status'            => $filter_status,
			'filter_date_init'        	=> $filter_date_init,
			'filter_date_fin'        	=> $filter_date_fin,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);

		$mesaentrada_total = $this->model_erp_mesaentrada->getTotalMesaentradas($filter_data);

		$this->load->model('user/user');
			
		
		
		$results = $this->model_erp_mesaentrada->getMesaentradas($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['mesaentradas'][] = array(
				'mesaentrada_id'    => $result['mesaentrada_id'],
				'name'           	=> $result['name'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'     	=> date('d-m-Y H:i', strtotime($result['date_added'])),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('erp/mesaentrada/edit', 'user_token=' . $this->session->data['user_token'] . '&mesaentrada_id=' . $result['mesaentrada_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get);
		$data['sort_id_mesaentrada'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . '&sort=id_mesaentrada' . $url, true);
		$data['sort_program'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . '&sort=program' . $url, true);
		$data['sort_name'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_status'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
		$data['sort_date_added'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);

		$pagination = new Pagination();
		$pagination->total = $mesaentrada_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($mesaentrada_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($mesaentrada_total -  $limit)) ? $mesaentrada_total : ((($page - 1) *  $limit) +  $limit), $mesaentrada_total, ceil($mesaentrada_total /  $limit));

		$data['filter_name'] = $filter_name;
		$data['filter_status'] = $filter_status;
		$data['filter_date_init'] = $filter_date_init;
		$data['filter_date_fin'] = $filter_date_fin;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/mesaentrada_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['mesaentrada_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//DEFINE SI ES ADD O EDIT
		if (isset($this->request->get['mesaentrada_id'])) {
			$data['mesaentrada_id'] = $this->request->get['mesaentrada_id'];
		} else {
			$data['mesaentrada_id'] = 0;
		}
		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['program'])) {
			$data['error_program'] = $this->error['program'];
		} else {
			$data['error_program'] = '';
		}

		$url = $this->filtrar($this->request->get);
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['mesaentrada_id'])) {
			$data['action'] = $this->url->link('erp/mesaentrada/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('erp/mesaentrada/edit', 'user_token=' . $this->session->data['user_token'] . '&mesaentrada_id=' . $this->request->get['mesaentrada_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('erp/mesaentrada', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['mesaentrada_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$mesaentrada_info = $this->model_erp_mesaentrada->getMesaentrada($this->request->get['mesaentrada_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($mesaentrada_info)) {
			$data['name'] = $mesaentrada_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['program'])) {
			$data['program'] = $this->request->post['program'];
		} elseif (!empty($mesaentrada_info)) {
			$data['program'] = $mesaentrada_info['program'];
		} else {
			$data['program'] = '';
		}		
		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($mesaentrada_info)) {
			$data['date_added'] = date("d-m-Y",strtotime($mesaentrada_info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($mesaentrada_info)) {
			$data['date_modified'] = $mesaentrada_info['date_modified']==""?"":date("d-m-Y",strtotime($mesaentrada_info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($mesaentrada_info)) {
			$data['date_delete'] = $mesaentrada_info['date_delete']==""?"":date("d-m-Y",strtotime($mesaentrada_info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($mesaentrada_info)) {
			$data['user_id_added'] = $mesaentrada_info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($mesaentrada_info)) {
			$data['user_id_modified'] = $mesaentrada_info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($mesaentrada_info)) {
			$data['user_id_delete'] = $mesaentrada_info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($mesaentrada_info)) {
			$data['status'] = $mesaentrada_info['status'];
		} else {
			$data['status'] = true;
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('erp/mesaentrada_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/mesaentrada')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['program']) < 1) || (utf8_strlen(trim($this->request->post['program'])) > 200)) {
			$this->error['program'] = $this->language->get('error_program');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/mesaentrada')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	public function autocomplete() {
		

		
		$json = array();

		if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_email'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			
			if (isset($this->request->get['filter_email'])) {
				$filter_email = $this->request->get['filter_email'];
			} else {
				$filter_email = '';
			}
			
			if (isset($this->request->get['filter_affiliate'])) {
				$filter_affiliate = $this->request->get['filter_affiliate'];
			} else {
				$filter_affiliate = '';
			}
			
			$this->load->model('erp/mesaentrada');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'start'            => 0,
				'limit'            => 20
			);

			foreach ($results as $result) {
				$json[] = array(
					'mesaentrada_id'       => $result['mesaentrada_id'],
					'name'              => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'date_added'		=> $result['date_added'],
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_program'])) {
			$filter_program = $this->request->get['filter_program'];
		} else {
			$filter_program = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['mesaentradas'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_program'              => $filter_program,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/mesaentrada');
		$results = $this->model_erp_mesaentrada->getMesaentradas($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['mesaentrada_id'])
					->setCellValue('B'.$row,  $result['name'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/mesaentrada');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"name" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_mesaentrada->editMesaentrada($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_mesaentrada->addMesaentrada($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	
	
	
		
}