<?php
class ControllerErpRecibo extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('erp/recibo');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/recibo');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_erp_recibo->bajaRecibo();
		$this->model_erp_recibo->creaRecibo();
		
		//			
		$this->getList();
	}
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/recibo');
		$this->load->model('erp/recibo');
		
		$this->model_erp_recibo->traeRecibo();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
	}
	
	public function reinicia(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/recibo');
		$this->load->model('erp/recibo');
		
		$this->model_erp_recibo->bajaRecibo();
		$this->model_erp_recibo->creaRecibo();
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
	}	
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.recibo_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_cajaapertura_id'])) {
			$url .= '&filter_cajaapertura_id=' . $get['filter_cajaapertura_id'];
		}
		if (isset($get['filter_matricula_id'])) {
			$url .= '&filter_matricula_id=' . $get['filter_matricula_id'];
		}		
		if (isset($get['filter_numero'])) {
			$url .= '&filter_numero=' . $get['filter_numero'];
		}		
		if (isset($get['filter_recibo_id'])) {
			$url .= '&filter_recibo_id=' . $get['filter_recibo_id'];
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/recibo');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/recibo');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			
			//echo "<pre>";
			//print_r($this->request->post);
			//echo "</pre>";
			
			//die;
			
			$this->model_erp_recibo->addRecibo($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('erp/recibo');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/recibo');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			$this->model_erp_recibo->editRecibo($this->request->get['recibo_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('erp/recibo');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/recibo');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $recibo_id) {
				$this->model_erp_recibo->deleteRecibo($recibo_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_cajaapertura_id'])) {
			$filter_cajaapertura_id = $this->request->get['filter_cajaapertura_id'];
		} else {
			$filter_cajaapertura_id = '';
		}
		if (isset($this->request->get['filter_recibo_id'])) {
			$filter_recibo_id = $this->request->get['filter_recibo_id'];
		} else {
			$filter_recibo_id = '';
		}
		if (isset($this->request->get['filter_matricula_id'])) {
			$filter_matricula_id = $this->request->get['filter_matricula_id'];
		} else {
			$filter_matricula_id = '';
		}
		if (isset($this->request->get['filter_numero'])) {
			$filter_numero = $this->request->get['filter_numero'];
		} else {
			$filter_numero = '';
		}
	
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.recibo_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/recibo/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('erp/recibo/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->load->model('admdirsis/codiva');
		
		$this->load->model('setting/store');

		$stores = $this->model_setting_store->getStores();
		
		$data['recibos'] = array();

		$filter_data = array(
			'filter_cajaapertura_id'           => $filter_cajaapertura_id,
			'filter_recibo_id'   	=> $filter_recibo_id,
			'filter_matricula_id'   	=> $filter_matricula_id,
			'filter_numero'   		=> $filter_numero,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);

		$recibo_total = $this->model_erp_recibo->getTotalRecibos($filter_data);

		$this->load->model('user/user');
			
		
		
		$results = $this->model_erp_recibo->getRecibos($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['recibos'][] = array(
				'recibo_id'    		=> $result['recibo_id'],
				'cajaapertura_id'    => $result['cajaapertura_id'],
				'tipocompr_id'    		=> $result['tipocompr_id'],
				'tipocompr'    		=> $result['tipocompr'],
				'coef'    		=> $result['coef'],
				'afip'    		=> $result['afip'],
				'persona_id'    		=> $result['persona_id'],
				'matricula_id'    		=> $result['matricula_id'],
				'persona'    		=> $result['persona'],
				'punto'           => $result['punto'],
				'numero'           => $result['numero'],
				'cae'           => $result['cae'],
				'total'           => $result['total']*$result['coef'],
				'date_added'           => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'date_cae'           => $result['date_cae']?date('d-m-Y', strtotime($result['date_cae'])):"",
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'tipodoc_id'    	=> $result['tipodoc_id'],
				'indice'    		=> $result['indice'],
				'chequeado'    		=> $result['chequeado'],
				'date_auto'    		=> $result['date_auto']!="0000-00-00 00:00:00"?date('d-m-Y', strtotime($result['date_auto'])):"",
				'date_modified'     => $result['date_modified']!="0000-00-00 00:00:00"?date('d-m-Y', strtotime($result['date_modified'])):"",
				'date_delete'     	=> $result['date_delete']!="0000-00-00 00:00:00"?date('d-m-Y', strtotime($result['date_delete'])):"",
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('erp/recibo/edit', 'user_token=' . $this->session->data['user_token'] . '&recibo_id=' . $result['recibo_id'] . $url, true),
				'printpdf'           	=> $this->url->link('erp/recibo/printpdf', 'user_token=' . $this->session->data['user_token'] . '&recibo_id=' . $result['recibo_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_recibo_id'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.recibo_id' . $url, true);
		
		$data['sort_cajaapertura_id'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.cajaapertura_id' . $url, true);
$data['sort_matricula_id'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.matricula_id' . $url, true);		
		$data['sort_user_id'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.user_id' . $url, true);
		$data['sort_date_open'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.date_open' . $url, true);
		$data['sort_date_close'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.date_close' . $url, true);
		$data['sort_falla'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.falla' . $url, true);
		$data['sort_punto'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.punto' . $url, true);		
		$data['sort_date_audit'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . '&sort=c.date_audit' . $url, true);
		
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $recibo_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($recibo_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($recibo_total -  $limit)) ? $recibo_total : ((($page - 1) *  $limit) +  $limit), $recibo_total, ceil($recibo_total /  $limit));

		$data['filter_cajaapertura_id'] = $filter_cajaapertura_id;
		
		$data['filter_numero'] = $filter_numero;
		$data['filter_matricula_id'] = $filter_matricula_id;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		
		$this->load->model('erp/cajaapertura');
		$caja=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		if (isset($caja['cajaapertura_id'])){
			$data['cajaapertura']="CAJA ABIERTA: N°:".$caja['cajaapertura_id'];
			$data['cajaapertura_id']=$caja['cajaapertura_id'];
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/recibo_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['recibo_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['punto'])) {
			$data['error_punto'] = $this->error['punto'];
		} else {
			$data['error_punto'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['recibo_id'])) {
			$data['action'] = $this->url->link('erp/recibo/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('erp/recibo/edit', 'user_token=' . $this->session->data['user_token'] . '&recibo_id=' . $this->request->get['recibo_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('erp/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['recibo_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_erp_recibo->getRecibo($this->request->get['recibo_id']);
		}

		
		$results=array(
			array("field" => "recibo_id", "type" => "n","default" => '0'),
			array("field" => "cajaapertura_id", "type" => "n","default" => '0'),
			array("field" => "tipocompr_id", "type" => "n","default" => '1'),
			array("field" => "persona_id", "type" => "n"),
			array("field" => "persona", "type" => "c"),
			array("field" => "total", "type" => "n","default" => '0'),
			array("field" => "tipodoc_id", "type" => "n","default" => '1'),
			array("field" => "date_added", "type" => "d","default" => date("d-m-Y")),
			array("field" => "status", "type" => "n","default" => '1'),
			array("field" => "punto", "type" => "n"),
			array("field" => "indice", "type" => "n"),
			array("field" => "chequeado", "type" => "n"),
			array("field" => "date_auto", "type" => "d","default" => ''),
			array("field" => "date_cae", "type" => "d","default" => ''),
			array("field" => "cae", "type" => "c"),
			array("field" => "numero", "type" => "n"),
			array("field" => "date_modified", "type" => "d","default" => ''),
			array("field" => "date_delete", "type" => "d","default" => ''),
			array("field" => "user_id_added", "type" => "n"),
			array("field" => "user_id_delete", "type" => "n")
		);
		foreach ($results as $result) {
			if (isset($this->request->post[$result['field']])) {
				$data[$result['field']] = $this->request->post[$result['field']];
			} elseif (!empty($info)) {
				$data[$result['field']] = $info[$result['field']];
			} else {
				if (isset($result['default'])){
					$data[$result['field']] = $result['default'];
				}else{
					$data[$result['field']] = '';
				}
			}				
			if ($result['type']=='d'){
				if ($data[$result['field']]!='0000-00-00 00:00:00' and $data[$result['field']]!=''){
					$data[$result['field']]=date("d-m-Y",strtotime($data[$result['field']]));
				}else{
					$data[$result['field']]="";
				}
			}
		}
		
		$this->load->model('erp/cajaapertura');
		
		
		//if ($data['recibo_id']=='0') {
		$cajaapertura=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		
 
		$data['error_caja'] = $this->language->get('error_caja');
		if (isset($cajaapertura['cajaapertura_id'])){
				$data['cajaapertura_id'] = $cajaapertura['cajaapertura_id'];
				$data['punto'] = $cajaapertura['punto'];
		}
		
	
		$this->load->model('erp/tipodoc');
		$data['tipodocs'] = $this->model_erp_tipodoc->getTipodocs(array());
		
		$this->load->model('erp/tipocompr');
		$data['tipocomprs'] = $this->model_erp_tipocompr->getTipocomprs(array());
		
		$data['recibo_items'] = array();
		$data['recibo_pagos'] = array();
		if ($data['recibo_id']!=0){
			$this->load->model('erp/recibo');
			$data['recibo_items'] = $this->model_erp_recibo->getRecibo_items($data['recibo_id']);
			$data['recibo_pagos'] = $this->model_erp_recibo->getRecibo_pagos($data['recibo_id']);
		}
		
		
			$data['periodos']=array(
				array("descrip" => "ENE","value" => 1),
				array("descrip" => "FEB","value" => 2),
				array("descrip" => "MAR","value" => 3),
				array("descrip" => "ABR","value" => 4),
				array("descrip" => "MAY","value" => 5),
				array("descrip" => "JUN","value" => 6),
				array("descrip" => "JUN","value" => 7),
				array("descrip" => "AGO","value" => 8),
				array("descrip" => "SEP","value" => 9),
				array("descrip" => "OCT","value" => 10),
				array("descrip" => "NOV","value" => 11),
				array("descrip" => "DIC","value" => 12));

			$anio=date("Y");
			$data['anios']=array(
				array("descrip" => $anio-2,"value" => $anio-2),
				array("descrip" => $anio-1,"value" => $anio-1),
				array("descrip" => $anio,"value" => $anio),
				array("descrip" => $anio+1,"value" => $anio+1),
				array("descrip" => $anio+2,"value" => $anio+2),
				array("descrip" => $anio+3,"value" => $anio+3)
			);	
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('erp/recibo_form', $data));
	}
	
	public function conceptosapagar() {
		$recibo_id=0;
		$this->load->model('erp/cajaapertura');
		$cajaapertura=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		if (isset($cajaapertura['cajaapertura_id'])){
			
				//DATOS DEL CLIENTES				
				$matricula_id = $this->request->post['matricula_id'];
				$this->load->model('erp/matricula');
				$matricula=$this->model_erp_matricula->getMatricula($matricula_id);
				$persona_id=$matricula['persona_id'];
				$persona=$matricula['persona'];			
				$tipodoc_id=15;
				$sql=array("cajaapertura_id" => $cajaapertura['cajaapertura_id'],
						  "persona_id" => $matricula['persona_id'],
						  "tipodoc_id" => $tipodoc_id,
						  "date_added" => date("Y-m-d"),
						  "status" => 1,
						  "punto" => $cajaapertura['punto']
				);
			
				$this->load->model('erp/recibo');
				$recibo_id=$this->model_erp_recibo->addRecibo($sql);
				if ($recibo_id){
					//CONCEPTOS SELECCIONADOS
					$total=0;
					if (isset($this->request->post['selected'])) {
						$this->load->model('erp/conceptoacobrar');
						foreach ($this->request->post['selected'] as $conceptoacobrar_id) {
							$filter_data = array('filter_conceptodevengado_id' => $conceptoacobrar_id);
							$results = $this->model_erp_conceptoacobrar->getConceptoacobrars($filter_data);
							$data=array(
								"conceptodevengado_id" => $results[0]['conceptodevengado_id'],
								"concepto_id" => $results[0]['concepto_id'],
								"recibo_id" => $recibo_id,
								"cantidad" => $results[0]['cantidad'],
								"periodo" => $results[0]['periodo'],
								"anio" => $results[0]['anio'],
								"cuota" => $results[0]['cuota'],
								"total" => $results[0]['total']
							);
							$this->model_erp_recibo->addRecibo_item($data);
							$total=$total+$results[0]['total'];
						}
					}
					//MODO DE PAGO
					$data=array("formadepago_id" => $matricula['formadepago_id'],
								"recibo_id" => $recibo_id,
								"total" => $total
					);
					$this->model_erp_recibo->addRecibo_pago($data);
				}
		}
		return $recibo_id;
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/recibo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/recibo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_cajaapertura_id'])) {
			$filter_cajaapertura_id = $this->request->get['filter_cajaapertura_id'];
		} else {
			$filter_cajaapertura_id = '';
		}
		if (isset($this->request->get['filter_recibo_id'])) {
			$filter_recibo_id = $this->request->get['filter_recibo_id'];
		} else {
			$filter_recibo_id = '';
		}

		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'punto';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['recibos'] = array();
		$filter_data = array(
			'filter_cajaapertura_id'              => $filter_cajaapertura_id,
			'filter_recibo_id'              => $filter_recibo_id,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/recibo');
		$results = $this->model_erp_recibo->getRecibos($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['recibo_id'])
					->setCellValue('B'.$row,  $result['punto'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/recibo');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"punto" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_recibo->editRecibo($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_recibo->addRecibo($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	//ITEMS
	public function getRecibo_items() {
		
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$json = array();
		if (isset($this->request->get['recibo_id'])) {
			$this->load->model('erp/recibo');
			$results = $this->model_erp_recibo->getRecibo_items($this->request->get['recibo_id']);
			foreach ($results as $result) {
				$json[] = array(
					'concepto_id' 		=> $result['concepto_id'],
					'concepto'    		=> $result['concepto'],
					'cantidad'    		=> $result['cantidad'],
					'periodo'    		=> $result['periodo'],
					'anio'    			=> $result['anio'],
					'cuota'           	=> $result['cuota'],
					'total'           	=> $result['total']
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	//PAGO
	public function getRecibo_pagos() {
		

		
		$json = array();
		if (isset($this->request->get['recibo_id'])) {
			$this->load->model('erp/recibo');
			$results = $this->model_erp_recibo->getRecibo_pagos($this->request->get['recibo_id']);
			foreach ($results as $result) {
				$json[] = array(
					'formadepago_id' 	=> $result['formadepago_id'],
					'formadepago'    	=> $result['formadepago'],
					'total'           	=> $result['total']
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
	public function generaNc(){
		
		$recibo_id=0;
		
		if (isset($this->request->get['recibo_id'])) {
			$origrecibo_id = $this->request->get['recibo_id'];		
			
			$this->load->model('erp/cajaapertura');
			$cajaapertura=$this->model_erp_cajaapertura->getCajaaperturaActiva();
			if (isset($cajaapertura['cajaapertura_id'])){
				$this->load->model('erp/recibo');
				$recibo=$this->model_erp_recibo->getRecibo($origrecibo_id);
				$persona_id=$recibo['persona_id'];
				$persona=$recibo['persona'];			
				$tipodoc_id=1;
				$tipocompr_id=$recibo['contradoc'];
				$total=$recibo['total'];
				$sql=array("cajaapertura_id" => $cajaapertura['cajaapertura_id'],
						  "persona_id" => $recibo['persona_id'],
						  "tipodoc_id" => $tipodoc_id,
						  "tipocompr_id" => $tipocompr_id,
						  "relacion_id" => $origrecibo_id,
						  "date_added" => date("Y-m-d"),
						  "status" => 1,
						  "punto" => $cajaapertura['punto']
				);
			
				$this->load->model('erp/recibo');
				$recibo_id=$this->model_erp_recibo->addRecibo($sql);
				if ($recibo_id){
					$reciboitems=$this->model_erp_recibo->getRecibo_items($origrecibo_id);
					$this->load->model('erp/conceptoacobrar');
					foreach ($reciboitems as $reciboitem) {
						
						$data=array(
							"concepto_id" => $reciboitem['concepto_id'],
							"recibo_id" => $recibo_id,
							"cantidad" => $reciboitem['cantidad'],
							"periodo" => $reciboitem['periodo'],
							"anio" => $reciboitem['anio'],
							"cuota" => $reciboitem['cuota'],
							"total" => $reciboitem['total']
						);
						$this->model_erp_recibo->addRecibo_item($data);
					}
					$recibopagos=$this->model_erp_recibo->getRecibo_pagos($origrecibo_id);
					foreach ($recibopagos as $recibopago) {
						//MODO DE PAGO
						$data=array("formadepago_id" => $recibopago['formadepago_id'],
								"recibo_id" => $recibo_id,
								"total" => $total
						);
						$this->model_erp_recibo->addRecibo_pago($data);
					}
				}
			}
		}
		return $recibo_id;
	}	
	public function printpdf(){
		if (isset($this->request->get['recibo_id'])) {
			$recibo_id = $this->request->get['recibo_id'];
			
			$this->load->model('admdirsis/codiva');
				
			$this->load->model('erp/recibo');
			$cabeza = $this->model_erp_recibo->getRecibo($recibo_id);
			$detalle = $this->model_erp_recibo->getRecibo_items($recibo_id);
			$pago = $this->model_erp_recibo->getRecibo_pagos($recibo_id);
			$letra="R";
			$this->load->model('erp/persona');
			$persona= $this->model_erp_persona->getPersona($cabeza['persona_id']);
			
			//print_r($pago);
			//die;
			
		 


	 
			
			$membrete = array(
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact'),
				"codiva_id" => $this->config->get('config_factura_codiva_id'),
				"codiva" => $this->model_admdirsis_codiva->getCodiva($this->config->get('config_factura_codiva_id'))
			);
			
			$json=array("ver" => "1",
				"fecha" => date("Y-m-d"),
				"cuit" => str_replace("-","",$membrete['cuit']),
				"ptoVta" => $cabeza['punto'],
				"tipoComp" => $cabeza['tipodoc_id'],
				"nroCmp" => $cabeza['numero'],
				"importe" => round($cabeza['total']*100,0),
				"moneda" => 'PES',
				"ctz" => '1',
				"tipoDocRec" => '99',
				"nroDocRec" => $persona['cuit'],
				"tipoCodAut" => "E",
				"codAut" => $cabeza['cae']);
			$qr0='https://www.afip.gob.ar/fe/qr/?p='.base64_encode(json_encode($json,true));
			$url=DIR_RAIZ.'phpqrcode/qrlib.php';
			require($url);
			$matrixPointSize = 10;
			$errorCorrectionLevel = 'L';
			$filename = DIR_RAIZ.'phpqrcode/test.png';
			QRcode::png($qr0, $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
			$qr=$filename;
			
			//print_r($store_codiva_id);			
			
			
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER."catalog/";
			$data['url'] = HTTPS_CATALOG;
		} else {
			$data['base'] = HTTP_SERVER."catalog/";
			$data['url'] = HTTPS_CATALOG;
		}
		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');
			
			require('dirsis/fpdf.php');
			$pdf = new FPDF('L','mm','A4');
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			

			
			$pdf->SetTitle($cabeza['tipocompr']." N°:".str_pad($cabeza['punto'], 4, "0", STR_PAD_LEFT).'-'.str_pad($cabeza['numero'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
				
				
		//ORIGINAL		
$A2=1;
for ($i = 1; $i <= 2; $i++) {
			$pdf->SetY(9);
			$pdf->SetFont('Arial','',12);
			$pdf->Cell($A2+40);
			if ($i==1){
				$pdf->Cell(40,0,"ORIGINAL",0,1,'R');
			}else{
				$pdf->Cell(40,0,"DUPLICADO",0,1,'R');
			}
			$pdf->Image($data['url']."image/".$membrete['image'],$A2+13,13,50);
			$pdf->Rect($A2+10,5, $A2+140,7);
			$pdf->Rect($A2+10,5+7, $A2+140,37);
			$pdf->Rect($A2+10,5+7+37, $A2+140,37);
			$pdf->Rect($A2+10,5+7+37+37, $A2+140,7);
			$pdf->Rect($A2+10,5+7+37+37+7, $A2+140,80);
			$pdf->Rect($A2+10,5+7+37+37+80, $A2+140,7);
//LOGO	
//CENTRO	
			$pdf->SetY(20);
			$pdf->SetFont('Arial','B',20);
 			$pdf->Cell($A2+68,0,"C",0,0,'R');
			$pdf->SetFont('Arial','',8);
			$pdf->Ln(4);
			$pdf->Cell($A2+70,0,"cod.15",0,0,'R');
			$pdf->Rect($A2+68,5+7,15,15);
//DERECHA	
			$pdf->SetY(20);
			$pdf->SetFont('Arial','B',18);
 			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,$cabeza['tipocompr'],0,0,'L');
			$pdf->Ln(5);
			$pdf->SetFont('Arial','',8);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'Punto de Venta:'.str_pad($cabeza['punto'], 4, "0", STR_PAD_LEFT).' Comp.Nro:'.str_pad($cabeza['numero'], 8, "0", STR_PAD_LEFT),0,0,'L');
			$pdf->Ln(5);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'Fecha de Emision: '.date("d/m/Y",strtotime($cabeza['date_added'])),0,0,'L');
			$pdf->SetY(35);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'CUIT: '.$membrete['cuit'],0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'Ingresos Brutos: 281116037',0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'Com. e Ind: C0154573',0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+80);
 			$pdf->Cell(130,0,'Inicio de Actividades: 18-11-1970',0,0,'L');
//DOMICILIO	
			$pdf->SetY(35);
			$pdf->SetFont('Arial','',8);
			$domicilio=explode(chr(10),$membrete['address']);
			$largo=sizeof($domicilio);
			$texto = utf8_decode($domicilio[0]);
			$pdf->Cell($A2+5);
			$pdf->Cell(60,0,"Domicilio Comercial:".$texto ,0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+5);
			$pdf->Cell(60,0,'Tel: '.$membrete['telephone']." Correo:".$membrete['email'],0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+5);
			$pdf->Cell(60,0,'Condicion frente al IVA: EXENTO',0,0,'L');
			//$pdf->Line($A2+10,50, $A2+140, 50);
			
//CLIENTE			
			$iva="Consumidor Final";
			if (!empty($cabeza['cuit'])){
				$doc=utf8_decode($cabeza['cuit']);
				$iva="Monotributo";
			}elseif (!empty($cabeza['cuil'])){
				$doc=utf8_decode($cabeza['cuil']);
			}else{
				$doc=utf8_decode($cabeza['doc']);
			}
			
			$pdf->SetY(55);
			$pdf->SetFont('Arial','',10);
			$pdf->Cell($A2+5);
			$pdf->Cell(80,0,'Apellido y Nombre/Razon Social: '.utf8_decode($cabeza['persona']),0,0,'L');
			$pdf->Cell(50,0,'MP: '.$persona['matricula'],0,0,'R');
			$pdf->SetFont('Arial','',10);
			$pdf->Ln(5);
			$pdf->Cell($A2+5);
			$pdf->Cell(80,0,'CUIT/CUIL/DNI: '.$doc,0,0,'L');
			$pdf->Ln(5);
			$pdf->Cell($A2+5);
			$pdf->Cell(80,0,'Condicion frente al IVA: '.utf8_decode($iva),0,0,'L');
			$pdf->Ln(5);
			$pdf->Cell($A2+5);
			$pdf->Cell(80,0,'Domicilio: '.$persona['domicilio'],0,0,'L');
			$pdf->Ln(5);

			foreach ($pago as $result) {
				$pdf->Cell($A2+5);
				$pdf->Cell(120,7,'Forma de Pago:'.utf8_decode($result['formadepago']),0,0,'L');
				$pdf->Ln();
			}
			$pdf->Ln(3);
			$pdf->Cell($A2+5);
			$pdf->Cell(80,7,'Concepto',0,0,'L');
			$pdf->Cell(40,7,'Periodo',0,0,'L');
			$pdf->Cell(40,7,'Monto',0,0,'L');
			$pdf->Ln();
			foreach ($detalle as $result) {
				$pdf->Cell($A2+5);
				$pdf->Cell(80,7,utf8_decode($result['concepto']),0,0,'L');
				if ($result['periodo']!=0){
					$pdf->Cell(40,7,$result['periodo']."/".$result['anio'],0,0,'L');
				}else{
					$pdf->Cell(40,7,"",0,0,'L');
				}
				$pdf->Cell(40,7,$result['total'],0,0,'L');
				$pdf->Ln(4);
			}
			$pdf->SetY(-40);
			$pdf->SetFont('Arial','',10);
			$pdf->Cell($A2+90);
			$pdf->Cell(20,0, "IMPORTE TOTAL:",0,0,'R');
			$pdf->SetFont('Arial','B',12);
			$pdf->Cell(20,0, $cabeza['total'],0,0,'R');	
			if (!empty($cabeza['cae'])){
				$pdf->Image($qr,$A2+10,176,28,28,'PNG');
			}
			if (!empty($cabeza['cae'])){
				$pdf->SetY(-20);
				$pdf->SetFont('Arial','',9);
				$pdf->Cell($A2+80);
				$pdf->Cell(40,7,"CAE N:".$cabeza['cae'],0,0,'L');
				$pdf->Ln();
				$pdf->Cell($A2+80);
				$pdf->Cell(40,7,"Fecha de Vto CAE:".date("d-m-Y",strtotime($cabeza['date_cae'])),0,0,'L');
			}
	
$A2=145;				
}
			
			
			//$pdf->Line(0, 250, 200, 250);
			/*
			I: envía el fichero al navegador de forma que se usa la extensión (plug in) si está disponible.
			D: envía el fichero al navegador y fuerza la descarga del fichero con el nombre especificado por name.
			F: guarda el fichero en un fichero local de nombre name.
			S: devuelve el documento como una cadena.
			*/	
			/*
			$dir=DIR_RAIZ.'fact';
			if (!is_dir($dir)){
				mkdir($dir);
			}
			*/
			$archivo="R".str_pad($cabeza['punto'], 4, "0", STR_PAD_LEFT).'-'.str_pad($cabeza['numero'], 8, "0", STR_PAD_LEFT).".pdf";
			//$pdf->Output($archivo,'F');
			$pdf->Output($archivo,'I');			
			
		}
	}
	
	
	
	public function generaasiento() {
		if (isset($this->request->get['recibo_id'])) {
			$this->load->model('erp/recibo');
			$this->model_erp_recibo->addRecibo_asiento($this->request->get['recibo_id']);
		}
	}
}