<?php
class ControllerErpLaboratorio extends Controller {
	private $error = array();

	public function index() {

		//
		$this->load->language('erp/laboratorio');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/laboratorio');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_erp_laboratorio->bajaLaboratorio();
		$this->model_erp_laboratorio->creaLaboratorio();
		//			
		$this->getList();
	}
	
	public function reinicia() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/laboratorio');
		$this->load->model('erp/laboratorio');
		
		$this->model_erp_laboratorio->bajaLaboratorio();
		$this->model_erp_laboratorio->creaLaboratorio();
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"filtro");
		$this->response->redirect($this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
	}	
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/laboratorio');
		$this->load->model('erp/laboratorio');
		if (isset($this->request->get['ini'])){
			$ini=$this->request->get['ini'];	
		}else{
			$ini=0;
		}
		if (isset($this->request->get['fin'])){
			$fin=$this->request->get['fin'];	
		}else{
			$fin=50;
		}		
		$result=$this->model_erp_laboratorio->traeLaboratorio($ini,$fin);
		print_r($result);
		if ($result['recorrido']!=0){
			$ini=$ini+$fin;
			$url=$this->url->link('erp/laboratorio/sincro', 'user_token=' .
			$this->session->data['user_token'] . '&ini='.$ini."&fin=".$fin."&recorrido=".$result['recorrido'],true);
			
			echo "<a href='".$url."'>sigue</a>";
			
			//$this->response->redirect($url);
		}
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.persona_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		
		if (isset($get['filter_laboratorio_id'])) {
			$url .= '&filter_laboratorio_id=' . $get['filter_laboratorio_id'];
		}		
		if (isset($get['filter_razon_social'])) {
			$url .= '&filter_razon_social=' . urlencode(html_entity_decode($get['filter_razon_social'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}

	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/laboratorio');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/laboratorio');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			 
			
			$this->model_erp_laboratorio->addLaboratorio($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"filtro");
			$this->response->redirect($this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		

		
		$this->load->language('erp/laboratorio');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/laboratorio');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')){ /* && $this->validateForm()) {*/
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			
			$this->model_erp_laboratorio->editLaboratorio($this->request->get['laboratorio_id'], $this->request->post);
			$this->model_erp_laboratorio->editLaboratorio_tipo($this->request->get['laboratorio_id'], $this->request->post['tipos']);
			$this->model_erp_laboratorio->editLaboratorio_propietario_instrumental($this->request->get['laboratorio_id'], $this->request->post['pinstrus']);
			$this->model_erp_laboratorio->editLaboratorio_titular($this->request->get['laboratorio_id'], $this->request->post['titulars']);
			$this->model_erp_laboratorio->editLaboratorio_area($this->request->get['laboratorio_id'], $this->request->post['areas']);
			if (isset($this->request->post['equipos'])){
				$this->model_erp_laboratorio->editLaboratorio_equipo($this->request->get['laboratorio_id'], $this->request->post['equipos']);
			}
			$this->model_erp_laboratorio->editLaboratorio_documento($this->request->get['laboratorio_id'], $this->request->post['documentos']);		$this->model_erp_laboratorio->editLaboratorio_auditoria($this->request->get['laboratorio_id'], $this->request->post['auditorias']);	
			$this->model_erp_laboratorio->editLaboratorio_tecnico($this->request->get['laboratorio_id'], $this->request->post['tecnicos']);
			$this->model_erp_laboratorio->editLaboratorio_personal($this->request->get['laboratorio_id'], $this->request->post['personals']);
			$this->model_erp_laboratorio->editLaboratorio_resolucion($this->request->get['laboratorio_id'], $this->request->post['resolucions']);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"filtro");
			$this->response->redirect($this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('erp/laboratorio');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/laboratorio');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $laboratorio_id) {
				$this->model_erp_laboratorio->deleteLaboratorio($laboratorio_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {
		
		$data['nivel']=$this->user->getNivel();

		if (isset($this->request->get['filter_laboratorio_id'])) {
			$filter_laboratorio_id = $this->request->get['filter_laboratorio_id'];
		} else {
			$filter_laboratorio_id = '';
		}
		if (isset($this->request->get['filter_numero'])) {
			$filter_numero = $this->request->get['filter_numero'];
		} else {
			$filter_numero = '';
		}		
		if (isset($this->request->get['filter_razon_social'])) {
			$filter_razon_social = $this->request->get['filter_razon_social'];
		} else {
			$filter_razon_social = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'razon_social';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/laboratorio/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('erp/laboratorio/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['laboratorios'] = array();

		$filter_data = array(
			'filter_laboratorio_id'           => $filter_laboratorio_id,
			'filter_numero'           => $filter_numero,
			'filter_razon_social'           => $filter_razon_social,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);

		$laboratorio_total = $this->model_erp_laboratorio->getTotalLaboratorios($filter_data);
		
		$data['laboratorio_total']=$laboratorio_total;

		$this->load->model('user/user');
		$results = $this->model_erp_laboratorio->getLaboratorios($filter_data);
		foreach ($results as $result) {
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['laboratorios'][] = array(
				'laboratorio_id'    		=> $result['laboratorio_id'],
				'razon_social'           => $result['razon_social'],
				'descrip'           => $result['descrip'],
				'domicilio'           => $result['domicilio'],
				'dpto'           => $result['dpto'],
				'piso'           => $result['piso'],
				'telefono'           => $result['telefono'],
				'prefijo'           => $result['prefijo'],
				'localidad'        	=> $result['localidad'],
				'correo'           => $result['correo'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'     	=> date('d-m-Y', strtotime($result['date_added'])),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('erp/laboratorio/edit', 'user_token=' . $this->session->data['user_token'] . '&laboratorio_id=' . $result['laboratorio_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_laboratorio_id'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=l.laboratorio_id' . $url, true);
		$data['sort_razon_social'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=l.razon_social' . $url, true);
		$data['sort_localidad'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=localidad' . $url, true);
		$data['sort_telefono'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=l.telefono' . $url, true);		
		$data['sort_status'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=l.status' . $url, true);
		$data['sort_date_added'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);
		
		
		$url = $this->filtrar($this->request->get,"nopage");
		$pagination = new Pagination();
		$pagination->total = $laboratorio_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($laboratorio_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($laboratorio_total -  $limit)) ? $laboratorio_total : ((($page - 1) *  $limit) +  $limit), $laboratorio_total, ceil($laboratorio_total /  $limit));

		$data['filter_laboratorio_id'] = $filter_laboratorio_id;
		$data['filter_numero'] = $filter_numero;
		$data['filter_razon_social'] = $filter_razon_social;
		$data['filter_status'] = $filter_status;
		

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/laboratorio_list', $data));
	}

	
	protected function getForm() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['laboratorio_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//DEFINE SI ES ADD O EDIT
		if (isset($this->request->get['laboratorio_id'])) {
			$data['laboratorio_id'] = $this->request->get['laboratorio_id'];
		} else {
			$data['laboratorio_id'] = 0;
		}
		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['descrip'])) {
			$data['error_descrip'] = $this->error['descrip'];
		} else {
			$data['error_descrip'] = '';
		}
		
		if (isset($this->error['razon_social'])) {
			$data['error_razon_social'] = $this->error['razon_social'];
		} else {
			$data['error_razon_social'] = '';
		}		

		$url = $this->filtrar($this->request->get);
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['laboratorio_id'])) {
			$data['action'] = $this->url->link('erp/laboratorio/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('erp/laboratorio/edit', 'user_token=' . $this->session->data['user_token'] . '&laboratorio_id=' . $this->request->get['laboratorio_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('erp/laboratorio', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['laboratorio_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$laboratorio_info = $this->model_erp_laboratorio->getLaboratorio($this->request->get['laboratorio_id']);
		}		
		
		if (isset($this->request->post['autogestion_id'])) {
			$data['autogestion_id'] = $this->request->post['autogestion_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['autogestion_id'] = $laboratorio_info['autogestion_id'];
		} else {
			$data['autogestion_id'] = '';
		}	
		 
		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($laboratorio_info)) {
			$data['descrip'] = $laboratorio_info['descrip'];
		} else {
			$data['descrip'] = '';
		}
		if (isset($this->request->post['razon_social'])) {
			$data['razon_social'] = $this->request->post['razon_social'];
		} elseif (!empty($laboratorio_info)) {
			$data['razon_social'] = $laboratorio_info['razon_social'];
		} else {
			$data['razon_social'] = '';
		}				

		if (isset($this->request->post['domicilio'])) {
			$data['domicilio'] = $this->request->post['domicilio'];
		} elseif (!empty($laboratorio_info)) {
			$data['domicilio'] = $laboratorio_info['domicilio'];
		} else {
			$data['domicilio'] = '';
		}
		if (isset($this->request->post['dpto'])) {
			$data['dpto'] = $this->request->post['dpto'];
		} elseif (!empty($laboratorio_info)) {
			$data['dpto'] = $laboratorio_info['dpto'];
		} else {
			$data['dpto'] = '';
		}
		if (isset($this->request->post['piso'])) {
			$data['piso'] = $this->request->post['piso'];
		} elseif (!empty($laboratorio_info)) {
			$data['piso'] = $laboratorio_info['piso'];
		} else {
			$data['piso'] = '';
		}		
		if (isset($this->request->post['barrio'])) {
			$data['barrio'] = $this->request->post['barrio'];
		} elseif (!empty($laboratorio_info)) {
			$data['barrio'] = $laboratorio_info['barrio'];
		} else {
			$data['barrio'] = '';
		}		
		if (isset($this->request->post['cp'])) {
			$data['cp'] = $this->request->post['cp'];
		} elseif (!empty($laboratorio_info)) {
			$data['cp'] = $laboratorio_info['cp'];
		} else {
			$data['cp'] = '';
		}
		if (isset($this->request->post['localidad_id'])) {
			$data['localidad_id'] = $this->request->post['localidad_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['localidad_id'] = $laboratorio_info['localidad_id'];
		} else {
			$data['localidad_id'] = '';
		}
		if (isset($this->request->post['prefijo'])) {
			$data['prefijo'] = $this->request->post['prefijo'];
		} elseif (!empty($laboratorio_info)) {
			$data['prefijo'] = $laboratorio_info['prefijo'];
		} else {
			$data['prefijo'] = '';
		}
		if (isset($this->request->post['telefono'])) {
			$data['telefono'] = $this->request->post['telefono'];
		} elseif (!empty($laboratorio_info)) {
			$data['telefono'] = $laboratorio_info['telefono'];
		} else {
			$data['telefono'] = '';
		}		
		if (isset($this->request->post['correo'])) {
			$data['correo'] = $this->request->post['correo'];
		} elseif (!empty($laboratorio_info)) {
			$data['correo'] = $laboratorio_info['correo'];
		} else {
			$data['correo'] = '';
		}	
		
		if (isset($this->request->post['categorialab_id'])) {
			$data['categorialab_id'] = $this->request->post['categorialab_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['categorialab_id'] = $laboratorio_info['categorialab_id'];
		} else {
			$data['categorialab_id'] = '';
		}	
		if (isset($this->request->post['lcomplejidad_id'])) {
			$data['lcomplejidad_id'] = $this->request->post['lcomplejidad_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['lcomplejidad_id'] = $laboratorio_info['lcomplejidad_id'];
		} else {
			$data['lcomplejidad_id'] = '';
		}	
		if (isset($this->request->post['especialidad_id'])) {
			$data['especialidad_id'] = $this->request->post['especialidad_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['especialidad_id'] = $laboratorio_info['especialidad_id'];
		} else {
			$data['especialidad_id'] = '';
		}	
		if (isset($this->request->post['google_id'])) {
			$data['google_id'] = $this->request->post['google_id'];
		} elseif (!empty($laboratorio_info)) {
			$data['google_id'] = $laboratorio_info['google_id'];
		} else {
			$data['google_id'] = '';
		}	
		if (isset($this->request->post['horarioate'])) {
			$data['horarioate'] = $this->request->post['horarioate'];
		} elseif (!empty($laboratorio_info)) {
			$data['horarioate'] = $laboratorio_info['horarioate'];
		} else {
			$data['horarioate'] = '';
		}	
		if (isset($this->request->post['lat'])) {
			$data['lat'] = $this->request->post['lat'];
		} elseif (!empty($laboratorio_info)) {
			$data['lat'] = $laboratorio_info['lat'];
		} else {
			$data['lat'] = '';
		}			
		if (isset($this->request->post['lng'])) {
			$data['lng'] = $this->request->post['lng'];
		} elseif (!empty($laboratorio_info)) {
			$data['lng'] = $laboratorio_info['lng'];
		} else {
			$data['lng'] = '';
		}	
		if (isset($this->request->post['ubicacion'])) {
			$data['ubicacion'] = $this->request->post['ubicacion'];
		} elseif (!empty($laboratorio_info)) {
			$data['ubicacion'] = $laboratorio_info['ubicacion'];
		} else {
			$data['ubicacion'] = '';
		}	
		if (isset($this->request->post['distrito'])) {
			$data['distrito'] = $this->request->post['distrito'];
		} elseif (!empty($laboratorio_info)) {
			$data['distrito'] = $laboratorio_info['distrito'];
		} else {
			$data['distrito'] = '';
		}	
	
	
		if ( isset( $this->request->post[ 'cdiario' ] ) ) {
			$data[ 'cdiario' ] = $this->request->post[ 'cdiario' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'cdiario' ] = $laboratorio_info[ 'cdiario' ];
		} else {
			$data[ 'cdiario' ] = '';
		}
		if ( isset( $this->request->post[ 'cambula' ] ) ) {
			$data[ 'cambula' ] = $this->request->post[ 'cambula' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'cambula' ] = $laboratorio_info[ 'cambula' ];
		} else {
			$data[ 'cambula' ] = '';
		}
		if ( isset( $this->request->post[ 'cinterna' ] ) ) {
			$data[ 'cinterna' ] = $this->request->post[ 'cinterna' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'cinterna' ] = $laboratorio_info[ 'cinterna' ];
		} else {
			$data[ 'cinterna' ] = '';
		}
		if ( isset( $this->request->post[ 'copropiedad' ] ) ) {
			$data[ 'copropiedad' ] = $this->request->post[ 'copropiedad' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'copropiedad' ] = $laboratorio_info[ 'copropiedad' ];
		} else {
			$data[ 'copropiedad' ] = '';
		}
		if ( isset( $this->request->post[ 'propietario' ] ) ) {
			$data[ 'propietario' ] = $this->request->post[ 'propietario' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'propietario' ] = $laboratorio_info[ 'propietario' ];
		} else {
			$data[ 'propietario' ] = '';
		}
		if ( isset( $this->request->post[ 'otralocali' ] ) ) {
			$data[ 'otralocali' ] = $this->request->post[ 'otralocali' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'otralocali' ] = $laboratorio_info[ 'otralocali' ];
		} else {
			$data[ 'otralocali' ] = '';
		}
		if ( isset( $this->request->post[ 'otropropietario' ] ) ) {
			$data[ 'otropropietario' ] = $this->request->post[ 'otropropietario' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'otropropietario' ] = $laboratorio_info[ 'otropropietario' ];
		} else {
			$data[ 'otropropietario' ] = '';
		}
		if ( isset( $this->request->post[ 'arugepresa' ] ) ) {
			$data[ 'arugepresa' ] = $this->request->post[ 'arugepresa' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'arugepresa' ] = $laboratorio_info[ 'arugepresa' ];
		} else {
			$data[ 'arugepresa' ] = '';
		}
		if ( isset( $this->request->post[ 'vrugepresa' ] ) ) {
			$data[ 'vrugepresa' ] = $this->request->post[ 'vrugepresa' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'vrugepresa' ] = $laboratorio_info[ 'vrugepresa' ];
		} else {
			$data[ 'vrugepresa' ] = '';
		}
		if ( isset( $this->request->post[ 'vestado' ] ) ) {
			$data[ 'vestado' ] = $this->request->post[ 'vestado' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'vestado' ] = $laboratorio_info[ 'vestado' ];
		} else {
			$data[ 'vestado' ] = '';
		}
		
		if ( isset( $this->request->post[ 'serv_recole' ] ) ) {
			$data[ 'serv_recole' ] = $this->request->post[ 'serv_recole' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_recole' ] = $laboratorio_info[ 'serv_recole' ];
		} else {
			$data[ 'serv_recole' ] = '';
		}
		if ( isset( $this->request->post[ 'serv_guardia' ] ) ) {
			$data[ 'serv_guardia' ] = $this->request->post[ 'serv_guardia' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_guardia' ] = $laboratorio_info[ 'serv_guardia' ];
		} else {
			$data[ 'serv_guardia' ] = '';
		}
		if ( isset( $this->request->post[ 'serv_extracc_dom' ] ) ) {
			$data[ 'serv_extracc_dom' ] = $this->request->post[ 'serv_extracc_dom' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_extracc_dom' ] = $laboratorio_info[ 'serv_extracc_dom' ];
		} else {
			$data[ 'serv_extracc_dom' ] = '';
		}
		if ( isset( $this->request->post[ 'serv_extrac_id' ] ) ) {
			$data[ 'serv_extrac_id' ] = $this->request->post[ 'serv_extrac_id' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_extrac_id' ] = $laboratorio_info[ 'serv_extrac_id' ];
		} else {
			$data[ 'serv_extrac_id' ] = '';
		}
		if ( isset( $this->request->post[ 'serv_extrac_movil' ] ) ) {
			$data[ 'serv_extrac_movil' ] = $this->request->post[ 'serv_extrac_movil' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_extrac_movil' ] = $laboratorio_info[ 'serv_extrac_movil' ];
		} else {
			$data[ 'serv_extrac_movil' ] = '';
		}
	
		if ( isset( $this->request->post[ 'serv_freezer' ] ) ) {
			$data[ 'serv_freezer' ] = $this->request->post[ 'serv_freezer' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_freezer' ] = $laboratorio_info[ 'serv_freezer' ];
		} else {
			$data[ 'serv_freezer' ] = '';
		}
		if ( isset( $this->request->post[ 'serv_heladera' ] ) ) {
			$data[ 'serv_heladera' ] = $this->request->post[ 'serv_heladera' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_heladera' ] = $laboratorio_info[ 'serv_heladera' ];
		} else {
			$data[ 'serv_heladera' ] = '';
		}
			
		if ( isset( $this->request->post[ 'serv_medicion' ] ) ) {
			$data[ 'serv_medicion' ] = $this->request->post[ 'serv_medicion' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'serv_medicion' ] = $laboratorio_info[ 'serv_medicion' ];
		} else {
			$data[ 'serv_medicion' ] = '';
		}
		if ( isset( $this->request->post[ 'dispositivos_medicion' ] ) ) {
			$data[ 'dispositivos_medicion' ] = $this->request->post[ 'dispositivos_medicion' ];
		} elseif ( !empty( $laboratorio_info ) ) {
			$data[ 'dispositivos_medicion' ] = $laboratorio_info[ 'dispositivos_medicion' ];
		} else {
			$data[ 'dispositivos_medicion' ] = '';
		}	
		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($laboratorio_info)) {
			$data['date_added'] = date("d-m-Y",strtotime($laboratorio_info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($laboratorio_info)) {
			$data['date_modified'] = $laboratorio_info['date_modified']==""?"":date("d-m-Y",strtotime($laboratorio_info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($laboratorio_info)) {
			$data['date_delete'] = $laboratorio_info['date_delete']==""?"":date("d-m-Y",strtotime($laboratorio_info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($laboratorio_info)) {
			$data['user_id_added'] = $laboratorio_info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($laboratorio_info)) {
			$data['user_id_modified'] = $laboratorio_info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($laboratorio_info)) {
			$data['user_id_delete'] = $laboratorio_info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($laboratorio_info)) {
			$data['status'] = $laboratorio_info['status'];
		} else {
			$data['status'] = true;
		}
 	
		$this->load->model('erp/localidad');
		$data['localidads'] = $this->model_erp_localidad->getLocalidads(array());
		
		$this->load->model('erp/categorialab');
		$data['categorialabs'] = $this->model_erp_categorialab->getCategorialabs(array());	
		
		$this->load->model('erp/lcomplejidad');
		$data['lcomplejidads'] = $this->model_erp_lcomplejidad->getLcomplejidads(array());
		
		$this->load->model('erp/especialidad');
		$data['especialidads'] = $this->model_erp_especialidad->getEspecialidads(array());		
		
		
		if (isset($this->request->get['laboratorio_id'])) {
			
			//print_r($this->request->get['laboratorio_id']);
			
			$data['laboratorio_tipos']=$this->model_erp_laboratorio->getLaboratorio_tipos($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_tipos']);
			$data['laboratorio_propietario_instrumentals']=$this->model_erp_laboratorio->getLaboratorio_propietario_instrumentals($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_propietario_instrumentals']);
			$data['laboratorio_titulars']=$this->model_erp_laboratorio->getLaboratorio_titulars($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_titulars']);
			$data['laboratorio_areas']=$this->model_erp_laboratorio->getLaboratorio_areas($this->request->get['laboratorio_id']);
			
			$data['laboratorio_equipos']=$this->model_erp_laboratorio->getLaboratorio_equipos($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_equipos']);
			$data['laboratorio_documentos']=$this->model_erp_laboratorio->getLaboratorio_documentos($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_documentos']);
			$data['laboratorio_auditorias']=$this->model_erp_laboratorio->getLaboratorio_auditorias($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_auditorias']);
			$data['laboratorio_tecnicos']=$this->model_erp_laboratorio->getLaboratorio_tecnicos($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_tecnicos']);			
			$data['laboratorio_personals']=$this->model_erp_laboratorio->getLaboratorio_personals($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_personals']);	
			$data['laboratorio_resolucions']=$this->model_erp_laboratorio->getLaboratorio_resolucions($this->request->get['laboratorio_id']);
			//print_r($data['laboratorio_resolucions']);			
		}		
		
		
		$this->load->model('erp/cargo');
		$data['cargos'] = $this->model_erp_cargo->getCargos();
		
		$this->load->model('erp/trelacion');
		$data['trelacions'] = $this->model_erp_trelacion->getTrelacions();	
		
		$this->load->model('erp/area');
		$data['areas'] = $this->model_erp_area->getAreas();		
		
		$this->load->model('erp/modpractica');
		$data['modpracticas'] = $this->model_erp_modpractica->getModpracticas();	
		
		$this->load->model('erp/equipo');
		$data['equipos'] = $this->model_erp_equipo->getEquipos();	
 
		$this->load->model('erp/audit');
		$data['audits'] = $this->model_erp_audit->getAudits();	
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('erp/laboratorio_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/laboratorio')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 200)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/laboratorio')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	public function autocomplete() {
		
				error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$json = array();
		if (isset($this->request->get['filter_razon_social'])) {
			if (isset($this->request->get['filter_razon_social'])) {
				$filter_razon_social= $this->request->get['filter_razon_social'];
			} else {
				$filter_razon_social = '';
			}
			$this->load->model('erp/laboratorio');

			$filter_data = array(
				'filter_razon_social'   => $filter_razon_social,
				'start'            => 0,
				'limit'            => 20
			);
			$results=$this->model_erp_laboratorio->getLaboratorios($filter_data);
			foreach ($results as $result) {
				$json[] = array(
					'laboratorio_id'       => $result['laboratorio_id'],
					'razon_social'              => strip_tags(html_entity_decode($result['razon_social'], ENT_QUOTES, 'UTF-8')),
					'date_added'		=> $result['date_added'],
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['razon_social'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_razon_social'])) {
			$filter_razon_social = $this->request->get['filter_razon_social'];
		} else {
			$filter_razon_social = '';
		}

		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'razon_social';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['laboratorios'] = array();
		$filter_data = array(
			'filter_razon_social'              => $filter_razon_social,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/laboratorio');
		$results = $this->model_erp_laboratorio->getLaboratorios($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['laboratorio_id'])
					->setCellValue('B'.$row,  $result['razon_social'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/laboratorio');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"razon_social" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_laboratorio->editLaboratorio($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_laboratorio->addLaboratorio($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
}