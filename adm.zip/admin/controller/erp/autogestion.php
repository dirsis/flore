<?php
class ControllerErpAutogestion extends Controller {
	private $error = array();

	public function index() {

		//
		$this->load->language('erp/autogestion');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/autogestion');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_erp_autogestion->bajaAutogestion();
		//$this->model_erp_autogestion->creaAutogestion();
		//			
		$this->getList();
	}
	
	public function reinicia() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/autogestion');
		$this->load->model('erp/autogestion');
		
		$this->model_erp_autogestion->bajaAutogestion();
		$this->model_erp_autogestion->creaAutogestion();
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"filtro");
		$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}	
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/autogestion');
		$this->load->model('erp/autogestion');
		if (isset($this->request->get['id'])){
			$this->model_erp_autogestion->tramitesAutogestion($this->request->get['id']);
		}else{
			$this->model_erp_autogestion->tramitesAutogestion();
		}
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"filtro");
		$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
	}
	public function tramites(){
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/autogestion');
		$this->load->model('erp/autogestion');
		$json=$this->model_erp_autogestion->tramitesAutogestion();
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
		
		/*
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"filtro");
		$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
		*/
		
	}	
	public function filtrar($get,$accion="filtro"){
		$url = '';

		if (isset($get['filter_autogestion_id'])) {
			$url .= '&filter_autogestion_id=' . $get['filter_autogestion_id'];
		}
		if (isset($get['filter_razon_social'])) {
			$url .= '&filter_razon_social=' . urlencode(html_entity_decode($get['filter_razon_social'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}

		if ($accion=="filtro"){
			if (isset($get['sort'])) {
				$url .= '&sort=' . $get['sort'];
			}
			if (isset($get['order'])) {
				if ($get['order']=='ASC'){
					$url .= '&order=DESC';
				}else{
					$url .= '&order=ASC';
				}
			}else{
				$url .= '&order=ASC';
			}
		}else{
			if (isset($get['order'])) {
				if ($get['order']=='ASC'){
					$url .= '&order=DESC';
				}else{
					$url .= '&order=ASC';
				}
			}else{
				$url .= '&order=ASC';
			}
		}
		if (!$accion=="pagina"){
			if (isset($get['page'])) {
				$url .= '&page=' . $get['page'];
			}
		}
		if (isset($get['limit'])) {
			$url .= '&limit=' . $get['limit'];
		}else{
			$url .= '&limit=' . $this->config->get('config_limit_admin');
		}		
		
		return $url;
	}

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/autogestion');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/autogestion');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			 
			
			$this->model_erp_autogestion->addAutogestion($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"filtro");
			$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		

		
		$this->load->language('erp/autogestion');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/autogestion');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')){ /* && $this->validateForm()) {*/
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			
			$this->model_erp_autogestion->editAutogestion($this->request->get['autogestion_id'], $this->request->post);
			$this->model_erp_autogestion->editAutogestion_tipo($this->request->get['autogestion_id'], $this->request->post['tipos']);
			$this->model_erp_autogestion->editAutogestion_propietario_instrumental($this->request->get['autogestion_id'], $this->request->post['pinstrus']);
			$this->model_erp_autogestion->editAutogestion_titular($this->request->get['autogestion_id'], $this->request->post['titulars']);
			$this->model_erp_autogestion->editAutogestion_area($this->request->get['autogestion_id'], $this->request->post['areas']);
			if (isset($this->request->post['equipos'])){
				$this->model_erp_autogestion->editAutogestion_equipo($this->request->get['autogestion_id'], $this->request->post['equipos']);
			}
			$this->model_erp_autogestion->editAutogestion_documento($this->request->get['autogestion_id'], $this->request->post['documentos']);		$this->model_erp_autogestion->editAutogestion_auditoria($this->request->get['autogestion_id'], $this->request->post['auditorias']);	
			$this->model_erp_autogestion->editAutogestion_tecnico($this->request->get['autogestion_id'], $this->request->post['tecnicos']);
			$this->model_erp_autogestion->editAutogestion_personal($this->request->get['autogestion_id'], $this->request->post['personals']);
			$this->model_erp_autogestion->editAutogestion_resolucion($this->request->get['autogestion_id'], $this->request->post['resolucions']);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"filtro");
			$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('erp/autogestion');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/autogestion');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $autogestion_id) {
				$this->model_erp_autogestion->deleteAutogestion($autogestion_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {
		
		$data['nivel']=$this->user->getNivel();

		if (isset($this->request->get['filter_autogestion_id'])) {
			$filter_autogestion_id = $this->request->get['filter_autogestion_id'];
		} else {
			$filter_autogestion_id = '';
		}
		if (isset($this->request->get['filter_razon_social'])) {
			$filter_razon_social = $this->request->get['filter_razon_social'];
		} else {
			$filter_razon_social = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'razon_social';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"filtro");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/autogestion/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('erp/autogestion/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['autogestions'] = array();

		$filter_data = array(
			'filter_autogestion_id'           => $filter_autogestion_id,
			'filter_razon_social'           => $filter_razon_social,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		
		$data['autogestions_resumen'] = $this->model_erp_autogestion->getAutogestions_resumen($filter_data);		

		$autogestion_total = $this->model_erp_autogestion->getTotalAutogestions($filter_data);

		$this->load->model('user/user');
		$results = $this->model_erp_autogestion->getAutogestions($filter_data);
		foreach ($results as $result) {
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}
			$edit="";
			if ($result['laboratorio_id']!=0){
 				$edit=$this->url->link('erp/laboratorio/edit', 'user_token=' . $this->session->data['user_token'] . '&laboratorio_id=' . $result['laboratorio_id'] . $url, true);
			}else{
				if ($result['matricula_id']!=0){
					$edit=$this->url->link('erp/matricula/edit', 'user_token=' . $this->session->data['user_token'] . '&matricula_id=' . $result['matricula_id'] . $url, true);
				}else{
					$edit=$this->url->link('erp/autogestion/edit', 'user_token=' . $this->session->data['user_token'] . '&tramite_id=' . $result['tramite_id'] . $url, true);
				}
			}
	 

			$data['autogestions'][] = array(
				'autogestion_id' => $result['autogestion_id'],
				'motivo'   => $result['motivo'],
				'tramite_id'   => $result['tramite_id'],
				'motivo_id'   => $result['motivo_id'],
				'persona_id'   => $result['persona_id'],
				'persona'   => $result['persona'],
				'laboratorio_id'   => $result['laboratorio_id'],
				'laboratorio'   => $result['laboratorio'],
				'matricula_id'   => $result['matricula_id'],
				'etramite_id'   => $result['tramite_id'],
				'etramite'   => $result['etramite'],
				'razon_social'   => $result['razon_social'],
				'descrip'        => $result['descrip'],
				'domicilio'      => $result['domicilio'],
				'dpto'           => $result['dpto'],
				'piso'           => $result['piso'],
				'telefono'       => $result['telefono'],
				'prefijo'        => $result['prefijo'],
				'localidad'      => $result['localidad'],
				'correo'         => $result['correo'],
				'categoria'         => $result['categoria'],
				'status'         => $result['estado'],
				'date_added'     	=> date('d-m-Y', strtotime($result['date_added'])),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $edit
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"columna");
		$data['sort_autogestion_id'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.autogestion_id' . $url, true);
		$data['sort_tramite_id'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.tramite_id' . $url, true);		
		$data['sort_razon_social'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.razon_social' . $url, true);
		$data['sort_localidad'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=localidad' . $url, true);
		$data['sort_telefono'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.telefono' . $url, true);		
		$data['sort_etramite_id'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.etramite_id' . $url, true);		
		$data['sort_status'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=l.status' . $url, true);
		$data['sort_date_added'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);
		
		
		$url = $this->filtrar($this->request->get,"pagina");
		$pagination = new Pagination();
		$pagination->total = $autogestion_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($autogestion_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($autogestion_total -  $limit)) ? $autogestion_total : ((($page - 1) *  $limit) +  $limit), $autogestion_total, ceil($autogestion_total /  $limit));

		
		$this->load->model('erp/autogestion');
		$data['motivos']=$this->model_erp_autogestion->getAutogestion_motivos();

		$this->load->model('erp/etramite');
		$data['etramites']=$this->model_erp_etramite->getEtramites();
		//print_r($data['etramites']);
		
		$data['filter_autogestion_id'] = $filter_autogestion_id;
		$data['filter_razon_social'] = $filter_razon_social;
		$data['filter_status'] = $filter_status;
		

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/autogestion_list', $data));
	}

	
	public function vista() {
		
		$this->load->language('erp/autogestion');
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		if (isset($this->request->get['tramite_id'])) {
			$this->load->model('erp/autogestion');
			$data['tramite_id']=$this->request->get['tramite_id'];
			$data['motivo_id']=$this->request->get['motivo_id'];
			$data['vista']="";
			$data['autogestion_infos']="";
			switch ($data['motivo_id']) {
			case 1:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_1($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;					
			case 2:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_2($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;
			case 7:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_7($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;
			case 8:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_8($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;
			case 10:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_10($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;
			case 11:
				$data['autogestion_infos']= $this->model_erp_autogestion->getAutogestion_11($data['tramite_id']);
				$data['vista'] =$this->load->view('erp/autogestion_vista', $data);
				break;					
			}
			//print_r($data['autogestion_infos']);
			$data['user_token'] = $this->session->data['user_token'];
			echo $data['vista'];
		}else{
			echo "Error";
		}
		
		
	}	
	
	public function cambioestadotramite() {
		$result=0;
		$this->load->language('erp/autogestion');
		if (isset($this->request->get['tramite_id'])) {
			$this->load->model('erp/autogestion');
			$data['tramite_id']=$this->request->get['tramite_id'];
			$data['etramite_id']=$this->request->get['etramite_id'];
			$result=$this->model_erp_autogestion->editAutogestion_etramite($data['tramite_id'],$data['etramite_id']);
		}
		echo $result;
	}	
	
	protected function getForm() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		
		$data['text_form'] = $this->language->get('text_edit');
		$data['user_token'] = $this->session->data['user_token'];
		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		$url = $this->filtrar($this->request->get);
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$data['action'] = $this->url->link('erp/autogestion/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['cancel'] = $this->url->link('erp/autogestion', 'user_token=' . $this->session->data['user_token'] . $url, true);

		
		if ($this->request->get['tramite_id']){
			//ALTA
			$autogestion_info = $this->model_erp_autogestion->getAutogestion_tramite($this->request->get['tramite_id']);

			if ($autogestion_info){
				print_r($autogestion_info);
				
				
	   //[forma_de_pago] => Débito por Caja de ahorro 

				
			//$data['autogestion_id'] = $this->request->get['autogestion_id'];
			$data['tramite_id'] = $autogestion_info['id'];
			$data['razon_social'] = $autogestion_info['razon_social'];
			$data['domicilio'] = $autogestion_info['calle']." ".$autogestion_info['calle_numero'];
			$data['dpto'] = $autogestion_info['dpto'];
			$data['piso'] = $autogestion_info['piso'];
			$data['barrio'] = $autogestion_info['barrio'];
			$data['cp'] = $autogestion_info['codigo_postal'];
			$data['localidad_id'] = $autogestion_info['localidad_id'];
			$data['prefijo'] = $autogestion_info['telefono_prefijo'];
			$data['telefono'] = $autogestion_info['telefono'];
			//$data['correo'] = $autogestion_info['correo'];
			//$data['categorialab_id'] = $autogestion_info['categorialab_id'];
			//$data['lcomplejidad_id'] = $autogestion_info['lcomplejidad_id'];
			//$data['especialidad_id'] = $autogestion_info['especialidad_id'];
			//$data['google_id'] = $autogestion_info['google_id'];
			$data['horarioate'] = $autogestion_info['horario_atencion'];
			$data['lat'] = $autogestion_info['lat'];
			$data['lng'] = $autogestion_info['lng'];
			$data['ubicacion'] = $autogestion_info['ubicacion'];
			//$data['distrito'] = $autogestion_info['distrito'];
			$data[ 'cdiario' ] = $autogestion_info[ 'cantidad_cuotas' ];
			$data[ 'cambula' ] = $autogestion_info[ 'cantidad_pacientes_por_dia_ambulatorios' ];
			$data[ 'cinterna' ] = $autogestion_info[ 'cantidad_pacientes_por_dia_internados' ];
			$data[ 'copropiedad' ] = $autogestion_info[ 'comparte_propiedad' ];
			$data[ 'propietario' ] = $autogestion_info[ 'es_propietario' ];
			//$data[ 'otralocali' ] = $autogestion_info[ 'otralocali' ];
			$data[ 'otropropietario' ] = $autogestion_info[ 'otro_propietario' ];
			$data[ 'arugepresa' ] = $autogestion_info[ 'habilitacion_rugepresa' ];
			$data[ 'vrugepresa' ] = $autogestion_info[ 'fecha_vencimiento' ];
			//$data[ 'vestado' ] = $autogestion_info[ 'vestado' ];
			//$data[ 'serv_recole' ] = $autogestion_info[ 'serv_recole' ];
			$data[ 'serv_guardia' ] = $autogestion_info[ 'servicio_de_guardia' ];
			$data[ 'serv_extracc_dom' ] = $autogestion_info[ 'quien_realiza_en_que_movilidad' ];
			$data[ 'serv_extrac_id' ] = $autogestion_info[ 'en_que_movilidad' ];
			$data[ 'serv_extrac_movil' ] = $autogestion_info[ 'extracciones_en_domicilio' ];
			//$data[ 'serv_freezer' ] = $autogestion_info[ 'serv_freezer' ];
			//$data[ 'serv_heladera' ] = $autogestion_info[ 'serv_heladera' ];
			//$data[ 'serv_medicion' ] = $autogestion_info[ 'serv_medicion' ];
			$data[ 'dispositivos_medicion' ] = $autogestion_info[ 'dispositivos_medicion' ];
			$data['date_added'] = date("d-m-Y",strtotime($autogestion_info['fecha_creacion']));
			$data['date_modified'] = $autogestion_info['fecha_ultima_actualizacion']==""?"":date("d-m-Y",strtotime($autogestion_info['fecha_ultima_actualizacion']));
			//$data['date_delete'] = $autogestion_info['date_delete']==""?"":date("d-m-Y",strtotime($autogestion_info['date_delete']));
			$data['user_id_added'] = $autogestion_info['usuario_id'];
			//$data['user_id_modified'] = $autogestion_info['user_id_modified'];
			//$data['user_id_delete'] = $autogestion_info['user_id_delete'];
			//$data['status'] = $autogestion_info['status'];
		
			$data['laboratorio_tipos']=$this->model_erp_autogestion->getAutogestion_tipos($data['tramite_id']);
			$data['laboratorio_propietario_instrumentals']=$this->model_erp_autogestion->getAutogestion_propietario_instrumentals($data['tramite_id']);	
/*		

			$data['laboratorio_titulars']=$this->model_erp_autogestion->getLaboratorio_titulars($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_titulars']);
			$data['laboratorio_areas']=$this->model_erp_autogestion->getLaboratorio_areas($data['tramite_id'],$data['laboratorio_id']);
			
			$data['laboratorio_equipos']=$this->model_erp_autogestion->getLaboratorio_equipos($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_equipos']);
			$data['laboratorio_documentos']=$this->model_erp_autogestion->getLaboratorio_documentos($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_documentos']);
			$data['laboratorio_auditorias']=$this->model_erp_autogestion->getLaboratorio_auditorias($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_auditorias']);
			$data['laboratorio_tecnicos']=$this->model_erp_autogestion->getLaboratorio_tecnicos($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_tecnicos']);			
			$data['laboratorio_personals']=$this->model_erp_autogestion->getLaboratorio_personals($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_personals']);	
			$data['laboratorio_resolucions']=$this->model_erp_autogestion->getLaboratorio_resolucions($data['tramite_id'],$data['laboratorio_id']);
			//print_r($data['laboratorio_resolucions']);
	
		}	
*/			
			}
		}
		//echo "<pre>";		print_r($data);		echo "</pre>"; die;
		
		
		$this->load->model('erp/localidad');
		$data['localidads'] = $this->model_erp_localidad->getLocalidads(array());
		
		$this->load->model('erp/categorialab');
		$data['categorialabs'] = $this->model_erp_categorialab->getCategorialabs(array());	
		
		$this->load->model('erp/lcomplejidad');
		$data['lcomplejidads'] = $this->model_erp_lcomplejidad->getLcomplejidads(array());
		
		$this->load->model('erp/especialidad');
		$data['especialidads'] = $this->model_erp_especialidad->getEspecialidads(array());		
				
		$this->load->model('erp/cargo');
		$data['cargos'] = $this->model_erp_cargo->getCargos();
		
		$this->load->model('erp/trelacion');
		$data['trelacions'] = $this->model_erp_trelacion->getTrelacions();	
		
		$this->load->model('erp/area');
		$data['areas'] = $this->model_erp_area->getAreas();		
		
		$this->load->model('erp/modpractica');
		$data['modpracticas'] = $this->model_erp_modpractica->getModpracticas();	
		
		$this->load->model('erp/equipo');
		$data['equipos'] = $this->model_erp_equipo->getEquipos();	
 
		$this->load->model('erp/audit');
		$data['audits'] = $this->model_erp_audit->getAudits();	
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('erp/autogestion_form', $data));	
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/autogestion')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 200)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/autogestion')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	public function autocomplete() {
		
				error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$json = array();
		if (isset($this->request->get['filter_razon_social'])) {
			if (isset($this->request->get['filter_razon_social'])) {
				$filter_razon_social= $this->request->get['filter_razon_social'];
			} else {
				$filter_razon_social = '';
			}
			$this->load->model('erp/autogestion');

			$filter_data = array(
				'filter_razon_social'   => $filter_razon_social,
				'start'            => 0,
				'limit'            => 20
			);
			$results=$this->model_erp_autogestion->getAutogestions($filter_data);
			foreach ($results as $result) {
				$json[] = array(
					'autogestion_id'       => $result['autogestion_id'],
					'razon_social'              => strip_tags(html_entity_decode($result['razon_social'], ENT_QUOTES, 'UTF-8')),
					'date_added'		=> $result['date_added'],
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['razon_social'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_razon_social'])) {
			$filter_razon_social = $this->request->get['filter_razon_social'];
		} else {
			$filter_razon_social = '';
		}

		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'razon_social';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['autogestions'] = array();
		$filter_data = array(
			'filter_razon_social'              => $filter_razon_social,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('erp/autogestion');
		$results = $this->model_erp_autogestion->getAutogestions($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['autogestion_id'])
					->setCellValue('B'.$row,  $result['razon_social'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/autogestion');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					"razon_social" => $in_ar[1],
					"status" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3]))
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_erp_autogestion->editAutogestion($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_erp_autogestion->addAutogestion($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
}