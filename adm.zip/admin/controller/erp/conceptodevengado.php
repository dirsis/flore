<?php
class ControllerErpConceptodevengado extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('erp/conceptodevengado');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/conceptodevengado');
		//CREA LA TABLA SI NO EXISTE
		//
		$this->model_erp_conceptodevengado->creaConceptodevengado();
		
		//			
		$this->getList();
	}
	
	public function sincro(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/conceptodevengado');
		$this->load->model('erp/conceptodevengado');
		if (isset($this->request->get['ini'])){
			$ini=$this->request->get['ini'];	
		}else{
			$ini=0;
		}
		if (isset($this->request->get['fin'])){
			$fin=$this->request->get['fin'];	
		}else{
			$fin=300;
		}		
		$result=$this->model_erp_conceptodevengado->traeConceptodevengado($ini,$fin);
		
		if ($result['recorrido']!=0){
			$ini=$ini+$fin;
			$url=$this->url->link('erp/conceptodevengado/sincro', 'user_token=' . $this->session->data['user_token'] . '&ini='.$ini."&recorrido=".$result['recorrido'],true);
			$this->response->redirect($url);
		}
		print_r($result);
	}
	
	
	public function reinicia(){
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');		
		$this->load->language('erp/conceptodevengado');
		$this->load->model('erp/conceptodevengado');
		
		$this->model_erp_conceptodevengado->bajaConceptodevengado();
		$this->model_erp_conceptodevengado->creaConceptodevengado();
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get);
		$this->response->redirect($this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'e.date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_formadepago_id'])) {
			$url .= '&filter_formadepago_id=' . $get['filter_formadepago_id'];
		}		
		if (isset($get['filter_matricula_id'])) {
			$url .= '&filter_matricula_id=' . $get['filter_matricula_id'];
		}
		if (isset($get['filter_persona_i'])) {
			$url .= '&filter_persona_id=' . $get['filter_persona_id'];
		}	
		if (isset($get['filter_recibo'])) {
			$url .= '&filter_recibo=' . $get['filter_recibo'];
		}		
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('erp/conceptodevengado');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/conceptodevengado');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$periodo=(int)$this->request->post['periodo'];
			$anio=(int)$this->request->post['anio'];
			$cuotas=(float)$this->request->post['cuota'];
			$total=((float)$this->request->post['total']*(float)$this->request->post['cantidad']);
			$debit=$this->request->post['date_debit'];
			$date1 = new DateTime($this->request->post['date_debit']);
			$date2 = new DateTime($this->request->post['date_vto']);
			$diff = $date1->diff($date2);
			$dias=$diff->days;
			if ((int)$this->request->post['cuota1']>0){
				if ($cuotas!=1){
					$saldo=$total-(float)$this->request->post['cuota1'];
					$saldo=$saldo/($cuotas-1);
				}else{
					$saldo=$total;
				}
			}else{
				$saldo=$total/($cuotas);
			}
			for ($i = 1; $i <= $cuotas; $i++) {
				
				$date_future = strtotime('+'.$dias.' day', strtotime($debit));
				$vto = date('d-m-Y', $date_future);
				
				//$vto= strtotime('+ 5 days', strtotime(date("Y-m-d")));
				if (($this->request->post['cuota1']!=0) and ($i==1)){
					$total=(float)$this->request->post['cuota1'];
				}else{
					$total=$saldo;
				}
				$result = array (
					"persona_id" => $this->request->post['persona_id'],
					"concepto_id" => $this->request->post['concepto_id'],
					"periodo" =>  $periodo,
					"anio" =>  $anio,
					"cantidad" => $this->request->post['cantidad'],
					"total" => $total,
					"cuota" => $i,
					"recibo" => 0,
					"date_debit"  => date("Y-m-d",strtotime( $debit)),
					"date_vto" => date("Y-m-d",strtotime( $vto))
				);
				
				$this->model_erp_conceptodevengado->addConceptodevengado($result);
				
				$periodo=$periodo+1;
				if ($periodo==13){
					$periodo=1;
					$anio++;
				}
				$debit=$anio."-".$periodo."-".date("d",strtotime( $debit));
				/*
				echo "<pre>";
				print_r($result);
				echo "</pre>";
				*/
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('erp/conceptodevengado');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/conceptodevengado');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_erp_conceptodevengado->editConceptodevengado($this->request->get['conceptodevengado_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		
		$this->load->language('erp/conceptodevengado');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('erp/conceptodevengado');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $conceptodevengado_id) {
					$this->model_erp_conceptodevengado->deleteConceptodevengado($conceptodevengado_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	public function emiterecibo($data,$asiento=false) {
		$this->load->model('erp/recibo');
		$recibo_id=$this->model_erp_recibo->addRecibo($data,$asiento);
		if ($recibo_id!=0){
			//MARCA EMITIDOS
			foreach ($data['detalle'] as $detalle) {
					$this->model_erp_conceptodevengado->editRecibo($detalle['conceptodevengado_id'],$recibo_id);
			}
			//FISCALIZAR Y EMITIR
			$this->load->model('admdirsis/fiscalizar');
			$cae=$this->model_admdirsis_fiscalizar->getFiscalizarecibo($recibo_id);
			return $recibo_id;
		}else{
			return "Fallo Recibo";
		}
	}
	
	
	
	public function procesarpago($post){
		$json=array();
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$this->load->model('erp/conceptodevengado');
		//$this->load->model('erp/persona');
		//$persona=$this->model_erp_persona->getPersona($this->request-ost['accion_persona_id']);
		//VER SI LA CAJA ESTA ABIERTA
		$this->load->model('erp/cajaapertura');
		$cajaapertura=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		
		$cajaapertura_id = $cajaapertura['cajaapertura_id'];
		$punto = $cajaapertura['punto'];

		//RECORRE SELECCIONADOS		
		//print_r($post);
		$seleccions=$this->model_erp_conceptodevengado->getConceptodevengadosApagar($post);
		
		
		
		$total=0;
		$persona_id=0;
		$detalle=array();
		$asie=array();
		foreach ($seleccions as $seleccion) {
			if ($persona_id!=$seleccion['persona_id'] and $total!=0){
						//nuevo recibo
				
				//return $data;
				
				$recibo_id=$this->emiterecibo($data,false);
				$asie[]=array("recibo_id" => $recibo_id );
				$json[]=array("data" => $data,
							"recibo_id" => $recibo_id,
									"url" => $this->url->link('erp/recibo/printpdf', 'user_token=' . $this->session->data['user_token'] . '&recibo_id='.$recibo_id,307)
				);
				//renueva
				$total=0;
				$detalle=array();
			}
			$persona_id=$seleccion['persona_id'];
			$value=$this->model_erp_conceptodevengado->getConceptodevengado($seleccion['conceptodevengado_id']);
			$total=$total+$value['total'];	
			$detalle[]=array(
				"concepto_id" => $value['concepto_id'],
				"conceptodevengado_id" => $seleccion['conceptodevengado_id'],
				"cantidad" => $value['cantidad'],
				"periodo" => $value['periodo'],
				"anio" => $value['anio'],
				"cuota" => $value['cuota'],
				"total" => $value['total']
			);	
			$pago=array();
			$pago[]=array(
				"formadepago_id" => $seleccion['formadepago_id'],
				"total" => $total
			);
			$data=array (
				"tipocompr_id" => '1',
				"cajaapertura_id" => $cajaapertura_id,
				"date_added" => date("Y-m-d"),
				"persona_id" => $seleccion['persona_id'],
				"pago" => $pago,
				"indice" => '',
				"tipodoc_id" => $seleccion['tipodoc_id'],
				"punto" => $punto,
				"detalle" => $detalle,
				"status" => 1
			);				
		}
		if ($total!=0){
			//nuevo recibo
			$recibo_id=$this->emiterecibo($data,false);
			$asie[]=array("recibo_id" => $recibo_id );
			$json[]=array("data" => $data,
						  "recibo_id" => $recibo_id,
							"url" => $this->url->link('erp/recibo/printpdf', 'user_token=' . $this->session->data['user_token'] . '&recibo_id='.$recibo_id,307)
			);			
		}
		if ($asie){
			$this->load->model('erp/recibo');
			$this->model_erp_recibo->addRecibo_asiento(0,$asie);
		}
		return $json;
	}
	public function pagar() {

		$json=array();
		$this->load->model('erp/cajaapertura');
		$cajaapertura=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		if (isset($cajaapertura['cajaapertura_id'])){
			$result="";
			if (isset($this->request->post['selected'])) {
				$json=$this->procesarpago($this->request->post);
			}
			$this->session->data['success'] = "Recibos Procesados";
		}else{
			$this->session->data['success'] = "No hay Caja Abierta!";
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
	}
	
	protected function getList() {
		
		if (isset($this->request->get['filter_matricula_id'])) {
			$filter_matricula_id = $this->request->get['filter_matricula_id'];
			$this->load->model('erp/matricula');
			$result=$this->model_erp_matricula->getMatricula($filter_matricula_id);
			$filter_persona_id = $result['persona_id'];
			$filter_persona = $result['persona'];
		} else {
			$filter_persona = $filter_matricula_id = $filter_persona_id = '';
			if (isset($this->request->get['filter_persona_id'])) {
				$filter_persona_id = $this->request->get['filter_persona_id'];
				$result=$this->model_erp_persona->getPersona($filter_persona_id);
				$filter_persona = $result['persona'];
			}
		}
		
		if (isset($this->request->get['filter_formadepago_id'])) {
			$filter_formadepago_id = $this->request->get['filter_formadepago_id'];
		} else {
			$filter_formadepago_id = '';
		}
		
		if (isset($this->request->get['filter_recibo'])) {
			$filter_recibo = $this->request->get['filter_recibo'];
		} else {
			$filter_recibo = '0';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'persona';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('erp/conceptodevengado/add', 'user_token=' . $this->session->data['user_token'] . $url."&matricula_id=". $filter_matricula_id, true);
		$data['delete'] = $this->url->link('erp/conceptodevengado/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['conceptodevengados'] = array();

		$filter_data = array(
			'filter_matricula_id'      => $filter_matricula_id,
			'filter_formadepago_id'      => $filter_formadepago_id,
			'filter_persona_id'        => $filter_persona_id,
			'filter_recibo'            => $filter_recibo,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$conceptodevengado_total = $this->model_erp_conceptodevengado->getTotalConceptodevengados($filter_data);
		$this->load->model('user/user');

		$acum=0;
		$results = $this->model_erp_conceptodevengado->getConceptodevengados($filter_data);
		foreach ($results as $result) {
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);

			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$acum=$acum+$result['total'];

			if (!$result['recibo']){
				$edit=$this->url->link('erp/conceptodevengado/edit', 'user_token=' . $this->session->data['user_token'] . '&conceptodevengado_id=' . $result['conceptodevengado_id'] . $url."&matricula_id=".$result['matricula_id'], true);
			}else{
				$edit="";
			}
			$data['conceptodevengados'][] = array(
				'numero'           => $result['numero'],
				'conceptodevengado_id'    		=> $result['conceptodevengado_id'],
				'concepto'           => $result['concepto'],
				'matricula_id'           => $result['matricula_id'],
				'persona'           => $result['persona'],
				'persona_id'           => $result['persona_id'],
				'pautogestion_id'           => $result['pautogestion_id'],
				'total2'           => $result['total'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				  "concepto_id" => $result['concepto_id'],
				  "periodo" => $result['periodo'],
				  "anio"  => $result['anio'],
				  "total"  => number_format($result['total'], 2, '.', ','),
				  "acum"  => number_format($acum, 2, '.', ','),
				  "cuota"  => $result['cuota'],
				  "cantidad"  => $result['cantidad'],
				  "recibo"  => $result['recibo'],
				  "recibo_id"  => $result['recibo_id'],
				  "debit" => $result['debit'],
				  "bancor " => $result['bancor'],
				  "circulo"  => $result['circulo'],
				'date_added'     	=> date('d-m-Y', strtotime($result['date_added'])),
				'date_vto'     => $result['date_vto']==""?"":date('d-m-Y', strtotime($result['date_vto'])),
				'date_debit'     	=> $result['date_debit']==""?"":date('d-m-Y', strtotime($result['date_debit'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $edit
			);
		}

		$data['acum'] = number_format($acum, 2, '.', ',');
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		
		$data['sort_matricula_id'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . '&sort=m.matricula_id' . $url, true);
		
		$data['sort_persona'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . '&sort=persona' . $url, true);

		$data['sort_concepto'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . '&sort=concepto' . $url, true);
		
		$data['sort_status'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . '&sort=e.status' . $url, true);
		$data['sort_date_added'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . '&sort=e.date_added' . $url, true);

		
		$url = $this->filtrar($this->request->get,"nopage");
		$pagination = new Pagination();
		$pagination->total = $conceptodevengado_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($conceptodevengado_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($conceptodevengado_total -  $limit)) ? $conceptodevengado_total : ((($page - 1) *  $limit) +  $limit), $conceptodevengado_total, ceil($conceptodevengado_total /  $limit));

		
		$this->load->model('erp/cajaapertura');
		$caja=$this->model_erp_cajaapertura->getCajaaperturaActiva();
		if (isset($caja['cajaapertura_id'])){
			$data['cajaapertura']="CAJA ABIERTA: N°:".$caja['cajaapertura_id'];
			$data['cajaapertura_id']=$caja['cajaapertura_id'];
		}


		$data['filter_persona_id'] = $filter_persona_id;
		$data['filter_persona'] = $filter_persona;
		$data['filter_matricula_id'] = $filter_matricula_id;
		$data['filter_formadepago_id'] = $filter_formadepago_id;
		$data['filter_recibo'] = $filter_recibo;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$this->load->model('ctb/formadepago');
		$data['formadepagos'] = $this->model_ctb_formadepago->getFormadepagos();		
		

		$this->response->setOutput($this->load->view('erp/conceptodevengado_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['conceptodevengado_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['user_token'] = $this->session->data['user_token'];
		$data['info_persona'] = array();
		$this->load->model('erp/persona');
		if (isset($this->request->get['filter_matricula_id'])){
		$data['info_persona'] = $this->model_erp_persona->getPersonaxmatricula($this->request->get['filter_matricula_id']);		
		}
		if (isset($this->request->get['matricula_id'])){
		$data['info_persona'] = $this->model_erp_persona->getPersonaxmatricula($this->request->get['matricula_id']);		
		}
		if (isset($this->request->get['persona_id'])){
		$data['info_persona'] = $this->model_erp_persona->getPersona($this->request->get['persona_id']);	
		}
		if($data['info_persona']){
			$data['matricula_id']=$data['info_persona']['matricula_id'];
			$data['persona_id']=$data['info_persona']['persona_id'];
			$data['persona']=$data['info_persona']['apellido'].",".$data['info_persona']['nombre'];
		}
			//DEFINE SI ES ADD O EDIT
			if (isset($this->request->get['conceptodevengado_id'])) {
				$data['conceptodevengado_id'] = $this->request->get['conceptodevengado_id'];
			} else {
				$data['conceptodevengado_id'] = 0;
			}
			//ERRORES
			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->error['apellido'])) {
				$data['error_apellido'] = $this->error['apellido'];
			} else {
				$data['error_apellido'] = '';
			}

			if (isset($this->error['nombre'])) {
				$data['error_nombre'] = $this->error['nombre'];
			} else {
				$data['error_nombre'] = '';
			}		

			$url = $this->filtrar($this->request->get);
			$data['breadcrumbs'] = array();
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);

			if (!isset($this->request->get['conceptodevengado_id'])) {
				$data['action'] = $this->url->link('erp/conceptodevengado/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
			} else {
				$data['action'] = $this->url->link('erp/conceptodevengado/edit', 'user_token=' . $this->session->data['user_token'] . '&conceptodevengado_id=' . $this->request->get['conceptodevengado_id'] . $url, true);
			}

			$data['cancel'] = $this->url->link('erp/conceptodevengado', 'user_token=' . $this->session->data['user_token'] . $url, true);

			if (isset($this->request->get['conceptodevengado_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
				$conceptodevengado_info = $this->model_erp_conceptodevengado->getConceptodevengado($this->request->get['conceptodevengado_id']);
			}		



			if (isset($this->request->post['concepto_id'])) {
				$data['concepto_id'] = $this->request->post['concepto_id'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['concepto_id'] = $conceptodevengado_info['concepto_id'];
			} else {
				$data['concepto_id'] = '';
			}
			
			if (isset($this->request->post['matricula_id'])) {
				$data['matricula_id'] = $this->request->post['matricula_id'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['matricula_id'] = $conceptodevengado_info['matricula_id'];
			}			

			if (isset($this->request->post['date_added'])) {
				$data['date_added'] = $this->request->post['date_added'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['date_added'] = $conceptodevengado_info['date_added'];
			} else {
				$data['date_added'] = date("d-m-Y");
			}
			if (isset($this->request->post['date_debit'])) {
				$data['date_debit'] = $this->request->post['date_debit'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['date_debit'] = $conceptodevengado_info['date_debit'];
			} else {
				$data['date_debit'] = date("d-m-Y");
			}		
			if (isset($this->request->post['date_vto'])) {
				$data['date_vto'] = $this->request->post['date_vto'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['date_vto'] = $conceptodevengado_info['date_vto'];
			} else {
				$data['date_vto'] = date("d-m-Y");
			}	

			if (isset($this->request->post['cantidad'])) {
				$data['cantidad'] = $this->request->post['cantidad'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['cantidad'] = $conceptodevengado_info['cantidad'];
			} else {
				$data['cantidad'] = '1';
			}
			if (isset($this->request->post['cuota'])) {
				$data['cuota'] = $this->request->post['cuota'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['cuota'] = $conceptodevengado_info['cuota'];
			} else {
				$data['cuota'] = "1";
			}	
			$data['cuota1'] = "0";

			if (isset($this->request->post['periodo'])) {
				$data['periodo'] = $this->request->post['periodo'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['periodo'] = $conceptodevengado_info['periodo'];
			} else {
				$data['periodo'] = date("m");
			}			

			if (isset($this->request->post['anio'])) {
				$data['anio'] = $this->request->post['anio'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['anio'] = $conceptodevengado_info['anio'];
			} else {
				$data['anio'] = date("Y");
			}
			if (isset($this->request->post['total'])) {
				$data['total'] = $this->request->post['total'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['total'] = $conceptodevengado_info['total'];
			} else {
				$data['total'] = '0';
			}
			if (isset($this->request->post['recibo'])) {
				$data['recibo'] = $this->request->post['recibo'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['recibo'] = $conceptodevengado_info['recibo'];
			} else {
				$data['recibo'] = '';
			}

			if (isset($this->request->post['debit'])) {
				$data['debit'] = $this->request->post['debit'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['debit'] = $conceptodevengado_info['debit'];
			} else {
				$data['debit'] = '1';
			}		
			$data['debits']=array(
				array("descrip" => "debito","value" => 1),
				array("descrip" => "TN","value" => 2),
				array("descrip" => "Bancor","value" => 3),
				array("descrip" => "Circulo","value" => 4));

			$data['periodos']=array(
				array("descrip" => "ENE","value" => 1),
				array("descrip" => "FEB","value" => 2),
				array("descrip" => "MAR","value" => 3),
				array("descrip" => "ABR","value" => 4),
				array("descrip" => "MAY","value" => 5),
				array("descrip" => "JUN","value" => 6),
				array("descrip" => "JUN","value" => 7),
				array("descrip" => "AGO","value" => 8),
				array("descrip" => "SEP","value" => 9),
				array("descrip" => "OCT","value" => 10),
				array("descrip" => "NOV","value" => 11),
				array("descrip" => "DIC","value" => 12));

			$anio=date("Y");
			$data['anios']=array(
				array("descrip" => $anio-2,"value" => $anio-2),
				array("descrip" => $anio-1,"value" => $anio-1),
				array("descrip" => $anio,"value" => $anio),
				array("descrip" => $anio+1,"value" => $anio+1),
				array("descrip" => $anio+2,"value" => $anio+2),
				array("descrip" => $anio+3,"value" => $anio+3)
			);		

			$data['debits'][]=array(
				array("descrip" => "TN","value" => 2),
				array("descrip" => "Bancor","value" => 3),
				array("descrip" => "Circulo","value" => 4));

	/*		
			if (isset($this->request->post['bancor'])) {
				$data['bancor'] = $this->request->post['bancor'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['bancor'] = $conceptodevengado_info['bancor'];
			} else {
				$data['bancor'] = '0';
			}

			if (isset($this->request->post['circulo'])) {
				$data['circulo'] = $this->request->post['circulo'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['circulo'] = $conceptodevengado_info['circulo'];
			} else {
				$data['circulo'] = '0';
			}
			if (isset($this->request->post['tn'])) {
				$data['tn'] = $this->request->post['tn'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['tn'] = $conceptodevengado_info['tn'];
			} else {
				$data['tn'] = '0';
			}
	*/		

			if (isset($this->request->post['date_modified'])) {
				$data['date_modified'] = $this->request->post['date_modified'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['date_modified'] = $conceptodevengado_info['date_modified']==""?"":date("d-m-Y",strtotime($conceptodevengado_info['date_modified']));
			} else {
				$data['date_modified'] = "";
			}
			if (isset($this->request->post['date_delete'])) {
				$data['date_delete'] = $this->request->post['date_delete'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['date_delete'] = $conceptodevengado_info['date_delete']==""?"":date("d-m-Y",strtotime($conceptodevengado_info['date_delete']));
			} else {
				$data['date_delete'] = "";
			}	

			if (isset($this->request->post['user_id_added'])) {
				$data['user_id_added'] = $this->request->post['user_id_added'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['user_id_added'] = $conceptodevengado_info['user_id_added'];
			} else {
				$data['user_id_added'] = $this->user->getId();
			}		
			if (isset($this->request->post['user_id_modified'])) {
				$data['user_id_modified'] = $this->request->post['user_id_modified'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['user_id_modified'] = $conceptodevengado_info['user_id_modified'];
			} else {
				$data['user_id_modified'] = "";
			}
			if (isset($this->request->post['user_id_delete'])) {
				$data['user_id_delete'] = $this->request->post['user_id_delete'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['user_id_delete'] = $conceptodevengado_info['user_id_delete'];
			} else {
				$data['user_id_delete'] = "";
			}


			if (isset($this->request->post['status'])) {
				$data['status'] = $this->request->post['status'];
			} elseif (!empty($conceptodevengado_info)) {
				$data['status'] = $conceptodevengado_info['status'];
			} else {
				$data['status'] = true;
			}

			$this->load->model('ctb/concepto');
			$data['conceptos'] = $this->model_ctb_concepto->getConceptos(array());

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('erp/conceptodevengado_form', $data));

	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'erp/conceptodevengado')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->request->post['total']<=0) {
			$this->error['total'] = $this->language->get('error_total');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'erp/conceptodevengado')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();
		$filter_nombre = '';
		if (isset($this->request->get['filter_nombre'])) {
			if (isset($this->request->get['filter_nombre'])) {
				$filter_nombre = $this->request->get['filter_nombre'];
			}
		}
		$this->load->model('erp/conceptodevengado');
		$filter_data = array(
			'filter_nombre'      => $filter_nombre,
			'start'            => 0,
			'limit'            => 20
		);
		$results = $this->model_erp_conceptodevengado->getConceptodevengados($filter_data);
		foreach ($results as $result) {
			$json[] = array(
				'conceptodevengado_id'       => $result['conceptodevengado_id'],
				'apellido'       => strip_tags(html_entity_decode($result['apellido'])),
				'nombre'       => strip_tags(html_entity_decode($result['nombre'])),
				'conceptodevengado'       => strip_tags(html_entity_decode($result['descrip'])),
				'tipodoc_id'       => $result['tipodoc_id'],
				'doc'       => strip_tags(html_entity_decode($result['doc'])),
				'cuit'       => $result['cuit'],
				'resolmuni'       => $result['resolmuni'],
				'cuil'       => $result['cuil'],
				'nacionalidad_id'       => $result['nacionalidad_id'],
				'sexo_id'       => $result['sexo_id'],
				'ecivil_id'       => $result['ecivil_id'],
				'fecha_nac'       => date("d/m/Y",strtotime($result['fecha_nac'])),
				'localidad_nac_id'       => $result['localidad_nac_id'],
  				'domicilio'       => strip_tags(html_entity_decode($result['domicilio'])),
  				'dpto'       => strip_tags(html_entity_decode($result['dpto'])),
				'piso'       => strip_tags(html_entity_decode($result['piso'])),
  				'barrio'       => strip_tags(html_entity_decode($result['barrio'])),
  				'cp'       => strip_tags(html_entity_decode($result['cp'])),
				'localidad_id'       => $result['localidad_id'],
  				'prefijo'       => strip_tags(html_entity_decode($result['prefijo'])),
  				'telefono'       => strip_tags(html_entity_decode($result['telefono'])),
  				'mprefijo'       => strip_tags(html_entity_decode($result['mprefijo'])),
  				'mtelefono'       => strip_tags(html_entity_decode($result['mtelefono'])),
				'correo'       => strip_tags(html_entity_decode($result['correo']))
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['conceptodevengado'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}		
	public function download_xlsx() {
	
		$this->load->model('erp/matricula');
		$this->load->model('erp/persona');
		
		if (isset($this->request->get['filter_matricula_id'])) {
			$filter_matricula_id = $this->request->get['filter_matricula_id'];
			$result=$this->model_erp_matricula->getMatricula($filter_matricula_id);
			$filter_persona_id = $result['persona_id'];
			$filter_persona = $result['persona'];
		} else {
			$filter_persona = $filter_matricula_id = $filter_persona_id = '';
			if (isset($this->request->get['filter_persona_id'])) {
				$filter_persona_id = $this->request->get['filter_persona_id'];
				$result=$this->model_erp_persona->getPersona($filter_persona_id);
				$filter_persona = $result['persona'];
			}
		}
		
		if (isset($this->request->get['filter_formadepago_id'])) {
			$filter_formadepago_id = $this->request->get['filter_formadepago_id'];
		} else {
			$filter_formadepago_id = '';
		}
		
		if (isset($this->request->get['filter_recibo'])) {
			$filter_recibo = $this->request->get['filter_recibo'];
		} else {
			$filter_recibo = '0';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}
		$sort = 'persona';
		$order = 'ASC';
		$filter_data = array(
			'filter_matricula_id'      => $filter_matricula_id,
			'filter_formadepago_id'    => $filter_formadepago_id,
			'filter_persona_id'        => $filter_persona_id,
			'filter_recibo'            => $filter_recibo,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order
		);
		$this->load->model('erp/conceptodevengado');
		$results = $this->model_erp_conceptodevengado->getConceptodevengados($filter_data);
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
		$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$row,  "id")
				->setCellValue('B'.$row,  "Matricula")
				->setCellValue('C'.$row,  "Titular")
				->setCellValue('D'.$row,  "Motivo")
				->setCellValue('E'.$row,  "Periodo")
				->setCellValue('F'.$row,  "Anio")
				->setCellValue('G'.$row,  "Importe");
		
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['conceptodevengado_id'])
					->setCellValue('B'.$row,  $result['matricula_id'])
					->setCellValue('C'.$row,  $result['persona'])
					->setCellValue('D'.$row,  $result['concepto'])
					->setCellValue('E'.$row,  $result['periodo'])
					->setCellValue('F'.$row,  $result['anio'])
					->setCellValue('G'.$row,  $result['total']);
			$row++;
		}
		foreach(range('A','E') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			$post=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			$json[]=array("Post" => $post);	
			$result=$this->procesarpago($post);
			$json[]=array("Resultado" => $result);			
			$this->session->data['success'] = "Archivo Procesado";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		$json=array();
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			//print_r($in_ar);
			if ($in_ar[0]!=0){
				$json['selected'][]=$in_ar[0];
			}
			$linea++;
		}
		return $json;
	}	
	
	
	
	
	
		
}