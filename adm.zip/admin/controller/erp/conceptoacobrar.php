<?php
class ControllerErpConceptoacobrar extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('erp/conceptoacobrar');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getList();
	}
	public function filtrar($get){
		$url="";
		if (isset($get['filter_matricula'])) {
			$url .= '&filter_matricula=' . $get['filter_matricula'];
		}		
		if (isset($get['filter_formadepago_id'])) {
			$url .= '&filter_formadepago_id=' . $get['filter_formadepago_id'];
		}		
		if (isset($get['filter_persona_id'])) {
			$url .= '&filter_persona_id=' . $get['filter_persona_id'];
		}
		return $url;
	}
	protected function getList() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');	
		
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		
		
		$this->load->model('erp/conceptoacobrar');
		
		$filter_matricula_id = '';
		if (isset($this->request->get['filter_matricula_id'])) {
			$filter_matricula_id = $this->request->get['filter_matricula_id'];
		}	
		
		$filter_formadepago_id = '';
		if (isset($this->request->get['filter_formadepago_id'])) {
			$filter_formadepago_id = $this->request->get['filter_formadepago_id'];
		}		
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('erp/conceptoacobrar', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['cobrar'] = $this->url->link('erp/recibo/conceptosapagar', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['conceptoacobrars'] = array();

		$filter_data = array(
			'filter_matricula_id'	=> $filter_matricula_id,
			'filter_formadepago_id'	=> $filter_formadepago_id
		);
		//print_r($filter_data);
		$results = $this->model_erp_conceptoacobrar->getConceptoacobrars($filter_data);
		foreach ($results as $result) {
			$data['conceptoacobrars'][] = array(
				'conceptodevengado_id' => $result['conceptodevengado_id'],
				'matricula_id'    	=> $result['matricula_id'],
				'formadepago_id'    	=> $result['formadepago_id'],
				'formadepago'    	=> $result['formadepago'],
				'persona_id'    	=> $result['persona_id'],
				'persona'          => $result['persona'],
				'concepto_id'    	=> $result['concepto_id'],
				'concepto'          => $result['concepto'],
				'monto'				=> $result['monto'],
				'date_added'        => $result['date_added'],
				'date_debit'        => $result['date_debit'],
				'periodo'           	=> $result['periodo'],
				'anio'           	=> $result['anio'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled'))
			);
		}
		
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get);
		
		$data['filter_matricula_id'] = $filter_matricula_id;
		$data['filter_formadepago_id'] = $filter_formadepago_id;

		
		
		$this->load->model('ctb/formadepago');
		$data['formadepagos'] = $this->model_ctb_formadepago->getFormadepagos();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('erp/conceptoacobrar_list', $data));
	}
	
	
	
	public function devenga() {
		
		if (isset($this->request->get['filter_formadepago_id'])) {
			$filter_formadepago_id = $this->request->get['filter_formadepago_id'];
			$filter_status = '1';
			
			$this->load->model('erp/conceptoacobrar');
			$conceptos = array();
			$filter_data = array('filter_formadepago_id'	=> $filter_formadepago_id);
			$results = $this->model_erp_conceptoacobrar->getConceptoacobrars($filter_data);
			foreach ($results as $result) {
				$conceptos[] = array(
				'conceptodevengado_id' => $result['conceptodevengado_id'],
				'matricula_id'    	=> $result['matricula_id'],
				'formadepago_id'    => $result['formadepago_id'],
				'formadepago'    	=> $result['formadepago'],
				'persona_id'    	=> $result['persona_id'],
				'persona'           => $result['persona'],
				'concepto_id'    	=> $result['concepto_id'],
				'concepto'          => $result['concepto'],
				'monto'				=> $result['monto'],
				'date_added'        => $result['date_added'],
				'date_debit'        => $result['date_debit'],
				'periodo'           => $result['periodo'],
				'anio'           	=> $result['anio'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled'))
				);
			}
			
	 
			
			//XLSX
			$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";
			require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->
			getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
			$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "Matricula")
					->setCellValue('B'.$row,  "ID")
					->setCellValue('C'.$row,  "Apellido y Nombre")
					->setCellValue('D'.$row,  "Fecha")
					->setCellValue('E'.$row,  "Periodo")
					->setCellValue('F'.$row,  "Monto");
			$row++;	
			foreach ($conceptos as $result) {
				$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['matricula_id'])
					->setCellValue('B'.$row,  $result['conceptodevengado_id'])
					->setCellValue('C'.$row,  $result['persona'])
					->setCellValue('D'.$row,  $result['date_added'])
					->setCellValue('E'.$row,  $result['periodo']."/".$result['anio'])
					->setCellValue('F'.$row,  $result['monto']);
				$row++;
			}
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	
	public function imputa() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('erp/matricula');
		$datos=$recibos=array();
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[0]) and $linea>0){
				$datos[]=array(
					"matricula_id" => $in_ar[0],
					"conceptodevengado_id" => $in_ar[1],
					"persona" => $in_ar[2],
					"date_added" => date("Y-m-d",strtotime($in_ar[3])),
					"periodo" => $in_ar[4],
					"monto" => $in_ar[5]
				);
				$edit++;
			}
			$linea++;
		}
		$this->load->model('erp/conceptoacobrar');
		$recibos=$this->model_erp_conceptoacobrar->editConceptoacobrar($datos);
		
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new,"recibos" => $recibos);
	}	
	
	
	


}