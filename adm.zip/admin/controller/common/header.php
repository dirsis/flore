<?php
class ControllerCommonHeader extends Controller {
	public function index() {
		
		date_default_timezone_set('America/Argentina/Buenos_Aires');
		$data['title'] = $this->document->getTitle();
		$data['diayhora']=date("d-m-Y H:i");

		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['base'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
		
		$this->load->model('tool/image');
		if (is_file(DIR_IMAGE . $this->config->get('config_icon'))) {
			$data['icon'] = $data['catalog'] . $this->config->get('config_icon');
			$data['icon'] = $this->model_tool_image->resize($this->config->get('config_icon'), 45, 45);
		}		
		if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
			$data['logo'] = $data['catalog']  . 'image/' . $this->config->get('config_logo');
			$data['logo'] = $this->model_tool_image->resize($this->config->get('config_logo'), 200, 45);
		} else {
			$data['logo'] = '';
		}		
			
		//date_default_timezone_set('Australia/Adelaide');

		$data['lang'] =
		$data['description'] = $this->document->getDescription();
		$data['keywords'] = $this->document->getKeywords();
		$data['links'] = $this->document->getLinks();
		$data['styles'] = $this->document->getStyles();
		$data['scripts'] = $this->document->getScripts();
		$data['lang'] = $this->language->get('code');
		$data['direction'] = $this->language->get('direction');
		$this->load->language('common/header');
		
		$data['text_logged'] = sprintf($this->language->get('text_logged'), $this->user->getUserName());

		if (!isset($this->request->get['user_token']) || !isset($this->session->data['user_token']) || ($this->request->get['user_token'] != $this->session->data['user_token'])) {
			$data['logged'] = '';

			$data['home'] = $this->url->link('common/dashboard', '', true);
		} else {
			$data['logged'] = true;

			$data['home'] = $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true);
			$data['logout'] = $this->url->link('common/logout', 'user_token=' . $this->session->data['user_token'], true);
			$data['profile'] = $this->url->link('common/profile', 'user_token=' . $this->session->data['user_token'], true);
		
			$this->load->model('user/user');
	
			
	
			$user_info = $this->model_user_user->getUser($this->user->getId());
	
			if ($user_info) {
				$data['firstname'] = $user_info['firstname'];
				$data['lastname'] = $user_info['lastname'];
				$data['username']  = $user_info['username'];
				$data['user_group'] = $user_info['user_group'];
				$data['user_group_nivel'] = $user_info['user_group_nivel'];
	
				if (is_file(DIR_IMAGE . $user_info['image'])) {
					$data['image'] = $this->model_tool_image->resize($user_info['image'], 45, 45);
				} else {
					$data['image'] = $this->model_tool_image->resize('profile.png', 45, 45);
				}
			} else {
				$data['firstname'] = '';
				$data['lastname'] = '';
				$data['user_group'] = '';
				$data['image'] = '';
			}		

			$this->load->model('design/layout');
			
			if (DIRX_COTIZA=='S'){
				$this->load->model('admdirsis/dolar');
				$results = $this->model_admdirsis_dolar->infoDolar();
				$data['blue_avg']=$results['blue']['value_avg'];
				$data['blue_sell']=$results['blue']['value_sell'];
				$data['blue_buy']=$results['blue']['value_buy'];

				$this->load->model('admdirsis/cripto');
				$results = $this->model_admdirsis_cripto->infousdt();
				$data['usdt_buy']=$results['ask'];
			}
			$data['layouts'] = $this->model_design_layout->getLayouts();
			$data['config_name'] = $this->config->get('config_name');
			$data['config_image'] = $this->config->get('config_image');			
			
			// Online Stores
			$data['stores'] = array();

			$data['stores'][] = array(
				'name' => $this->config->get('config_name'),
				'href' => HTTP_CATALOG
			);

			$this->load->model('setting/store');

			$results = $this->model_setting_store->getStores();

			foreach ($results as $result) {
				$data['stores'][] = array(
					'name' => $result['name'],
					'href' => $result['url']
				);
			}
			
			
			$data['user_token'] = $this->session->data['user_token'];
			
			///DIRSIS CHAT
			
			if ($this->config->get('config_funciones_chat')){			
						$data['chat'] = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'], true);
			}
			///DIRSIS ALERTAS			
			$data['alertas'] = array();
			$this->load->model('admdirsis/alerta');
			$filter_vence = date("Y-m-d");
			$filter_data = array( "filter_vence" => $filter_vence,
								  "filter_status" => '1');
			$results = $this->model_admdirsis_alerta->getAlertas($filter_data);
			$data['totalalertas'] = $this->model_admdirsis_alerta->getTotalAlertas($filter_data);
			foreach ($results as $result) {
				$data['alertas'][] = array(
					'alerta_id' => $result['alerta_id'],
					'motivo' => $result['motivo'],
					'vence' => date("d-m-Y",strtotime($result['vence'])),
					'ciclica' => $result['ciclica'],
					'edit' => $this->url->link('admdirsis/alerta/edit', 'user_token=' . $this->session->data['user_token'] . '&alerta_id=' . $result['alerta_id'], true)
				);
			}
			///DIRSIS ALERTAS FIN	
			
			
			///DIRSIS ALERTAS			
			$this->load->model('dirsismrp/pr');
			$data_filter = array(
					"filter_status" => '1' 
			);
			$results = $this->model_dirsismrp_pr->getHistories($data_filter);
			foreach ($results as $result) {
				$data['totalalertas'] = (int)$data['totalalertas'] + 1;
				$data['alertas'][] = array(
					'alerta_id' => $result['pr_history_id'],
					'motivo' => nl2br($result['stop_motivo']),
					'vence' => date("d-m-Y",strtotime($result['date_registro'])),
					'ciclica' => 0,
					'edit' => $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&pr_history_id=' . $result['pr_history_id'], true)
				);
			}
			///DIRSIS ALERTAS FIN	
			
			///DIRSIS ALERTAS			
			$this->load->model('dirsiscrud/mtproceso');
			$filter_data = array(
				'filter_mtstatus_id'            => $this->config->get('config_mtstatus_default'),
			);
			$results = $this->model_dirsiscrud_mtproceso->getMtprocesos($filter_data);
			foreach ($results as $result) {
				$data['totalalertas'] = (int)$data['totalalertas'] + 1;
				$data['alertas'][] = array(
					'alerta_id' => $result['mtproceso_id'],
					'motivo' => trim(nl2br($result['motivo'])),
					'vence' => date("d-m-Y",strtotime($result['date_added'])),
					'ciclica' => 0,
					'edit' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&mtproceso_id=' . $result['mtproceso_id'], true)
				);
			}
			///DIRSIS ALERTAS FIN				
			
			$data['menus'] = $this->load->controller('common/column_left/menu');
			//echo "<pre>";
			//print_r($data['menus']);
			//echo "</pre>";
			
			if (file_exists('manifest.json')){
				$data['pwa']="S";
			}
			
			//view/stylesheet/stylesheet.css
			$cssFile		= 'view/stylesheet/stylesheet.css';
			$data['timeModified']	= date ("dmy", filemtime($cssFile));
		}

		return $this->load->view('common/header', $data);
	}
}