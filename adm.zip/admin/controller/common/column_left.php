<?php
class ControllerCommonColumnLeft extends Controller {
	public function index() {
		$data = array();
		if ( $this->user->hasPermission( 'access', 'common/column_left' ) ) {
			$data = $this->menu();
		}		
		return $this->load->view( 'common/column_left', $data );
	}
	
	public function menu() {
		$data = array();
		if ( isset( $this->request->get[ 'user_token' ] ) && isset( $this->session->data[ 'user_token' ] ) && ( $this->request->get[ 'user_token' ] == $this->session->data[ 'user_token' ] ) ) {

			$this->load->language( 'common/column_left' );
			$nivel = 9;
			$this->load->model( 'user/user' );
			$user_info = $this->model_user_user->getUser( $this->user->getId() );

			$out = "<button class='lunar-dg'></button> ";
			$war = "<button class='lunar-wr'></button> ";
			$ok = "<button class='lunar-sc'></button> ";
			if ( $user_info ) {
				$nivel = $user_info[ 'user_group_nivel' ];
				$data[ 'nivel' ] = $nivel;
			}
//////////////////////////////////////
// PANEL
//////////////////////////////////////		
			if ( $this->config->get( 'config_menu_panel1' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/dashboard',
					'icon' => 'fa-dashboard',
					'name' => $this->language->get( 'text_dashboard' ),
					'column' => 1,
					'href' => $this->url->link( 'common/dashboard', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->config->get( 'config_menu_panel3' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/dashboard3',
					'icon' => 'fa-dashboard',
					'name' => $this->language->get( 'text_dashboard3' ),
					'column' => 1,
					'href' => $this->url->link( 'common/dashboard3', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->config->get( 'config_menu_panel2' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/dashboard2',
					'icon' => 'fa-dashboard',
					'name' => $this->language->get( 'text_dashboard2' ),
					'column' => 1,
					'href' => $this->url->link( 'common/dashboard2', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
//////////////////////////////////////
// VARIOS GENERAL
//////////////////////////////////////		

			if ( $this->user->hasPermission( 'access', 'admdirsis/alerta' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/alerta',
					'icon' => 'fa-bell',
					'name' => $this->language->get( 'text_alerta' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/alerta', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsisexcel/integra' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/integracion',
					'icon' => 'fa-bell',
					'name' => $this->language->get( 'text_integra' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsisexcel/integra', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/notaeditor' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/notaeditor',
					'icon' => 'fa-bell',
					'name' => $this->language->get( 'text_notaeditor' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/notaeditor', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/chat' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/chat',
					'icon' => 'fa-chat',
					'name' => $this->language->get( 'text_chat' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/chat', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			
//////////////////////////////////
//GACELA
/////////////////////////////////			
			$produccion = array();
			$result = $this->definemenu('produccion/stockxlote');
			if ($result) { $produccion[]=$result; }				
			//REGISTRO OPERACIONES
			$result = $this->definemenu('produccion/otpr');
			if ($result) { $produccion[]=$result; }			
			//ORDEN TRABAJO
			$result = $this->definemenu('produccion/ot');
			if ($result) { $produccion[]=$result; }
			//ORDEN COMPRA
			$result = $this->definemenu('produccion/oc');
			if ($result) { $produccion[]=$result; }
			//PROYECCION
			$result = $this->definemenu('produccion/proy');
			if ($result) { $produccion[]=$result; }			
			//LIBERACION
			$result = $this->definemenu('produccion/libera');
			if ($result) { $produccion[]=$result; }			
			//ORDEN COMPRA
			$result = $this->definemenu('produccion/lote');
			if ($result) { $produccion[]=$result; }			
			//MOVIMIENTO INTERNO
			$result = $this->definemenu('produccion/mi');
			if ($result) { $produccion[]=$result; }
			//PAÑOL
			$result = $this->definemenu('produccion/panol');
			if ($result) { $produccion[]=$result; }
			//ETIQ
			$result = $this->definemenu('produccion/etiq');
			if ($result) { $produccion[]=$result; }
			
			if ($result) { $produccioncrud[]=$result; }
				$produccioncrud = array();
				$result = $this->definemenu('produccion/product');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/grupo');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/category');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/family');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/maquina');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/tarea');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/dispo');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/proveedor');
				if ($result) { $produccioncrud[]=$result; }
				//$result = $this->definemenu('produccion/cliente');
				//if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/proceso');
				if ($result) { $produccioncrud[]=$result; }
				//$result = $this->definemenu('produccion/deposito');
				//if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/sector');
				if ($result) { $produccioncrud[]=$result; }
				$result = $this->definemenu('produccion/estado');
				if ($result) { $produccioncrud[]=$result; }
				if ( $produccioncrud ) {
					$produccion[] = array(
						'id' => 'menu/produccioncrud',
						'name' => $this->language->get( 'text_produccioncrud' ),
						'column' => 1,
						'href' => '',
						'children' => $produccioncrud
					);
				}
			if ( $produccion ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/produccion',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_produccion' ),
					'column' => 1,
					'href' => '',
					'children' => $produccion
				);
			}			
////////////////////////
//FIN PRODUCCION			
////////////////////////			
			$admdirsis = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/saldo' ) ) {
				$admdirsis[] = array(
					'id' => 'catalog/saldo',
					'name' => $this->language->get( 'text_saldo' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/saldo', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/estado' ) ) {
				$admdirsis[] = array(
					'id' => 'catalog/estado',
					'name' => $this->language->get( 'text_estado' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/estado', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/contab' )and $data[ 'nivel' ] < 1 ) {
				$admdirsis[] = array(
					'id' => 'catalog/contab',
					'name' => $this->language->get( 'text_contab' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/contab', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/contab' ) ) {
				$admdirsis[] = array(
					'id' => 'admdirsis/contab/add',
					'name' => $this->language->get( 'text_debcre' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/contab/add', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/presu' ) ) {
				$admdirsis[] = array(
					'id' => 'admdirsis/presu',
					'name' => $this->language->get( 'text_presu' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/presu', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			//ABC CAJA
			$admdirsis_caja = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/caja' ) ) {
				$admdirsis_caja[] = array(
					'id' => 'admdirsis/caja/add',
					'name' => $this->language->get( 'text_cajaadd' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/caja/add', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
				$admdirsis_caja[] = array(
					'id' => 'admdirsis/contab/caja',
					'name' => $this->language->get( 'text_cajaaddcaja' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/contab/caja', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
				$admdirsis_caja[] = array(
					'id' => 'admdirsis/caja',
					'name' => $this->language->get( 'text_cajainfo' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/caja', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $admdirsis_caja ) {
				$admdirsis[] = array(
					'id' => 'menu-caja',
					'name' => $this->language->get( 'text_caja' ),
					'column' => 1,
					'href' => '',
					'children' => $admdirsis_caja
				);
			}
			$admdirsis_abonados = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/planabono' ) ) {
				$admdirsis_abonados[] = array(
					'id' => 'admdirsis/planabono',
					'name' => $this->language->get( 'text_planabono' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/planabono', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/abono' ) ) {
				$admdirsis_abonados[] = array(
					'id' => 'admdirsis/abono',
					'name' => $this->language->get( 'text_abono' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/abono', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/abonoxdom' ) ) {
				$admdirsis_abonados[] = array(
					'id' => 'admdirsis/abonoxdom',
					'name' => $this->language->get( 'text_abonoxdom' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/abonoxdom', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $admdirsis_abonados ) {
				$admdirsis[] = array(
					'id' => 'admdirsis/abonados',
					'name' => $this->language->get( 'text_abonados' ),
					'column' => 1,
					'href' => '',
					'children' => $admdirsis_abonados
				);
			}
			//ABC DIRSIS
			$admdirsis_abc = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/fpago' ) ) {
				$admdirsis_abc[] = array(
					'id' => 'admdirsis/fpago',
					'name' => $this->language->get( 'text_fpago' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/fpago', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/comprob' ) ) {
				$admdirsis_abc[] = array(
					'id' => 'admdirsis/comprob',
					'name' => $this->language->get( 'text_comprob' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/comprob', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/codiva' ) ) {
				$admdirsis_abc[] = array(
					'id' => 'admdirsis/codiva',
					'name' => $this->language->get( 'text_codiva' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/codiva', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/plataforma' ) ) {
				$admdirsis_abc[] = array(
					'id' => 'admdirsis/plataforma',
					'name' => $this->language->get( 'text_plataforma' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/plataforma', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/precio' ) ) {
				$admdirsis_abc[] = array(
					'id' => 'admdirsis/precio',
					'name' => $this->language->get( 'text_precio' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/precio', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $admdirsis_abc ) {
				$admdirsis[] = array(
					'id' => 'admdirsis/abc',
					'name' => $this->language->get( 'text_abc' ),
					'column' => 1,
					'href' => '',
					'children' => $admdirsis_abc
				);
			}
			//FIN ABC DIRSIS
			if ( $admdirsis ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/admdirsis',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_admdirsis' ),
					'column' => 1,
					'href' => '',
					'children' => $admdirsis
				);
			}

///////////////////////////////////////////////////			
//COBICO
///////////////////////////////////////////////////			
			$erp = array();
//ADMINISTRACION
			$erp_adm = $erp_adm_caja = $erp_adm_abc = array();
			
			$result = $this->definemenu('erp/persona');
			if ($result) { $erp_adm[]=$result; }
			$result = $this->definemenu('erp/contacto');
			if ($result) { $erp_adm[]=$result; }
			$result = $this->definemenu('erp/proveedor');
			if ($result) { $erp_adm[]=$result; }
			
				$result = $this->definemenu('erp/caja');
				if ($result) { $erp_adm_caja[]=$result; }
				$result = $this->definemenu('erp/cajaapertura');
				if ($result) { $erp_adm_caja[]=$result; }
				$result = $this->definemenu('erp/recibo');
				if ($result) { $erp_adm_caja[]=$result; }
				$result = $this->definemenu('erp/conceptodevengado');
				if ($result) { $erp_adm_caja[]=$result; }
				//$result = $this->definemenu('erp/conceptoacobrar');
				//if ($result) { $erp_adm_caja[]=$result; }
				$result = $this->definemenu('erp/conceptoagendado');
				if ($result) { $erp_adm_caja[]=$result; }
				$result = $this->definemenu('ctb/formadepago');
				if ($result) { $erp_adm_abc[]=$result; }			
			
				if ( $erp_adm_caja ) {
					$erp_adm[] = array(
						'name' => $this->language->get( 'text_caja' ),
						'column' => 1,
						'href' => '',
						'children' => $erp_adm_caja
					);
				}			

				$result = $this->definemenu('erp/tipocompr');
				if ($result) { $erp_adm_abc[]=$result; }
			
				$result = $this->definemenu('ctb/ecategoria');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('ctb/tasaiva');
				if ($result) { $erp_adm_abc[]=$result; }
				
				$result = $this->definemenu('ctb/tarjeta');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('ctb/banco');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('ctb/tcheque');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('ctb/echeque');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('ctb/tcuentabc');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/dpto');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/distrito');
				if ($result) { $erp_adm_abc[]=$result; }		
				$result = $this->definemenu('erp/localidad');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/provincia');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/ecivil');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/sexo');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/tipodoc');
				if ($result) { $erp_adm_abc[]=$result; }
				$result = $this->definemenu('erp/nacionalidad');
				if ($result) { $erp_adm_abc[]=$result; }
				if ( $erp_adm_abc ) {
					$erp_adm[] = array(
						'name' => $this->language->get( 'text_abc' ),
						'column' => 1,
						'href' => '',
						'children' => $erp_adm_abc
					);
				}	
			if ( $erp_adm ) {
				$erp[] = array(
					'id' => 'menu/erp/adm',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_erp_adm' ),
					'href' => '',
					'children' => $erp_adm
				);
			}
			
			//MATRICULAS	
			$erp_matricula = $erp_matricula_abc = $erp_autogestion = array();
			
			$result = $this->definemenu('erp/matricula');
			if ($result) { $erp_matricula[]=$result; }
			$result = $this->definemenu('erp/circulo');
			if ($result) { $erp_matricula[]=$result; }

				$result = $this->definemenu('erp/comision');
				if ($result) { $erp_matricula[]=$result; }
				$result = $this->definemenu('erp/organizacion');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/torganizacion');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/categoria');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/motivo');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/trelacion');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('ctb/ulegajo');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/universidad');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/facultad');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/designatitulo');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/condicionflia');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/modflia');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/osocial');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('erp/relacion');
				if ($result) { $erp_matricula_abc[]=$result; }
				$result = $this->definemenu('ctb/condicioniva');
				if ($result) { $erp_matricula_abc[]=$result; }
				if ( $erp_matricula_abc ) {
					$erp_matricula[] = array(
						'name' => $this->language->get( 'text_abc' ),
						'column' => 1,
						'href' => '',
						'children' => $erp_matricula_abc
					);
				}
			if ( $erp_matricula ) {
				$erp[] = array(
					'id' => 'menu/erp/matricula',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_erp_matricula' ),
					'href' => '',
					'children' => $erp_matricula
				);
			}
			

			//LABORATORIO
			$erp_laboratorio = $erp_laboratorio_abc = array();
			
			$result = $this->definemenu('erp/laboratorio');
			if ($result) { $erp_laboratorio[]=$result; }
			$result = $this->definemenu('erp/tlaboratorio');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/elaboratorio');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/categorialab');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/especialidad');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/eespecializacion');
				if ($result) { $erp_laboratorio_abc[]=$result; }			
				$result = $this->definemenu('erp/lcomplejidad');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/area');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/practica');
				if ($result) { $erp_laboratorio_abc[]=$result; }		
				$result = $this->definemenu('erp/modpractica');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/equipo');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/tequipo');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/marca');
				if ($result) { $erp_laboratorio_abc[]=$result; }		
				$result = $this->definemenu('erp/audit');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/resolucion');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/plantilla');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('erp/cargo');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('ctb/eauditoria');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('ctb/lmotivo');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('ctb/mespecializacion');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				$result = $this->definemenu('ctb/tactualizacion');
				if ($result) { $erp_laboratorio_abc[]=$result; }
				if ( $erp_laboratorio_abc ) {
					$erp_laboratorio[] = array(
						'name' => $this->language->get( 'text_abc' ),
						'column' => 1,
						'href' => '',
						'children' => $erp_laboratorio_abc
					);
				}			
				//AUTOGESTION
				$result = $this->definemenu('erp/autogestion');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/tmuestra');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/malta');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/mbaja');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/mtramite');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/etramite');
				if ($result) { $erp_autogestion[]=$result; }
				$result = $this->definemenu('erp/tactual');
				if ($result) { $erp_autogestion[]=$result; }			
				if ( $erp_autogestion ) {
					$erp_laboratorio[] = array(
						'name' => $this->language->get( 'text_erp_autogestion' ),
						'column' => 1,
						'href' => '',
						'children' => $erp_autogestion
					);
				}


			if ( $erp_laboratorio ) {
				$erp[] = array(
					'id' => 'menu/erp/laboratorio',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_erp_laboratorio' ),
					'href' => '',
					'children' => $erp_laboratorio
				);
			}

			//TRAMITES
			$erp_tramite = array();
			
			$result = $this->definemenu('erp/tramite');
			if ($result) { $erp_tramite[]=$result; }
			$result = $this->definemenu('erp/mesaentrada');
			if ($result) { $erp_tramite[]=$result; }
	
			if ( $erp_tramite ) {
				$erp[] = array(
					'id' => 'menu/erp/tramite',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_erp_tramite' ),
					'href' => '',
					'children' => $erp_tramite
				);
			}
			
			
			// CONTABILIDAD
			$erp_contable = $erp_contable_abc = array();			
			
			$result = $this->definemenu('ctb/asiento');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/diario');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/mayor');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/balance');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/ejercicio');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/cuenta');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/concepto');
			if ($result) { $erp_contable[]=$result; }
			$result = $this->definemenu('ctb/modulo');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/coeficientertg');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/easiento');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/tcuenta');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/tregistro');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/dminuta');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/rdebito');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/rdebitobc');
				if ($result) { $erp_contable_abc[]=$result; }
				$result = $this->definemenu('ctb/eregistro');
				if ($result) { $erp_contable_abc[]=$result; }
				if ( $erp_contable_abc ) {
					$erp_contable[] = array(
						'id' => 'erp/ctb/abc',
						'icon' => 'fa-cog',
						'name' => $this->language->get( 'text_abc' ),
						'href' => '',
						'children' => $erp_contable_abc
					);
				}
			if ( $erp_contable ) {
				$erp[] = array(
					'id' => 'erp/ctb',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_ctb' ),
					'href' => '',
					'children' => $erp_contable
				);
			}
			// Users
			$erp_user = array();
			$result = $this->definemenu('user/user');
			if ($result) { $erp_user[]=$result; }
			$result = $this->definemenu('user/user_permission');
			if ($result) { $erp_user[]=$result; }
			if ( $erp_user ) {
				$erp[] = array(
					'id' => 'menu/erp/user',
					'icon' => 'fa-cog',
					'name' => $this->language->get( 'text_users' ),
					'href' => '',
					'children' => $erp_user
				);
			}			

//GENERAL	
			if ( $nivel==0 ) {
			if ( $erp ) {
				$data[ 'menus' ][] = array(
					'id' => 'erp',
					'icon' => 'fa-user',
					'name' => $this->language->get( 'text_erp' ),
					'column' => 1,
					'href' => '',
					'children' => $erp
				);
			}
			}

/////////////////////////////////////
//			FIN COBICO
////////////////////////////////////				
			
			//TURNO
			$turno = array();
			if ( $this->user->hasPermission( 'access', 'rmadirsis/profesional' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/profesional',
					'name' => $this->language->get( 'text_profesional' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/profesional', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/servicio' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/servicio',
					'name' => $this->language->get( 'text_servicio' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/servicio', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/customer' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/customer',
					'name' => $this->language->get( 'text_paciente' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/customer', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/calendario' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/calendario',
					'name' => $this->language->get( 'text_calendario' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/calendario', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/agenda' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/agenda',
					'name' => $this->language->get( 'text_agenda' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/agenda', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/miturno' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/miturno',
					'name' => $this->language->get( 'text_miturno' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/miturno', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/aviso' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/aviso',
					'name' => $this->language->get( 'text_aviso' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/aviso', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/feriado' ) ) {
				$turno[] = array(
					'id' => 'rmadirsis/feriado',
					'name' => $this->language->get( 'text_feriado' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/feriado', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $turno ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/turno',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_turno' ),
					'column' => 1,
					'href' => '',
					'children' => $turno
				);
			}
			//RMA
			$rma = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/paciente' ) ) {
				$rma[] = array(
					'id' => 'admdirsis/paciente',
					'name' => $this->language->get( 'text_paciente' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/paciente', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/evento' ) ) {
				$rma[] = array(
					'id' => 'rmadirsis/evento',
					'name' => $this->language->get( 'text_evento' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/evento', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
				
			$rmadirsis_abc = array();
			if ( $this->user->hasPermission( 'access', 'rmadirsis/status' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/status',
					'name' => $this->language->get( 'text_status' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/status', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}			
			if ( $this->user->hasPermission( 'access', 'rmadirsis/profesional' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/profesional',
					'name' => $this->language->get( 'text_profesional' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/profesional', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/paciente_group' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'admdirsis/paciente_group',
					'name' => $this->language->get( 'text_paciente_group' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/paciente_group', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/paciente_sgroup' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'admdirsis/paciente_sgroup',
					'name' => $this->language->get( 'text_paciente_sgroup' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/paciente_sgroup', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/servicio' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/servicio',
					'name' => $this->language->get( 'text_servicio' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/servicio', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/diagno' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/diagno',
					'name' => $this->language->get( 'text_diagno' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/diagno', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/tratamiento' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/tratamiento',
					'name' => $this->language->get( 'text_tratamiento' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/tratamiento', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'rmadirsis/formula' ) ) {
				$rmadirsis_abc[] = array(
					'id' => 'rmadirsis/formula',
					'name' => $this->language->get( 'text_formula' ),
					'column' => 1,
					'href' => $this->url->link( 'rmadirsis/formula', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $rmadirsis_abc ) {
				$rma[] = array(
					'name' => $this->language->get( 'text_abc' ),
					'column' => 1,
					'href' => '',
					'children' => $rmadirsis_abc
				);
			}
			if ( $rma ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/rma',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_rma' ),
					'column' => 1,
					'href' => '',
					'children' => $rma
				);
			}
/*	SIN USO		
			//BANCK
			$banco = array();
			if ( $this->user->hasPermission( 'access', 'banco/transmovim' ) ) {
				$banco[] = array(
					'id' => 'banco/transmovim',
					'name' => $this->language->get( 'text_transmovim' ),
					'column' => 1,
					'href' => $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'banco/bankcta' ) ) {
				$banco[] = array(
					'id' => 'banco/bankcta',
					'name' => $this->language->get( 'text_bankcta' ),
					'column' => 1,
					'href' => $this->url->link( 'banco/bankcta', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'banco/repetido' ) ) {
				$banco[] = array(
					'id' => 'banco/repetido',
					'name' => $this->language->get( 'text_repetido' ),
					'column' => 1,
					'href' => $this->url->link( 'banco/repetido', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/tmotivo' ) ) {
				$banco[] = array(
					'id' => 'admdirsis/tmotivo',
					'name' => $this->language->get( 'text_tmotivo' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/tmotivo', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $banco ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/banco',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_bank' ),
					'column' => 1,
					'href' => '',
					'children' => $banco
				);
			}
*/			
/*SIN USO			
			// CRM
			$crm = array();
			if ( $this->user->hasPermission( 'access', 'dirsiscrm/compra' ) ) {
				$crm[] = array(
					'id' => 'dirsiscrm/compra',
					'name' => $this->language->get( 'text_compra' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrm/compra', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrm/proveedor' ) ) {
				$crm[] = array(
					'id' => 'dirsiscrm/proveedor',
					'name' => $this->language->get( 'text_proveedor' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrm/proveedor', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrm/proveedor_group' ) ) {
				$crm[] = array(
					'id' => 'dirsiscrm/proveedor_group',
					'name' => $this->language->get( 'text_proveedor_group' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrm/proveedor_group', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $crm ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu-crm',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_crm' ),
					'column' => 1,
					'href' => '',
					'children' => $crm
				);
			}
*/
/* SIN USO			
			$library = array();
			if ( $this->user->hasPermission( 'access', 'dirsislibrary/product' ) ) {
				$library[] = array(
					'id' => 'dirsislibrary/product',
					'name' => $this->language->get( 'text_libraryitems' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsislibrary/product', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $library ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu-library',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_library' ),
					'column' => 1,
					'href' => '',
					'children' => $library
				);
			}
*/
/* SIN USO			
			// CREDIT
			$credit = array();
			if ( $this->user->hasPermission( 'access', 'dirsiscredito/consultafinanciero' ) ) {
				$credit[] = array(
					'id' => 'dirsiscredito/consultafinanciero',
					'name' => $this->language->get( 'text_consultafinanciero' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscredito/consultafinanciero', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscredito/coeficientecuota' ) ) {
				$credit[] = array(
					'id' => 'dirsiscredito-coeficientecuota',
					'name' => $this->language->get( 'text_coeficientecuota' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscredito/coeficientecuota', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscredito/calculofinanciero' ) ) {
				$credit[] = array(
					'id' => 'dirsiscredito/calculofinanciero',
					'name' => $this->language->get( 'text_calculofinanciero' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscredito/calculofinanciero', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $credit ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/credit',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_credit' ),
					'column' => 1,
					'href' => '',
					'children' => $credit
				);
			}
*/
//////////////////////			
//MPR ENPOLEX
//////////////////////
			
			$mrp = array();
			if ( $this->user->hasPermission( 'access', 'dirsismrp/pr' ) ) {
				$mrp[] = array(
					'id' => 'dirsismrp/pr',
					'name' => $this->language->get( 'text_pr' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsismrp/pr', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsismrp/prstop' ) ) {
				$mrp[] = array(
					'id' => 'dirsismrp/prstop',
					'name' => $this->language->get( 'text_prstop' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsismrp/prstop', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $nivel==1 and $this->user->hasPermission( 'access', 'dirsiscrud/operador' ) ) {
				$mrp[] = array(
					'id' => 'dirsiscrud/operador',
					'name' => $this->language->get( 'text_operador' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/operador', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}			
			if ( $this->user->hasPermission( 'access', 'dirsismrp/ot' ) ) {
				$mrp[] = array(
					'id' => 'dirsismrp/ot',
					'name' => $this->language->get( 'text_ot' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsismrp/ot', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsismrp/es' ) ) {
				$mrp[] = array(
					'id' => 'dirsismrp/es',
					'name' => $this->language->get( 'text_es' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsismrp/es', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			$mrpdirsis_abc = array();
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/sector' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/sector',
					'name' => $this->language->get( 'text_sector' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/sector', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/turno' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/turno',
					'name' => $this->language->get( 'text_turno' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/turno', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/maqui' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/maqui',
					'name' => $this->language->get( 'text_maqui' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/maqui', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/matriz' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud-matriz',
					'name' => $this->language->get( 'text_matriz' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/matriz', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/silo' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/silo',
					'name' => $this->language->get( 'text_silo' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/silo', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/operador' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/operador',
					'name' => $this->language->get( 'text_operador' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/operador', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/equipo' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/equipo',
					'name' => $this->language->get( 'text_equipo' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/equipo', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}	
			
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/manutentor' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/manutentor',
					'name' => $this->language->get( 'text_manutentor' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/manutentor', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}			
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/dispo' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/dispo',
					'name' => $this->language->get( 'text_dispo' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/dispo', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/prstatus' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud-prstatus',
					'name' => $this->language->get( 'text_prstatus' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/prstatus', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/proceso' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/proceso',
					'name' => $this->language->get( 'text_proceso' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/proceso', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/otstatus' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/otstatus',
					'name' => $this->language->get( 'text_otstatus' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/otstatus', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsiscrud/deposito' ) ) {
				$mrpdirsis_abc[] = array(
					'id' => 'dirsiscrud/deposito',
					'name' => $this->language->get( 'text_deposito' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsiscrud/deposito', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
if ($nivel==0){
			if ( $mrpdirsis_abc ) {
				$mrp[] = array(
					'id' => 'menu/mrp/abc',
					'name' => $this->language->get( 'text_crud' ),
					'column' => 1,
					'href' => '',
					'children' => $mrpdirsis_abc
				);
			}
}
			if ( $mrp ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu-mrp',
					'icon' => 'fa-crosshairs',
					'name' => $this->language->get( 'text_mrp' ),
					'column' => 1,
					'href' => '',
					'children' => $mrp
				);
			}
			
///////////////////////////////////			
//MANTENIMIENTO ENPOLEX
//////////////////////////////////			
			
			$mt=array();
			$result = $this->definemenu('dirsiscrud/mtproceso');
			if ($result) { $mt[]=$result; }
		
			$result = $this->definemenu('dirsiscrud/tarea');
			if ($result) { $mt[]=$result; }
			$result = $this->definemenu('dirsiscrud/operador');
			if ($result) { $mt[]=$result; }
			$result = $this->definemenu('dirsiscrud/mtstatus');
			if ($result) { $mt[]=$result; }
			$result = $this->definemenu('dirsiscrud/ciclico');
			if ($result) { $mt[]=$result; }
			$result = $this->definemenu('dirsiscrud/defecto');
			if ($result) { $mt[]=$result; }
			
if ($nivel==0){
			if ( $mt ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu-mt',
					'icon' => 'fa-crosshairs',
					'name' => $this->language->get( 'text_mt' ),
					'column' => 1,
					'href' => '',
					'children' => $mt
				);
			}	
}
///////////////////////////////////			
//FIN MANTENIMIENTO ENPOLEX
//////////////////////////////////				
			
			
			// MELI
			$meli = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/mlconsulta' ) ) {
				$meli[] = array(
					'id' => 'admdirsis/mlconsulta',
					'name' => $this->language->get( 'text_consultorio' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/mlconsulta', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/preyfirma' ) ) {
				$meli[] = array(
					'id' => 'admdirsis/preyfirma',
					'name' => $this->language->get( 'text_preyfirma' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/preyfirma', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsismeli/product' ) ) {
				$meli[] = array(
					'id' => 'dirsismeli/product',
					'name' => $this->language->get( 'text_mlpublicado' ),
					'column' => 1,
					'href' => $this->url->link( 'dirsismeli/product', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/mlcompetencia' ) ) {
				$meli[] = array(
					'id' => 'admdirsis/mlcompetencia',
					'name' => $this->language->get( 'text_mlcompetencia' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/mlcompetencia', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $meli ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/meli',
					'icon' => 'fa-bar-chart-o',
					'name' => $this->language->get( 'text_meli' ),
					'column' => 1,
					'href' => '',
					'children' => $meli
				);
			}
			
/* SIN USO			
			//ENCUESTAS
			$encuesta = array();
			if ( $this->user->hasPermission( 'access', 'admdirsis/encuesta' ) ) {
				$encuesta[] = array(
					'id' => 'admdirsis/encuesta',
					'name' => $this->language->get( 'text_encuesta' ),
					'href' => $this->url->link( 'admdirsis/encuesta', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'dirsisturno/banner' ) ) {
				$encuesta[] = array(
					'id' => 'dirsisturno/banner',
					'name' => $this->language->get( 'text_banner' ),
					'href' => $this->url->link( 'dirsisturno/banner', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/encuestahistoria' ) ) {
				$encuesta[] = array(
					'id' => 'admdirsis/encuestahistoria',
					'name' => $this->language->get( 'text_encuestahistoria' ),
					'href' => $this->url->link( 'admdirsis/encuestahistoria', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/encuestaconsola' ) ) {
				$encuesta[] = array(
					'id' => 'admdirsis/encuestaconsola',
					'name' => $this->language->get( 'text_encuestaconsola' ),
					'href' => $this->url->link( 'admdirsis/encuestaconsola', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $encuesta ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/encuesta',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_encuesta' ),
					'href' => '',
					'children' => $encuesta
				);
			}
*/			
			
///////////////////////////////////////////////////////////////
////////////ORIGINAL
			
			
			
			// Catalog
			$catalog = array();
			if ( $this->user->hasPermission( 'access', 'catalog/category' ) ) {
				$catalog[] = array(
					'id' => 'catalog/category',
					'name' => $this->language->get( 'text_category' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/category', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/product' ) ) {
				$catalog[] = array(
					'id' => 'catalog/product',
					'name' => $this->language->get( 'text_product' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/product', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/comixcant' ) ) {
				$catalog[] = array(
					'id' => 'catalog-comixcant',
					'name' => $this->language->get( 'text_comixcant' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/comixcant', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/nproduct' ) ) {
				$catalog[] = array(
					'id' => 'catalog/nproduct',
					'name' => $this->language->get( 'text_nproduct' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/nproduct', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/stock' ) ) {
				$catalog[] = array(
					'id' => 'catalog-stock',
					'name' => $this->language->get( 'text_ctrlstock' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/stock', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/artconsulta' ) ) {
				$catalog[] = array(
					'id' => 'catalog-artconsulta',
					'name' => $this->language->get( 'text_artconsulta' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/artconsulta', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}			
			if ( $this->user->hasPermission( 'access', 'catalog/recurring' ) ) {
				$catalog[] = array(
					'id' => 'catalog/recurring',
					'name' => $this->language->get( 'text_recurring' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/recurring', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/filter' ) ) {
				$catalog[] = array(
					'id' => 'catalog/filter',
					'name' => $this->language->get( 'text_filter' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/filter', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			// Attributes
			$attribute = array();
			if ( $this->user->hasPermission( 'access', 'catalog/attribute' ) ) {
				$attribute[] = array(
					'id' => 'catalog/attribute',
					'name' => $this->language->get( 'text_attribute' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/attribute', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/attribute_group' ) ) {
				$attribute[] = array(
					'id' => 'catalog/attribute_group',
					'name' => $this->language->get( 'text_attribute_group' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/attribute_group', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $attribute ) {
				$catalog[] = array(
					'id' => 'menu/attribute',
					'name' => $this->language->get( 'text_attribute' ),
					'column' => 1,
					'href' => '',
					'children' => $attribute
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/option' ) ) {
				$catalog[] = array(
					'id' => 'catalog/option',
					'name' => $this->language->get( 'text_option' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/option', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/manufacturer' ) ) {
				$catalog[] = array(
					'id' => 'catalog/manufacturer',
					'name' => $this->language->get( 'text_manufacturer' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/manufacturer', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/download' ) ) {
				$catalog[] = array(
					'id' => 'catalog/download',
					'name' => $this->language->get( 'text_download' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/download', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/review' ) ) {
				$catalog[] = array(
					'id' => 'catalog/review',
					'name' => $this->language->get( 'text_review' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/review', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/opinion' ) ) {
				$catalog[] = array(
					'id' => 'catalog/opinion',
					'name' => $this->language->get( 'text_opinion' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/opinion', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/information' ) ) {
				$catalog[] = array(
					'id' => 'catalog/information',
					'name' => $this->language->get( 'text_information' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/information', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $catalog ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/catalog',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_catalog' ),
					'column' => 1,
					'href' => '',
					'children' => $catalog
				);
			}
			if ( $this->user->hasPermission( 'access', 'catalog/information' ) ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/inform',
					'icon' => 'fa-tags',
					'name' => $this->language->get( 'text_information' ),
					'column' => 1,
					'href' => $this->url->link( 'catalog/information', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			
			// Customer
			$customer = array();
			if ( $this->user->hasPermission( 'access', 'customer/customer' ) ) {
				$customer[] = array(
					'id' => 'customer/customer',
					'name' => $this->language->get( 'text_customer' ),
					'column' => 1,
					'href' => $this->url->link( 'customer/customer', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'customer/address' ) ) {
				$customer[] = array(
					'id' => 'customer/address',
					'name' => $this->language->get( 'text_address' ),
					'column' => 1,
					'href' => $this->url->link( 'customer/address', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'customer/customer_group' ) ) {
				$customer[] = array(
					'id' => 'customer/customer_group',
					'name' => $this->language->get( 'text_customer_group' ),
					'column' => 1,
					'href' => $this->url->link( 'customer/customer_group', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'customer/customer_approval' ) ) {
				$customer[] = array(
					'id' => 'customer/customer_approval',
					'name' => $this->language->get( 'text_customer_approval' ),
					'column' => 1,
					'href' => $this->url->link( 'customer/customer_approval', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'customer/custom_field' ) ) {
				$customer[] = array(
					'id' => 'customer/custom_field',
					'name' => $this->language->get( 'text_custom_field' ),
					'href' => $this->url->link( 'customer/custom_field', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $customer ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/customer',
					'icon' => 'fa-user',
					'name' => $this->language->get( 'text_customer' ),
					'column' => 1,
					'href' => '',
					'children' => $customer
				);
			}			
			
			
			
			
			// Sales
			$sale = array();
			if ( $this->user->hasPermission( 'access', 'sale/order' ) ) {
				$sale[] = array(
					'id' => 'sale/order',
					'name' => $this->language->get( 'text_order' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/order', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'sale/abando' ) ) {
				$sale[] = array(
					'id' => 'sale/abando',
					'name' => $this->language->get( 'text_abando' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/abando', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/reparto' ) ) {
				$sale[] = array(
					'id' => 'admdirsis/reparto',
					'name' => $this->language->get( 'text_reparto' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/reparto', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'sale/orderxmanu' ) ) {
				$sale[] = array(
					'id' => 'sale/orderxmanu',
					'name' => $this->language->get( 'text_orderxmanu' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/orderxmanu', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'sale/recurring' ) ) {
				$sale[] = array(
					'id' => 'sale/recurring',
					'name' => $this->language->get( 'text_recurring' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/recurring', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'sale/return' ) ) {
				$sale[] = array(
					'id' => 'sale/return',
					'name' => $this->language->get( 'text_return' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/return', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			// Voucher
			$voucher = array();
			if ( $this->user->hasPermission( 'access', 'sale/voucher' ) ) {
				$voucher[] = array(
					'id' => 'sale/voucher',
					'name' => $this->language->get( 'text_voucher' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/voucher', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'sale/voucher_theme' ) ) {
				$voucher[] = array(
					'id' => 'sale/voucher_theme',
					'name' => $this->language->get( 'text_voucher_theme' ),
					'column' => 1,
					'href' => $this->url->link( 'sale/voucher_theme', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $voucher ) {
				$sale[] = array(
					'id' => 'menu/voucher',
					'name' => $this->language->get( 'text_voucher' ),
					'column' => 1,
					'href' => '',
					'children' => $voucher
				);
			}
			$reportsale = array();
			if ( $this->user->hasPermission( 'access', 'report/report' ) ) {
				$reportsale[] = array(
					'id' => 'report/report',
					'name' => $this->language->get( 'text_reports' ),
					'column' => 1,
					'href' => $this->url->link( 'report/report', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'report/online' ) ) {
				$reportsale[] = array(
					'id' => 'report/online',
					'name' => $this->language->get( 'text_online' ),
					'column' => 1,
					'href' => $this->url->link( 'report/online', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'report/statistics' ) ) {
				$reportsale[] = array(
					'id' => 'report/statistics',
					'name' => $this->language->get( 'text_statistics' ),
					'column' => 1,
					'href' => $this->url->link( 'report/statistics', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $sale ) {
				if ( $reportsale ) {
					$sale[] = array(
						'id' => 'menu/sale/report',
						'name' => $this->language->get( 'text_reports' ),
						'column' => 1,
						'href' => '',
						'children' => $reportsale
					);
				}
				$data[ 'menus' ][] = array(
					'id' => 'menu/sale',
					'icon' => 'fa-shopping-cart',
					'name' => $this->language->get( 'text_sale' ),
					'column' => 1,
					'href' => '',
					'children' => $sale
				);
			}
			// Marketing
			$marketing = array();
			if ( $this->user->hasPermission( 'access', 'marketing/marketing' ) ) {
				$marketing[] = array(
					'id' => 'marketing/marketing',
					'name' => $this->language->get( 'text_marketing' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/marketing', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'marketing/coupon' ) ) {
				$marketing[] = array(
					'id' => 'marketing/coupon',
					'name' => $this->language->get( 'text_coupon' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/coupon', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'marketing/contact' ) ) {
				$marketing[] = array(
					'id' => 'marketing/contact',
					'name' => $this->language->get( 'text_contact' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/contact', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'admdirsis/discountlabel' ) ) {
				$marketing[] = array(
					'id' => 'admdirsis/discountlabel',
					'name' => $this->language->get( 'text_discountlabel' ),
					'column' => 1,
					'href' => $this->url->link( 'admdirsis/discountlabel', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'marketing/ganador' ) ) {
				$marketing[] = array(
					'id' => 'marketing/ganador',
					'name' => $this->language->get( 'text_ganador' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/ganador', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}		
			if ( $this->user->hasPermission( 'access', 'marketing/concurso' ) ) {
				$marketing[] = array(
					'id' => 'marketing/concurso',
					'name' => $this->language->get( 'text_concurso' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/concurso', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}	
			if ( $this->user->hasPermission( 'access', 'marketing/sucursal' ) ) {
				$marketing[] = array(
					'id' => 'marketing/sucursal',
					'name' => $this->language->get( 'text_sucursal' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/sucursal', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'marketing/cumple' ) ) {
				$marketing[] = array(
					'id' => 'marketing/cumple',
					'name' => $this->language->get( 'text_cumple' ),
					'column' => 1,
					'href' => $this->url->link( 'marketing/cumple', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}			
			if ( $marketing ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/marketing',
					'icon' => 'fa-share-alt',
					'name' => $this->language->get( 'text_marketing' ),
					'column' => 1,
					'href' => '',
					'children' => $marketing
				);
			}
			
			// Extension
			$marketplace = array();
			/*
			if ($this->user->hasPermission('access', 'marketplace/marketplace')) {		
					$marketplace[] = array(
						'id'       => 'marketplace/marketplace',
						'name'	   => $this->language->get('text_marketplace'),
						'href'     => $this->url->link('marketplace/marketplace', 'user_token=' . $this->session->data['user_token'], true),
						'children' => array()		
					);					
				}
			*/
			/*
			if ($this->user->hasPermission('access', 'marketplace/installer')) {		
					$marketplace[] = array(
						'id'       => 'marketplace/installer',
						'name'	   => $this->language->get('text_installer'),
						'href'     => $this->url->link('marketplace/installer', 'user_token=' . $this->session->data['user_token'], true),
						'children' => array()		
					);					
				}	
			*/
			if ( $this->user->hasPermission( 'access', 'marketplace/extension' ) ) {
				$marketplace[] = array(
					'id' => 'marketplace/extension',
					'name' => $this->language->get( 'text_extension' ),
					'href' => $this->url->link( 'marketplace/extension', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'marketplace/modification' ) ) {
				$marketplace[] = array(
					'id' => 'marketplace/modification',
					'name' => $this->language->get( 'text_modification' ),
					'href' => $this->url->link( 'marketplace/modification', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			/*
			if ($this->user->hasPermission('access', 'marketplace/event')) {
					$marketplace[] = array(
						'id'       => 'marketplace/event',
						'name'	   => $this->language->get('text_event'),
						'href'     => $this->url->link('marketplace/event', 'user_token=' . $this->session->data['user_token'], true),
						'children' => array()		
					);
				}
			*/
			if ( $marketplace ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/extension',
					'icon' => 'fa-puzzle-piece',
					'name' => $this->language->get( 'text_extension' ),
					'href' => '',
					'children' => $marketplace
				);
			}
			// Design
			$design = array();
			if ( $this->user->hasPermission( 'access', 'design/layout' ) ) {
				$design[] = array(
					'id' => 'design/layout',
					'name' => $this->language->get( 'text_layout' ),
					'href' => $this->url->link( 'design/layout', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'design/theme' ) ) {
				$design[] = array(
					'id' => 'design/themek',
					'name' => $this->language->get( 'text_theme' ),
					'href' => $this->url->link( 'design/theme', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'design/translation' ) ) {
				$design[] = array(
					'id' => 'design/translation',
					'name' => $this->language->get( 'text_language_editor' ),
					'href' => $this->url->link( 'design/translation', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'design/banner' ) ) {
				$design[] = array(
					'id' => 'design/banner',
					'name' => $this->language->get( 'text_banner' ),
					'href' => $this->url->link( 'design/banner', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
			if ( $this->user->hasPermission( 'access', 'design/seo_url' ) ) {
				$design[] = array(
					'id' => 'design/seo_url',
					'name' => $this->language->get( 'text_seo_url' ),
					'href' => $this->url->link( 'design/seo_url', 'user_token=' . $this->session->data[ 'user_token' ], true ),
					'children' => array()
				);
			}
if ( $nivel==0 ) {			
			if ( $design ) {
				$data[ 'menus' ][] = array(
					'id' => 'menu/design',
					'icon' => 'fa-television',
					'name' => $this->language->get( 'text_design' ),
					'href' => '',
					'children' => $design
				);
			}
}
			if ( $nivel == 0 ) {
				// System
				$system = array();
				if ( $this->user->hasPermission( 'access', 'setting/setting' ) ) {
					$system[] = array(
						'id' => 'setting/setting',
						'name' => $this->language->get( 'text_setting' ),
						'href' => $this->url->link( 'setting/store', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				// Users
				$user = array();
				if ( $this->user->hasPermission( 'access', 'user/user' ) ) {
					$user[] = array(
						'id' => 'user/user',
						'name' => $this->language->get( 'text_users' ),
						'href' => $this->url->link( 'user/user', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'user/user_permission' ) ) {
					$user[] = array(
						'id' => 'user/user_permission',
						'name' => $this->language->get( 'text_user_group' ),
						'href' => $this->url->link( 'user/user_permission', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'user/api' ) ) {
					$user[] = array(
						'id' => 'user/api',
						'name' => $this->language->get( 'text_api' ),
						'href' => $this->url->link( 'user/api', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $user ) {
					$system[] = array(
						'id' => 'menu/user',
						'name' => $this->language->get( 'text_users' ),
						'href' => '',
						'children' => $user
					);
				}
				// Localisation
				$localisation = array();
				if ( $this->user->hasPermission( 'access', 'localisation/location' ) ) {
					$localisation[] = array(
						'id' => 'localisation/location',
						'name' => $this->language->get( 'text_location' ),
						'href' => $this->url->link( 'localisation/location', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/language' ) ) {
					$localisation[] = array(
						'id' => 'localisation/language',
						'name' => $this->language->get( 'text_language' ),
						'href' => $this->url->link( 'localisation/language', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/currency' ) ) {
					$localisation[] = array(
						'id' => 'localisation/currency',
						'name' => $this->language->get( 'text_currency' ),
						'href' => $this->url->link( 'localisation/currency', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/stock_status' ) ) {
					$localisation[] = array(
						'id' => 'localisation/stock_status',
						'name' => $this->language->get( 'text_stock_status' ),
						'href' => $this->url->link( 'localisation/stock_status', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/order_status' ) ) {
					$localisation[] = array(
						'id' => 'localisation/order_status',
						'name' => $this->language->get( 'text_order_status' ),
						'href' => $this->url->link( 'localisation/order_status', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/factura_status' ) ) {
					$localisation[] = array(
						'id' => 'localisation/factura_status',
						'name' => $this->language->get( 'text_factura_status' ),
						'href' => $this->url->link( 'localisation/factura_status', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				// Returns
				$return = array();
				if ( $this->user->hasPermission( 'access', 'localisation/return_status' ) ) {
					$return[] = array(
						'id' => 'localisation/return_status',
						'name' => $this->language->get( 'text_return_status' ),
						'href' => $this->url->link( 'localisation/return_status', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/return_action' ) ) {
					$return[] = array(
						'id' => 'localisation/return_action',
						'name' => $this->language->get( 'text_return_action' ),
						'href' => $this->url->link( 'localisation/return_action', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/return_reason' ) ) {
					$return[] = array(
						'id' => 'localisation/return_reason',
						'name' => $this->language->get( 'text_return_reason' ),
						'href' => $this->url->link( 'localisation/return_reason', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $return ) {
					$localisation[] = array(
						'id' => 'menu/return',
						'name' => $this->language->get( 'text_return' ),
						'href' => '',
						'children' => $return
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/country' ) ) {
					$localisation[] = array(
						'id' => 'localisation/country',
						'name' => $this->language->get( 'text_country' ),
						'href' => $this->url->link( 'localisation/country', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/zone' ) ) {
					$localisation[] = array(
						'id' => 'localisation/zone',
						'name' => $this->language->get( 'text_zone' ),
						'href' => $this->url->link( 'localisation/zone', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/geo_zone' ) ) {
					$localisation[] = array(
						'id' => 'localisation/geo_zone',
						'name' => $this->language->get( 'text_geo_zone' ),
						'href' => $this->url->link( 'localisation/geo_zone', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				// Tax		
				$tax = array();
				if ( $this->user->hasPermission( 'access', 'localisation/tax_class' ) ) {
					$tax[] = array(
						'id' => 'localisation/tax_class',
						'name' => $this->language->get( 'text_tax_class' ),
						'href' => $this->url->link( 'localisation/tax_class', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/tax_rate' ) ) {
					$tax[] = array(
						'id' => 'localisation/tax_rate',
						'name' => $this->language->get( 'text_tax_rate' ),
						'href' => $this->url->link( 'localisation/tax_rate', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $tax ) {
					$localisation[] = array(
						'id' => 'menu/tax',
						'name' => $this->language->get( 'text_tax' ),
						'href' => '',
						'children' => $tax
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/length_class' ) ) {
					$localisation[] = array(
						'id' => 'localisation/length_class',
						'name' => $this->language->get( 'text_length_class' ),
						'href' => $this->url->link( 'localisation/length_class', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'localisation/weight_class' ) ) {
					$localisation[] = array(
						'id' => 'localisation/weight_class',
						'name' => $this->language->get( 'text_weight_class' ),
						'href' => $this->url->link( 'localisation/weight_class', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $localisation ) {
					$system[] = array(
						'id' => 'menu-locatisation',
						'name' => $this->language->get( 'text_localisation' ),
						'href' => '',
						'children' => $localisation
					);
				}
				
				
				
				// Tools	
				$maintenance = array();
				if ( $this->user->hasPermission( 'access', 'tool/backup' ) ) {
					$maintenance[] = array(
						'id' => 'tool/backup',
						'name' => $this->language->get( 'text_backup' ),
						'href' => $this->url->link( 'tool/backup', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'extension/export_import' ) ) {
					$maintenance[] = array(
						'id' => 'extension/export_import',
						'name' => $this->language->get( 'text_export_import' ),
						'href' => $this->url->link( 'extension/export_import', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'tool/upload' ) ) {
					$maintenance[] = array(
						'id' => 'tool/upload',
						'name' => $this->language->get( 'text_upload' ),
						'href' => $this->url->link( 'tool/upload', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $this->user->hasPermission( 'access', 'tool/log' ) ) {
					$maintenance[] = array(
						'id' => 'tool/log',
						'name' => $this->language->get( 'text_log' ),
						'href' => $this->url->link( 'tool/log', 'user_token=' . $this->session->data[ 'user_token' ], true ),
						'children' => array()
					);
				}
				if ( $maintenance ) {
					$system[] = array(
						'id' => 'menu/maintenance',
						'icon' => 'fa-cog',
						'name' => $this->language->get( 'text_maintenance' ),
						'href' => '',
						'children' => $maintenance
					);
				}
				if ( $system ) {
					$data[ 'menus' ][] = array(
						'id' => 'menu/system',
						'icon' => 'fa-cog',
						'name' => $this->language->get( 'text_system' ),
						'href' => '',
						'children' => $system
					);
				}
			}
			return $data;
		}
	}
	
	public function definemenu($id) {
		$result=array();
		if ( $this->user->hasPermission( 'access', $id ) ) {
			$result = array(
				'id' => $id,
				'icon' => 'fa-cog',
				'name' => $this->language->get( 'text_'.str_replace("/", "_", $id)),
				'column' => 1,
				'href' => $this->url->link( $id, 'user_token=' . $this->session->data[ 'user_token' ], true ),
				'children' => array()
			);
		}		
		return $result;
	}
	
}