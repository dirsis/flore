<?php
class ControllerPkdirsisPpstdownload extends Controller {
	private $error = array();
	public function add() {
		$this->load->language('pkdirsis/ppstdownload');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getForm();
	}
	protected function getForm() {
		if (isset($this->error['filename'])) {
			$data['error_filename'] = $this->error['filename'];
		} else {
			$data['error_filename'] = '';
		}		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('pkdirsis/ppstdownload', 'user_token=' . $this->session->data['user_token'] , true)
		);
		/*
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->get['ppstdownload_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$ppstdownload_info = $this->model_pkdirsis_ppstdownload->getPpstdownload($this->request->get['ppstdownload_id']);
		}
		*/

		$data['user_token'] = $this->session->data['user_token'];

		/*
		if (isset($this->request->get['ppstdownload_id'])) {
			$data['ppstdownload_id'] = $this->request->get['ppstdownload_id'];
		} else {
			$data['ppstdownload_id'] = 0;
		}

		if (isset($this->request->post['ppstdownload_description'])) {
			$data['ppstdownload_description'] = $this->request->post['ppstdownload_description'];
		} elseif (isset($this->request->get['ppstdownload_id'])) {
			$data['ppstdownload_description'] = $this->model_pkdirsis_ppstdownload->getPpstdownloadDescriptions($this->request->get['ppstdownload_id']);
		} else {
			$data['ppstdownload_description'] = array();
		}
		*/

		if (isset($this->request->post['filename'])) {
			$data['filename'] = $this->request->post['filename'];
		} elseif (!empty($ppstdownload_info)) {
			$data['filename'] = $ppstdownload_info['filename'];
		} else {
			$data['filename'] = '';
		}

		$data['mask3'] = $this->config->get('config_valor_fecha_ppst');		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		//print_r(__DIR__);
		$data['uploads']=array();
		$ruta="dirsis/upload_ppst";
		if (is_dir($ruta)){
			$gestor = opendir($ruta);
			while (($archivo = readdir($gestor)) !== false)  {
				$ruta_completa = $ruta . "/" . $archivo;
				if ($archivo != "." && $archivo != "..") {
					if (is_dir($ruta_completa)) {
					} else {
                    	$data['uploads'][]= $archivo;
                	}
            	}
        	}
        	closedir($gestor);
		}
		arsort($data['uploads']);

		$this->response->setOutput($this->load->view('pkdirsis/ppstdownload_form', $data));
	}
}