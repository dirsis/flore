<?php
class ControllerPkdirsisPpsrdownload extends Controller {
	private $error = array();
	public function add() {
		$this->load->language('pkdirsis/ppsrdownload');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getForm();
	}
	protected function getForm() {
		if (isset($this->error['filename'])) {
			$data['error_filename'] = $this->error['filename'];
		} else {
			$data['error_filename'] = '';
		}		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('pkdirsis/ppsrdownload', 'user_token=' . $this->session->data['user_token'] , true)
		);
		/*
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->get['ppsrdownload_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$ppsrdownload_info = $this->model_pkdirsis_ppsrdownload->getPpsrdownload($this->request->get['ppsrdownload_id']);
		}
		*/

		$data['user_token'] = $this->session->data['user_token'];

		/*
		if (isset($this->request->get['ppsrdownload_id'])) {
			$data['ppsrdownload_id'] = $this->request->get['ppsrdownload_id'];
		} else {
			$data['ppsrdownload_id'] = 0;
		}

		if (isset($this->request->post['ppsrdownload_description'])) {
			$data['ppsrdownload_description'] = $this->request->post['ppsrdownload_description'];
		} elseif (isset($this->request->get['ppsrdownload_id'])) {
			$data['ppsrdownload_description'] = $this->model_pkdirsis_ppsrdownload->getPpsrdownloadDescriptions($this->request->get['ppsrdownload_id']);
		} else {
			$data['ppsrdownload_description'] = array();
		}
		*/

		if (isset($this->request->post['filename'])) {
			$data['filename'] = $this->request->post['filename'];
		} elseif (!empty($ppsrdownload_info)) {
			$data['filename'] = $ppsrdownload_info['filename'];
		} else {
			$data['filename'] = '';
		}

		$data['mask3'] = $this->config->get('config_valor_fecha_ppsr');		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		//print_r(__DIR__);
		$data['uploads']=array();
		$ruta="dirsis/upload_ppsr";
		if (is_dir($ruta)){
			$gestor = opendir($ruta);
			while (($archivo = readdir($gestor)) !== false)  {
				$ruta_completa = $ruta . "/" . $archivo;
				if ($archivo != "." && $archivo != "..") {
					if (is_dir($ruta_completa)) {
					} else {
                    	$data['uploads'][]= $archivo;
                	}
            	}
        	}
        	closedir($gestor);
		}
		arsort($data['uploads']);

		$this->response->setOutput($this->load->view('pkdirsis/ppsrdownload_form', $data));
	}
}