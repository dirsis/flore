<?php
class ControllerPkdirsisPpstestadi extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('pkdirsis/ppstestadi');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('pkdirsis/ppstestadi');

		$this->getList();
		
	}
	
	public function enviaexcelacero() {
		$this->load->model('pkdirsis/ppstestadi');
		$this->model_pkdirsis_ppstestadi->enviaexcelacero();
	}	
	
	public function editenviar_jugador() {
		$this->load->model('pkdirsis/ppstestadi');
		$id_jugador=$this->request->get['id_jugador'];
		$estado=$this->request->get['estado'];
		$resul = $this->model_pkdirsis_ppstestadi->editEnviar_jugador($id_jugador,$estado);
		echo $resul;
	}
	
	public function actualizarestadoclub() {
		$this->load->model('pkdirsis/ppstestadi');
		$valor=$this->request->get['id'];
		$resul = $this->model_pkdirsis_ppstestadi->editEstadoClub($valor);
		echo $resul;
	}
	
	public function generarexcel() {
			$recorre=0;
			if (isset($this->request->get['filter_memo'])) {
				$recorre++;
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$recorre++;
				$filter_ppst_club = $this->request->get['filter_ppst_club'];
			} else {
				$filter_ppst_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$recorre++;
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$recorre++;
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$recorre++;
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}		
			if (isset($this->request->get['filter_apodo'])) {
				$recorre++;
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$recorre++;
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$recorre++;
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$recorre++;
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$recorre++;
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$recorre++;
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$recorre++;
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
			if (isset($this->request->get['filter_status'])) {
				$recorre++;
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$recorre++;
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = " ";
			}		
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'id_jugador, fecha, ganancia';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
		
			if ($recorre==0){
				$filter_status = '2';
			}

			$filter_data = array(
				'filter_memo'			=> $filter_memo,
				'filter_ppst_club'		=> $filter_ppst_club,
				'filter_ganancia'	  	=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		=> $filter_agrupar,
			);
			$this->load->model('pkdirsis/ppstestadi');
			$results = $this->model_pkdirsis_ppstestadi->getGenerarexcel($filter_data);
		
			$data['products']=array();
		
			$ganancia=0;
			$entrada=0;
			
			foreach ($results as $result) {
				$data['products'][] = array(
					'fecha' 		=> $result['fecha'],
					'ppst_club' 	=> $result['ppst_club'],
					'juego' 		=> isset($result['juego'])?$result['juego']:'',
					'id_club' 		=> $result['id_club'],
					'name_club' 	=> $result['name_club'],
					'id_jugador' 	=> $result['id_jugador'],
					'apodo' 		=> $result['apodo'],
					'entrada' 		=> number_format($result['entrada'],2),
					'ranking' 		=> $result['ranking'],
					'ganancia'   	=> number_format($result['ganancia'],2),
					'minijuego'   	=> isset($result['minijuego'])?$result['minijuego']:'',
					'total'   	=> number_format($result['total'],2)
				);
				$ganancia=$ganancia+$result['ganancia'];
				$entrada=$entrada+$result['entrada'];
			}			
			//----------------------------------
				require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
				$objPHPExcel = new PHPExcel();
				$objPHPExcel->
				getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
				/* Datos Hojas */
				$row=2;
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A'.$row, 'Fecha')
						->setCellValue('B'.$row, 'Ppst Club')
						->setCellValue('C'.$row, 'Juego')
						->setCellValue('D'.$row, 'Id Club')
						->setCellValue('E'.$row, 'Nombre Club')
						->setCellValue('F'.$row, 'Id Jugador')
						->setCellValue('G'.$row, 'Apodo')
						->setCellValue('H'.$row, 'Cuotas')
						->setCellValue('I'.$row, 'Ranking')
						->setCellValue('J'.$row, 'Ganancia')
						->setCellValue('K'.$row, 'Total');		
		
				if ($filter_memo!='0'){
					$objPHPExcel->getActiveSheet()->getStyle('A'.$row.':K'.$row)->getFill()->applyFromArray(array('type' => PHPExcel_Style_Fill::FILL_SOLID,'startcolor' => array( 'rgb' => 'F28A8C')));
				}
		
		
				$row++;
				$id_jugador='';
				$acum=0;
				$gana=0;
				$entr=0;
		
				$ganaf=0;
				$entrf=0;		
		
				foreach ($results as $result) {
					if ($filter_memo!='0' and $acum!=0){
						if ($id_jugador<>$result['id_jugador']){
							$objPHPExcel->getActiveSheet()->getStyle('A'.$row.':K'.$row)->getFill()->applyFromArray(array('type' => PHPExcel_Style_Fill::FILL_SOLID,'startcolor' => array( 'rgb' => 'F28A8C')));						
							$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('G'.$row,  'SUBTOTAL:')
							->setCellValue('H'.$row,  round($entr,2))
							->setCellValue('J'.$row,  round($gana,2))
							->setCellValue('K'.$row,  round($acum,2));
							$row++;
							$acum=0;
							$gana=0;
							$entr=0;
						}
					}
					$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row, $result['fecha'])
					->setCellValue('B'.$row,  $result['ppst_club'])
					->setCellValue('C'.$row,  isset($result['juego'])?$result['juego']:'')
					->setCellValue('D'.$row,  $result['id_club'])
					->setCellValue('E'.$row,  $result['name_club'])
					->setCellValue('F'.$row,  $result['id_jugador'])
					->setCellValue('G'.$row,  $result['apodo'])
					->setCellValue('H'.$row,  round($result['entrada'],2))
					->setCellValue('I'.$row,  $result['ranking'])
					->setCellValue('J'.$row,  round($result['ganancia'],2))
					->setCellValue('K'.$row,  round($result['total'],2));						
					$acum=$acum+$result['total'];
					$gana=$gana+$result['ganancia'];
					$entr=$entr+$result['entrada'];
					$id_jugador=$result['id_jugador'];
					
					$ganaf=$ganaf+$result['ganancia'];
					$entrf=$entrf+$result['entrada'];
					$row++;
				}
							$objPHPExcel->getActiveSheet()->getStyle('A'.$row.':K'.$row)->getFill()->applyFromArray(array('type' => PHPExcel_Style_Fill::FILL_SOLID,'startcolor' => array( 'rgb' => 'F28A8C')));						
							$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('G'.$row,  'SUBTOTAL:')
							->setCellValue('H'.$row,  round($entr,2))
							->setCellValue('J'.$row,  round($gana,2))
							->setCellValue('K'.$row,  round($acum,2));
							$row++;

		
				$row2=$row+2;
		
				$objPHPExcel->getActiveSheet()->setCellValue('G'.$row2, "TOTALES")
                            ->setCellValue('H'.$row2, round($entrf,2))
							->setCellValue('J'.$row2, round($ganaf,2))
							->setCellValue('K'.$row2, round($entrf+$ganaf,2));		

				/*Nombre de la página*/
				$objPHPExcel->getActiveSheet()->setTitle('SuperUnion');
				$objPHPExcel->setActiveSheetIndex(0);

				/*Crear Filtro Hoja*/
				//$objPHPExcel->getActiveSheet()->setAutoFilter('A1:C2');

				/* Columnas AutoAjuste */
				$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
		
		
				// Save Excel 2007 file
				//echo date('H:i:s') , " Write to Excel2007 format" , EOL;
				//$callStartTime = microtime(true);
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('exportppstclub.xlsx', __FILE__);

				
			//----------------------------------		
			echo 'exportppstclub.xlsx';
		
		}
	
	
	public function generarexcel_envio() {
			$recorre=0;
			if (isset($this->request->get['filter_memo'])) {
				$recorre++;
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_selected'])) {
				$recorre++;
				$filter_selected = $this->request->get['filter_selected'];
			} else {
				$filter_selected = '';
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$recorre++;
				$filter_ppst_club = $this->request->get['filter_ppst_club'];
			} else {
				$filter_ppst_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$recorre++;
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$recorre++;
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$recorre++;
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}		
			if (isset($this->request->get['filter_apodo'])) {
				$recorre++;
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$recorre++;
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$recorre++;
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$recorre++;
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$recorre++;
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$recorre++;
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$recorre++;
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
			if (isset($this->request->get['filter_status'])) {
				$recorre++;
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$recorre++;
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = " ";
			}		
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'id_jugador, fecha, ganancia';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
		
			if ($recorre==0){
				$filter_status = '2';
			}

			$filter_data = array(
				'filter_memo'		=> $filter_memo,
				'filter_selected'		=> $filter_selected,
				'filter_ppst_club'		=> $filter_ppst_club,
				'filter_ganancia'	  	=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		=> $filter_agrupar,
			);
			$this->load->model('pkdirsis/ppstestadi');
			$results = $this->model_pkdirsis_ppstestadi->getGenerarexcel_envio($filter_data);
		
			$data['products']=array();
		
			$ganancia=0;
			$entrada=0;
			
			foreach ($results as $result) {
				$data['products'][] = array(
					'id_club' 		=> $result['id_club'],
					'id_jugador' 	=> $result['id_jugador'],
				);
			}			
			//----------------------------------
				require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
				$objPHPExcel = new PHPExcel();
				$objPHPExcel->
				getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
				/* Datos Hojas */
				$col = array('A','C','E','G','I','K','M','O','Q','S','U','W','Z');
				$row=2;
				$rowh=1;
				$coln=0;
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue($col[0].$rowh,  'UID');
				$id_club="";
				$id_club25="";
				$row25=0;
				foreach ($results as $result) {
					if ($id_club!=$result['id_club']){
						$row++;
						$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue($col[$coln].$row,  $result['name_club']);
						$row++;
						$row++;
						$id_club=$result['id_club'];
						$id_club25=$result['id_club'];
						$row25=0;
					}
					$existe=$this->model_pkdirsis_ppstestadi->leerEnviar_jugador($result['id_jugador']);
					if ($existe=='0'){
						if ($row25<25 and $id_club25==$result['id_club']){
							$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue($col[$coln].$row,  $result['id_jugador']);
							$row++;
							$this->model_pkdirsis_ppstestadi->editEnviar_jugador($result['id_jugador'],"1");
						}
						$row25++;
					}
					
					if ($row>55){
						$coln++;
						$row=2;
						if ($coln>12){
							break;
						}
						$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue($col[$coln].$rowh,  'UID');
					}
				}
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('export_audit.xlsx', __FILE__);
			//----------------------------------		
			echo 'export_audit.xlsx';
		
		}
	
	public function enviaexcel(){
			$this->load->model('pkdirsis/ppstestadi');
			error_reporting(E_ALL);
			ini_set('display_errors', '1');
			$recorre=0;
			if (isset($this->request->get['filter_memo'])) {
				$recorre++;
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_union_club'])) {
				$recorre++;
				$filter_union_club = $this->request->get['filter_union_club'];
			} else {
				$filter_union_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$recorre++;
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$recorre++;
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$recorre++;
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}
			if (isset($this->request->get['filter_mesa'])) {
				$filter_mesa = $this->request->get['filter_mesa'];
			} else {
				$filter_mesa = '';
			}		
		
			if (isset($this->request->get['filter_apodo'])) {
				$recorre++;
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_manos'])) {
				$recorre++;
				$filter_manos = $this->request->get['filter_manos'];
			} else {
				$filter_manos = '';
			}
			if (isset($this->request->get['filter_ganancias'])) {
				$recorre++;
				$filter_ganancias = $this->request->get['filter_ganancias'];
			} else {
				$filter_ganancias = '';
			}		
			if (isset($this->request->get['filter_ganancia'])) {
				$recorre++;
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$recorre++;
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$recorre++;
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$recorre++;
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$recorre++;
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$recorre++;
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
			if (isset($this->request->get['filter_status'])) {
				$recorre++;
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$recorre++;
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = " ";
			}		
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'fecha, ganancia';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
		
			if ($recorre==0){
				$filter_status = '2';
			}

			$filter_data = array(
				'filter_memo'		=> $filter_memo,
				'filter_union_club'		=> $filter_union_club,
				'filter_ganancia'	  		=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
					'filter_mesa'	  	=> $filter_mesa,
			'filter_apodo'		  	=> $filter_apodo,
				'filter_manos'		  	=> $filter_manos,
				'filter_ganancias'		=> $filter_ganancias,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		  	=> $filter_agrupar,
				'sort'            => $sort,
				'order'           => $order,
				'start'           => 0,
				'limit'           => 1000
			);

			$results = $this->model_pkdirsis_ppstestadi->getInformesSinenviar($filter_data);
		
			//----------------------------------
			require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->
			getProperties()
				->setCreator("dirsis.com.ar")
				->setLastModifiedBy("dirsis.com.ar")
				->setTitle("Exportar XLSX")
				->setSubject("Excel")
				->setCategory("reportes");
			/* Datos Hojas */
			$col = array('A','C','E','G','I','K','M','O','Q','S','U','W','Z');
			$row=2;
			$rowh=1;
			$coln=0;
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($col[0].$rowh,  'UID');
			foreach ($results as $result) {
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($col[$coln].$row,  $result['id_jugador']);
				$row++;
				$this->model_pkdirsis_ppstestadi->editEnviar_jugador($result['id_jugador'],"1");
			}
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
			for ($i = 1; $i <= 1000; $i++) {
				$archivo="ppst_preview".$i.".xlsx";
				if (!file_exists($archivo)){
					$objWriter->save($archivo, __FILE__);
					break;
				}
			}
			//----------------------------------		
			echo $archivo;
		
	}	

	public function enviaexcelbck(){
		$this->load->model('pkdirsisppstestadi');
			error_reporting(E_ALL);
			ini_set('display_errors', '1');
			$recorre=0;
			if (isset($this->request->get['filter_memo'])) {
				$recorre++;
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_union_club'])) {
				$recorre++;
				$filter_union_club = $this->request->get['filter_union_club'];
			} else {
				$filter_union_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$recorre++;
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$recorre++;
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$recorre++;
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}
			if (isset($this->request->get['filter_mesa'])) {
				$filter_mesa = $this->request->get['filter_mesa'];
			} else {
				$filter_mesa = '';
			}		
		
			if (isset($this->request->get['filter_apodo'])) {
				$recorre++;
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_manos'])) {
				$recorre++;
				$filter_manos = $this->request->get['filter_manos'];
			} else {
				$filter_manos = '';
			}
			if (isset($this->request->get['filter_ganancias'])) {
				$recorre++;
				$filter_ganancias = $this->request->get['filter_ganancias'];
			} else {
				$filter_ganancias = '';
			}		
			if (isset($this->request->get['filter_ganancia'])) {
				$recorre++;
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$recorre++;
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$recorre++;
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$recorre++;
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$recorre++;
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$recorre++;
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
			if (isset($this->request->get['filter_status'])) {
				$recorre++;
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$recorre++;
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = " ";
			}		
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'fecha, ganancia';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
		
			if ($recorre==0){
				$filter_status = '2';
			}

			$filter_data = array(
				'filter_memo'		=> $filter_memo,
				'filter_union_club'		=> $filter_union_club,
				'filter_ganancia'	  		=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_mesa'	  		=> $filter_mesa,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_manos'		  	=> $filter_manos,
				'filter_ganancias'		=> $filter_ganancias,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		  	=> $filter_agrupar,
				'sort'            => $sort,
				'order'           => $order,
				'start'           => 0,
				'limit'           => 1000
			);

			$results = $this->model_pkdirsis_ppstestadi->getInformesSinenviar($filter_data);
		
			//----------------------------------
			require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->
			getProperties()
				->setCreator("dirsis.com.ar")
				->setLastModifiedBy("dirsis.com.ar")
				->setTitle("Exportar XLSX")
				->setSubject("Excel")
				->setCategory("reportes");
			/* Datos Hojas */
			$col = array('A','C','E','G','I','K','M','O','Q','S','U','W','Z');
			$row=2;
			$rowh=1;
			$coln=0;
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($col[0].$rowh,  'UID');
			foreach ($results as $result) {
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue($col[$coln].$row,  $result['id_jugador']);
				$row++;
				$this->model_pkdirsis_ppstestadi->editEnviar_jugador($result['id_jugador'],"1");
			}
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
			for ($i = 1; $i <= 1000; $i++) {
				$archivo="preview".$i.".xlsx";
				if (!file_exists($archivo)){
					$objWriter->save($archivo, __FILE__);
					break;
				}
			}
			//----------------------------------		
			echo $archivo;
		
	}
	
	protected function getList() {

	/*DIRSIS*/		
			$this->load->model('user/user');
			$user_info = $this->model_user_user->getUser($this->user->getId());
			if ($user_info) {

				//logs( json_encode($user_info) );
				$data['bank'] = $user_info['bank'];
				$data['firstname'] = $user_info['firstname'];
				$data['lastname'] = $user_info['lastname'];
				$data['username']  = $user_info['username'];
				$data['user_group'] = $user_info['user_group'];		
				$data['user_group_id'] = $user_info['user_group_id'];		
				$data['user_group_nivel'] = $user_info['user_group_nivel'];	
			}

			$data['mask3'] = $this->config->get('config_valor_fecha_ppst');		
	/*DIRSIS*/

	//PRIMERO	
			$recorre=0;
			if (isset($this->request->get['filter_memo'])) {
				$recorre++;
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$recorre++;
				$filter_ppst_club = $this->request->get['filter_ppst_club'];
			} else {
				$filter_ppst_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$recorre++;
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$recorre++;
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$recorre++;
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}		
			if (isset($this->request->get['filter_apodo'])) {
				$recorre++;
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$recorre++;
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$recorre++;
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$recorre++;
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$recorre++;
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$recorre++;
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = date('Y-m-d');
			}
			if (isset($this->request->get['filter_hasta'])) {
				$recorre++;
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = date('Y-m-d');
			}
			if (isset($this->request->get['filter_status'])) {
				$recorre++;
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$recorre++;
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = " ";
			}		
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'fecha, ganancia';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
		
			if ($recorre==0){
				$filter_status = '2';
			}


	//SEGUNDO


			$url = '';
			if (isset($this->request->get['filter_memo'])) {
				$url .= '&filter_memo=' . urlencode(html_entity_decode($this->request->get['filter_memo'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$url .= '&filter_ganancia=' . urlencode(html_entity_decode($this->request->get['filter_ganancia'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_juego'])) {
				$url .= '&filter_juego=' . urlencode(html_entity_decode($this->request->get['filter_juego'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_juego2'])) {
				$url .= '&filter_juego2=' . urlencode(html_entity_decode($this->request->get['filter_juego2'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$url .= '&filter_ppst_club=' . urlencode(html_entity_decode($this->request->get['filter_ppst_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_club'])) {
				$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_name_club'])) {
				$url .= '&filter_name_club=' . urlencode(html_entity_decode($this->request->get['filter_name_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_jugador'])) {
				$url .= '&filter_id_jugador=' . urlencode(html_entity_decode($this->request->get['filter_id_jugador'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_apodo'])) {
				$url .= '&filter_apodo=' . urlencode(html_entity_decode($this->request->get['filter_apodo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_desde'])) {
				$url .= '&filter_desde=' . urlencode(html_entity_decode($this->request->get['filter_desde'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . urlencode(html_entity_decode($this->request->get['filter_hasta'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . urlencode(html_entity_decode($this->request->get['filter_status'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$url .= '&filter_agrupar=' . urlencode(html_entity_decode($this->request->get['filter_agrupar'], ENT_QUOTES, 'UTF-8'));
			}		

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
	//TERCERO
			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('catalog/product', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);

			//$data['add'] = $this->url->link('catalog/product/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
			//$data['copy'] = $this->url->link('catalog/product/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
			//$data['delete'] = $this->url->link('catalog/product/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
	//CUARTO
			$filter_data = array(
				'filter_memo'		=> $filter_memo,
				'filter_ppst_club'		=> $filter_ppst_club,
				'filter_ganancia'	  		=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		  	=> $filter_agrupar,
				'sort'            => $sort,
				'order'           => $order,
				'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
				'limit'           => $this->config->get('config_limit_admin')
			);

			$product_total = $this->model_pkdirsis_ppstestadi->getTotalInformes($filter_data);
		
			$results = $this->model_pkdirsis_ppstestadi->getInformes($filter_data);

			$data['products']=array();
		
			$ganancia=0;
			$entrada=0;
			
			foreach ($results as $result) {
				$data['products'][] = array(
					'enviado'		=> $this->model_pkdirsis_ppstestadi->leerEnviar_jugador($result['id_jugador']),
					'fecha' 		=> $result['fecha'],
					'ppst_club' 	=> $result['ppst_club'],
					'juego' 		=> isset($result['juego'])?$result['juego']:'',
					'id_club' 		=> $result['id_club'],
					'name_club' 	=> $result['name_club'],
					'id_jugador' 	=> $result['id_jugador'],
					'apodo' 		=> $result['apodo'],
					'entrada' 		=> number_format($result['entrada'],2),
					'ranking' 		=> $result['ranking'],
					'ganancia'   	=> number_format($result['ganancia'],2),
					'minijuego'   	=> isset($result['minijuego'])?$result['minijuego']:'',
					'total'   	=> number_format($result['total'],2)
				);
				$ganancia=$ganancia+$result['ganancia'];
				$entrada=$entrada+$result['entrada'];
			}	
		
			$data['ganancia']=number_format($ganancia,2);
			$data['entrada']=number_format($entrada,2);
			$data['total']=number_format($entrada+$ganancia,2);

			$results = $this->model_pkdirsis_ppstestadi->getInformesxClub($filter_data);

			$data['idclubs']=array();
			foreach ($results as $result) {
				$data['idclubs'][] = array(
					'id_club' 		=> $result['id_club'],
					'name_club' 	=> $result['name_club'],
					'total' 		=> $result['total'],
					'estado' 		=> $result['estado']
				);
			}	
			foreach ($data['idclubs'] as $key => $row) {
    			$aux[$key] = $row['total'];
			}		
		if ($data['idclubs']){
			array_multisort($aux, SORT_DESC, $data['idclubs']);
		}


			$results = $this->model_pkdirsis_ppstestadi->getInformesxPpst($filter_data);
			$data['clubs']=array();
			foreach ($results as $result) {
				$data['clubs'][] = array(
					'ppst_club' 		=> $result['ppst_club'],
					'cantidad'   	=> 0, //$result['cantidad'],
					'checked'		=> strpos($filter_ppst_club, $result['ppst_club']."|") !== false?'checked':'',
				);
			}
		


			$results = $this->model_pkdirsis_ppstestadi->getInformesxJuego($filter_data);
			$data['juegos']=array();
			foreach ($results as $result) {
				$data['juegos'][] = array(
					'juego' 		=> $result['juego'],
					'cantidad'   	=> $result['cantidad'],
					'checked'		=> strpos($filter_juego, $result['juego']."|") !== false?'checked':'',
				);
			}


			$results = $this->model_pkdirsis_ppstestadi->getInformesxFecha($filter_data);
			$data['fechas']=array();
			foreach ($results as $result) {
				$data['fechas'][] = array(
					'fecha' 		=> $result['fecha'],
					'cantidad'   	=> $result['cantidad'],
					'checked'		=> strpos($filter_fecha, $result['fecha']."|") !== false?'checked':'',
				);
			}		
			$data['ganancias'][] = array(
				'ganancias' 		=> "Positivas",
				'valor'			=> "1",
				'checked'		=> strpos($filter_ganancia, "1") !== false?'checked':'',
			);		
			$data['ganancias'][] = array(
				'ganancias' 		=> "Negativas",
				'valor'			=> "2",
				'checked'		=> strpos($filter_ganancia, "2") !== false?'checked':'',
			);	
			$data['ganancias'][] = array(
				'ganancias' 		=> "Empatada",
				'valor'			=> "3",
				'checked'		=> strpos($filter_ganancia, "3") !== false?'checked':'',
			);		

	//QUINTO
			$data['user_token'] = $this->session->data['user_token'];

			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];

				unset($this->session->data['success']);
			} else {
				$data['success'] = '';
			}

			if (isset($this->request->post['selected'])) {
				$data['selected'] = (array)$this->request->post['selected'];
			} else {
				$data['selected'] = array();
			}
	//SEXTO
			$url = '';
			if (isset($this->request->get['filter_memo'])) {
				$url .= '&filter_memo=' . urlencode(html_entity_decode($this->request->get['filter_memo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$url .= '&filter_ganancia=' . urlencode(html_entity_decode($this->request->get['filter_ganancia'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_juego'])) {
				$url .= '&filter_juego=' . urlencode(html_entity_decode($this->request->get['filter_juego'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_juego2'])) {
				$url .= '&filter_juego2=' . urlencode(html_entity_decode($this->request->get['filter_juego2'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$url .= '&filter_ppst_club=' . urlencode(html_entity_decode($this->request->get['filter_ppst_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_club'])) {
				$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_name_club'])) {
				$url .= '&filter_name_club=' . urlencode(html_entity_decode($this->request->get['filter_name_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_jugador'])) {
				$url .= '&filter_id_jugador=' . urlencode(html_entity_decode($this->request->get['filter_id_jugador'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_apodo'])) {
				$url .= '&filter_apodo=' . urlencode(html_entity_decode($this->request->get['filter_apodo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_desde'])) {
				$url .= '&filter_desde=' . urlencode(html_entity_decode($this->request->get['filter_desde'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . urlencode(html_entity_decode($this->request->get['filter_hasta'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . urlencode(html_entity_decode($this->request->get['filter_status'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_agrupar'])) {
				$url .= '&filter_agrupar=' . urlencode(html_entity_decode($this->request->get['filter_agrupar'], ENT_QUOTES, 'UTF-8'));
			}		
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
	//SEPTIMO

			$data['sort_fecha'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=fecha' . $url, true);	
			$data['sort_juego'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=juego' . $url, true);		
			$data['sort_ppst_club'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=ppst_club' . $url, true);		
			$data['sort_id_club'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=id_club' . $url, true);		
			$data['sort_name_club'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=name_club' . $url, true);		
			$data['sort_id_jugador'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=id_jugador' . $url, true);		
			$data['sort_apodo'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=apodo' . $url, true);		
			$data['sort_entrada'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=entrada' . $url, true);		
			$data['sort_ranking'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=ranking' . $url, true);		
			$data['sort_ganancia'] = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . '&sort=ganancia' . $url, true);


	//OCTAVO

			$url = '';
			if (isset($this->request->get['filter_memo'])) {
				$url .= '&filter_memo=' . urlencode(html_entity_decode($this->request->get['filter_memo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$url .= '&filter_ganancia=' . urlencode(html_entity_decode($this->request->get['filter_ganancia'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_juego'])) {
				$url .= '&filter_juego=' . urlencode(html_entity_decode($this->request->get['filter_juego'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_juego2'])) {
				$url .= '&filter_juego2=' . urlencode(html_entity_decode($this->request->get['filter_juego2'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$url .= '&filter_ppst_club=' . urlencode(html_entity_decode($this->request->get['filter_ppst_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_club'])) {
				$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_name_club'])) {
				$url .= '&filter_name_club=' . urlencode(html_entity_decode($this->request->get['filter_name_club'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_id_jugador'])) {
				$url .= '&filter_id_jugador=' . urlencode(html_entity_decode($this->request->get['filter_id_jugador'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_apodo'])) {
				$url .= '&filter_apodo=' . urlencode(html_entity_decode($this->request->get['filter_apodo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_desde'])) {
				$url .= '&filter_desde=' . urlencode(html_entity_decode($this->request->get['filter_desde'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . urlencode(html_entity_decode($this->request->get['filter_hasta'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . urlencode(html_entity_decode($this->request->get['filter_status'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_agrupar'])) {
				$url .= '&filter_agrupar=' . urlencode(html_entity_decode($this->request->get['filter_agrupar'], ENT_QUOTES, 'UTF-8'));
			}		

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			$pagination = new Pagination();
			$pagination->total = $product_total;
			$pagination->page = $page;
			$pagination->limit = $this->config->get('config_limit_admin');
			$pagination->url = $this->url->link('pkdirsis/ppstestadi', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

			$data['pagination'] = $pagination->render();

			$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

			$data['filter_desde']=$filter_desde;
			$data['filter_hasta']=$filter_hasta;
			
			$data['filter_fecha']=$filter_fecha;
			$data['filter_ganancia']=$filter_ganancia;
			$data['filter_juego']=$filter_juego;
			$data['filter_juego2']=$filter_juego2;
			$data['filter_ppst_club']=$filter_ppst_club;
			$data['filter_id_club']=$filter_id_club;
			$data['filter_name_club']=$filter_name_club;
			$data['filter_id_jugador']=$filter_id_jugador;
			$data['filter_apodo']=$filter_apodo;
			$data['filter_status']=$filter_status;
			$data['filter_agrupar']=$filter_agrupar;

			$data['sort'] = $sort;
			$data['order'] = $order;

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
//print_r($data);
			$this->response->setOutput($this->load->view('pkdirsis/ppstestadi_list', $data));
		}

	public function getArchivar() {
		
			if (isset($this->request->get['filter_accion'])) {
				$filter_accion = $this->request->get['filter_accion'];
			} else {
				$filter_accion = '';
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$filter_ppst_club = $this->request->get['filter_ppst_club'];
			} else {
				$filter_ppst_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}		
			if (isset($this->request->get['filter_apodo'])) {
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}	
			if (isset($this->request->get['filter_juego2'])) {
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
		
			if (isset($this->request->get['filter_status'])) {
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
		
			if (isset($this->request->get['filter_agrupar'])) {
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = '';
			}		

			$filter_data = array(
				'filter_ppst_club'		=> $filter_ppst_club,
				'filter_ganancia'	  	=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		  	=> $filter_agrupar
			);

			$this->load->model('pkdirsis/ppstestadi');
			$result = $this->model_pkdirsis_ppstestadi->editEstado($filter_data);
		
		

			$this->load->language('pkdirsis/ppstestadi');

			$this->document->setTitle($this->language->get('heading_title'));

			$this->getList();

	}
	
	
	public function getMemo() {
		
			if (isset($this->request->get['filter_memo'])) {
				$filter_memo = $this->request->get['filter_memo'];
			} else {
				$filter_memo = '';
			}		
			if (isset($this->request->get['filter_ppst_club'])) {
				$filter_ppst_club = $this->request->get['filter_ppst_club'];
			} else {
				$filter_ppst_club = '';
			}
			if (isset($this->request->get['filter_id_club'])) {
				$filter_id_club = $this->request->get['filter_id_club'];
			} else {
				$filter_id_club = '';
			}		
			if (isset($this->request->get['filter_name_club'])) {
				$filter_name_club = $this->request->get['filter_name_club'];
			} else {
				$filter_name_club = '';
			}	
			if (isset($this->request->get['filter_id_jugador'])) {
				$filter_id_jugador = $this->request->get['filter_id_jugador'];
			} else {
				$filter_id_jugador = '';
			}		
			if (isset($this->request->get['filter_apodo'])) {
				$filter_apodo = $this->request->get['filter_apodo'];
			} else {
				$filter_apodo = '';
			}
			if (isset($this->request->get['filter_ganancia'])) {
				$filter_ganancia = $this->request->get['filter_ganancia'];
			} else {
				$filter_ganancia = '';
			}	
			if (isset($this->request->get['filter_fecha'])) {
				$filter_fecha = $this->request->get['filter_fecha'];
			} else {
				$filter_fecha = '';
			}	
			if (isset($this->request->get['filter_juego'])) {
				$filter_juego = $this->request->get['filter_juego'];
			} else {
				$filter_juego = '';
			}
			if (isset($this->request->get['filter_juego2'])) {
				$filter_juego2 = $this->request->get['filter_juego2'];
			} else {
				$filter_juego2 = '';
			}		
			if (isset($this->request->get['filter_desde'])) {
				$filter_desde = $this->request->get['filter_desde'];
			} else {
				$filter_desde = '';
			}
			if (isset($this->request->get['filter_hasta'])) {
				$filter_hasta = $this->request->get['filter_hasta'];
			} else {
				$filter_hasta = '';
			}
		
			if (isset($this->request->get['filter_status'])) {
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}	
		
			if (isset($this->request->get['filter_agrupar'])) {
				$filter_agrupar = $this->request->get['filter_agrupar'];
			} else {
				$filter_agrupar = '';
			}		

			$filter_data = array(
				'filter_memo'			=> $filter_memo,
				'filter_ppst_club'		=> $filter_ppst_club,
				'filter_ganancia'	  	=> $filter_ganancia,
				'filter_fecha'	  		=> $filter_fecha,
				'filter_juego'	  		=> $filter_juego,
				'filter_juego2'	  		=> $filter_juego2,
				'filter_id_club'	  	=> $filter_id_club,
				'filter_name_club'	  	=> $filter_name_club,
				'filter_id_jugador'	  	=> $filter_id_jugador,
				'filter_apodo'		  	=> $filter_apodo,
				'filter_desde'		  	=> $filter_desde,
				'filter_hasta'		  	=> $filter_hasta,
				'filter_status'		  	=> $filter_status,
				'filter_agrupar'		=> $filter_agrupar
			);
		
			$this->load->model('pkdirsis/ppstestadi');
			$result = $this->model_pkdirsis_ppstestadi->editMemo($filter_data);
			echo $result;
				
	}
}
function logs( $sql ) {
	$outputBuffer = fopen( 'log.txt', 'a' );
	fwrite( $outputBuffer, $sql . PHP_EOL );
	fclose( $outputBuffer );
}