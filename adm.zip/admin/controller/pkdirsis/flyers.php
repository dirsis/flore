<?php
class ControllerPkdirsisFlyers extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('pkdirsis/flyers');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('pkdirsis/flyers');

		$this->getList();
	}
	protected function getList() {
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('pkdirsis/flyers', 'user_token=' . $this->session->data['user_token'] , true)
		);
		
/*DIRSIS*/		
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['firstname'] = $user_info['firstname'];
			$data['lastname'] = $user_info['lastname'];
			$data['username']  = $user_info['username'];
			$data['user_group'] = $user_info['user_group'];		
			$data['user_group_id'] = $user_info['user_group_id'];	
			$data['user_group_nivel'] = $user_info['user_group_nivel'];	
		}
/*DIRSIS*/			

		$data['add'] = $this->url->link('pkdirsis/flyers/add', 'user_token=' . $this->session->data['user_token'] , true);
		$data['delete'] = $this->url->link('pkdirsis/flyers/delete', 'user_token=' . $this->session->data['user_token'] , true);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('pkdirsis/flyers_list', $data));
	}
}