<?php
class ControllerMarketingCumple extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('marketing/cumple');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('marketing/cumple');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_marketing_cumple->bajaCumple();
		$this->model_marketing_cumple->creaCumple();
		
		//			
		$this->getList();
	}
	public function sincro(){
		$this->load->language('marketing/cumple');
		$this->load->model('marketing/cumple');
		$this->model_marketing_cumple->traeCumple();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'familiar';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_cumple_id'])) {
			$url .= '&filter_cumple_id=' . $get['filter_cumple_id'];
		}
		if (isset($get['filter_familiar'])) {
			$url .= '&filter_familiar=' . $get['filter_familiar'];
		}
		if (isset($get['filter_cumple'])) {
			$url .= '&filter_cumple=' . $get['filter_cumple'];
		}	
		if (isset($get['filter_date_cumplei'])) {
			$url .= '&filter_date_cumplei=' . $get['filter_date_cumplei'];
		}	
		if (isset($get['filter_date_cumplef'])) {
			$url .= '&filter_date_cumplef=' . $get['filter_date_cumplef'];
		}	
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('marketing/cumple');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('marketing/cumple');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			
			$this->model_marketing_cumple->addCumple($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('marketing/cumple');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('marketing/cumple');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			$this->model_marketing_cumple->editCumple($this->request->get['cumple_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('marketing/cumple');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('marketing/cumple');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $cumple_id) {
				$this->model_marketing_cumple->deleteCumple($cumple_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	
	public function copy() {
		$this->load->language('marketing/cumple');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('marketing/cumple');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $cumple_id) {
				$this->model_marketing_cumple->copyCumple($cumple_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_cumple_id'])) {
			$filter_cumple_id = $this->request->get['filter_cumple_id'];
		} else {
			$filter_cumple_id = '';
		}
		if (isset($this->request->get['filter_cp'])) {
			$filter_cp = $this->request->get['filter_cp'];
		} else {
			$filter_cp = '';
		}		
		if (isset($this->request->get['filter_familiar'])) {
			$filter_familiar = $this->request->get['filter_familiar'];
		} else {
			$filter_familiar = '';
		}
		if (isset($this->request->get['filter_cumple'])) {
			$filter_cumple = $this->request->get['filter_cumple'];
		} else {
			$filter_cumple = '';
		}		
		if (isset($this->request->get['filter_date_cumplei'])) {
			$filter_date_cumplei = $this->request->get['filter_date_cumplei'];
		} else {
			$filter_date_cumplei = '';
		}		

		if (isset($this->request->get['filter_date_cumplef'])) {
			$filter_date_cumplef = $this->request->get['filter_date_cumplef'];
		} else {
			$filter_date_cumplef = '';
		}		
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'familiar';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('marketing/cumple/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('marketing/cumple/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('marketing/cumple/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['cumples'] = array();
		$filter_data = array(
			'filter_cumple_id'         => $filter_cumple_id,
			'filter_cp'         		=> $filter_cp,
			'filter_familiar'   		=> $filter_familiar,
			'filter_cumple'   		=> $filter_cumple,
			'filter_date_cumplei'   		=> $filter_date_cumplei,
			'filter_date_cumplef'   		=> $filter_date_cumplef,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);

		$cumple_total = $this->model_marketing_cumple->getTotalCumples($filter_data);

		$this->load->model('user/user');
		$results = $this->model_marketing_cumple->getCumples($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['cumples'][] = array(
				'cumple_id'    		=> $result['cumple_id'],
				'sucursal_id'    		=> $result['sucursal_id'],
				'sucursal'    		=> $result['sucursal'],
				'cp'    				=> $result['cp'],
				'familiar'    		=> $result['familiar'],
				'cumple'    		=> $result['cumple'],
				'date_cumple'        => date('d-m-Y', strtotime($result['date_cumple'])),
				'domicilio'    			=> $result['domicilio'],
				'ciudad'    			=> $result['ciudad'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'total_actividad'	=> $this->model_marketing_cumple->getTotalCumpleactividad(array("filter_cumple_id" => $result['cumple_id'] )),
				'edit'           	=> $this->url->link('marketing/cumple/edit', 'user_token=' . $this->session->data['user_token'] . '&cumple_id=' . $result['cumple_id'] . $url, true),
				'clonar'           	=> $this->url->link('marketing/cumple/clonar', 'user_token=' . $this->session->data['user_token'] . '&cumple_id=' . $result['cumple_id'] . $url, true)				
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		
		$data['sort_cumple_id'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.cumple_id' . $url, true);
		
		$data['sort_sucursal_id'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.sucursal_id' . $url, true);		
		
		$url = $this->filtrar($this->request->get,"column");
		$data['sort_cp'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.cp' . $url, true);
		
		$data['sort_familiar'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.familiar' . $url, true);
		
		$data['sort_cumple'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.cumple' . $url, true);

		$data['sort_date_cumple'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.date_cumple' . $url, true);
		
		$data['sort_domicilio'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.domicilio' . $url, true);
		
		$data['sort_ciudad'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.ciudad' . $url, true);
		
		$data['sort_status'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . '&sort=g.status' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $cumple_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($cumple_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($cumple_total -  $limit)) ? $cumple_total : ((($page - 1) *  $limit) +  $limit), $cumple_total, ceil($cumple_total /  $limit));

		$data['filter_cumple_id'] = $filter_cumple_id;
		$data['filter_cp'] = $filter_cp;
		$data['filter_familiar'] = $filter_familiar;
		$data['filter_cumple'] = $filter_cumple;
		$data['filter_date_cumplei'] = $filter_date_cumplei;
		$data['filter_date_cumplef'] = $filter_date_cumplef;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('marketing/cumple_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['cumple_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['cp'])) {
			$data['error_cp'] = $this->error['cp'];
		} else {
			$data['error_cp'] = '';
		}
		if (isset($this->error['sucursal_id'])) {
			$data['error_sucursal_id'] = $this->error['sucursal_id'];
		} else {
			$data['error_sucursal_id'] = '';
		}
		if (isset($this->error['familiar'])) {
			$data['error_familiar'] = $this->error['familiar'];
		} else {
			$data['error_familiar'] = '';
		}
		if (isset($this->error['cumple'])) {
			$data['error_cumple'] = $this->error['cumple'];
		} else {
			$data['error_cumple'] = '';
		}
		if (isset($this->error['date_cumple'])) {
			$data['error_date_cumple'] = $this->error['date_cumple'];
		} else {
			$data['error_date_cumple'] = '';
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['cumple_id'])) {
			$data['action'] = $this->url->link('marketing/cumple/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('marketing/cumple/edit', 'user_token=' . $this->session->data['user_token'] . '&cumple_id=' . $this->request->get['cumple_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('marketing/cumple', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['cumple_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_marketing_cumple->getCumple($this->request->get['cumple_id']);
		}

		if (isset($this->request->get['cumple_id'])) {
			$data['cumple_id'] = $this->request->get['cumple_id'];
		} else {
			$data['cumple_id'] = 0;
		}
		
		if (isset($this->request->post['cp'])) {
			$data['cp'] = $this->request->post['cp'];
		} elseif (!empty($info)) {
			$data['cp'] = $info['cp'];
		} else {
			$data['cp'] = '';
		}	
		
		

		if (isset($this->request->post['familiar'])) {
			$data['familiar'] = $this->request->post['familiar'];
		} elseif (!empty($info)) {
			$data['familiar'] = $info['familiar'];
		} else {
			$data['familiar'] = '';
		}	
		
		if (isset($this->request->post['cumple'])) {
			$data['cumple'] = $this->request->post['cumple'];
		} elseif (!empty($info)) {
			$data['cumple'] = $info['cumple'];
		} else {
			$data['cumple'] = '';
		}

		if (isset($this->request->post['date_cumple'])) {
			$data['date_cumple'] = $this->request->post['date_cumple'];
		} elseif (!empty($info)) {
			$data['date_cumple'] = date("d-m-Y",strtotime($info['date_cumple']));
		} else {
			$data['date_cumple'] = '';
		}
		
		if (isset($this->request->post['sucursal_id'])) {
			$data['sucursal_id'] = $this->request->post['sucursal_id'];
		} elseif (!empty($info)) {
			$data['sucursal_id'] = $info['sucursal_id'];
		} else {
			$data['sucursal_id'] = '';
		}		
		
		if (isset($this->request->post['domicilio'])) {
			$data['domicilio'] = $this->request->post['domicilio'];
		} elseif (!empty($info)) {
			$data['domicilio'] = $info['domicilio'];
		} else {
			$data['domicilio'] = '';
		}		

		if (isset($this->request->post['ciudad'])) {
			$data['ciudad'] = $this->request->post['ciudad'];
		} elseif (!empty($info)) {
			$data['ciudad'] = $info['ciudad'];
		} else {
			$data['ciudad'] = '';
		}	

		if (isset($this->request->post['telefono'])) {
			$data['telefono'] = $this->request->post['telefono'];
		} elseif (!empty($info)) {
			$data['telefono'] = $info['telefono'];
		} else {
			$data['telefono'] = '';
		}	
		
		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} elseif (!empty($info)) {
			$data['email'] = $info['email'];
		} else {
			$data['email'] = '';
		}	
		
		$this->load->model('marketing/sucursal');
		$data['sucursals'] = $this->model_marketing_sucursal->getSucursals();
				
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($info)) {
			$data['date_added'] = date("d-m-Y",strtotime($info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($info)) {
			$data['date_modified'] = $info['date_modified']==""?"":date("d-m-Y",strtotime($info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($info)) {
			$data['date_delete'] = $info['date_delete']==""?"":date("d-m-Y",strtotime($info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($info)) {
			$data['user_id_added'] = $info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($info)) {
			$data['user_id_modified'] = $info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($info)) {
			$data['user_id_delete'] = $info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('marketing/cumple_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'marketing/cumple')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['cp']) < 5) || (utf8_strlen(trim($this->request->post['cp'])) > 13)) {
			$this->error['cp'] = $this->language->get('error_cp');
		}		
		if ((utf8_strlen($this->request->post['familiar']) < 1) || (utf8_strlen(trim($this->request->post['familiar'])) > 100)) {
			$this->error['familiar'] = $this->language->get('error_familiar');
		}
		if ((utf8_strlen($this->request->post['cumple']) < 1) || (utf8_strlen(trim($this->request->post['cumple'])) > 100)) {
			$this->error['cumple'] = $this->language->get('error_cumple');
		}
		if (empty($this->request->post['sucursal_id'])) {
			$this->error['sucursal_id'] = $this->language->get('error_sucursal_id');
		}		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'marketing/cumple')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'marketing/cumple')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_cumple_id'])) {
			$filter_cumple_id = $this->request->get['filter_cumple_id'];
		} else {
			$filter_cumple_id = '';
		}
		if (isset($this->request->get['filter_familiar'])) {
			$filter_familiar = $this->request->get['filter_familiar'];
		} else {
			$filter_familiar = '';
		}
		if (isset($this->request->get['filter_cumple'])) {
			$filter_cumple = $this->request->get['filter_cumple'];
		} else {
			$filter_cumple = '';
		}

		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'familiar';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['cumples'] = array();
		$filter_data = array(
			'filter_cumple_id'        => $filter_cumple_id,
			'filter_familiar'           => $filter_familiar,
			'filter_cumple'           => $filter_cumple,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('marketing/cumple');
		$results = $this->model_marketing_cumple->getCumples($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCumple("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['cumple_id'])
					->setCellValue('B'.$row,  $result['familiar'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('marketing/cumple');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					
					
					"familiar" => $in_ar[1],
					"domicilio" => $in_ar[2],
					"ciudad" => $in_ar[3],
					"telefono" => $in_ar[4],
					"email" => $in_ar[5],
					"status" => 1
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_marketing_cumple->editCumple($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_marketing_cumple->addCumple($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
		
}