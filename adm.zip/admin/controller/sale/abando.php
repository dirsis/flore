<?php
class ControllerSaleAbando extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('sale/abando');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/abando');

		$this->getList();
	}
/*
	public function add() {
		$this->load->language('sale/abando');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/abando');

		$this->getForm();
	}
*/
/*	
	public function edit() {
		$this->load->language('sale/abando');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/abando');

		$this->getForm();
	}
*/
	
	public function delete() {
		$this->load->language('sale/abando');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/abando');

		
		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $cart_id) {
				
				$this->model_sale_abando->deleteAbando($cart_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}

			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
			
	protected function getList() {
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'cart_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['delete'] = $this->url->link('sale/abando/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['abandos'] = array();

		$filter_data = array(
			'filter_status'    		=> $filter_status,
			'filter_date_desde'     => $filter_date_desde,
			'filter_date_hasta'   	=> $filter_date_hasta,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		$abando_total = $this->model_sale_abando->getTotalAbandos($filter_data);

		$results = $this->model_sale_abando->getAbandos($filter_data);
	
		foreach ($results as $result) {
			$data['abandos'][] = array(
				'cart_id' 		=> $result['cart_id'],
				'customer_id'   => $result['customer_id'],
				'customer'		=> $result['customer'],
				'email'			=> $result['email'],
				'telephone' 	=> $result['telephone'],
				'date_added'  	=> $result['date_added'],
				'sku'			=> $result['sku'],
				'product_id'	=> $result['product_id'],
				'name'			=> $result['name'],
				'quantity'  	=> $result['quantity'],
				'price'  		=> $result['price'] 
			);
		}
		$data['abandosagrupados'] = array();
		$results = $this->model_sale_abando->getAbandosagrupado($filter_data);
		foreach ($results as $result) {
			$data['abandosagrupados'][] = array(
				'customer_id'   => $result['customer_id'],
				'customer'		=> $result['customer'],
				'email'			=> $result['email'],
				'telephone' 	=> $result['telephone']
			);
		}		

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';


		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

$data['sort_cart_id'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=cart_id' . $url, true);
$data['sort_customer_id'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=customer_id' . $url, true);
$data['sort_customer'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
$data['sort_telephone'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=telephone' . $url, true);
$data['sort_date_added'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);	
$data['sort_email'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=email' . $url, true);
$data['sort_sku'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=sku' . $url, true);
$data['sort_product_id'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=product_id' . $url, true);
$data['sort_name'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
$data['sort_quantity'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=quantity' . $url, true);
$data['sort_price'] = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . '&sort=price' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		$pagination = new Pagination();
		$pagination->total = $abando_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('sale/abando', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($abando_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($abando_total - $this->config->get('config_limit_admin'))) ? $abando_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $abando_total, ceil($abando_total / $this->config->get('config_limit_admin')));

		$data['filter_status'] = $filter_status;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('sale/abando_list', $data));
	}
	
	
	public function enviarmail() {

		if (isset($this->request->get['correo'])) {
					
			$correo=$this->request->get['correo'];
			$this->load->model('customer/customer');
			$store_name = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
			$store_url = HTTP_CATALOG . 'index.php?route=account/login';
			$store_logo = HTTP_CATALOG . 'image/'.html_entity_decode($this->config->get('config_logo'), ENT_QUOTES, 'UTF-8');

			$this->load->language('mail/abando');
			
			$data['login'] = $store_url . 'index.php?route=account/login';
			$data['store'] = $store_name;
			$data['store_url']=$store_url;
			$data['store_name']=$store_name;
			$data['image']=$store_logo;
			
			
			$data['text_greeting']=sprintf($this->language->get('text_subject'), $store_name);
			$data['text_from']=$this->config->get('config_email');
			$data['text_message']=$this->language->get('text_message');
			$data['text_url'] = $data['store_url'];
			
			$mail = new Mail($this->config->get('config_mail_engine'));
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			//$correo="dirsis@gmail.com";
			$mail->setTo($correo);
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender(html_entity_decode($store_name, ENT_QUOTES, 'UTF-8'));
			$mail->setSubject(html_entity_decode($data['text_greeting'], ENT_QUOTES, 'UTF-8'));
			$mail->setHtml($this->load->view('mail/abando', $data));
			
			$result=$mail->send();
			if (empty($result)){
				echo "Se envio correo a ".$correo." con exito!!";
			}else{
				echo "Problemas para enviar correo a ".$correo." :(";
			}
		}
	}	
	
}
