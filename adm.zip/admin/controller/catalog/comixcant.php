<?php
class ControllerCatalogComixcant extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/comixcant');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getList();
	}

	protected function getList() {
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/comixcant', 'user_token=' . $this->session->data['user_token'], true)
		);
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$product_id=$this->config->get('config_factura_product_id');
		
		$this->load->model('customer/customer_group');
		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();
		$this->load->model('catalog/product');
		$product_discounts = $this->model_catalog_product->getProductDiscounts($product_id);
		$data['product_discounts'] = array();
		foreach ($product_discounts as $product_discount) {
			$data['product_discounts'][] = array(
				'customer_group_id' => $product_discount['customer_group_id'],
				'quantity'          => $product_discount['quantity'],
				'priority'          => $product_discount['priority'],
				'price'             => round($product_discount['price'],2),
				'date_start'        => ($product_discount['date_start'] != '0000-00-00') ? $product_discount['date_start'] : '',
				'date_end'          => ($product_discount['date_end'] != '0000-00-00') ? $product_discount['date_end'] : ''
			);
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$data['discount'] = $this->url->link('catalog/comixcant/discount', 'user_token=' . $this->session->data['user_token'], true);
		$this->response->setOutput($this->load->view('catalog/comixcant_list', $data));
	}
	
	public function discount() {
		$this->load->language('catalog/comixcant');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/comixcant');
		
		$this->model_catalog_comixcant->discountProductdelete();
		
		if (isset($this->request->post)) {
			$this->model_catalog_comixcant->discountProduct($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('catalog/comixcant', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getList();
	}	

}
