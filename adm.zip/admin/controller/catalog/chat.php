<?php
class ControllerCatalogChat extends Controller {
	private $error = array();

	public function chatsinleer() {
		$canti=0;
		$this->load->model('catalog/chat');
		$canti=$this->model_catalog_chat->sinleerChat();
		echo $canti;
	}	
	public function index() {
		$this->load->language('catalog/chat');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/chat');
		$this->getList();
	}

	public function add() {
		$this->load->language('catalog/chat');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/chat');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_chat->addChat($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('catalog/chat');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/chat');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_chat->editChat($this->request->get['chat_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}

	public function delete() {
		$this->load->language('catalog/chat');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/chat');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $chat_id) {
				$this->model_catalog_chat->deleteChat($chat_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	public function leer() {
		$this->load->language('catalog/chat');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/chat');
		
		
		if (isset($this->request->post['selected'])){
			foreach ($this->request->post['selected'] as $chat_id) {
				$this->model_catalog_chat->leerChat($chat_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		}else{
			$filter_customer = '';
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		}else{
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		}else{
			$filter_date_hasta = '';
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 't.date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('catalog/chat/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('catalog/chat/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['leer'] = $this->url->link('catalog/chat/leer', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['chats'] = array();

		$filter_data = array(
			'filter_customer' 	=> $filter_customer,
			'filter_date_hasta' => $filter_date_hasta,
			'filter_date_desde' => $filter_date_desde,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$chat_total = $this->model_catalog_chat->getTotalChats();

		$results = $this->model_catalog_chat->getChats($filter_data);

		foreach ($results as $result) {
			$data['chats'][] = array(
				'chat_id' 		=> $result['chat_id'],
				'date_added'    => date("d-m-Y h:m",strtotime($result['date_added'])),
				'motivo'        => $result['motivo'],
				'leido'        => $result['leido'],
				'comment'     	=> trim(strip_tags(html_entity_decode($result['comment'], ENT_QUOTES, 'UTF-8'))),
				'commentcorto'     	=> utf8_substr(trim(strip_tags(html_entity_decode($result['comment'], ENT_QUOTES, 'UTF-8'))), 0, 30) . '..',
				'customer_id'	=> $result['customer_id'],
				'customer'		=> $result['customer'],
				'status'		=> $result['status']==1 ? $result['customer'] : 'TU',
				'color'		=> $result['status']==1 ? 'success' : 'danger',
				'edit'          => $this->url->link('catalog/chat/edit', 'user_token=' . $this->session->data['user_token'] . '&chat_id=' . $result['chat_id'] . $url, true)
			);
		}

		$data['chatsresumido'] = array();
		$results = $this->model_catalog_chat->getChatsresumido($filter_data);
		foreach ($results as $result) {
			$data['chatsresumido'][] = array(
				'customer_id'	=> $result['customer_id'],
				'customer'		=> $result['customer'],
				'cantidad'		=> $result['cantidad'],
				'edit'          => $this->url->link('catalog/chat/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id='.$result['customer_id'], true)
			);
		}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
$data['sort_date_added'] = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . '&sort=t.date_added' . $url, true);
$data['sort_comment'] = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . '&sort=t.comment' . $url, true);
$data['sort_customer_id'] = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . '&sort=t.customer_id' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		$pagination = new Pagination();
		$pagination->total = $chat_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($chat_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($chat_total - $this->config->get('config_limit_admin'))) ? $chat_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $chat_total, ceil($chat_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/chat_list', $data));
	}

	protected function getForm() {
		
		if (!isset($this->request->get['chat_id'])){
			$data['text_form'] = $this->language->get('text_add');
		}
		if (isset($this->request->get['chat_id'])){
			if (isset($this->request->get['customer_id'])){
				$data['text_form'] = $this->language->get('text_add');
			}else{
				$data['text_form'] = $this->language->get('text_edit');
			}
		}
		

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['motivo'])) {
			$data['error_motivo'] = $this->error['motivo'];
		} else {
			$data['error_motivo'] = '';
		}
		
		if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}		

		if (isset($this->error['comment'])) {
			$data['error_comment'] = $this->error['comment'];
		} else {
			$data['error_comment'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['chat_id'])) {
			$data['action'] = $this->url->link('catalog/chat/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			if (isset($this->request->get['customer_id'])){
				$data['action'] = $this->url->link('catalog/chat/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
			}else{
				$data['action'] = $this->url->link('catalog/chat/edit', 'user_token=' . $this->session->data['user_token'] . '&chat_id=' . $this->request->get['chat_id'] . $url, true);
			}
		}

		$data['cancel'] = $this->url->link('catalog/chat', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['chat_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$chat_info = $this->model_catalog_chat->getChat($this->request->get['chat_id']);
			if (!empty($chat_info)){
				$this->load->model('customer/customer');
				$chat_customer = $this->model_customer_customer->getCustomer($chat_info['customer_id']);
			}
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($chat_info)) {
			$data['date_added'] = date("d-m-Y",strtotime($chat_info['date_added']));
		} else {
			$data['date_added'] = date("d-m-Y");
		}

		if (isset($this->request->post['customer'])) {
			$data['customer'] = $this->request->post['customer'];
		} elseif (!empty($chat_info)) {
			$data['customer'] = $chat_customer['name'];
		} else {
			$data['customer'] = '';
		}		
		
		$data['chats'] = array();
		$data['customer_id'] = '';
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($chat_info)) {
			$data['customer_id'] = $chat_info['customer_id'];
		} elseif (isset($this->request->get['customer_id'])) {
			$data['customer_id'] = $this->request->get['customer_id'];
		}
		if (!empty($data['customer_id'])){
			$filter_data = array(
				'customer_id' => $data['customer_id'], 
				'sort'  => 'date_added',
				'order' => 'DESC',
				'start' => 0,
				'limit' => 1000
			);
			$results = $this->model_catalog_chat->getChats($filter_data);
			foreach ($results as $result) {
				$data['chats'][] = array(
					'chat_id' 		=> $result['chat_id'],
					'date_added'    => date("d-m-Y",strtotime($result['date_added'])),
					'motivo'        => utf8_substr(trim(strip_tags(html_entity_decode($result['comment'], ENT_QUOTES, 'UTF-8'))), 0, 30) . '..',
					'comment'     	=> $result['comment'],
					'customer_id'	=> $result['customer_id'],
					'customer'		=> $result['customer'],
					'status'		=> $result['status']
				);
				$data['customer'] = $result['customer'];
			}			
		}
		
		
		if (isset($this->request->post['motivo'])) {
			$data['motivo'] = $this->request->post['motivo'];
		} elseif (!empty($chat_info)) {
			$data['motivo'] = $chat_info['motivo'];
		} else {
			$data['motivo'] = '';
		}		

		if (isset($this->request->post['comment'])) {
			$data['comment'] = $this->request->post['comment'];
		} elseif (!empty($chat_info)) {
			$data['comment'] = $chat_info['comment'];
		} else {
			$data['comment'] = '';
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($chat_info)) {
			$data['status'] = $chat_info['status'];
		} else {
			$data['status'] = true;
		}
		
		if (isset($this->request->get['customer_id'])){
			$data['date_added'] = date("d-m-Y");
			$data['motivo'] = '';
			$data['comment'] = '';
			$data['status'] = false;
		}

		$this->load->model('design/layout');

		$data['layouts'] = $this->model_design_layout->getLayouts();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/chat_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/chat')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->request->post['customer_id']<1){
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		}		

		if (utf8_strlen($this->request->post['comment']) < 1) {
			$this->error['comment'] = $this->language->get('error_comment');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/chat')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}
}