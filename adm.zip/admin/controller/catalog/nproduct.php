<?php
class ControllerCatalogNproduct extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('catalog/nproduct');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/nproduct');
		$this->getList();
	}
	protected function getList() {
		
		error_reporting(E_ALL);
ini_set('display_errors', '1');
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		if (isset($this->request->get['filter_sku'])) {
			$filter_sku = $this->request->get['filter_sku'];
		} else {
			$filter_sku = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}		
		if (isset($this->request->get['filter_fotos'])) {
			$filter_fotos = $this->request->get['filter_fotos'];
		} else {
			$filter_fotos = '';
		}		
		if (isset($this->request->get['filter_pvp2'])) {
			$filter_pvp2 = $this->request->get['filter_pvp2'];
		} else {
			$filter_pvp2 = '';
		}
		if (isset($this->request->get['filter_qty'])) {
			$filter_qty = $this->request->get['filter_qty'];
		} else {
			$filter_qty = '';
		}
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sku'])) {
			$url .= '&filter_sku=' . urlencode(html_entity_decode($this->request->get['filter_sku'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_fotos'])) {
			$url .= '&filter_fotos=' . $this->request->get['filter_fotos'];
		}		

		if (isset($this->request->get['filter_pvp2'])) {
			$url .= '&filter_pvp2=' . $this->request->get['filter_pvp2'];
		}

		if (isset($this->request->get['filter_qty'])) {
			$url .= '&filter_qty=' . $this->request->get['filter_qty'];
		}
	
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['add'] = $this->url->link('catalog/product/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['addmasivo'] = $this->url->link('catalog/nproduct/addmasivo', 'user_token=' . $this->session->data['user_token'] . $url, true);
		//$data['delete'] = $this->url->link('catalog/nproduct/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['revisafotos'] = $this->url->link('catalog/product/revisafotos', 'user_token=' . $this->session->data['user_token'] . $url, true);		
		

		$data['products'] = array();

		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_sku'	  => $filter_sku,
			'filter_pvp2'	  => $filter_pvp2,
			'filter_qty'   => $filter_qty,
			'filter_status'	  => $filter_status,
			'filter_fotos'	  => $filter_fotos,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		$this->load->model('tool/image');
		$product_total = $this->model_catalog_nproduct->getTotalNproducts($filter_data);
		$results = $this->model_catalog_nproduct->getNproducts($filter_data);

		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 40, 40);
			} else {
				
				$ver = 'catalog/webx/'.trim($result['sku']).".jpg";
				//print_r(DIR_IMAGE . $ver);
				if (is_file(DIR_IMAGE . $ver)) {
					$image = $this->model_tool_image->resize($ver, 40, 40);
				}else{
					$image = $this->model_tool_image->resize('no_image.png', 40, 40);
				}
			}
			
			$data['products'][] = array(
				'erp_upload_id' => $result['erp_upload_id'],
				'image'      	=> $image,
				'name'       	=> $result['name'],
				'sku'      		=> $result['sku'],
				'pvp2'      	=> $this->currency->format($result['pvp2'], $this->config->get('config_currency')),
				'qty'   		=> $result['qty'],
				'outlet'   		=> $result['outlet'],
				'status'   		=> $result['status'],
				'fechaalta'  	=> $result['fechaalta'],
				'edit'       	=> $this->url->link('catalog/product/add', 'user_token=' . $this->session->data['user_token'] . '&sku=' . $result['sku'] . $url, true)
			);
			
			
			
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sku'])) {
			$url .= '&filter_sku=' . urlencode(html_entity_decode($this->request->get['filter_sku'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_pvp2'])) {
			$url .= '&filter_pvp2=' . $this->request->get['filter_pvp2'];
		}

		if (isset($this->request->get['filter_qty'])) {
			$url .= '&filter_qty=' . $this->request->get['filter_qty'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=pd.name' . $url, true);
		$data['sort_sku'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=sku' . $url, true);
		$data['sort_pvp2'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=pvp2' . $url, true);
		$data['sort_qty'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=qty' . $url, true);
		$data['sort_outlet'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=outlet' . $url, true);
		$data['sort_fechaalta'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=fechaalta' . $url, true);
		$data['sort_order'] = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . '&sort=p.sort_order' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sku'])) {
			$url .= '&filter_sku=' . urlencode(html_entity_decode($this->request->get['filter_sku'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_fotos'])) {
			$url .= '&filter_fotos=' . $this->request->get['filter_fotos'];
		}
		
		if (isset($this->request->get['filter_pvp2'])) {
			$url .= '&filter_pvp2=' . $this->request->get['filter_pvp2'];
		}

		if (isset($this->request->get['filter_qty'])) {
			$url .= '&filter_qty=' . $this->request->get['filter_qty'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));
		
		$data['filter_name'] = $filter_name;
		$data['filter_sku'] = $filter_sku;
		$data['filter_status'] = $filter_status;		
		$data['filter_fotos'] = $filter_fotos;
		$data['filter_pvp2'] = $filter_pvp2;
		$data['filter_qty'] = $filter_qty;
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('catalog/nproduct_list', $data));
	}
	
	public function add($erp_upload_id){
			//$sku=urlencode(html_entity_decode($this->request->get['sku'], ENT_QUOTES, 'UTF-8'));
			$product_id=0;
			$this->load->model('catalog/nproduct');
			$related_info = $this->model_catalog_nproduct->getNproductxerp_upload_id($erp_upload_id);
		

			if ($related_info){
				$sku=$related_info['sku'];
				$image = 'catalog/webx/'.str_replace('+','x',$sku).'.jpg';
				if (isset($image) && is_file(DIR_IMAGE . $image)) {
				}else{
					$image='';
				}
				$data=array(
					 'model' => $sku,
					 'sku' => $sku,
					 'upc' => '',
					 'ean' => '',
					 'jan' => '',
					 'isbn' => '',
					 'mpn' => '',
					 'location' => '',
					 'quantity' => $related_info['qty'],
					 'minimum' => '1',
					 'subtract' => '1',
					 'stock_status_id' => '0',
					 'date_available' => date('Y-m-d'),
					 'manufacturer_id' => '', 
					 'shipping' => '1',
					 'price' => $related_info['pvp2'], 
					 'currency_id' => $this->config->get('config_currency_auto'),
					 'tasaiva' => '21',
					 'lista' => '0',
					 'dto1' => '', 
					 'dto2' => '', 
					 'dto3' => '', 
					 'dto4' => '', 
					 'costo' => '',
					 'util' => '', 
					 'venta' => '', 
					 'sincro' => '1', 
					 'points' => '0', 
					 'weight' => '0', 
					 'weight_class_id' => '1', 
					 'length' => '0', 
					 'width' => '0', 
					 'height' => '0',  
					 'length_class_id' => '1', 
					 'status' => '', 
					 'tax_class_id' => '', 
					 'sort_order' => '1',
					 'image' => '',
					 'product_description' => array( '2' => 
						array(
						'name'             => strtolower($related_info['name']),
						'description'      => $related_info['name'],
						'meta_title'       => strtolower($related_info['name']),
						'meta_description' => $related_info['name'],
						'meta_keyword'     => $related_info['name'],
						'tag'              => $related_info['name']
						)
					),
					'product_store' => array( '0' => '0')
				);
				$this->load->model('catalog/product');
				$product_id=$this->model_catalog_product->addProduct($data);	
			}
			return $product_id;

	}
	
	
	public function addmasivo() {
		$this->load->language('catalog/nproduct');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('catalog/nproduct');
		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $product_id) {
				$this->add($product_id);
				//print_r($product_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('catalog/nproduct', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getList();
	}
	
	
}

