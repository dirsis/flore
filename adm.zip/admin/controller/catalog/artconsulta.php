<?php
class ControllerCatalogArtconsulta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/artconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->getForm();
	}

	public function edit() {
		
ini_set('display_errors', 1);

error_reporting(E_ALL);
		
		$this->load->language('catalog/artconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			
			
			$this->load->model('setting/setting');
			$key="config_artconsulta_banner";
			$value=$this->request->post['banner_id'];
			$this->model_setting_setting->bajaosubeSetting($key, $value);
			
			$key="config_artconsulta_exacto";
			$value=$this->request->post['exacto_id'];
			$this->model_setting_setting->bajaosubeSetting($key, $value);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('catalog/artconsulta', 'user_token=' . $this->session->data['user_token'] , true));
		}

		$this->getForm();
	}

	protected function getForm() {
		
		

		
		$data['text_form'] = $this->language->get('text_edit');
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),

			'href' => $this->url->link('catalog/artconsulta', 'user_token=' . $this->session->data['user_token'], true)
		);
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['action'] = $this->url->link('catalog/artconsulta/edit', 'user_token=' . $this->session->data['user_token'] , true);

		$data['cancel'] = $this->url->link('catalog/artconsulta', 'user_token=' . $this->session->data['user_token'] , true);

		$data['user_token'] = $this->session->data['user_token'];


		$data['exacto_id'] 	= $this->config->get('config_artconsulta_exacto');
		$data['banner_id'] 	= $this->config->get('config_artconsulta_banner');
		
		$data['exactos'][] = array ("id" => '1',"name" => "Si");
		$data['exactos'][] = array ("id" => '2',"name" => "No");
		
		
		$this->load->model('design/banner');
		$data['banners'] = $this->model_design_banner->getBanners();

		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$this->response->setOutput($this->load->view('catalog/artconsulta_form', $data));
	}

	
}

