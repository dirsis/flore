<?php
class ControllerDirsismeliProduct extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsismeli/product');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismeli/rutinas');
		
		$this->getList();
	}

	protected function getList() {	
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_model'])) {
			$filter_model = $this->request->get['filter_model'];
		} else {
			$filter_model = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = 'active';
		}


		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_model'])) {
			$url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsismeli/product', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['products'] = array();

		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_model'	  => $filter_model,
			'filter_status'   => $filter_status,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);

		$data['totals']= $this->model_dirsismeli_rutinas->getTotalProducts($filter_data);
		$results = $this->model_dirsismeli_rutinas->getProducts($filter_data);

		$product_total=0;
		foreach ($data['totals'] as $result) {
			$product_total+= (int)$result['items'];
		}

		foreach ($results as $result) {
			$data['products'][] = array(
				'id' => $result['id'],
				'marketplaceimg' => $result['marketplaceimg'],
				'marketplace' => $result['marketplace'],
				'mla' => $result['mla'],
				'title' => $result['title'],
				'status' => $result['status'],
				'category_id' => $result['category_id'],
				'category' => $result['category'],
				'price' => $result['price'],
				'available_quantity' => $result['available_quantity'],
				'sold_quantity' => $result['sold_quantity'],
				'permalink' => $result['permalink'],
				'thumbnail' => $result['thumbnail'],
				'attributes' => $result['attributes']
			);
		}
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_model'])) {
			$url .= '&filter_model=' . urlencode(html_entity_decode($this->request->get['filter_model'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsismeli/product', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_model'] = $filter_model;
		$data['filter_status'] = $filter_status;;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsismeli/product_list', $data));
	}

	public function meliactualizarstock() {
		$json=array();
		if (isset($this->request->get['mla']) || isset($this->request->get['quantity'])) {
			$filter_data = array(
				'mla'  => $this->request->get['mla'],
				'quantity'  => (int)$this->request->get['quantity']
			);
			$this->load->model('dirsismeli/rutinas');
			$json = $this->model_dirsismeli_rutinas->actualizaStock($filter_data);		
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function meliactualizarprecio() {
		$json=array();
		if (isset($this->request->get['mla']) || isset($this->request->get['price'])) {
			$filter_data = array(
				'mla'  => $this->request->get['mla'],
				'price'  => (float)$this->request->get['price']
			);
			$this->load->model('dirsismeli/rutinas');
			$json = $this->model_dirsismeli_rutinas->actualizaPrecio($filter_data);		
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

	}	
	public function meliactualizarestado() {
		$json=array();
		if (isset($this->request->get['mla']) || isset($this->request->get['status'])) {
			$filter_data = array(
				'mla'  => $this->request->get['mla'],
				'status'  => $this->request->get['status']
			);
			$this->load->model('dirsismeli/rutinas');
			$json = $this->model_dirsismeli_rutinas->actualizaEstado($filter_data);		
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
}

