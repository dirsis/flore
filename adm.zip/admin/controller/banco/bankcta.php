<?php
class ControllerBancoBankcta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('banco/bankcta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankcta');

		$this->getList();
	}

	public function add() {
		$this->load->language('banco/bankcta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankcta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_banco_bankcta->addBankcta($this->request->post);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_descrip'])) {
				$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
			}
			if (isset($this->request->get['filter_tipo'])) {
				$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getForm();
	}

	public function edit() {
		$this->load->language('banco/bankcta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankcta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_banco_bankcta->editBankcta($this->request->get['bankcta_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_descrip'])) {
				$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
			}
			if (isset($this->request->get['filter_tipo'])) {
				$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('banco/bankcta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankcta');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $bankcta_id) {
				$this->model_banco_bankcta->deleteBankcta($bankcta_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_descrip'])) {
				$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
			}

			if (isset($this->request->get['filter_tipo'])) {
				$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		$data['nivel']=9;
		$data['user_id']=$this->user->getId();
		$data['bank']=9;	
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
			$data['bank']=$user_info['bank'];	
			$data['username']=$user_info['username'];
		}		
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}

		if (isset($this->request->get['filter_tipo'])) {
			$filter_tipo = $this->request->get['filter_tipo'];
		} else {
			$filter_tipo = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_tipo'])) {
			$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
		}
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['nivel']=9;
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
		}	
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('banco/bankcta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('banco/bankcta/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['bankctas'] = array();
		
		$filter_data = array(
			'filter_descrip'       	=> $filter_descrip,
			'filter_tipo'        	=> $filter_tipo,
			'filter_status'        	=> $filter_status,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		
		$this->load->model('customer/customer');
		$this->load->model('banco/transmovim');
		
		$bankcta_total = $this->model_banco_bankcta->getTotalBankctas($filter_data);
		
		$results = $this->model_banco_bankcta->getBankctas($filter_data);
		$negativos=$positivos=0;
		foreach ($results as $result) {
			$saldo=$this->model_banco_transmovim->getTotalByBankctaTransmovim($result['bankcta_id']);
			$data['bankctas'][] = array(
				'bankcta_id'     => $result['bankcta_id'],
				'tipo'       	 => $result['tipo'],
				'descrip'        => $result['descrip'],
				'origen'      	 => $this->model_banco_bankcta->getBankorigen($result['origen']),
				'saldo'			 => $this->currency->format( $saldo, $this->config->get( 'config_currency' ) ),
				'customer_id'    => $result['customer_id'],
				'comision'        => $result['comision'],
				'customer'    	 => $this->model_customer_customer->getCustomername($result['customer_id']),
				'status'      	 => ($result['status']=='1')?$this->language->get('text_enabled'):$this->language->get('text_disabled'),
				'edit'           => $this->url->link('banco/bankcta/edit', 'user_token=' . $this->session->data['user_token'] . '&bankcta_id=' . $result['bankcta_id'] . $url, true),
				'list'           => $this->url->link('banco/transmovim','user_token='. $this->session->data['user_token'] .'&filter_bankcta_id=' . $result['bankcta_id'].'&filter_customer_id='.$result['customer_id'] . $url, true)
			);
			if ($saldo<0){
				$negativos=$negativos+$saldo;
			}else{
				$positivos=$positivos+$saldo;
			}
		}
		
		$data['totalpositivas'] = $this->currency->format($negativos, $this->config->get( 'config_currency' ) );
		$data['totalnegativas'] = $this->currency->format($positivos, $this->config->get( 'config_currency' ) );
		$data['totalgenerales'] = $this->currency->format($negativos+$positivos, $this->config->get( 'config_currency' ) );
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		if (isset($this->request->get['filter_tipo'])) {
			$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
		}
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

$data['sort_bankcta_id'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . '&sort=bankcta_id' . $url, true);
$data['sort_tipo'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . '&sort=tipo' . $url, true);		
$data['sort_descrip'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . '&sort=descrip' . $url, true);
$data['sort_status'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
$data['sort_origen'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . '&sort=origen' . $url, true);		
		
		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_tipo'])) {
			$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
		}
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}

		$pagination = new Pagination();
		$pagination->total = $bankcta_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($bankcta_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($bankcta_total - $this->config->get('config_limit_admin'))) ? $bankcta_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $bankcta_total, ceil($bankcta_total / $this->config->get('config_limit_admin')));

		$data['filter_descrip']	= $filter_descrip;
		$data['filter_tipo']	= $filter_tipo;
		$data['filter_status']	= $filter_status;
		
		//print_r($data);

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankcta_list', $data));
	}

	protected function getForm() {
		
		$data['text_form'] = !isset($this->request->get['bankcta_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['bankcta_id'])) {
			$data['bankcta_id'] = $this->request->get['bankcta_id'];
		} else {
			$data['bankcta_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['descrip'])) {
			$data['error_descrip'] = $this->error['descrip'];
		} else {
			$data['error_descrip'] = '';
		}	
		if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}		
		if (isset($this->error['tipo'])) {
			$data['error_tipo'] = $this->error['tipo'];
		} else {
			$data['error_tipo'] = '';
		}		
		
		$url = '';
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_tipo'])) {
			$url .= '&filter_tipo=' . $this->request->get['filter_tipo'];
		}
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		
		
		if (!isset($this->request->get['bankcta_id'])) {
			$data['action'] = $this->url->link('banco/bankcta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('banco/bankcta/edit', 'user_token=' . $this->session->data['user_token'] . '&bankcta_id=' . $this->request->get['bankcta_id'] . $url, true);
		}
		
		$data['cancel'] = $this->url->link('banco/bankcta', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['bankcta_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$bankcta_info = $this->model_banco_bankcta->getBankcta($this->request->get['bankcta_id']);
		}

		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($bankcta_info)) {
			$data['descrip'] = $bankcta_info['descrip'];
		} else {
			$data['descrip'] = '';
		}
		
		if (isset($this->request->post['tipo'])) {
			$data['tipo'] = $this->request->post['tipo'];
		} elseif (!empty($bankcta_info)) {
			$data['tipo'] = $bankcta_info['tipo'];
		} else {
			$data['tipo'] = '';
		}
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($bankcta_info)) {
			$data['status'] = $bankcta_info['status'];
		} else {
			$data['status'] = '0';
		}
		if (isset($this->request->post['bankcta_id'])) {
			$data['bankcta_id'] = $this->request->post['bankcta_id'];
		} elseif (!empty($bankcta_info)) {
			$data['bankcta_id'] = $bankcta_info['bankcta_id'];
		} else {
			$data['bankcta_id'] = '0';
		}	
		
		if (isset($this->request->post['origen'])) {
			$data['origen'] = $this->request->post['origen'];
		} elseif (!empty($bankcta_info)) {
			$data['origen'] = $bankcta_info['origen'];
		} else {
			$data['origen'] = '0';
		}	
		
		if (isset($this->request->post['comision'])) {
			$data['comision'] = $this->request->post['comision'];
		} elseif (!empty($bankcta_info)) {
			$data['comision'] = $bankcta_info['comision'];
		} else {
			$data['comision'] = '0';
		}		
		
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($bankcta_info)) {
			$data['customer_id'] = $bankcta_info['customer_id'];
		} else {
			$data['customer_id'] = '0';
		}	
		
		
		
		$this->load->model('customer/customer');
		$data['customers'] = $this->model_customer_customer->getCustomers();
		
		$data['bankrelacions'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['bankcta_id']!=0){
				$relacion = $this->model_banco_bankcta->getBankrelacion($data['bankcta_id'],$result['user_id']);	
			}else{
				$relacion = "0";
			}
			$orden++;
			$data['bankrelacions'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'relacion'		 => $relacion,
				'orden'			 => $orden
			);
		}	
		
		$data['bankabcs'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['bankcta_id']!=0){
				$abc = $this->model_banco_bankcta->getBankabc($data['bankcta_id'],$result['user_id']);	
			}else{
				$abc = "0";
			}
			$orden++;
			$data['bankabcs'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'abc'		 => $abc,
				'orden'			 => $orden
			);
		}
		
		$data['bankdels'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['bankcta_id']!=0){
				$del = $this->model_banco_bankcta->getBankdel($data['bankcta_id'],$result['user_id']);	
			}else{
				$del = "0";
			}
			$orden++;
			$data['bankdels'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'del'		 	 => $del,
				'orden'			 => $orden
			);
		}	
		
		$this->load->model('banco/bankcta');
		$data['bankctas'] = $this->model_banco_bankcta->getBankctas(array());
		

		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankcta_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'banco/bankcta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 32)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
		
		if ($this->request->post['customer_id']<0) {
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		} 
		
		if (empty(utf8_strlen($this->request->post['tipo']))) {
			$this->error['tipo'] = $this->language->get('error_tipo');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'banco/bankcta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
}