<?php
class ControllerBancoBankinver extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('banco/bankinver');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankinver');

		$this->getList();
	}

	public function add() {
		$this->load->language('banco/bankinver');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankinver');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_banco_bankinver->addBankinver($this->request->post);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_interes'])) {
				$url .= '&filter_interes=' . urlencode(html_entity_decode($this->request->get['filter_interes']));
			}
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}
			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getForm();
	}

	public function edit() {
		$this->load->language('banco/bankinver');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankinver');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_banco_bankinver->editBankinver($this->request->get['bankinver_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}
			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}			
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function editverify() {
		$verify='1';
		if (isset($this->request->get['id'])) {
			$this->load->model('banco/bankinver');
			$verify = $this->model_banco_bankinver->editverifyBankinver($this->request->get['id']);
		}
		echo $verify;
	}

	public function editstatus() {
		$status='1';
		if (isset($this->request->get['id'])) {
			$this->load->model('banco/bankinver');
			$status = $this->model_banco_bankinver->editstatusBankinver($this->request->get['id']);
		}
		echo $status;
	}
	
	public function delete() {
		$this->load->language('banco/bankinver');

		$this->document->setTitle($this->language->get('heading_title'));

		
		
		$this->load->model('banco/bankinver');
		$this->load->model('banco/bankcta');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			$mensajeresultado="";
			foreach ($this->request->post['selected'] as $bankinver_id) {
				$operacion=$this->model_banco_bankinver->getBankinver($bankinver_id);
				$customer_id=$operacion['customer_id'];
				$result=$this->model_banco_bankcta->getBankdel($customer_id,$this->user->getId());
				if ($result=='1'){
					$this->model_banco_bankinver->deleteBankinver($bankinver_id);
				}else{
					$mensajeresultado.=$bankinver_id.",";
				}
			}
			if (!empty($mensajeresultado)){
				$this->session->data['success'] = $this->language->get('text_success')."-Sin permiso para estas oper.: ".$mensajeresultado;
			}else{
				$this->session->data['success'] = $this->language->get('text_success');
			}

			$url = '';

			if (isset($this->request->get['filter_interes'])) {
				$url .= '&filter_interes=' . $this->request->get['filter_interes'];
			}
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}	
			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_fecha'])) {
			$filter_fecha = $this->request->get['filter_fecha'];
		} else {
			$filter_fecha = '';
		}
		
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		
		if (isset($this->request->get['filter_interes'])) {
			$filter_interes = $this->request->get['filter_interes'];
		} else {
			$filter_interes = '';
		}	
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'fecha';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_verify'])) {
			$url .= '&filter_verify=' . $this->request->get['filter_verify'];
		}		
		if (isset($this->request->get['filter_interes'])) {
			$url .= '&filter_interes=' . urlencode(html_entity_decode($this->request->get['filter_interes']));
		}



		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		/*
		$data['nivel']=9;
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
		}
		*/

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('banco/bankinver/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('banco/bankinver/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		/*

		$data['bankinvers'] = array();
		
		if ($data['bank']=='1'){
			$filter_user_id=$this->user->getId();
		}else{
			$filter_user_id=0;
		}
		*/
		

		$filter_data = array(
			'filter_fecha'          => $filter_fecha,
			'filter_customer_id'	 	=> $filter_customer_id,
			'filter_status'        	=> $filter_status,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		$bankinver_total = $this->model_banco_bankinver->getTotalBankinvers($filter_data,$this->user->getId());
		
		/*
	
		$results = $this->model_banco_bankinver->getBankinversumas($filter_data,$this->user->getId());
		
		$data['totales'] = array(
				'acumulados'   => $this->currency->format($results['acumulados'], $this->config->get('config_currency')),
				'auditados'    => $this->currency->format($results['auditados'], $this->config->get('config_currency')),
				'verificados'  => $this->currency->format($results['verificados'], $this->config->get('config_currency')),
				'invertidos'   => $this->currency->format($results['invertidos'], $this->config->get('config_currency'))
		);
		*/

		$results = $this->model_banco_bankinver->getBankinvers($filter_data,$this->user->getId());
		
		foreach ($results as $result) {
			$data['bankinvers'][] = array(
				'bankinver_id'    	 => $result['bankinver_id'],
				'customer_id'    	 => $result['customer_id'],
				'fecha'     	=> date($this->language->get('date_format_short'), strtotime($result['fecha'])),
				'fecha_final'     	=> date($this->language->get('date_format_short'), strtotime($result['fecha_final'])),
				'interes'       => $result['interes'],
				'name'       => $result['name'],
				'notauser'       => $result['notauser'],
				'importe'          => $this->currency->format($result['importe'], $this->config->get('config_currency')),
				'dias'          => $result['dias'],
				'status'      	 => $result['status']==1?"Activo":"Cancelado",	
				'liqui'           => $this->url->link('banco/bankinver/edit', 'user_token=' . $this->session->data['user_token'] . '&bankinver_id=' . $result['bankinver_id'] . $url, true),
				'edit'           => $this->url->link('banco/bankinver/edit', 'user_token=' . $this->session->data['user_token'] . '&bankinver_id=' . $result['bankinver_id'] . $url, true)
			);
		}
		
//print_r($data['bankinvers']);
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_bankinver_id'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.bankinver_id' . $url, true);
		$data['sort_customer_id'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.customer_id' . $url, true);
		$data['sort_fecha'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.fecha' . $url, true);
		$data['sort_name'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.namer' . $url, true);
		$data['sort_importe'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.importe' . $url, true);
		$data['sort_dias'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.dias' . $url, true);
		$data['sort_notauser'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.notauser' . $url, true);
		$data['sort_status'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankinver.status' . $url, true);
		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}


		$pagination = new Pagination();
		$pagination->total = $bankinver_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($bankinver_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($bankinver_total - $this->config->get('config_limit_admin'))) ? $bankinver_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $bankinver_total, ceil($bankinver_total / $this->config->get('config_limit_admin')));

		$data['filter_fecha'] 	= $filter_fecha;
		$data['filter_customer_id'] = $filter_customer_id;
		$data['filter_status']	= $filter_status;
		
		$this->load->model('customer/customer');
		$data['customers'] = $this->model_customer_customer->getCustomers();

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankinver_list', $data));
	}

	protected function getForm() {
		
		$data['text_form'] = !isset($this->request->get['bankinver_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['bankinver_id'])) {
			$data['bankinver_id'] = $this->request->get['bankinver_id'];
		} else {
			$data['bankinver_id'] = 0;
		}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['importe'])) {
			$data['error_importe'] = $this->error['importe'];
		} else {
			$data['error_importe'] = '';
		}
		if (isset($this->error['interes'])) {
			$data['error_interes'] = $this->error['interes'];
		} else {
			$data['error_interes'] = '';
		}		
		if (isset($this->error['dias'])) {
			$data['error_dias'] = $this->error['dias'];
		} else {
			$data['error_dias'] = '';
		}		
	
		
		$url = '';
		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		
		
		if (!isset($this->request->get['bankinver_id'])) {
			$data['action'] = $this->url->link('banco/bankinver/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('banco/bankinver/edit', 'user_token=' . $this->session->data['user_token'] . '&bankinver_id=' . $this->request->get['bankinver_id'] . $url, true);
		}
		
		$data['cancel'] = $this->url->link('banco/bankinver', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['bankinver_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$bankinver_info = $this->model_banco_bankinver->getBankinver($this->request->get['bankinver_id']);
		}

		if (isset($this->request->post['fecha'])) {
			$data['fecha'] = date("Y-m-d", strtotime($this->request->post['fecha']));
		} elseif (!empty($bankinver_info)) {
			$data['fecha'] = date("Y-m-d", strtotime($bankinver_info['fecha']));
		} else {
			$data['fecha'] = date("Y-m-d"); 
		}

		if (isset($this->request->post['notauser'])) {
			$data['notauser'] = $this->request->post['notauser'];
		} elseif (!empty($bankinver_info)) {
			$data['notauser'] = $bankinver_info['notauser'];
		} else {
			$data['notauser'] = '';
		}

		if (isset($this->request->post['importe'])) {
			$data['importe'] = $this->request->post['importe'];
		} elseif (!empty($bankinver_info)) {
			$data['importe'] = $bankinver_info['importe'];
		} else {
			$data['importe'] = '0';
		}
		
		if (isset($this->request->post['interes'])) {
			$data['interes'] = $this->request->post['interes'];
		} elseif (!empty($bankinver_info)) {
			$data['interes'] = $bankinver_info['interes'];
		} else {
			$data['interes'] = '0';
		}	
		
		if (isset($this->request->post['dias'])) {
			$data['dias'] = $this->request->post['dias'];
		} elseif (!empty($bankinver_info)) {
			$data['dias'] = $bankinver_info['dias'];
		} else {
			$data['dias'] = '0';
		}		

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($bankinver_info)) {
			$data['status'] = $bankinver_info['status'];
		} else {
			$data['status'] = '1';
		}
		
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($bankinver_info)) {
			$data['customer_id'] = $bankinver_info['customer_id'];
		} else {
			$data['customer_id'] = '1';
		}		
		
		$this->load->model('customer/customer');
		$data['customers'] = $this->model_customer_customer->getCustomers();

		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankinver_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'banco/bankinver')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ($this->request->post['customer_id'] <= 0) {
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		}
		if ($this->request->post['interes'] <= 0) {
			$this->error['interes'] = $this->language->get('error_interes');
		}
		if ($this->request->post['importe'] <= 0) {
			$this->error['importe'] = $this->language->get('error_importe');
		}
		if ($this->request->post['dias'] <= 0) {
			$this->error['dias'] = $this->language->get('error_dias');
		}		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'banco/bankinver')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	


}