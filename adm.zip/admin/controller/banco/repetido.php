<?php
class ControllerBancoRepetido extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('banco/repetido');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/repetido');

		$this->getList();
	}

	public function add() {
		$this->load->language('banco/repetido');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/repetido');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_banco_repetido->addRepetido($this->request->post);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . $this->request->get['filter_titular'];
			}
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . $this->request->get['filter_customer'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getForm();
	}

	public function edit() {
		$this->load->language('banco/repetido');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/repetido');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_banco_repetido->editRepetido($this->request->get['customer_repetido_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';


			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . $this->request->get['filter_titular'];
			}
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . $this->request->get['filter_customer'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('banco/repetido');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/repetido');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $customer_repetido_id) {
				$this->model_banco_repetido->deleteRepetido($customer_repetido_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . $this->request->get['filter_titular'];
			}
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . $this->request->get['filter_customer'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_titular'])) {
			$filter_titular = $this->request->get['filter_titular'];
		} else {
			$filter_titular = '';
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'titular';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . $this->request->get['filter_titular'];
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['nivel']=9;
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
		}	
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('banco/repetido/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('banco/repetido/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['repetidos'] = array();
		
		$filter_data = array(
			'filter_titular'       	=> $filter_titular,
			'filter_customer'       	=> $filter_customer,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		$this->load->model('banco/repetido');
		
		$repetido_total = $this->model_banco_repetido->getTotalRepetidos($filter_data);
		
		$results = $this->model_banco_repetido->getRepetidos($filter_data);
		$totalficha=$negativos=$positivos=0;
		foreach ($results as $result) {
			$saldo=$this->model_banco_repetido->getSaldo($result['customer_repetido_id']);
			$ficha=$this->model_banco_repetido->getFicha($result['customer_repetido_id']);
			$data['repetidos'][] = array(
				'customer_repetido_id'     => $result['customer_repetido_id'],
				'titular'        => $result['titular'],
				'customer'        => $result['customer'],
				'saldo'			 => $this->currency->format( $saldo, $this->config->get( 'config_currency' ) ),
				'ficha'			 => number_format( $ficha,0),
				'edit'           => $this->url->link('banco/repetido/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_repetido_id=' . $result['customer_repetido_id'] . $url, true),
			);
			if ($saldo<0){
				$negativos=$negativos+$saldo;
			}else{
				$positivos=$positivos+$saldo;
			}
			$totalficha=$totalficha+$ficha;
		}
		
		$data['totalficha'] = number_format( $totalficha,0);
		
		$data['totalpositivas'] = $this->currency->format($negativos, $this->config->get( 'config_currency' ) );
		$data['totalnegativas'] = $this->currency->format($positivos, $this->config->get( 'config_currency' ) );
		$data['totalgenerales'] = $this->currency->format($negativos+$positivos, $this->config->get( 'config_currency' ) );
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . $this->request->get['filter_titular'];
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}		

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_customer_repetido_id'] = $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . '&sort=a.customer_repetido_id' . $url, true);
		$data['sort_titular'] = $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . '&sort=a.titular' . $url, true);
		$data['sort_customer_id'] = $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . '&sort=a.customer_id' . $url, true);		
		
		$url = '';


		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . $this->request->get['filter_titular'];
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}		

		$pagination = new Pagination();
		$pagination->total = $repetido_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($repetido_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($repetido_total - $this->config->get('config_limit_admin'))) ? $repetido_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $repetido_total, ceil($repetido_total / $this->config->get('config_limit_admin')));

		$data['filter_titular']		= $filter_titular;
		$data['filter_customer']	= $filter_customer;
		
		//print_r($data);

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/repetido_list', $data));
	}

	protected function getForm() {
		
		$data['text_form'] = !isset($this->request->get['customer_repetido_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['customer_repetido_id'])) {
			$data['customer_repetido_id'] = $this->request->get['customer_repetido_id'];
		} else {
			$data['customer_repetido_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['titular'])) {
			$data['error_titular'] = $this->error['titular'];
		} else {
			$data['error_titular'] = '';
		}	
		if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}		
		if (isset($this->error['tipo'])) {
			$data['error_tipo'] = $this->error['tipo'];
		} else {
			$data['error_tipo'] = '';
		}		
		
		$url = '';

		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . $this->request->get['filter_titular'];
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		
		
		if (!isset($this->request->get['customer_repetido_id'])) {
			$data['action'] = $this->url->link('banco/repetido/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('banco/repetido/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_repetido_id=' . $this->request->get['customer_repetido_id'] . $url, true);
		}
		
		$data['cancel'] = $this->url->link('banco/repetido', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['customer_repetido_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$repetido_info = $this->model_banco_repetido->getRepetido($this->request->get['customer_repetido_id']);
		}

		if (isset($this->request->post['titular'])) {
			$data['titular'] = $this->request->post['titular'];
		} elseif (!empty($repetido_info)) {
			$data['titular'] = $repetido_info['titular'];
		} else {
			$data['titular'] = '';
		}
		
		if (isset($this->request->post['tipo'])) {
			$data['tipo'] = $this->request->post['tipo'];
		} elseif (!empty($repetido_info)) {
			$data['tipo'] = $repetido_info['tipo'];
		} else {
			$data['tipo'] = '';
		}
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($repetido_info)) {
			$data['status'] = $repetido_info['status'];
		} else {
			$data['status'] = '0';
		}
		if (isset($this->request->post['customer_repetido_id'])) {
			$data['customer_repetido_id'] = $this->request->post['customer_repetido_id'];
		} elseif (!empty($repetido_info)) {
			$data['customer_repetido_id'] = $repetido_info['customer_repetido_id'];
		} else {
			$data['customer_repetido_id'] = '0';
		}	
		
		if (isset($this->request->post['origen'])) {
			$data['origen'] = $this->request->post['origen'];
		} elseif (!empty($repetido_info)) {
			$data['origen'] = $repetido_info['origen'];
		} else {
			$data['origen'] = '0';
		}	
		
		if (isset($this->request->post['comision'])) {
			$data['comision'] = $this->request->post['comision'];
		} elseif (!empty($repetido_info)) {
			$data['comision'] = $repetido_info['comision'];
		} else {
			$data['comision'] = '0';
		}		
		
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($repetido_info)) {
			$data['customer_id'] = $repetido_info['customer_id'];
		} else {
			$data['customer_id'] = '0';
		}	
		
		
		
		$this->load->model('customer/customer');
		$data['customers'] = $this->model_customer_customer->getCustomers();
		
		$data['bankrelacions'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['customer_repetido_id']!=0){
				$relacion = $this->model_banco_repetido->getBankrelacion($data['customer_repetido_id'],$result['user_id']);	
			}else{
				$relacion = "0";
			}
			$orden++;
			$data['bankrelacions'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'relacion'		 => $relacion,
				'orden'			 => $orden
			);
		}	
		
		$data['bankabcs'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['customer_repetido_id']!=0){
				$abc = $this->model_banco_repetido->getBankabc($data['customer_repetido_id'],$result['user_id']);	
			}else{
				$abc = "0";
			}
			$orden++;
			$data['bankabcs'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'abc'		 => $abc,
				'orden'			 => $orden
			);
		}
		
		$data['bankdels'] = array();
		$this->load->model('user/user');
		$results = $this->model_user_user->getUsers();
		$orden=0;
		foreach ($results as $result) {
			if ($data['customer_repetido_id']!=0){
				$del = $this->model_banco_repetido->getBankdel($data['customer_repetido_id'],$result['user_id']);	
			}else{
				$del = "0";
			}
			$orden++;
			$data['bankdels'][] = array(
				'user_id'    	 => $result['user_id'],
				'username'       => $result['username'],
				'del'		 	 => $del,
				'orden'			 => $orden
			);
		}	
		
		$this->load->model('banco/repetido');
		$data['repetidos'] = $this->model_banco_repetido->getRepetidos(array());
		

		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/repetido_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'banco/repetido')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['titular']) < 1) || (utf8_strlen(trim($this->request->post['titular'])) > 32)) {
			$this->error['titular'] = $this->language->get('error_titular');
		}
		
		if ($this->request->post['customer_id']<0) {
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		} 
		
		if (empty(utf8_strlen($this->request->post['tipo']))) {
			$this->error['tipo'] = $this->language->get('error_tipo');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'banco/repetido')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
}