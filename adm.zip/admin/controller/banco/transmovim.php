<?php
class ControllerBancoTransmovim extends Controller {
	private $error = array();
	public	function index() {
		$this->load->language( 'banco/transmovim' );
		$this->document->setTitle( $this->language->get( 'heading_title' ) );
		$this->load->model( 'banco/transmovim' );
		$this->getList();
	}
	public	function add() {
		$this->load->language( 'banco/transmovim' );
		$this->document->setTitle( $this->language->get( 'heading_title' ) );
		$this->load->model( 'banco/transmovim' );
		if ( ( $this->request->server[ 'REQUEST_METHOD' ] == 'POST' ) && $this->validateForm() ) {
			$this->model_banco_transmovim->addTransmovim( $this->request->post );
			$this->session->data[ 'success' ] = $this->language->get( 'text_success' );
			$url = '';
			if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
				$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
			}
			if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
				$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
			}
			if ( isset( $this->request->get[ 'filter_description' ] ) ) {
				$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
			}
			if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
				$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
			}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
			
			if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
				$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
			}
			if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
				$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
			}
			if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
				$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
			}
			if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
				$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
			}
			if ( isset( $this->request->get[ 'sort' ] ) ) {
				$url .= '&sort=' . $this->request->get[ 'sort' ];
			}
			if ( isset( $this->request->get[ 'order' ] ) ) {
				$url .= '&order=' . $this->request->get[ 'order' ];
			}
			if ( isset( $this->request->get[ 'page' ] ) ) {
				$url .= '&page=' . $this->request->get[ 'page' ];
			}
			$this->response->redirect( $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true ) );
		}
		$this->getForm();
	}
	public	function edit() {
		$this->load->language( 'banco/transmovim' );
		$this->document->setTitle( $this->language->get( 'heading_title' ) );
		$this->load->model( 'banco/transmovim' );
		if ( ( $this->request->server[ 'REQUEST_METHOD' ] == 'POST' ) && $this->validateForm() ) {
			$this->model_banco_transmovim->editTransmovim2( $this->request->get[ 'customer_transaction_id' ], $this->request->post );
			
			$this->session->data[ 'success' ] = $this->language->get( 'text_success' );
			$url = '';
			if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
				$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
			}
			if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
				$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
			}
			if ( isset( $this->request->get[ 'filter_description' ] ) ) {
				$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
			}
			if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
				$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
			}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
			
			if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
				$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
			}
			if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
				$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
			}
			if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
				$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
			}
			if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
				$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
			}
			if ( isset( $this->request->get[ 'sort' ] ) ) {
				$url .= '&sort=' . $this->request->get[ 'sort' ];
			}
			if ( isset( $this->request->get[ 'order' ] ) ) {
				$url .= '&order=' . $this->request->get[ 'order' ];
			}
			if ( isset( $this->request->get[ 'page' ] ) ) {
				$url .= '&page=' . $this->request->get[ 'page' ];
			}
			$this->response->redirect( $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true ) );
		}
		$this->getForm();
	}
	public	function editorder_id() {
		$order_id = '1';
		if ( isset( $this->request->get[ 'id' ] ) ) {
			$this->load->model( 'banco/transmovim' );
			$order_id = $this->model_banco_transmovim->editorder_idTransmovim( $this->request->get[ 'id' ] );
		}
		echo $order_id;
	}
	public	function aprobar() {
		$order_id = 0;
		if ( isset( $this->request->get[ 'customer_transaction_id' ] ) ) {
			$this->load->model( 'banco/transmovim' );
			$this->model_banco_transmovim->Aprobar( $this->request->get[ 'customer_transaction_id' ] );
			$order_id = 1;
		}
		echo $order_id;
	}
	public	function actualizatotales() {
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$filter_description = urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
		} else {
			$filter_description = '';
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$filter_cuit = urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		} else {
			$filter_cuit = '';
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$filter_amount = $this->request->get[ 'filter_amount' ];
		} else {
			$filter_amount = '';
		}		
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$filter_fecha_desde = $this->request->get[ 'filter_fecha_desde' ];
		} else {
			$filter_fecha_desde = '';
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$filter_fecha_hasta = $this->request->get[ 'filter_fecha_hasta' ];
		} else {
			$filter_fecha_hasta = '';
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$filter_bankcta_id = $this->request->get[ 'filter_bankcta_id' ];
		} else {
			$filter_bankcta_id = '';
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$filter_customer_id = $this->request->get[ 'filter_customer_id' ];
		} else {
			$filter_customer_id = '';
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$filter_order_id = $this->request->get[ 'filter_order_id' ];
		} else {
			$filter_order_id = '';
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$filter_aprobado = $this->request->get[ 'filter_aprobado' ];
		} else {
			$filter_aprobado = '';
		}
		$filter_user_id = 0;
		$this->load->model( 'user/user' );
		$user_info = $this->model_user_user->getUser( $this->user->getId() );
		if ( $user_info ) {
			if ( $user_info[ 'user_group_nivel' ] != 0 ) {
				$filter_user_id = $this->user->getId();
			}
		}
		$filter_data = array( 'filter_fecha_desde' => $filter_fecha_desde, 
							 'filter_fecha_hasta' => $filter_fecha_hasta, 
							 'filter_customer_id' => $filter_customer_id, 
							 'filter_bankcta_id' => $filter_bankcta_id, 
							 'filter_description' => $filter_description, 
							 'filter_cuit' => $filter_cuit, 
							 'filter_amount' => $filter_amount,
							 'filter_user_id' => $filter_user_id, 
							 'filter_order_id' => $filter_order_id, 
							 'filter_aprobado' => $filter_aprobado );
		$this->load->model( 'banco/transmovim' );
		$results = $this->model_banco_transmovim->getTransmovimsumas( $filter_data, $this->user->getId() );
		$totales = array( 'acumulados' => $this->currency->format( $results[ 'acumulados' ], $this->config->get( 'config_currency' ) ), 'auditados' => $this->currency->format( $results[ 'auditados' ], $this->config->get( 'config_currency' ) ), 'verificados' => $this->currency->format( $results[ 'verificados' ], $this->config->get( 'config_currency' ) ), 'invertidos' => $this->currency->format( $results[ 'invertidos' ], $this->config->get( 'config_currency' ) ) );
		$this->response->addHeader( 'Content-Type: application/json' );
		$this->response->setOutput( json_encode( $totales ) );
	}
	public	function delete() {
		$this->load->language( 'banco/transmovim' );
		$this->document->setTitle( $this->language->get( 'heading_title' ) );
		$this->load->model( 'banco/transmovim' );
		if ( isset( $this->request->post[ 'selected' ] ) && $this->validateDelete() ) {
			$mensajeresultado = "";
			foreach ( $this->request->post[ 'selected' ] as $customer_transaction_id ) {
				$this->model_banco_transmovim->deleteTransmovim( $customer_transaction_id );
			}
			$this->session->data[ 'success' ] = $this->language->get( 'text_success' );
			$url = '';
			if ( isset( $this->request->get[ 'filter_description' ] ) ) {
				$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ], ENT_QUOTES, 'UTF-8' ) );
			}
			if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
				$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ], ENT_QUOTES, 'UTF-8' ) );
			}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
			
			if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
				$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
			}
			if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
				$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
			}
			if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
				$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
			}
			if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
				$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
			}
			if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
				$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
			}
			if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
				$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
			}
			if ( isset( $this->request->get[ 'sort' ] ) ) {
				$url .= '&sort=' . $this->request->get[ 'sort' ];
			}
			if ( isset( $this->request->get[ 'order' ] ) ) {
				$url .= '&order=' . $this->request->get[ 'order' ];
			}
			if ( isset( $this->request->get[ 'page' ] ) ) {
				$url .= '&page=' . $this->request->get[ 'page' ];
			}
			$this->response->redirect( $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true ) );
		}
		$this->getList();
	}
	protected	function getList() {
		$data[ 'nivel' ] = 9;
		$data[ 'user_id' ] = $this->user->getId();
		$data[ 'bank' ] = 9;
		$this->load->model( 'user/user' );
		$user_info = $this->model_user_user->getUser( $this->user->getId() );
		if ( $user_info ) {
			$data[ 'nivel' ] = $user_info[ 'user_group_nivel' ];
			$data[ 'bank' ] = $user_info[ 'bank' ];
			$data[ 'username' ] = $user_info[ 'username' ];
		}
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$filter_description = urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
			$filter_description = $this->request->get[ 'filter_description' ];
		} else {
			$filter_description = '';
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$filter_cuit = urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		} else {
			$filter_cuit = '';
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$filter_amount = $this->request->get[ 'filter_amount' ];
		} else {
			$filter_amount = '';
		}		
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$filter_fecha_desde = $this->request->get[ 'filter_fecha_desde' ];
		} else {
			$filter_fecha_desde = '';
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$filter_fecha_hasta = $this->request->get[ 'filter_fecha_hasta' ];
		} else {
			$filter_fecha_hasta = '';
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$filter_bankcta_id = $this->request->get[ 'filter_bankcta_id' ];
		} else {
			$filter_bankcta_id = '';
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$filter_customer_id = $this->request->get[ 'filter_customer_id' ];
		} else {
			$filter_customer_id = '';
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$filter_order_id = $this->request->get[ 'filter_order_id' ];
		} else {
			$filter_order_id = '-1';
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$filter_aprobado = $this->request->get[ 'filter_aprobado' ];
		} else {
			$filter_aprobado = '-1';
		}
		if ( isset( $this->request->get[ 'sort' ] ) ) {
			$sort = $this->request->get[ 'sort' ];
		} else {
			$sort = 'date_added,customer_transaction_id';
		}
		if ( isset( $this->request->get[ 'order' ] ) ) {
			$order = $this->request->get[ 'order' ];
		} else {
			$order = 'DESC';
		}
		if ( isset( $this->request->get[ 'page' ] ) ) {
			$page = $this->request->get[ 'page' ];
		} else {
			$page = 1;
		}
		$url = '';
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
		
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
		}
		if ( isset( $this->request->get[ 'sort' ] ) ) {
			$url .= '&sort=' . $this->request->get[ 'sort' ];
		}
		if ( isset( $this->request->get[ 'order' ] ) ) {
			$url .= '&order=' . $this->request->get[ 'order' ];
		}
		if ( isset( $this->request->get[ 'page' ] ) ) {
			$url .= '&page=' . $this->request->get[ 'page' ];
		}
		$data[ 'nivel' ] = 9;
		$this->load->model( 'user/user' );
		$user_info = $this->model_user_user->getUser( $this->user->getId() );
		if ( $user_info ) {
			$data[ 'nivel' ] = $user_info[ 'user_group_nivel' ];
		}
		$data[ 'breadcrumbs' ] = array();
		$data[ 'breadcrumbs' ][] = array( 'text' => $this->language->get( 'text_home' ), 'href' => $this->url->link( 'common/dashboard', 'user_token=' . $this->session->data[ 'user_token' ], true ) );
		$data[ 'breadcrumbs' ][] = array( 'text' => $this->language->get( 'heading_title' ), 'href' => $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true ) );
		$data[ 'add' ] = $this->url->link( 'banco/transmovim/add', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true );
		$data[ 'delete' ] = $this->url->link( 'banco/transmovim/delete', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true );
		$data[ 'transmovims' ] = array(); /*		if ($data['bank']=='1'){			$filter_user_id=$this->user->getId();		}else{			$filter_user_id=0;		}		*/
		$filter_data = array( 'filter_fecha_desde' => $filter_fecha_desde, 
							 'filter_fecha_hasta' => $filter_fecha_hasta, 
							 'filter_customer_id' => $filter_customer_id, 
							 'filter_bankcta_id' => $filter_bankcta_id, 
							 'filter_description' => $filter_description, 
							 'filter_cuit' => $filter_cuit, 
							 'filter_amount' => $filter_amount, 
							 'filter_order_id' => $filter_order_id, 
							 'filter_aprobado' => $filter_aprobado, 
							 'sort' => $sort, 
							 'order' => $order, 
							 'start' => ( $page - 1 ) * $this->config->get( 'config_limit_admin' ), 
							 'limit' => $this->config->get( 'config_limit_admin' ) );
		$transmovim_total = $this->model_banco_transmovim->getTotalTransmovims( $filter_data, $this->user->getId() );
		
		$totalpositivas = $this->model_banco_transmovim->getTotalValueTransmovim( $filter_data, $this->user->getId() ,1);
		$totalnegativas = $this->model_banco_transmovim->getTotalValueTransmovim( $filter_data, $this->user->getId() ,-1);
		
		$data['totalpositivas'] = $this->currency->format( $totalpositivas, $this->config->get( 'config_currency' ) );
		$data['totalnegativas'] = $this->currency->format( $totalnegativas, $this->config->get( 'config_currency' ) );
		$data['totalgenerales'] = $this->currency->format( $totalpositivas+$totalnegativas, $this->config->get( 'config_currency' ) );
			
		$transmovim_total = $this->model_banco_transmovim->getTotalTransmovims( $filter_data, $this->user->getId() );
		//print_r($filter_data);
		
		$fichas=$this->model_banco_transmovim->getTotalTransmovimsFichas( $filter_data, $this->user->getId() );
		$data[ 'totalficha' ] = number_format($fichas,0);
		
		$results = $this->model_banco_transmovim->getTransmovims( $filter_data, $this->user->getId() );
		$this->load->model( 'customer/customer' );
		$this->load->model( 'admdirsis/tmotivo' );
		$this->load->model( 'banco/bankcta' );
		$ficha=0;
		foreach ( $results as $result ) {
			$tmotivo = $this->model_admdirsis_tmotivo->getTmotivo2( $result[ 'motivo_id' ] );
			if ( $result[ 'bankcta_id' ] != 0 ) {
				$bankcta = $this->model_banco_bankcta->getBankcta( $result[ 'bankcta_id' ] );
				$bankcta = $bankcta[ 'descrip' ];
			} else {
				$bankcta = '';
			}
			//print_r($result);
			$aprobado=0;
			if ($tmotivo['aprobado'] == 1){
				$aprobado=$result['aprobado'];
			}else{
				if ($result['aprobado']==0 and DIRX_TKAPRUEBA=='S'){
					$aprobado=0;
				}else{
					$aprobado=1;
				}
			}
			$data[ 'transmovims' ][] = array( 
			 'customer_transaction_id' => $result[ 'customer_transaction_id' ], 
			 'customer_id' => $result[ 'customer_id' ], 
			 'customer' => $this->model_customer_customer->getCustomername( $result[ 'customer_id' ] ), 
			 'bankcta_id' => $result[ 'bankcta_id' ], 
			 'bankcta' => $bankcta, 
			 'date_added' => date( $this->language->get( 'date_format_short' ), strtotime( $result[ 'date_added' ] ) ), 
			 'cuit' => $result[ 'cuit' ], 
			 'description' => $result[ 'description' ], 
			 'amount' => $this->currency->format( $result[ 'amount' ], $this->config->get( 'config_currency' ) ), 
			 'ficha' =>  number_format($result[ 'ficha' ],0),
			 'order_id' => $result[ 'order_id' ], 
			 'registro' => $result[ 'registro' ],
			 'adjunto' => $result[ 'adjunto' ], 
			 'aprobado' => $aprobado, 
			 'tmotivo' => $tmotivo[ 'name' ], 
			 'motivo_id' => $result[ 'motivo_id' ], 
			 'linkadjunto' => HTTPS_CATALOG . 'image/catalog/productos/' . $result[ 'adjunto' ], 
			 'edit' => $this->url->link( 'banco/transmovim/edit', 
			 'user_token=' . $this->session->data[ 'user_token' ] . '&customer_transaction_id=' . $result[ 'customer_transaction_id' ] . $url, true ) );
			$ficha=$ficha+$result[ 'ficha' ];
		}
		
		//$data[ 'totalficha' ] = number_format($ficha,0);
		
		$data[ 'user_token' ] = $this->session->data[ 'user_token' ];
		if ( isset( $this->error[ 'warning' ] ) ) {
			$data[ 'error_warning' ] = $this->error[ 'warning' ];
		} else {
			$data[ 'error_warning' ] = '';
		}
		if ( isset( $this->session->data[ 'success' ] ) ) {
			$data[ 'success' ] = $this->session->data[ 'success' ];
			unset( $this->session->data[ 'success' ] );
		} else {
			$data[ 'success' ] = '';
		}
		if ( isset( $this->request->post[ 'selected' ] ) ) {
			$data[ 'selected' ] = ( array )$this->request->post[ 'selected' ];
		} else {
			$data[ 'selected' ] = array();
		}
		$url = '';
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
		}
		if ( $order == 'ASC' ) {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}
		if ( isset( $this->request->get[ 'page' ] ) ) {
			$url .= '&page=' . $this->request->get[ 'page' ];
		}
		$data[ 'sort_customer_transaction_id' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=customer_transaction_id' . $url, true );
		$data[ 'sort_customer_id' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=customer_id' . $url, true );
		$data[ 'sort_bankcta_id' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=bankcta_id' . $url, true );
		$data[ 'sort_date_added' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=date_added' . $url, true );
		$data[ 'sort_cuit' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=cuit' . $url, true );
		$data[ 'sort_description' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=description' . $url, true );
		$data[ 'sort_amount' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=amount' . $url, true );
		$data[ 'sort_registro' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=registro' . $url, true );
		$data[ 'sort_tmotivo' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=motivo_id' . $url, true );
		$data[ 'sort_order_id' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=order_id' . $url, true );
		$data[ 'sort_adjunto' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . '&sort=adjunto' . $url, true );
		$url = '';
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
		
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
		}
		$pagination = new Pagination();
		$pagination->total = $transmovim_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get( 'config_limit_admin' );
		$pagination->url = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url . '&page={page}', true );
		$data[ 'pagination' ] = $pagination->render();
		$data[ 'results' ] = sprintf( $this->language->get( 'text_pagination' ), ( $transmovim_total ) ? ( ( $page - 1 ) * $this->config->get( 'config_limit_admin' ) ) + 1 : 0, ( ( ( $page - 1 ) * $this->config->get( 'config_limit_admin' ) ) > ( $transmovim_total - $this->config->get( 'config_limit_admin' ) ) ) ? $transmovim_total : ( ( ( $page - 1 ) * $this->config->get( 'config_limit_admin' ) ) + $this->config->get( 'config_limit_admin' ) ), $transmovim_total, ceil( $transmovim_total / $this->config->get( 'config_limit_admin' ) ) );
		$data[ 'filter_description' ] = $filter_description;
		$data[ 'filter_cuit' ] = $filter_cuit;
		$data[ 'filter_amount' ] = $filter_amount;
		$data[ 'filter_fecha_desde' ] = $filter_fecha_desde;
		$data[ 'filter_fecha_hasta' ] = $filter_fecha_hasta;
		$data[ 'filter_customer_id' ] = $filter_customer_id;
		$data[ 'filter_bankcta_id' ] = $filter_bankcta_id;
		$data[ 'filter_order_id' ] = $filter_order_id;
		$data[ 'filter_aprobado' ] = $filter_aprobado;
		$this->load->model( 'banco/bankcta' );

		$data[ 'bankctas' ] = $this->model_banco_bankcta->getBankctas();
		$this->load->model( 'customer/customer' );
		$data[ 'customers' ] = $this->model_customer_customer->getCustomers();
		$data[ 'sort' ] = $sort;
		$data[ 'order' ] = $order;
		$data[ 'header' ] = $this->load->controller( 'common/header' );
		$data[ 'column_left' ] = $this->load->controller( 'common/column_left' );
		$data[ 'footer' ] = $this->load->controller( 'common/footer' );
		$this->response->setOutput( $this->load->view( 'banco/transmovim_list', $data ) );
	}
	protected	function getForm() {
		$data[ 'nivel' ] = 9;
		$data[ 'bank' ] = 9;
		$data[ 'user_id' ] = $this->user->getId();
		$this->load->model( 'user/user' );
		$user_info = $this->model_user_user->getUser( $this->user->getId() );
		if ( $user_info ) {
			$data[ 'nivel' ] = $user_info[ 'user_group_nivel' ];
			$data[ 'bank' ] = $user_info[ 'bank' ];
		}
		$data[ 'text_form' ] = !isset( $this->request->get[ 'customer_transaction_id' ] ) ? $this->language->get( 'text_add' ) : $this->language->get( 'text_edit' );
		$data[ 'user_token' ] = $this->session->data[ 'user_token' ];
		if ( isset( $this->request->get[ 'customer_transaction_id' ] ) ) {
			$data[ 'customer_transaction_id' ] = $this->request->get[ 'customer_transaction_id' ];
		} else {
			$data[ 'customer_transaction_id' ] = 0;
		}
		if ( isset( $this->error[ 'warning' ] ) ) {
			$data[ 'error_warning' ] = $this->error[ 'warning' ];
		} else {
			$data[ 'error_warning' ] = '';
		}
		if ( isset( $this->error[ 'description' ] ) ) {
			$data[ 'error_description' ] = $this->error[ 'description' ];
		} else {
			$data[ 'error_description' ] = '';
		}
		if ( isset( $this->error[ 'amount' ] ) ) {
			$data[ 'error_amount' ] = $this->error[ 'amount' ];
		} else {
			$data[ 'error_amount' ] = '';
		}
		if ( isset( $this->error[ 'cuit' ] ) ) {
			$data[ 'error_cuit' ] = $this->error[ 'cuit' ];
		} else {
			$data[ 'error_cuit' ] = '';
		}
		$url = '';
		if ( isset( $this->request->get[ 'filter_fecha_desde' ] ) ) {
			$url .= '&filter_fecha_desde=' . $this->request->get[ 'filter_fecha_desde' ];
		}
		if ( isset( $this->request->get[ 'filter_fecha_hasta' ] ) ) {
			$url .= '&filter_fecha_hasta=' . $this->request->get[ 'filter_fecha_hasta' ];
		}
		if ( isset( $this->request->get[ 'filter_bankcta_id' ] ) ) {
			$url .= '&filter_bankcta_id=' . $this->request->get[ 'filter_bankcta_id' ];
		}
		if ( isset( $this->request->get[ 'filter_customer_id' ] ) ) {
			$url .= '&filter_customer_id=' . $this->request->get[ 'filter_customer_id' ];
		}
		if ( isset( $this->request->get[ 'filter_order_id' ] ) ) {
			$url .= '&filter_order_id=' . $this->request->get[ 'filter_order_id' ];
		}
		if ( isset( $this->request->get[ 'filter_aprobado' ] ) ) {
			$url .= '&filter_aprobado=' . $this->request->get[ 'filter_aprobado' ];
		}
		if ( isset( $this->request->get[ 'filter_cuit' ] ) ) {
			$url .= '&filter_cuit=' . urlencode( html_entity_decode( $this->request->get[ 'filter_cuit' ] ) );
		}
		if ( isset( $this->request->get[ 'filter_amount' ] ) ) {
			$url .= '&filter_amount=' . $this->request->get[ 'filter_amount' ];
		}		
		
		if ( isset( $this->request->get[ 'filter_description' ] ) ) {
			$url .= '&filter_description=' . urlencode( html_entity_decode( $this->request->get[ 'filter_description' ] ) );
		}
		if ( isset( $this->request->get[ 'sort' ] ) ) {
			$url .= '&sort=' . $this->request->get[ 'sort' ];
		}
		if ( isset( $this->request->get[ 'order' ] ) ) {
			$url .= '&order=' . $this->request->get[ 'order' ];
		}
		if ( isset( $this->request->get[ 'page' ] ) ) {
			$url .= '&page=' . $this->request->get[ 'page' ];
		}
		
		
		
		
		
		
		$data[ 'breadcrumbs' ] = array();
		$data[ 'breadcrumbs' ][] = array( 'text' => $this->language->get( 'text_home' ), 'href' => $this->url->link( 'common/dashboard', 'user_token=' . $this->session->data[ 'user_token' ], true ) );
		$data[ 'breadcrumbs' ][] = array( 'text' => $this->language->get( 'heading_title' ), 'href' => $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true ) );
		
		
		if ( !isset( $this->request->get[ 'customer_transaction_id' ] ) ) {
			$data[ 'action' ] = $this->url->link( 'banco/transmovim/add', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true );
		} else {
			$data[ 'action' ] = $this->url->link( 'banco/transmovim/edit', 'user_token=' . $this->session->data[ 'user_token' ] . '&customer_transaction_id=' . $this->request->get[ 'customer_transaction_id' ] . $url, true );
		}
		$data[ 'cancel' ] = $this->url->link( 'banco/transmovim', 'user_token=' . $this->session->data[ 'user_token' ] . $url, true );
		
		if ( isset( $this->request->get[ 'customer_transaction_id' ] ) && ( $this->request->server[ 'REQUEST_METHOD' ] != 'POST' ) ) {
			$transmovim_info = $this->model_banco_transmovim->getTransmovim( $this->request->get[ 'customer_transaction_id' ] );
		}
		
		/*
		echo "<pre>";
		print_r($transmovim_info);
		echo "</pre>";
		*/
		
		if ( isset( $this->request->post[ 'customer_id' ] ) ) {
			$data[ 'customer_id' ] = $this->request->post[ 'customer_id' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'customer_id' ] = $transmovim_info[ 'customer_id' ];
		}
		if ( isset( $this->request->post[ 'order_id' ] ) ) {
			$data[ 'order_id' ] = $this->request->post[ 'order_id' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'order_id' ] = $transmovim_info[ 'order_id' ];
		} else {
			$data[ 'order_id' ] = '0';
		}		
		if ( isset( $this->request->post[ 'description' ] ) ) {
			$data[ 'description' ] = $this->request->post[ 'description' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'description' ] = $transmovim_info[ 'description' ];
		} else {
			$data[ 'description' ] = '';
		}
		if ( isset( $this->request->post[ 'amount' ] ) ) {
			$data[ 'amount' ] = $this->request->post[ 'amount' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'amount' ] = $transmovim_info[ 'amount' ];
		} else {
			$data[ 'amount' ] = '0';
		}
		if ( isset( $this->request->post[ 'date_added' ] ) ) {
			$data[ 'date_added' ] = date( "d-m-Y", strtotime( $this->request->post[ 'date_added' ] ) );
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'date_added' ] = date( "d-m-Y", strtotime( $transmovim_info[ 'date_added' ] ) );
		} else {
			$data[ 'date_added' ] = date( "d-m-Y" );
		}
		if ( isset( $this->request->post[ 'cuit' ] ) ) {
			$data[ 'cuit' ] = $this->request->post[ 'cuit' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'cuit' ] = $transmovim_info[ 'cuit' ];
		} else {
			$data[ 'cuit' ] = '';
		}
		if ( isset( $this->request->post[ 'adjunto' ] ) ) {
			$data[ 'adjunto' ] = $this->request->post[ 'adjunto' ];
			$data[ 'linkadjunto' ] = HTTPS_CATALOG . 'image/bank/' . $data[ 'adjunto' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'adjunto' ] = $transmovim_info[ 'adjunto' ];
			$data[ 'linkadjunto' ] = HTTPS_CATALOG . 'image/bank/' . $transmovim_info[ 'adjunto' ];
		} else {
			$data[ 'adjunto' ] = '';
		}
		if ( isset( $this->request->post[ 'bankcta_id' ] ) ) {
			$data[ 'bankcta_id' ] = $this->request->post[ 'bankcta_id' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'bankcta_id' ] = $transmovim_info[ 'bankcta_id' ];
		} else {
			$data[ 'bankcta_id' ] = '';
		}
		
		if ( isset( $this->request->post[ 'registro' ] ) ) {
			$data[ 'registro' ] = $this->request->post[ 'registro' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'registro' ] = $transmovim_info[ 'registro' ];
		} else {
			$data[ 'registro' ] = '';
		}

		if ( isset( $this->request->post[ 'oculta' ] ) ) {
			$data[ 'oculta' ] = $this->request->post[ 'oculta' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'oculta' ] = $transmovim_info[ 'oculta' ];
		} else {
			$data[ 'oculta' ] = '';
		}
		if ( isset( $this->request->post[ 'oc_customer_tmotivo_id' ] ) ) {
			$data[ 'motivo_id' ] = $this->request->post[ 'motivo_id' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'motivo_id' ] = $transmovim_info[ 'motivo_id' ];
		} else {
			$data[ 'motivo_id' ] = '';
		}		
		
		//print_r($data[ 'motivo_id' ]);
		
		if ( isset( $this->request->post[ 'aprobado' ] ) ) {
			$data[ 'aprobado' ] = $this->request->post[ 'aprobado' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'aprobado' ] = $transmovim_info[ 'aprobado' ];
		} else {
			$data[ 'aprobado' ] = '0';
		}
		if ( isset( $this->request->post[ 'customer_transaction_id' ] ) ) {
			$data[ 'customer_transaction_id' ] = $this->request->post[ 'customer_transaction_id' ];
		} elseif ( !empty( $transmovim_info ) ) {
			$data[ 'customer_transaction_id' ] = $transmovim_info[ 'customer_transaction_id' ];
		} else {
			$data[ 'customer_transaction_id' ] = '0';
		}

		/*
		if ($data[ 'motivo_id' ]!=0){
			$this->load->model( 'admdirsis/tmotivo' );
			$tmotivo = $this->model_admdirsis_tmotivo->getTmotivo2( $data[ 'motivo_id' ] );
			$data['tmotivo'] = $tmotivo['name'];
		}else{
			$data['tmotivo'] = "";
		}
		
		if ( $data[ 'bankcta_id' ] != 0 ) {
			$this->load->model( 'banco/bankcta' );
			$bankcta = $this->model_banco_bankcta->getBankcta( $data[ 'bankcta_id' ] );
			$data['bankcta'] = $bankcta[ 'descrip' ];
		} else {
			$data['bankcta'] = '';
		}
		*/
		$this->load->model( 'banco/bankcta' );
		$data[ 'bankctas' ] = $this->model_banco_bankcta->getBankctas();
		
		$this->load->model( 'admdirsis/tmotivo' );
		$data[ 'tmotivos' ] = $this->model_admdirsis_tmotivo->getTmotivos();	
		
		//print_r($data[ 'tmotivos' ]);
		
		$this->load->model( 'user/user' );
		$data[ 'user_ids' ] = $this->model_user_user->getUsers( array() );
		$data[ 'header' ] = $this->load->controller( 'common/header' );
		$data[ 'column_left' ] = $this->load->controller( 'common/column_left' );
		$data[ 'footer' ] = $this->load->controller( 'common/footer' );
		$this->response->setOutput( $this->load->view( 'banco/transmovim_form', $data ) );
	}
	protected	function validateForm() {
		if ( !$this->user->hasPermission( 'modify', 'banco/transmovim' ) ) {
			$this->error[ 'warning' ] = $this->language->get( 'error_permission' );
		}
		/*
		if ( ( utf8_strlen( $this->request->post[ 'description' ] ) < 1 ) || ( utf8_strlen( trim( $this->request->post[ 'description' ] ) ) > 32 ) ) {
			$this->error[ 'description' ] = $this->language->get( 'error_description' );
		}
		if ( ( utf8_strlen( $this->request->post[ 'cuit' ] ) <> 11 ) ) {
			$this->error[ 'cuit' ] = $this->language->get( 'error_cuit' );
		}
		*/
		/*
		if ( $this->request->post[ 'amount' ] != 0 ) {
			$this->error[ 'amount' ] = $this->language->get( 'error_amount' );
		}
		*/
		if ( $this->error && !isset( $this->error[ 'warning' ] ) ) {
			$this->error[ 'warning' ] = $this->language->get( 'error_warning' );
		}
		return !$this->error;
	}
	protected	function validateDelete() {
		if ( !$this->user->hasPermission( 'modify', 'banco/transmovim' ) ) {
			$this->error[ 'warning' ] = $this->language->get( 'error_permission' );
		}
		return !$this->error;
	}
	public	function upload() {
		$json = array();
		$provisorio = date( "YmdHis" );
		if ( isset( $this->request->files[ 'file' ][ 'name' ] ) ) {
			$json[ 'subio' ] = $this->request->files[ 'file' ][ 'name' ];
			$dato = pathinfo( $this->request->files[ 'file' ][ 'name' ] );
			$dir = DIR_IMAGE . 'bank/';
			if ( !file_exists( $dir ) ) {
				mkdir( $dir, 0777, true );
			}
			$json[ 'dir' ] = $dir;
			$file = $dir . $provisorio . '.' . $dato[ 'extension' ];
			move_uploaded_file( $this->request->files[ 'file' ][ 'tmp_name' ], $file );
			if ( is_file( $file ) ) {
				$json[ 'subio' ] = $provisorio . '.' . $dato[ 'extension' ];
				$json[ 'linksubio' ] = HTTPS_CATALOG . 'image/bank/' . $json[ 'subio' ];
			} else {
				$json[ 'linksubio' ] = "";
				$json[ 'subio' ] = "";
			}
		}
		$this->response->addHeader( 'Content-Type: application/json' );
		$this->response->setOutput( json_encode( $json ) );
	}
}