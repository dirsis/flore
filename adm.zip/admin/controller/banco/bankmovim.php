<?php
class ControllerBancoBankmovim extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('banco/bankmovim');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankmovim');

		$this->getList();
	}

	public function add() {
		$this->load->language('banco/bankmovim');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankmovim');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_banco_bankmovim->addBankmovim($this->request->post);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
			}
			if (isset($this->request->get['filter_cuit'])) {
				$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
			}
			if (isset($this->request->get['filter_verify'])) {
				$url .= '&filter_verify=' . $this->request->get['filter_verify'];
			}			
			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}
			if (isset($this->request->get['filter_bankcta_id'])) {
				$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getForm();
	}

	public function edit() {
		$this->load->language('banco/bankmovim');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('banco/bankmovim');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_banco_bankmovim->editBankmovim($this->request->get['bankmovim_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_verify'])) {
				$url .= '&filter_verify=' . $this->request->get['filter_verify'];
			}
			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
			}
			if (isset($this->request->get['filter_cuit'])) {
				$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
			}

			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}
			if (isset($this->request->get['filter_bankcta_id'])) {
				$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
			}			
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function editverify() {
		$verify='1';
		if (isset($this->request->get['id'])) {
			$this->load->model('banco/bankmovim');
			$verify = $this->model_banco_bankmovim->editverifyBankmovim($this->request->get['id']);
		}
		echo $verify;
	}

	public function editstatus() {
		$status='1';
		if (isset($this->request->get['id'])) {
			$this->load->model('banco/bankmovim');
			$status = $this->model_banco_bankmovim->editstatusBankmovim($this->request->get['id']);
		}
		echo $status;
	}
	
	public function actualizatotales() {
		
		if (isset($this->request->get['filter_verify'])) {
			$filter_verify = $this->request->get['filter_verify'];
		} else {
			$filter_verify = '';
		}

		if (isset($this->request->get['filter_titular'])) {
			$filter_titular = urlencode(html_entity_decode($this->request->get['filter_titular']));
		} else {
			$filter_titular = '';
		}

		if (isset($this->request->get['filter_cuit'])) {
			$filter_cuit = urlencode(html_entity_decode($this->request->get['filter_cuit']));
		} else {
			$filter_cuit = '';
		}

		if (isset($this->request->get['filter_fecha'])) {
			$filter_fecha = $this->request->get['filter_fecha'];
		} else {
			$filter_fecha = '';
		}
		
		if (isset($this->request->get['filter_bankcta_id'])) {
			$filter_bankcta_id = $this->request->get['filter_bankcta_id'];
		} else {
			$filter_bankcta_id = '';
		}
		
		if (isset($this->request->get['filter_verify'])) {
			$filter_verify = $this->request->get['filter_verify'];
		} else {
			$filter_verify = '';
		}	
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}	
		$filter_user_id=0;
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			if ($user_info['user_group_nivel']!=0){
				$filter_user_id=$this->user->getId();
			}
		}
		
		$filter_data = array(
			'filter_fecha'          => $filter_fecha,
			'filter_bankcta_id'	 	=> $filter_bankcta_id,
			'filter_titular'       	=> $filter_titular,
			'filter_cuit'        	=> $filter_cuit,
			'filter_user_id'		=> $filter_user_id,
			'filter_status'        	=> $filter_status,
			'filter_verify'        	=> $filter_verify
		);
		

		
		$this->load->model('banco/bankmovim');
		$results = $this->model_banco_bankmovim->getBankmovimsumas($filter_data,$this->user->getId());
		$totales = array(
				'acumulados'   => $this->currency->format($results['acumulados'], $this->config->get('config_currency')),
				'auditados'    => $this->currency->format($results['auditados'], $this->config->get('config_currency')),
				'verificados'  => $this->currency->format($results['verificados'], $this->config->get('config_currency')),
				'invertidos'   => $this->currency->format($results['invertidos'], $this->config->get('config_currency'))
		);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($totales));
		
	}	
	
	public function delete() {
		$this->load->language('banco/bankmovim');

		$this->document->setTitle($this->language->get('heading_title'));

		
		
		$this->load->model('banco/bankmovim');
		$this->load->model('banco/bankcta');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			$mensajeresultado="";
			foreach ($this->request->post['selected'] as $bankmovim_id) {
				$operacion=$this->model_banco_bankmovim->getBankmovim($bankmovim_id);
				$bankcta_id=$operacion['bankcta_id'];
				$result=$this->model_banco_bankcta->getBankdel($bankcta_id,$this->user->getId());
				if ($result=='1'){
					$this->model_banco_bankmovim->deleteBankmovim($bankmovim_id);
				}else{
					$mensajeresultado.=$bankmovim_id.",";
				}
			}
			if (!empty($mensajeresultado)){
				$this->session->data['success'] = $this->language->get('text_success')."-Sin permiso para estas oper.: ".$mensajeresultado;
			}else{
				$this->session->data['success'] = $this->language->get('text_success');
			}

			$url = '';

			if (isset($this->request->get['filter_titular'])) {
				$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_cuit'])) {
				$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_verify'])) {
				$url .= '&filter_verify=' . $this->request->get['filter_verify'];
			}

			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
			}	
			if (isset($this->request->get['filter_bankcta_id'])) {
				$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		$data['nivel']=9;
		$data['user_id']=$this->user->getId();
		$data['bank']=9;	
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
			$data['bank']=$user_info['bank'];	
			$data['username']=$user_info['username'];
		}		
		

		if (isset($this->request->get['filter_verify'])) {
			$filter_verify = $this->request->get['filter_verify'];
		} else {
			$filter_verify = '';
		}

		if (isset($this->request->get['filter_titular'])) {
			$filter_titular = urlencode(html_entity_decode($this->request->get['filter_titular']));
		} else {
			$filter_titular = '';
		}

		if (isset($this->request->get['filter_cuit'])) {
			$filter_cuit = urlencode(html_entity_decode($this->request->get['filter_cuit']));
		} else {
			$filter_cuit = '';
		}

		if (isset($this->request->get['filter_fecha'])) {
			$filter_fecha = $this->request->get['filter_fecha'];
		} else {
			$filter_fecha = '';
		}
		
		if (isset($this->request->get['filter_bankcta_id'])) {
			$filter_bankcta_id = $this->request->get['filter_bankcta_id'];
		} else {
			$filter_bankcta_id = '';
		}
		
		if (isset($this->request->get['filter_verify'])) {
			$filter_verify = $this->request->get['filter_verify'];
		} else {
			$filter_verify = '';
		}	
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'fecha';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_bankcta_id'])) {
			$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_verify'])) {
			$url .= '&filter_verify=' . $this->request->get['filter_verify'];
		}		
		if (isset($this->request->get['filter_cuit'])) {
			$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
		}
		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
		}


		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['nivel']=9;
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('banco/bankmovim/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('banco/bankmovim/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['bankmovims'] = array();
		
		if ($data['bank']=='1'){
			$filter_user_id=$this->user->getId();
		}else{
			$filter_user_id=0;
		}
		

		$filter_data = array(
			'filter_fecha'          => $filter_fecha,
			'filter_bankcta_id'	 	=> $filter_bankcta_id,
			'filter_titular'       	=> $filter_titular,
			'filter_cuit'        	=> $filter_cuit,
			'filter_status'        	=> $filter_status,
			'filter_verify'        	=> $filter_verify,
			'filter_user_id'		=> $filter_user_id,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		$bankmovim_total = $this->model_banco_bankmovim->getTotalBankmovims($filter_data,$this->user->getId());
	
		$results = $this->model_banco_bankmovim->getBankmovimsumas($filter_data,$this->user->getId());
		
		$data['totales'] = array(
				'acumulados'   => $this->currency->format($results['acumulados'], $this->config->get('config_currency')),
				'auditados'    => $this->currency->format($results['auditados'], $this->config->get('config_currency')),
				'verificados'  => $this->currency->format($results['verificados'], $this->config->get('config_currency')),
				'invertidos'   => $this->currency->format($results['invertidos'], $this->config->get('config_currency'))
		);

		$results = $this->model_banco_bankmovim->getBankmovims($filter_data,$this->user->getId());
		
		foreach ($results as $result) {
			$data['bankmovims'][] = array(
				'bankmovim_id'    	 => $result['bankmovim_id'],
				'bankcta_id'    	 => $result['bankcta_id'],
				'descrip'    	 => $result['descrip'],
				'user_id'       => $result['user_id'],
				'username'       => $result['username'],
				'fecha'     	=> date($this->language->get('date_format_short'), strtotime($result['fecha'])),
				'cuit'       => $result['cuit'],
				'coef'       => $result['coef'],
				'titular'       => $result['titular'],
				'notauser'       => $result['notauser'],
				'importe'          => $this->currency->format($result['importe'], $this->config->get('config_currency')),
				'conversion'          => $result['conversion'],
				'verify'      	 => $result['verify'],
				'status'      	 => $result['status'],	
				'archivo'		  => $result['archivo'],	
				'linkarchivo'		  => HTTPS_CATALOG.'image/bank/'.$result['archivo'],	
				'edit'           => $this->url->link('banco/bankmovim/edit', 'user_token=' . $this->session->data['user_token'] . '&bankmovim_id=' . $result['bankmovim_id'] . $url, true)
			);
		}
		
//print_r($data['bankmovims']);
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_bankcta_id'])) {
			$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
		}		
		if (isset($this->request->get['filter_cuit'])) {
			$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
		}
		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
		}
		if (isset($this->request->get['filter_verify'])) {
			$url .= '&filter_verify=' . $this->request->get['filter_verify'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_bankmovim_id'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.bankmovim_id' . $url, true);
		$data['sort_bankcta_id'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.bankcta_id' . $url, true);
		$data['sort_username'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_user.username' . $url, true);		

		$data['sort_fecha'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.fecha' . $url, true);
		$data['sort_cuit'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=cuit' . $url, true);		
		$data['sort_titular'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.titular' . $url, true);
		$data['sort_importe'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.importe' . $url, true);
		$data['sort_notauser'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.notauser' . $url, true);
		$data['sort_verify'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.verify' . $url, true);
		$data['sort_status'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.status' . $url, true);
		$data['sort_archivo'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . '&sort=oc_bankmovim.archivo' . $url, true);
		
		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_bankcta_id'])) {
			$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_verify'])) {
			$url .= '&filter_verify=' . $this->request->get['filter_verify'];
		}		
		if (isset($this->request->get['filter_cuit'])) {
			$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
		}
		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
		}

		$pagination = new Pagination();
		$pagination->total = $bankmovim_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($bankmovim_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($bankmovim_total - $this->config->get('config_limit_admin'))) ? $bankmovim_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $bankmovim_total, ceil($bankmovim_total / $this->config->get('config_limit_admin')));

		$data['filter_titular']	= $filter_titular;
		$data['filter_cuit']	= $filter_cuit;
		$data['filter_fecha'] 	= $filter_fecha;
		$data['filter_bankcta_id'] = $filter_bankcta_id;
		$data['filter_status']	= $filter_status;
		$data['filter_verify']	= $filter_verify;
		
		$this->load->model('banco/bankcta');
		$data['bankctas'] = $this->model_banco_bankcta->getBankctasxuser($this->user->getId());

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankmovim_list', $data));
	}

	protected function getForm() {
		
		

		$data['nivel']=9;
		$data['bank']=9;
		$data['user_id']=$this->user->getId();
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['nivel']=$user_info['user_group_nivel'];	
			$data['bank']=$user_info['bank'];	
		}
		
		$data['text_form'] = !isset($this->request->get['bankmovim_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['bankmovim_id'])) {
			$data['bankmovim_id'] = $this->request->get['bankmovim_id'];
		} else {
			$data['bankmovim_id'] = 0;
		}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['titular'])) {
			$data['error_titular'] = $this->error['titular'];
		} else {
			$data['error_titular'] = '';
		}		
		if (isset($this->error['importe'])) {
			$data['error_importe'] = $this->error['importe'];
		} else {
			$data['error_importe'] = '';
		}
		if (isset($this->error['conversion'])) {
			$data['error_conversion'] = $this->error['conversion'];
		} else {
			$data['error_conversion'] = '';
		}		
		if (isset($this->error['cuit'])) {
			$data['error_cuit'] = $this->error['cuit'];
		} else {
			$data['error_cuit'] = '';
		}		
		
		$url = '';
		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . $this->request->get['filter_fecha'];
		}
		if (isset($this->request->get['filter_bankcta_id'])) {
			$url .= '&filter_bankcta_id=' . $this->request->get['filter_bankcta_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_cuit'])) {
			$url .= '&filter_cuit=' . urlencode(html_entity_decode($this->request->get['filter_cuit']));
		}
		if (isset($this->request->get['filter_titular'])) {
			$url .= '&filter_titular=' . urlencode(html_entity_decode($this->request->get['filter_titular']));
		}
		if (isset($this->request->get['filter_verify'])) {
			$url .= '&filter_verify=' . $this->request->get['filter_verify'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		
		
		if (!isset($this->request->get['bankmovim_id'])) {
			$data['action'] = $this->url->link('banco/bankmovim/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('banco/bankmovim/edit', 'user_token=' . $this->session->data['user_token'] . '&bankmovim_id=' . $this->request->get['bankmovim_id'] . $url, true);
		}
		
		$data['cancel'] = $this->url->link('banco/bankmovim', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['bankmovim_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$bankmovim_info = $this->model_banco_bankmovim->getBankmovim($this->request->get['bankmovim_id']);
		}

		
		if (isset($this->request->post['titular'])) {
			$data['titular'] = $this->request->post['titular'];
		} elseif (!empty($bankmovim_info)) {
			$data['titular'] = $bankmovim_info['titular'];
		} else {
			$data['titular'] = '';
		}
		
		if (isset($this->request->post['user_id'])) {
			$data['user_id'] = $this->request->post['user_id'];
		} elseif (!empty($bankmovim_info)) {
			$data['user_id'] = $bankmovim_info['user_id'];
		}

		if (isset($this->request->post['cuit'])) {
			$data['cuit'] = $this->request->post['cuit'];
		} elseif (!empty($bankmovim_info)) {
			$data['cuit'] = $bankmovim_info['cuit'];
		} else {
			$data['cuit'] = '';
		}
		
		if (isset($this->request->post['coef'])) {
			$data['coef'] = $this->request->post['coef'];
		} elseif (!empty($bankmovim_info)) {
			$data['coef'] = $bankmovim_info['coef'];
		} else {
			$data['coef'] = '1';
		}		

		if (isset($this->request->post['notauser'])) {
			$data['notauser'] = $this->request->post['notauser'];
		} elseif (!empty($bankmovim_info)) {
			$data['notauser'] = $bankmovim_info['notauser'];
		} else {
			$data['notauser'] = '';
		}

		if (isset($this->request->post['importe'])) {
			$data['importe'] = $this->request->post['importe'];
		} elseif (!empty($bankmovim_info)) {
			$data['importe'] = $bankmovim_info['importe'];
		} else {
			$data['importe'] = '0';
		}
		
		
		$this->load->model('admdirsis/dolar');
		$results = $this->model_admdirsis_dolar->infoDolar();
		$data['blue_avg']=$results['blue']['value_avg'];
		$data['blue_sell']=$results['blue']['value_sell'];
		$data['blue_buy']=$results['blue']['value_buy'];
			
		$this->load->model('admdirsis/cripto');
		$results = $this->model_admdirsis_cripto->infousdt();
		$data['usdt_buy']=$results['ask'];
		
		
		if (isset($this->request->post['conversion'])) {
			$data['conversion'] = $this->request->post['conversion'];
		} elseif (!empty($bankmovim_info)) {
			$data['conversion'] = $bankmovim_info['conversion'];
		} else {
			$data['conversion'] = '1';
		}		
		
		if (isset($this->request->post['archivo'])) {
			$data['archivo'] = $this->request->post['archivo'];
			$data['linkarchivo'] = HTTPS_CATALOG.'image/bank/'.$data['archivo'];
		} elseif (!empty($bankmovim_info)) {
			$data['archivo'] = $bankmovim_info['archivo'];
			$data['linkarchivo'] = HTTPS_CATALOG.'image/bank/'.$bankmovim_info['archivo'];
		} else {
			$data['archivo'] = '';
		}
		
		if (isset($this->request->post['verify'])) {
			$data['verify'] = $this->request->post['verify'];
		} elseif (!empty($bankmovim_info)) {
			$data['verify'] = $bankmovim_info['verify'];
		} else {
			$data['verify'] = '0';
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($bankmovim_info)) {
			$data['status'] = $bankmovim_info['status'];
		} else {
			$data['status'] = '0';
		}
		
		if (isset($this->request->post['fecha'])) {
			$data['fecha'] = date("Y-m-d", strtotime($this->request->post['fecha']));
		} elseif (!empty($bankmovim_info)) {
			$data['fecha'] = date("Y-m-d", strtotime($bankmovim_info['fecha']));
		} else {
			$data['fecha'] = date("Y-m-d"); 
		}
		
		if (isset($this->request->post['bankmovim_id'])) {
			$data['bankmovim_id'] = $this->request->post['bankmovim_id'];
		} elseif (!empty($bankmovim_info)) {
			$data['bankmovim_id'] = $bankmovim_info['bankmovim_id'];
		} else {
			$data['bankmovim_id'] = '0';
		}	
		
		if (isset($this->request->post['bankcta_id'])) {
			$data['bankcta_id'] = $this->request->post['bankcta_id'];
		} elseif (!empty($bankmovim_info)) {
			$data['bankcta_id'] = $bankmovim_info['bankcta_id'];
		} else {
			$data['bankcta_id'] = '';
		}			
		$this->load->model('banco/bankcta');
		$data['bankctas'] = $this->model_banco_bankcta->getBankctasxuserxabc($this->user->getId());
		
		$this->load->model('user/user');
		$data['user_ids'] = $this->model_user_user->getUsers(array());
		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('banco/bankmovim_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'banco/bankmovim')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['titular']) < 1) || (utf8_strlen(trim($this->request->post['titular'])) > 32)) {
			$this->error['titular'] = $this->language->get('error_titular');
		}
		if ((utf8_strlen($this->request->post['cuit']) <> 11)) {
			$this->error['cuit'] = $this->language->get('error_cuit');
		}
		if ($this->request->post['importe'] <= 0) {
			$this->error['importe'] = $this->language->get('error_importe');
		}
		if ($this->request->post['conversion'] <= 0) {
			$this->error['conversion'] = $this->language->get('error_conversion');
		}		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'banco/bankmovim')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function upload() {
		$json = array();
		$provisorio = date("YmdHis");
		if (isset($this->request->files['file']['name'])) {
			$json['subio'] =$this->request->files['file']['name'];
			$dato=pathinfo($this->request->files['file']['name']);
			
			$dir = DIR_IMAGE . 'bank/';
			if (!file_exists($dir)) {
    			mkdir($dir, 0777, true);
			}
			$json['dir']=$dir;
			$file = $dir . $provisorio . '.'.$dato['extension'];
			move_uploaded_file($this->request->files['file']['tmp_name'], $file);
			if (is_file($file)) {
				$json['subio'] =$provisorio . '.'.$dato['extension'];
				$json['linksubio']=HTTPS_CATALOG.'image/bank/'.$json['subio'];
			}else{
				$json['linksubio']="";
				$json['subio'] ="";
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

}