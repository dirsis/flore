<?php
class ControllerApisTiendanube extends Controller {
	private $error = array();
	public function index() {	}
	public function id() {
		$resultproduct=$this->productxid($this->request->get['id']);
		print_r($resultproduct);
	}
	public function categories() {
		//https://dirsis.com.ar/adm/admin/index.php?route=apis/tiendanube/categories&user_token=tgeZwnhHjROQNyPUwuTe8HKI5vWZFT1E
		$this->load->model('catalog/category');
		$results=$this->Get("categories");
		foreach ($results as & $result) {
			$id=$result['id'];
			$name=$result['name']['es'];
			$query=$this->model_catalog_category->getCategoryParent_origen($id);
			if (!isset($query['parent_id'])){
				$data=array( 
					'category_description' => array( 
							'2' => array ( 'name' => $name,
										  'description'=>"",
										  'meta_title' => $name, 
										  'meta_description'=>"",
										  'meta_keyword' => "") 
					),
					'path' => "",
					'parent_id' => 0,
					'parent_origen' => $id,
					'type' => 0,
					'comision' => 0, 
					'comisionl' => 0, 
					'margen1' => 0 ,
					'margen2' => 0 ,
					'margen3' => 0 ,
					'filter' => '',
					'category_store' => array ( 			'0' => 0 	), 
					'image' => '',
					'column' => 1, 
					'sort_order' => 0, 
					'status' => 1, 
					'category_seo_url' => array ( 		'0' => array ( 			'2' => '') 	), 
					'category_layout' => array ( 		'0' => '' ) 	
					);
				$this->model_catalog_category->addCategory($data);
			}
		}
	}
	public function products() {
		$this->load->model('catalog/category');
		$this->load->model('catalog/product');
		$results=$this->Get("products");
		$trecord=$tedit=$tadd=0;
		foreach ($results as & $result) {
			$trecord++;
			$id=$result['id'];
			$resultproduct=$this->productxid($id);
			
			if ($resultproduct['nuevo']==1){
				$tadd++;
			}else{
				$tedit++;
			}
		}
		$data = array( 'trecord'=>$trecord, 'tedit' => $tedit, 'tadd' => $tadd );
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}
	public function productxid($id) {
		$product=array("nuevo" => 0, "product_id" => 0);
		if (isset($id)) {
			$result=$this->Get("products/".$id);
			if (isset($result['id'])){
						
				$id=$result['id'];
				$name=$result['name']['es'];
				$image=$result['images'][0]['src'];
				$stock=$result['variants'][0]['stock'];
				$price=$result['variants'][0]['price'];
				$sku=$result['variants'][0]['sku'];
				if (empty($sku)){
					$sku=$id;
				}
				
				$this->load->model('catalog/category');
				$this->load->model('catalog/product');				
				$results=$this->model_catalog_product->getProductxJan($id);		
				$trow=0;
				foreach ($results as $result) {
					$this->model_catalog_product->editStock($result['product_id'], $stock);
					if ($stock>0){ $status=1; }else{ $status=0; }
					$this->model_catalog_product->editStatus($result['product_id'], $status);
					$trow++;
					$product_id=$result['product_id'];
				}		
				if ($trow==0){
					$product_category=array();
					if (!empty($image)){
						$archivoFinal0 = "../image/catalog/mlas/tb".$id.".jpg";
						if (!file_exists($archivoFinal0)){
							$imagen = file_get_contents($image);
							$save = file_put_contents($archivoFinal0,$imagen);
						}
						if (file_exists($archivoFinal0)){
							$image = "catalog/mlas/tb".$id.".jpg";
						}
					}
					$parent_origen=$result['categories'][0]['id'];
				
					$query=$this->model_catalog_category->getCategoryParent_origen($parent_origen);
					if (isset($query['category_id'])){
						$product_category[]=$query['category_id'];
					}

					$data=array(
						'product_description' => array(
							'2' => array(
							'name' => $name,
							'description' => '', 
							'meta_title' => $name,
							'meta_description' => '',
							'meta_keyword' => '',
							'tag' => '',
						)),
						'model' => $sku,
						'sku' => $sku,
						'sincro' => 1,
						'upc' => '',
						'ean' => '',
						'jan' => $id,
						'isbn' => '',
						'mpn' => '',
						'location' => '',
						'price' => $price,
						'tasaiva' => 0,
						'tax_class_id' => 0,
						'quantity' => $stock,
						'minimum' => 1,
						'subtract' => 1,
						'stock_status_id' => 6,
						'shipping' => 1,
						'date_available' => date("Y-m-d"),
						'length' => '',
						'width' => '',
						'height' => '',
						'length_class_id' => 1,
						'weight' => '',
						'weight_class_id' => 1,
						'status' => 1,
						'sort_order' => 1,
						'manufacturer' => '',
						'manufacturer_id' => 0,
						'product_category' => $product_category,
						'filter' => '',
						'product_store' => array        (  '0' => 0        ),
						'download' => '',
						'related' => '',
						'option' => '',
						'image' => $image,
						'lista' => 0,
						'dto1' => 0,
						'dto2' => 0,
						'dto3' => 0,
						'dto4' => 0,
						'currency_id' => 2,
						'costo' => 0,
						'util' => 0,
						'venta' => 0,
						'points' => '',
						'product_reward' => array(
							'1' => array      (         'points' =>''       ),
							'5' => array      (          'points' =>''       ),
							'6' => array      (          'points' =>  ''     ),
							'2' => array      (          'points' => ''      ),
							'3' => array      (          'points' => ''      ),
							'4' => array      (          'points' =>  ''     ),
						),
						'product_seo_url' => array        (     '0' => array      (          '2' =>  ''     )        ),
						'product_layout' => array        (     '0' => ''        )
					);
					$product_id=$this->model_catalog_product->addProduct($data);
					
					$product=array("nuevo" => 1, "product_id" => $product_id);
				}else{
					$product=array("nuevo" => 0, "product_id" => $product_id);
				}
			
			}else{
				$product=array("nuevo" => 2, "product_id" => 0);
			}
		}
		return $product;
	}
	public function orders() {
		ini_set("display_errors", 1);
		error_reporting(E_ALL);
		
		$this->load->language('sale/order');
		$data['store_id']=0;
		$data['store_name']=$this->language->get('text_default');
		
		
		$this->load->model('localisation/currency');
		$currencies = $this->model_localisation_currency->getCurrencies();

		
			
		// API login
		$catalog = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
		
		// API login
		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info && $this->user->hasPermission('modify', 'sale/order')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);
			
			$session->start();
					
			$this->model_user_api->deleteApiSessionBySessonId($session->getId());
			
			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
			
			$session->data['api_id'] = $api_info['api_id'];

			$api_token = $session->getId();
		} else {
			$api_token = '';
		}
		$customer_group_id=(int)$this->config->get('config_customer_group_id');
		//https://dirsis.com.ar/adm/admin/index.php?route=apis/tiendanube/orders&user_token=tgeZwnhHjROQNyPUwuTe8HKI5vWZFT1E
		$this->load->model('sale/order');
		$this->load->model('customer/customer');
		$results_order=$this->Get("orders");
		$recorre=0;
		$reviso="";
		foreach ($results_order as & $result_order) {
			$invoice_prefix="TN";
			$original_id=$result_order['id'];
			$orders=$this->model_sale_order->getOrderxoriginal_id($invoice_prefix,$original_id);
			if ($orders['order_id']==0){
				$customer=$this->model_customer_customer->getCustomerByEmail($result_order['contact_email']);
				if ($customer){
					$customer_id =$customer['customer_id'];
					$customer_group_id=$customer['customer_group_id'];
				}else{
					$data['firstname']= $result_order['contact_name'];
					$data['lastname']= "(TN)";
					$data['email']=$result_order['contact_email'];
					$data['telephone']= $result_order['contact_phone'];
					$customer_id =$this->model_customer_customer->addCustomerexpress($data);
				}
				$data['original_id']= $original_id;
				$data['invoice_no']= "";
				$data['invoice_prefix']= $invoice_prefix;
				$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
				$data['customer_id']=$customer_id;
				$data['customer_group_id']=$customer_group_id;
				$data['firstname']=$result_order['contact_name'];
				$data['lastname']= "(TN)";
				$data['email']= $result_order['contact_email'];
				$data['telephone']= $result_order['contact_phone'];
				$data['payment_firstname']="";
				$data['payment_lastname']= $result_order['contact_name'];
				$data['payment_company']="";
				$data['payment_address_1']= $result_order['billing_address']." ".$result_order['billing_number'];
				$data['payment_address_2']="";
				$data['payment_city']= $result_order['billing_city'];
				$data['payment_postcode']=$result_order['billing_zipcode'];
				$data['payment_country']='Argentina';
				$data['payment_country_id']=10;
				$data['payment_zone']= $result_order['billing_province'];
				$data['payment_zone_id']=160;
				$data['payment_address_format']="";			
				$data['payment_method']=$result_order['gateway_name'];
				$data['payment_code']='';
				$data['shipping_firstname']="";
				$data['shipping_lastname']= $result_order['contact_name'];
				$data['shipping_company']="";
				$data['shipping_address_1']= $result_order['billing_address']." ".$result_order['billing_number'];
				$data['shipping_address_2']="";
				$data['shipping_city']= $result_order['billing_city'];
				$data['shipping_postcode']=$result_order['billing_zipcode'];
				$data['shipping_country']='Argentina';
				$data['shipping_country_id']=10;
				$data['shipping_zone']= $result_order['billing_province'];
				$data['shipping_zone_id']=160;
				$data['shipping_address_format']="";		
				$data['shipping_method']= $result_order['shipping_pickup_type'];
				$data['shipping_code'] =$result_order['shipping_option'];
				$data['comment'] = $result_order['contact_identification'];
				$data['total'] = $result_order['total'];
				$data['affiliate_id'] ='';
				$data['commission']=0;
				$data['marketing_id']='';
				$data['pay']='1';
				$data['tracking']='';
				$data['language_id'] = $this->config->get('config_language_id');
				$data['currency_id'] = $this->currency->getId($this->session->data['currency']);
				$data['currency_code'] = $this->session->data['currency'];
				$data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
				$data['ip'] = $this->request->server['REMOTE_ADDR'];
				if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
					$data['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
				} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
					$data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
				} else {
					$data['forwarded_ip'] = '';
				}
				if (isset($this->request->server['HTTP_USER_AGENT'])) {
					$data['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
				} else {
					$data['user_agent'] = '';
				}
				if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
					$data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
				} else {
					$data['accept_language'] = '';
				}

				$data['order_status_id']=$this->config->get('config_order_status_id');
				
			
				$this->load->model('catalog/product');
				
				
				$data['products']=array();
				
				foreach ($result_order['products'] as & $product) {
					$resultproduct=$this->productxid($product['product_id']);
					if (isset($resultproduct['product_id'])){
						$product_id=$resultproduct['product_id'];
						$data['products'][]=array(
							'product_id' => $product_id,
							'model' => $product['product_id'],
							'name' => $product['name'],
							'price' => $product['price'],
							'quantity' => $product['quantity'],
							'total' => $product['quantity']*$product['price'],
							'tax' => 0,
							'reward' => 0
						);
					}
				}
				
				$data['totals'][] = array(
					'code'       => 'total',
					'title'      => $this->language->get('text_total'),
					'value'      => max(0, $result_order['total']),
					'sort_order' => $this->config->get('total_total_sort_order')
				);
				
				//REGISTRAR
				$order_id=$this->model_sale_order->addOrder($data);
				//break;
			}else{
				$order_id=$orders['order_id'];
			}
			$recorre++;
			//$reviso.="|".$invoice_prefix."(".$order_id.")".$orders['sql']."<br>";
			
		}	
		return 0;
	}
	public function Get($url) {
		$url='https://api.tiendanube.com/v1/'.$this->config->get('config_tiendanube_id').'/'.$url;
		//print_r($url);
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'Authentication: bearer '.$this->config->get('config_tiendanube_token'),
			'User-Agent: Your App Name (dirsis@gmail.com)'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		return  json_decode($response,true);
	}
}
				

								
																
