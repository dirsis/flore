<?php
class ControllerDirsismrpPr extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsismrp/pr');
		date_default_timezone_set('America/Argentina/Buenos_Aires');
		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		$this->getList();
	}

	public function add() {
		
		$this->load->language('dirsismrp/pr');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsismrp_pr->addPr($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function addall() {
		$this->load->language('dirsismrp/pr');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('dirsismrp/pr');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			//print_r($this->request->post);
			//die;
			
			$this->model_dirsismrp_pr->addallPr($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}

	public function edit() {
		$this->load->language('dirsismrp/pr');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsismrp_pr->editPr($this->request->get['pr_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsismrp/pr');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $pr_id) {
				$this->model_dirsismrp_pr->deletePr($pr_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	
	public function closeall() {
		$this->load->model('dirsismrp/pr');
		$data_filter = array (
				'filter_sector_id' => $this->request->get['sector_id'],
				'filter_turno_id'=> $this->request->get['turno_id'],
				'filter_date_desde' => $this->request->get['date_registro'],
				'filter_date_hasta' => $this->request->get['date_registro']
		);
		//print_r($data_filter);
		$results=$this->model_dirsismrp_pr->getPrs($data_filter);
		//print_r($results);
		foreach ($results as $result) {
			echo $result['pr_id']."<br>";
			$this->model_dirsismrp_pr->editstatusPr($result['pr_id'],'2');
		}
		echo "1";
	}
	
	public function editstatus() {
		$this->load->language('dirsismrp/pr');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');
		$json = array();
		$result=$cerrado=$total=0;
		if (isset($this->request->get['pr_id'])) {
			$pr_id=$this->request->get['pr_id'];
			$status=$this->model_dirsismrp_pr->editstatusPr($pr_id);
			$querypr=$this->model_dirsismrp_pr->getPr($pr_id);
			//ACTUALIZA MAQUI-CONSUMO
			if ($querypr['qty_final']!=0){
				$consumo=$querypr['qty_final']-$querypr['qty_inicial']+1;
				$this->load->model('dirsiscrud/maqui');
				if ($status==1){
					$this->model_dirsiscrud_maqui->editCicloconsumo($querypr['maqui_id'],$consumo*-1);
				}else{
					$this->model_dirsiscrud_maqui->editCicloconsumo($querypr['maqui_id'],$consumo);
				}
			}
			//ACTUALIZA TOTALIZADORES
			$query=$this->model_dirsismrp_pr->countstatusPr($querypr['date_registro'],$querypr['sector_id'],$querypr['turno_id']);
			if ($query){
				$cerrado = $query['cerrado'];
				$total = $query['total'];
			}
			
		}
		$json=array(
			"status" => $status,
			"cerrado" => $cerrado,
			"total"	=> $total
		);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
	}

	protected function getList() {
		

		date_default_timezone_set('America/Argentina/Buenos_Aires');
		if (isset($this->error['turno_id'])) {
			$data['error_turno_id'] = $this->error['turno_id'];
		} else {
			$data['error_turno_id'] = array();
		}

		if (isset($this->error['sector_id'])) {
			$data['error_sector_id'] = $this->error['sector_id'];
		} else {
			$data['error_sector_id'] = array();
		}
		
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = date("Y-m-d");
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = date("Y-m-d");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
/*
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
*/
		$sort = 'p.sector_id,p.turno_id,m.code,m.sort_order';
/*		
		}
*/		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}	
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['addall'] = $this->url->link('dirsismrp/pr/addall', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('dirsismrp/pr/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsismrp/pr/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		
		$data['statuss'][]=array("status" => 1, "name" => 'Cerrado');
		$data['statuss'][]=array("status" => 2, "name" => 'Abierto');
			
		$page=($page - 1) * $this->config->get('config_limit_admin');
		$limit=$this->config->get('config_limit_admin');
		$page=0;
		$limit=1000000000;

		$data['prs'] = array();

		$filter_data = array(
			'filter_status'   => $filter_status,
			'filter_turno_id'   => $filter_turno_id,
			'filter_sector_id'   => $filter_sector_id,
			'filter_maqui_id'   => $filter_maqui_id,			
			'filter_date_desde'   => $filter_date_desde,
			'filter_date_hasta'   => $filter_date_hasta,
			'filter_user_id'	=> $this->user->isLogged(),
			'sort'            => $sort,
			'order'           => $order,
			//'start'           => $page,
			//'limit'           => $limit
		);
		$pr_total = $this->model_dirsismrp_pr->getTotalPrs($filter_data);
		
		$this->load->model('dirsiscrud/prstatus');
		$this->load->model('dirsiscrud/maqui');
		
		$results = $this->model_dirsismrp_pr->getPrs($filter_data);
		$contar=0;
		foreach ($results as $result) {
			$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
			
			$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
			///print_r($matrizs);
			$operadors=$this->model_dirsismrp_pr->getOperadorxPr($result['pr_id']);

			$silos=$this->model_dirsismrp_pr->getSiloxPr($result['pr_id']);
			
			$stops=$this->model_dirsismrp_pr->getTotalStops($result['pr_id']);
			 
			$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($result['maqui_id']);
			
			$qty_obj=$qty_obj['ciclos'];
			$contar++;	
			$data['prs'][] = array(
				'pr_id' => $result['pr_id'],
				'date_registro' => date($this->language->get('date_format_short'), strtotime($result['date_registro'])),
				'date_registro_base' => $result['date_registro'],
				'turno_id' => $result['turno_id'],
				'turno_name' => $result['turno_name'],
				'total' => $completo['total'],
				'cerrado' => $completo['cerrado'],
				'sector_id' => $result['sector_id'],
				'sector_name' => $result['sector_name'],
				'cant_maqui' => $result['cant_maqui'],
				'nro_pedido' => $result['nro_pedido'],
				'maqui_id' => $result['maqui_id'],
				'maqui_name' => $result['maqui_name'],
				'maqui_code' => $result['maqui_code'],
				'maqui_ciclos' => $qty_obj,
				'diseno_id' => $result['diseno_id'],
				'diseno_name' => $result['diseno_name'],
				'lote_id' => $result['lote_id'],
				'lote_name' => $result['lote_name'],
				'matriz_id' => $result['matriz_id'],
				'matriz_name' => $result['matriz_name'],
				'matrizs' => $matrizs,
				'operadors' => $operadors,
				'silos' => $silos,
				'operador_id' => $result['operador_id'],
				'operador_name' => $result['operador_name'],
				'qty_inicial' => $result['qty_inicial'],
				'qty_final' => $result['qty_final'],
				'qty_obj' => $qty_obj,
				'etq_inicial' => $result['etq_inicial'],
				'etq_final' => $result['etq_final'],
				'etq_obj' => $result['etq_obj'],
				'hora_inicial' => $result['hora_inicial'],
				'hora_final' => $result['hora_final'],
				'scrap' => $result['scrap'],
				'puestaapunto' => 	$result['puestaapunto']?'Si':'No',
				'stops' 			=> $stops['total'],
				'stopsdanger'	=> $stops['danger'],
				'stopswarning'	=> $stops['warning'],
				'stopssuccess'	=> $stops['success'],									 
				'status'     		=> $result['status'],
				'statusname'     	=> $result['status']==1?'Abierto':'Cerrado',
				'statuscolor'     	=> $result['status']==1?'danger':'success',
				'user_id' => $result['user_id'],
				'username' => $result['username'],
				'edit'       => $this->url->link('dirsismrp/pr/edit', 'user_token=' . $this->session->data['user_token'] . '&pr_id=' . $result['pr_id'] . $url, true)
			);
			
		}
		$data['contar']=$contar;
		$data['date_registro'] = date('d-m-Y');
		$this->load->model('dirsiscrud/turno');
		$data['turnos'] = $this->model_dirsiscrud_turno->getTurnos();
		
		$this->load->model('dirsiscrud/sector');
		$data_filter = array (
			'filter_user_id'	=> $this->user->isLogged()
		);
		$data['sectors'] = $this->model_dirsiscrud_sector->getSectors($data_filter);
		
		$this->load->model('dirsiscrud/maqui');
		$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis();			
		
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}		
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['sort_pr_id'] = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.pr_id' . $url, true);
		$data['sort_code'] = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . '&sort=m.code' . $url, true);		

		$data['sort_date_registro'] = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_registro' . $url, true);
		$data['sort_status'] = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.status' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $pr_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($pr_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($pr_total - $limit)) ? $pr_total : ((($page - 1) * $limit) + $limit), $pr_total, ceil($pr_total / $limit));
		


		
		$data['filter_date_desde'] = date("d-m-Y",strtotime($filter_date_desde));
		$data['filter_date_hasta'] = date("d-m-Y",strtotime($filter_date_hasta));
		$data['filter_status'] = $filter_status;
		$data['filter_turno_id'] = $filter_turno_id;
		$data['filter_sector_id'] = $filter_sector_id;
		$data['filter_maqui_id'] = $filter_maqui_id;		
		
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		

		
		$this->response->setOutput($this->load->view('dirsismrp/pr_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['pr_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['turno_id'])) {
			$data['error_turno_id'] = $this->error['turno_id'];
		} else {
			$data['error_turno_id'] = array();
		}

		if (isset($this->error['sector_id'])) {
			$data['error_sector_id'] = $this->error['sector_id'];
		} else {
			$data['error_sector_id'] = array();
		}

		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),

			'href' => $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['pr_id'])) {
			$data['action'] = $this->url->link('dirsismrp/pr/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsismrp/pr/edit', 'user_token=' . $this->session->data['user_token'] . '&pr_id=' . $this->request->get['pr_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['pr_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$data['pr_id'] = $this->request->get['pr_id'];
			$pr_info = $this->model_dirsismrp_pr->getPr($this->request->get['pr_id']);
		}else{
			$data['pr_id'] = "";
		}


		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->post['date_registro'])) {
			$data['date_registro'] = date("d-m-Y",strtotime($this->request->post['date_registro']));
		} elseif (isset($pr_info)) {
			$data['date_registro'] = date("d-m-Y",strtotime($pr_info['date_registro']));
		} else {
			$data['date_registro'] = date('d-m-Y');
		}
		
		$this->load->model('dirsiscrud/turno');
		$this->load->model('dirsiscrud/sector');
		
		if (isset($this->request->post['turno_id'])) {
			$data['turno_id'] = $this->request->post['turno_id'];
			$data['turno_name'] = $this->model_dirsiscrud_turno->getTurnoName($data['turno_id']);
		} elseif (isset($pr_info)) {
			$data['turno_id'] = $pr_info['turno_id'];
			$data['turno_name'] = $this->model_dirsiscrud_turno->getTurnoName($data['turno_id']);
		} else {
			$data['turno_id'] = "";
		}
		if (isset($this->request->post['sector_id'])) {
			$data['sector_id'] = $this->request->post['sector_id'];
			$data['sector_name'] = $this->model_dirsiscrud_sector->getSectorName($data['sector_id']);
		} elseif (isset($pr_info)) {
			$data['sector_id'] = $pr_info['sector_id'];
			$data['sector_name'] = $this->model_dirsiscrud_sector->getSectorName($data['sector_id']);
		} else {
			$data['sector_id'] = "0";
		}		
		
		if (isset($this->request->post['turno_id'])) {
			$data['turno_id'] = $this->request->post['turno_id'];
		} elseif (isset($pr_info)) {
			$data['turno_id'] = $pr_info['turno_id'];
		} else {
			$data['turno_id'] = "";
		}			
		
		if (isset($this->request->post['maqui_id'])) {
			$data['maqui_id'] = $this->request->post['maqui_id'];
		} elseif (isset($pr_info)) {
			$data['maqui_id'] = $pr_info['maqui_id'];
		} else {
			$data['maqui_id'] = "";
		}			

		if (isset($this->request->post['diseno_id'])) {
			$data['diseno_id'] = $this->request->post['diseno_id'];
		} elseif (isset($pr_info)) {
			$data['diseno_id'] = $pr_info['diseno_id'];
		} else {
			$data['diseno_id'] = "";
		}			
		
		if (isset($this->request->post['matriz_id'])) {
			$data['matriz_id'] = $this->request->post['matriz_id'];
		} elseif (isset($pr_info)) {
			$data['matriz_id'] = $pr_info['matriz_id'];
		} else {
			$data['matriz_id'] = "";
		}		
		
		
		
		
		if (isset($this->request->post['lote_id'])) {
			$data['lote_id'] = $this->request->post['lote_id'];
		} elseif (isset($pr_info)) {
			$data['lote_id'] = $pr_info['lote_id'];
		} else {
			$data['lote_id'] = "";
		}			
		
		if (isset($this->request->post['operador_id'])) {
			$data['operador_id'] = $this->request->post['operador_id'];
		} elseif (isset($pr_info)) {
			$data['operador_id'] = $pr_info['operador_id'];
		} else {
			$data['operador_id'] = "";
		}			
		
		if (isset($this->request->post['qty_inicial'])) {
			$data['qty_inicial'] = $this->request->post['qty_inicial'];
		} elseif (isset($pr_info)) {
			$data['qty_inicial'] = $pr_info['qty_inicial'];
		} else {
			$data['qty_inicial'] = "";
		}			
		
		if (isset($this->request->post['qty_final'])) {
			$data['qty_final'] = $this->request->post['qty_final'];
		} elseif (isset($pr_info)) {
			$data['qty_final'] = $pr_info['qty_final'];
		} else {
			$data['qty_final'] = "";
		}			
		
		if (isset($this->request->post['qty_obj'])) {
			$data['qty_obj'] = $this->request->post['qty_obj'];
		} elseif (isset($pr_info)) {
			$data['qty_obj'] = $pr_info['qty_obj'];
		} else {
			$data['qty_obj'] = "";
		}
		
		if ($data['maqui_id']!=0){
			$this->load->model('dirsiscrud/maqui');
			$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($data['maqui_id']);
			$data['qty_obj'] = $qty_obj['ciclos'];
		}
		
		
		if (isset($this->request->post['etq_inicial'])) {
			$data['etq_inicial'] = $this->request->post['etq_inicial'];
		} elseif (isset($pr_info)) {
			$data['etq_inicial'] = $pr_info['etq_inicial'];
		} else {
			$data['etq_inicial'] = "";
		}			
		
		if (isset($this->request->post['etq_final'])) {
			$data['etq_final'] = $this->request->post['etq_final'];
		} elseif (isset($pr_info)) {
			$data['etq_final'] = $pr_info['etq_final'];
		} else {
			$data['etq_final'] = "";
		}		
		
		if (isset($this->request->post['etq_obj'])) {
			$data['etq_obj'] = $this->request->post['etq_obj'];
		} elseif (isset($pr_info)) {
			$data['etq_obj'] = $pr_info['etq_obj'];
		} else {
			$data['etq_obj'] = "";
		}		
		
		if (isset($this->request->post['scrap'])) {
			$data['scrap'] = $this->request->post['scrap'];
		} elseif (isset($pr_info)) {
			$data['scrap'] = $pr_info['scrap'];
		} else {
			$data['scrap'] = "";
		}
		
		if (isset($this->request->post['defecto_id'])) {
			$data['defecto_id'] = $this->request->post['defecto_id'];
		} elseif (isset($pr_info)) {
			$data['defecto_id'] = $pr_info['defecto_id'];
		} else {
			$data['defecto_id'] = "";
		}		
		
		if (isset($this->request->post['puestaapunto'])) {
			$data['puestaapunto'] = $this->request->post['puestaapunto'];
		} elseif (isset($pr_info)) {
			$data['puestaapunto'] = $pr_info['puestaapunto'];
		} else {
			$data['puestaapunto'] = "";
		}			
		
		if (isset($this->request->post['pedido'])) {
			$data['pedido'] = $this->request->post['pedido'];
		} elseif (isset($pr_info)) {
			$data['pedido'] = $pr_info['pedido'];
		} else {
			$data['pedido'] = "";
		}	
		
		$data['stop_inicial']="";
		$data['stop_final']="";
			
		
		$data['turnos'] = $this->model_dirsiscrud_turno->getTurnos();
		
		
		$data['sectors'] = $this->model_dirsiscrud_sector->getSectors();
		
		$this->load->model('dirsiscrud/maqui');
		$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis();		

		$this->load->model('dirsiscrud/diseno');
		$data['disenos'] = $this->model_dirsiscrud_diseno->getDisenos();
		
		$this->load->model('dirsiscrud/lote');
		$data['lotes'] = $this->model_dirsiscrud_lote->getLotes();
		
		$this->load->model('dirsiscrud/matriz');
		$matrizs = $this->model_dirsiscrud_matriz->getMatrizs();
		
		$this->load->model('dirsismrp/pr');
		$data['matrizs'] = array();
		
		foreach ($matrizs as $matriz) {
			//print_r($matriz);
			if (isset($this->request->get['pr_id'])){
				$ok = $this->model_dirsismrp_pr->getPrxMatriz($this->request->get['pr_id'],$matriz['matriz_id']);
			}else{
				$ok = 0;
			}
			if ($matriz['status']!=0){
				$data['matrizs'][]=array(
				'matriz_id' => $matriz['matriz_id'],
				'name' => $matriz['name'],
				'code' => $matriz['code'],
				'selected' => $ok );
			}
		}		
		
		
		$this->load->model('dirsiscrud/operador');
		$data['operadors'] = $this->model_dirsiscrud_operador->getOperadors();
		
		$this->load->model('dirsiscrud/silo');
		$data['silos'] = $this->model_dirsiscrud_silo->getSilos();		
		
		$data['lotes']=array();
		if ($data['maqui_id']!=0){
			$data_filter = array (
				'filter_maqui_id' => $data['maqui_id']
			);
			$this->load->model('dirsiscrud/maqui');
			$cicloss = $this->model_dirsiscrud_maqui->getCiclos($data_filter);
			foreach ($cicloss as $ciclo) {
				$data['lotes'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			};
		}
		
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($pr_info['status'])) {
			$data['status'] = $pr_info['status'];
		} else {
			$data['status'] = '';
		}				
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if (isset($this->request->get['modal'])){
			$this->response->setOutput($this->load->view('dirsismrp/pr_form_modal', $data));
		}else{
			$this->response->setOutput($this->load->view('dirsismrp/pr_form', $data));
		}
	}

	
	
	public function edithistory() {
		$this->load->language('dirsismrp/pr');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsismrp/pr');
		$data['pr_id'] = 0;
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->request->get['pr_id'])){
			$data['pr_id'] = $this->request->get['pr_id'];
			
			$pr_info = $this->model_dirsismrp_pr->getPr($this->request->get['pr_id']);
			if ($pr_info){
				$data['date_registro'] = date("d-m-Y",strtotime($pr_info['date_registro']));
				$this->load->model('dirsiscrud/turno');
				$this->load->model('dirsiscrud/sector');
				$data['turno_id'] = $pr_info['turno_id'];
				$data['turno_name'] = $this->model_dirsiscrud_turno->getTurnoName($data['turno_id']);
				$data['sector_id'] = $pr_info['sector_id'];
				$data['sector_name'] = $this->model_dirsiscrud_sector->getSectorName($data['sector_id']);
				$data['turno_id'] = $pr_info['turno_id'];
				$data['maqui_id'] = $pr_info['maqui_id'];
				$data['maqui_name'] = $pr_info['maqui_name'];
				$data['maqui_code'] = $pr_info['maqui_code'];
				$data['diseno_id'] = $pr_info['diseno_id'];
				$data['matriz_id'] = $pr_info['matriz_id'];
				$data['lote_id'] = $pr_info['lote_id'];
				$data['operador_id'] = $pr_info['operador_id'];
				$data['qty_inicial'] = $pr_info['qty_inicial'];
				$data['qty_final'] = $pr_info['qty_final'];
				$data['qty_obj'] = $pr_info['qty_obj'];
				if ($data['maqui_id']!=0){
					$this->load->model('dirsiscrud/maqui');
					$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($data['maqui_id']);
					$data['qty_obj'] = $qty_obj['ciclos'];
				}				
				$data['etq_inicial'] = $pr_info['etq_inicial'];
				$data['etq_final'] = $pr_info['etq_final'];
				$data['etq_obj'] = $pr_info['etq_obj'];
				$data['scrap'] = $pr_info['scrap'];
				$data['defecto_id'] = $pr_info['defecto_id'];
				$data['puestaapunto'] = $pr_info['puestaapunto'];
				$data['pedido'] = $pr_info['pedido'];
				$data['stop_inicial']="";
				$data['stop_final']="";
				$data['status'] = $pr_info['status'];
				$data['stop_image'] = '';

			}

		}
		
		$this->load->model('tool/image');
		$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['placeholder'] = $this->model_tool_image->resize('loading.gif', 100, 100);
		$data['directory'] = '';
		
		$this->response->setOutput($this->load->view('dirsismrp/prstop_form_modal', $data));
	}
	public function editamodal() {
		
		$this->load->language('dirsismrp/pr');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsismrp/pr');
		$data['text_form'] = $this->language->get('text_edit');
		$data['error_warning'] = '';
		$data['error_turno_id'] = array();
		$data['error_sector_id'] = array();
		
		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['action'] = $this->url->link('dirsismrp/pr/savemodal', 'user_token=' . $this->session->data['user_token'] . '&pr_id=' . $this->request->get['pr_id'] . $url, true);
		

		$data['pr_id'] = $this->request->get['pr_id'];
		
		//$this->load->model('dirsismrp/pr');
		//$this->model_dirsismrp_pr->cierraHistory($data['pr_id']);
		//die;		

		$data['user_token'] = $this->session->data['user_token'];
		$pr_info = $this->model_dirsismrp_pr->getPr($this->request->get['pr_id']);
		if ($pr_info){
			$data['date_registro'] = date("d-m-Y",strtotime($pr_info['date_registro']));
			$this->load->model('dirsiscrud/turno');
			$this->load->model('dirsiscrud/sector');
			$data['turno_id'] = $pr_info['turno_id'];
			$data['turno_name'] = $this->model_dirsiscrud_turno->getTurnoName($data['turno_id']);
			$data['sector_id'] = $pr_info['sector_id'];
			$data['sector_name'] = $this->model_dirsiscrud_sector->getSectorName($data['sector_id']);
			$data['turno_id'] = $pr_info['turno_id'];
			$data['cant_maqui'] = (int)$pr_info['cant_maqui'];
			$data['nro_pedido'] = $pr_info['nro_pedido'];
			$data['maqui_id'] = $pr_info['maqui_id'];
			$data['maqui_name'] = $pr_info['maqui_name'];
			$data['maqui_code'] = $pr_info['maqui_code'];
			$data['diseno_id'] = $pr_info['diseno_id'];
			$data['matriz_id'] = $pr_info['matriz_id'];
			$data['lote_id'] = $pr_info['lote_id'];
			$data['silo_id'] = $pr_info['silo_id'];
			$data['operador_id'] = $pr_info['operador_id'];
			$data['qty_inicial'] = $pr_info['qty_inicial'];
			$data['qty_final'] = $pr_info['qty_final'];
			$data['qty_obj'] = $pr_info['qty_obj'];
			$data['etq_obj'] = $pr_info['etq_obj'];	
			if ($data['maqui_id']!=0){
				$this->load->model('dirsiscrud/maqui');
				if ($data['lote_id']){
					$qty_obj=$this->model_dirsiscrud_maqui->getCiclo($data['lote_id']);

					if (isset($qty_obj)){
						if ($qty_obj['type']=='1'){
							$data['qty_obj'] = $qty_obj['ciclos'];
						}else{
							$data['etq_obj'] = $qty_obj['ciclos'];	
						}
					}
				}
			}			
			
			$data['etq_inicial'] = $pr_info['etq_inicial'];
			$data['etq_final'] = $pr_info['etq_final'];
			
			$data['scrap'] = $pr_info['scrap'];
			$data['defecto_id'] = $pr_info['defecto_id'];
			$data['puestaapunto'] = $pr_info['puestaapunto'];
			$data['pedido'] = $pr_info['pedido'];
			$data['stop_inicial']="";
			$data['stop_final']="";
			$data['turnos'] = $this->model_dirsiscrud_turno->getTurnos();
			$data['sectors'] = $this->model_dirsiscrud_sector->getSectors();
			$this->load->model('dirsiscrud/maqui');
			$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis();		
			$this->load->model('dirsiscrud/diseno');
			$data['disenos'] = $this->model_dirsiscrud_diseno->getDisenos();
			$this->load->model('dirsiscrud/lote');
			$data['lotes'] = $this->model_dirsiscrud_lote->getLotes();
			
//GRILLA DE MATRIZ			
			$this->load->model('dirsiscrud/matriz');
			$matrizs = $this->model_dirsiscrud_matriz->getMatrizs();
//MATRIZ ASOCIADAS AL PR			
			$this->load->model('dirsismrp/pr');
			$data['matrizs'] = array();
			foreach ($matrizs as $matriz) {
				if (isset($this->request->get['pr_id'])){
					$ok = $this->model_dirsismrp_pr->getPrxMatriz($this->request->get['pr_id'],$matriz['matriz_id']);
				}else{
					$ok = 0;
				}
				if ($matriz['status']!=0){
					$data['matrizs'][]=array(
					'matriz_id' => $matriz['matriz_id'],
					'name' => $matriz['name'],
					'code' => $matriz['code'],
					'selected' => $ok );
				}
			}		
		$this->load->model('dirsiscrud/silo');
		$data['silos'] = $this->model_dirsiscrud_silo->getSilos();
			
			
		$this->load->model('dirsiscrud/operador');
		$data['operadors'] = $this->model_dirsiscrud_operador->getOperadors();
			
		$this->load->model('dirsiscrud/defecto');
		$data['defectos'] = $this->model_dirsiscrud_defecto->getDefectos();
		
		$data['lotes']=array();
		if ($data['maqui_id']!=0){
			$data_filter = array (
				'filter_maqui_id' => $data['maqui_id'],
				'filter_status_no' => '3'
			);
			$this->load->model('dirsiscrud/maqui');
			$cicloss = $this->model_dirsiscrud_maqui->getCiclos($data_filter);
			foreach ($cicloss as $ciclo) {
				$data['lotes'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			};
		}

			
//GRILLA DE OPERADOR			
			$this->load->model('dirsiscrud/operador');
			$data['operadors'] = $this->model_dirsiscrud_operador->getOperadors();
			$operadors = $this->model_dirsiscrud_operador->getOperadors();
//OPERADORES ASOCIADOS AL PR			
			$this->load->model('dirsismrp/pr');
			$data['operadors'] = array();
			foreach ($operadors as $operador) {
				if (isset($this->request->get['pr_id'])){
					$ok = $this->model_dirsismrp_pr->getPrxOperador($this->request->get['pr_id'],$operador['operador_id']);
				}else{
					$ok = 0;
				}
				$data['operadors'][]=array(
					'operador_id' => $operador['operador_id'],
					'name' => $operador['name'],
					'selected' => $ok );
			}	
			
//GRILLA DE SILOS			
			$this->load->model('dirsiscrud/silo');
			$data['silos'] = $this->model_dirsiscrud_silo->getSilos();
			$silos = $this->model_dirsiscrud_silo->getSilos();
//OPERADORES ASOCIADOS AL PR			
			$this->load->model('dirsismrp/pr');
			$data['silos'] = array();
			foreach ($silos as $silo) {
				if (isset($this->request->get['pr_id'])){
					$ok = $this->model_dirsismrp_pr->getPrxSilo($this->request->get['pr_id'],$silo['silo_id']);
				}else{
					$ok = 0;
				}
				$data['silos'][]=array(
					'silo_id' => $silo['silo_id'],
					'name' => $silo['name'],
					'selected' => $ok );
			}			
			
			$data['status'] = $pr_info['status'];
			$this->response->setOutput($this->load->view('dirsismrp/pr_form_modal', $data));
		}
	}
	
	public function savemodal() {
		$this->load->language('dirsismrp/pr');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsismrp_pr->editPr($this->request->get['pr_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			

			$this->response->redirect($this->url->link('dirsismrp/pr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		//$this->getList();
	}
	
	
	
	public function savescrap() {
		//print_r($this->request->post);
		//file_put_contents("data.txt", json_encode($this->request->post));
		//die;
		$json="1";
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$this->load->model('dirsismrp/pr');
			$this->model_dirsismrp_pr->editPrScrap($this->request->get['pr_id'], $this->request->post);
			//$this->session->data['success'] = $this->language->get('text_success');
		}
		echo $json;
	}	
	
	public function savepeso() {
		//print_r($this->request->post);
		//file_put_contents("data.txt", json_encode($this->request->post));
		//die;
		$json="1";
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$this->load->model('dirsismrp/pr');
			$this->model_dirsismrp_pr->editPrPeso($this->request->get['pr_id'], $this->request->post);
			//$this->session->data['success'] = $this->language->get('text_success');
		}
		echo $json;
	}	
	
	public function savemodal2() {
		$json="";
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$this->load->model('dirsismrp/pr');
			$this->model_dirsismrp_pr->editPr($this->request->get['pr_id'], $this->request->post);
			//$this->session->data['success'] = $this->language->get('text_success');
			$json="1";
		}
		echo $json;
	}	
	
	
	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/pr')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		
		if ($this->request->post['turno_id'] == 0) {
			$this->error['turno_id'] = $this->language->get('error_turno_id');
		}

		if ($this->request->post['sector_id'] == 0) {
			$this->error['sector_id'] = $this->language->get('error_sector_id');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/pr')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	
	
	public function getPr() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$json=array();
		if (isset($this->request->get['pr_id'])) {
			$this->load->model('dirsismrp/pr');
			$data_filter=array(
				"filter_pr_id" => $this->request->get['pr_id']
			);
			
			$results = $this->model_dirsismrp_pr->getPrs($data_filter);
			if ($results){
				$result=$results[0];
				$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
				$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
				
			$qty_obj=$result['qty_obj'];	
		if ($data['maqui_id']!=0){
			$this->load->model('dirsiscrud/maqui');
			$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($result['maqui_id']);
			$qty_obj = $qty_obj['ciclos'];
		}
				
				$json = array(
				'pr_id' 			=> $result['pr_id'],
				'date_registro' 	=> date($this->language->get('date_format_short'), strtotime($result['date_registro'])),
				'turno_id' 			=> $result['turno_id'],
				'turno_name' 		=> $result['turno_name'],
				'total' 			=> $completo['total'],
				'cerrado' 			=> $completo['cerrado'],
				'sector_id' 		=> $result['sector_id'],
				'sector_name' 		=> $result['sector_name'],
				'maqui_id' 			=> $result['maqui_id'],
				'maqui_name' 		=> $result['maqui_name'],
				'maqui_code' 		=> $result['maqui_code'],
				'maqui_ciclos' 		=> $result['maqui_ciclos'],
				'diseno_id' 		=> $result['diseno_id'],
				'diseno_name' 		=> $result['diseno_name'],
				'lote_id' 			=> $result['lote_id'],
				'lote_name' 		=> $result['lote_name'],
				'matriz_id' 		=> $result['matriz_id'],
				'matriz_name' 		=> $result['matriz_name'],
				'matrizs' 			=> $matrizs,
				'operador_id' 		=> $result['operador_id'],
				'operador_name' 	=> $result['operador_name'],
				'qty_inicial' 		=> $result['qty_inicial'],
				'qty_final' 		=> $result['qty_final'],
				'qty_obj' 			=> $qty_obj,
				'etq_inicial' 		=> $result['etq_inicial'],
				'etq_final' 		=> $result['etq_final'],
				'etq_obj' 			=> $result['etq_obj'],
				'hora_inicial' 		=> $result['hora_inicial'],
				'hora_final' 		=> $result['hora_final'],
				'scrap' 			=> $result['scrap'],
				'puestaapunto' 		=> $result['puestaapunto']?'Si':'No',
				'stops' 			=> $this->model_dirsismrp_pr->getTotalHistories($result['pr_id']),
				'status'     		=> $result['status'],
				'statusname'     	=> $result['status']?'Abierto':'Cerrado',
				'statuscolor'     	=> $result['status']?'red':'green',
				'user_id' => $result['user_id'],
				'username' => $result['username']
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
	}
	
	
	
	public function loadPr() {
		
		$this->load->language('dirsismrp/pr');
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->request->get['pr_id'])) {
			
			$this->load->model('dirsismrp/pr');
			$data_filter=array(
				"filter_pr_id" => $this->request->get['pr_id']
			);
			
			$results = $this->model_dirsismrp_pr->getPrs($data_filter);
			if ($results){
				$pr_info=$results[0];
				$data['pr_id'] = $pr_info['pr_id'];
				$data['date_registro'] = date("d-m-Y",strtotime($pr_info['date_registro']));
				$data['turno_id'] = $pr_info['turno_id'];
				$data['turno_name'] = $pr_info['turno_name'];
				$data['sector_id'] 	= $pr_info['sector_id'];
				$data['sector_name'] =  $pr_info['sector_name'];
				$data['maqui_id'] = $pr_info['maqui_id'];
				$data['maqui_name'] = $pr_info['maqui_name'];
				$data['maqui_code'] = $pr_info['maqui_code'];
				$data['maqui_ciclos'] = $pr_info['maqui_ciclos'];
				$data['diseno_id'] = $pr_info['diseno_id'];
				$data['diseno_name'] = $pr_info['diseno_name'];
				$data['matriz_id'] = $pr_info['matriz_id'];
				$data['matriz_name'] = $pr_info['matriz_name'];
				$data['lote_id'] = $pr_info['lote_id'];
				$data['lote_name'] = $pr_info['lote_name'];
				$data['operador_id'] = $pr_info['operador_id'];
				$data['operador_name'] = $pr_info['operador_name'];
				$data['qty_inicial'] = $pr_info['qty_inicial'];
				$data['qty_final'] = $pr_info['qty_final'];
				$data['qty_result'] = $pr_info['qty_final']-$pr_info['qty_inicial']+1>0?$pr_info['qty_final']-$pr_info['qty_inicial']+1:'--';
				$data['qty_obj'] = $pr_info['qty_obj'];
				
		if ($pr_info['maqui_id']!=0){
			$this->load->model('dirsiscrud/maqui');
			$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($pr_info['maqui_id']);
			$data['qty_obj'] = $qty_obj['ciclos'];
		}				
				$data['etq_inicial'] = $pr_info['etq_inicial'];
				$data['etq_final'] = $pr_info['etq_final'];
				$data['etq_result'] = $pr_info['etq_final']-$pr_info['etq_inicial']+1>0?$pr_info['etq_final']-$pr_info['etq_inicial']+1:'--';
				$data['etq_obj'] = $pr_info['etq_obj'];
				$data['scrap'] = $pr_info['scrap'];
				$data['defecto_id'] = $pr_info['defecto_id'];
				$data['hora_inicial'] = $pr_info['hora_inicial'];
				$data['hora_final'] = $pr_info['hora_final'];				
				$data['puestaapunto'] = $pr_info['puestaapunto'];
				$data['pedido'] = $pr_info['pedido'];
				$data['status'] = $pr_info['status'];
				$this->response->setOutput($this->load->view('dirsismrp/pr_load', $data));
			}
		}
	}
	
	
	public function history() {
		$this->load->language('dirsismrp/pr');
		
		
		$this->load->model('tool/image');
		$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['directory'] = '';
		
		
		if (isset($this->request->get['page'])) { $page = $this->request->get['page']; } else { $page = 1; }
		$data['histories'] = array();
		$this->load->model('dirsismrp/pr');
		$data_filter = array(
			"filter_pr_id" => $this->request->get['pr_id'] 
		);
		$results = $this->model_dirsismrp_pr->getHistories($data_filter);
		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . "catalog/".$result['stop_image'])) {
				$image = $this->model_tool_image->resize("catalog/".$result['stop_image'], 40, 40);
			} else {
				$image = '';
			}
			$data['histories'][] = array(
				'pr_history_id' => $result['pr_history_id'],
				'date_registro' => date("d-m-Y",strtotime($result['date_registro'])),
				'stop_inicial'  => $result['stop_inicial'],
				'stop_final'  => $result['stop_final'],
				'status'  	=> $result['status'],
				'statustext' 	=> $result['status']==1?"Pendiente":($result['status']==2?"En Proceso":"Terminado"),
				'statuscolor' 	=> $result['status']==1?"danger":($result['status']==2?"warning":"success"),
				'stop_image'	=> $image,
				'stop_alerta1' 	=> $result['stop_alerta'],
				'stop_alerta' 	=> $result['stop_alerta'] ? $this->language->get('text_yes') : $this->language->get('text_no'),
				'stop_motivo'   => nl2br($result['stop_motivo'])
			);
		}
		//print_r($data['histories']);
		$history_total = $this->model_dirsismrp_pr->getTotalHistories($this->request->get['pr_id']);
		$pagination = new Pagination();
		$pagination->total = $history_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('dirsismrp/pr/history', 'user_token=' . $this->session->data['user_token'] . '&pr_id=' . $this->request->get['pr_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($history_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($history_total - 10)) ? $history_total : ((($page - 1) * 10) + 10), $history_total, ceil($history_total / 10));
		

		

		$this->response->setOutput($this->load->view('dirsismrp/pr_history', $data));
	}
	
	public function gethistory() {
		$this->load->model('dirsismrp/pr');
		$result = $this->model_dirsismrp_pr->getHistory($this->request->get['pr_history_id']);
		
		$this->load->model('tool/image');
		if (is_file(DIR_IMAGE . "catalog/".$result['stop_image'])) {
			$image = $this->model_tool_image->resize("catalog/".$result['stop_image'], 40, 40);
		} else {
			$image = $this->model_tool_image->resize('no_image.png', 40, 40);
		}
		$json = array(
			'pr_history_id' => $result['pr_history_id'],
			'date_registro' => date("d-m-Y",strtotime($result['date_registro'])),
			'stop_inicial'  => $result['stop_inicial'],
			'stop_final'  	=> $result['stop_final'],
			'status'  		=> $result['status'],
			'statustext' 	=> $result['status']==1?"Pendiente":($result['status']==2?"En Proceso":"Terminado"),
			'statuscolor' 	=> $result['status']==1?"danger":($result['status']==2?"warning":"success"),
			'stop_image'	=> $result['stop_image'],
			'thumb'			=> $image,
			'stop_alerta1' 	=> $result['stop_alerta'],
			'stop_alerta' 	=> $result['stop_alerta'] ? $this->language->get('text_yes') : $this->language->get('text_no'),
			'stop_motivo'   => nl2br($result['stop_motivo'])
		);
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	
	public function addhistory() {
		$this->load->language('dirsismrp/pr');
		$this->load->model('dirsismrp/pr');
		if (isset($this->request->get['pr_id'])){
			$pr_id=$this->request->get['pr_id'];
		}else{
			$pr_id=0;
		}
		//STOPS
		$pr_history_id=$this->model_dirsismrp_pr->addHistory($pr_id,$this->request->post);
		$json['mtproceso_id']=0;
		if ($this->request->post['stop_mantenimiento']==1){
			//MANTENIMIENTO
			$this->load->model('dirsiscrud/mtproceso');
			$json['mtproceso_id']=$this->model_dirsiscrud_mtproceso->addStop($pr_id,$pr_history_id,$this->request->post);
		}
		
		$json['success'] = $this->language->get('text_success');
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function clonarPr() {
		$results=".";
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->clonarPr($this->request->get['pr_id']);
		echo $results;
	}	
	

	
	public function excel() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		$this->load->model('dirsismrp/pr');
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date("d-m-Y",strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde = "";
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date("d-m-Y",strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date("d-m-Y");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		$sort = 'p.sector_id,p.date_registro,p.turno_id,p.maqui_id';
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}		

		$filter_data = array(
			'filter_status'   		=> $filter_status,
			'filter_turno_id'   		=> $filter_turno_id,
			'filter_sector_id'   		=> $filter_sector_id,
			'filter_maqui_id'   		=> $filter_maqui_id,
			'filter_date_desde'   	=> $filter_date_desde,
			'filter_date_hasta'   	=> $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
		);
		
		//print_r($filter_data);
		
		
		
		$cabeza=array(
			"ID",
			"Sector",  
			"Cav.Anul.", 
			"Maq.Code",
			"Fecha",  
			"User",			
			"Turno",
			"Matriz",
			"Matriz",
			"Matriz",
			"Matriz",
			"Matriz",
			"Matriz",
			"Operadores",
			"Cant.Inicial",
			"Cant.Final",
			"Cant.Obj", 
			"Etq.Inicial",    
			"Etq.Final",    
			"Etq.Obj.",
			"Stops Detalle",
			"Tiempo(h)",
			"Stops Inicio",   
			"Fin",
			"Silos",
			"Status",
			"Sector ID",
		);
		$sc=0;
		$scf=0;
		
		$pe=0;
		$pef=0;		
		/*
			"ID", 		
			"Cant Cerrados",  
			"Sector ID",  
			"Sector",  
			"Maqui ID",  
			"Maquina",  
			"Maq.Code",  
			"Ciclos",  
			"Diseño ID",   
			"Diseño",   
			"Lote ID",   
			"lote",
			"Hora Inicial",   
			"Hora Final",   
			"Puesta a Punto?",   
			"Status ID",   
			"User ID",      
			"No Pedido",   
			"Cant.Maqui",
			"Turno ID",
			"Cant x Turno");
		*/
		$this->load->model('dirsiscrud/prstatus');
		$results = $this->model_dirsismrp_pr->getPrs($filter_data);
		//print_r($results);
		$datos=array();
		foreach ($results as $result) {
			$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
			$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
			$matri="";
			foreach ($matrizs as $matriz) {
				//$matri.="(".$matriz['code']."-".$matriz['name'].")";
				if (!empty($matri)){
					$matri.=", ";	
				}				
				$matri.=$matriz['code'];
			}
			$operadors=$this->model_dirsismrp_pr->getOperadorxPr($result['pr_id']);
			$oper="";
			foreach ($operadors as $operador) {
				//$oper.="(".$operador['operador_id']."-".$operador['name'].")";
				if (!empty($oper)){
					$oper.=", ";	
				}
				$oper.=$operador['name'];
			}
			$silos=$this->model_dirsismrp_pr->getSiloxPr($result['pr_id']);
			$silo="";
			foreach ($silos as $silox) {
				//$silo.="(".$silox['silo_id']."-".$silox['name'].")";
				if (!empty($silo)){
					$silo.=", ";	
				}
				$silo.=$silox['name'];
			}
			
			$data_stops=array('filter_pr_id' => $result['pr_id']);
			$stops=$this->model_dirsismrp_pr->getHistories($data_stops);
			

			
			$item=array(
				$result['pr_id'],
				$result['sector_name'],
				$result['cant_maqui'],
				$result['maqui_code'],
				date("d/m/Y",strtotime($result['date_registro'])),
				$result['username'],
				$result['turno_name'],
				$oper,
				$result['qty_inicial'],
				$result['qty_final'],
				$result['qty_obj'],
				$result['etq_inicial'],
				$result['etq_final'],
				$result['etq_obj'],	
				$silo,
				$result['status'],
				$result['sector_id'],
			);
			/*
				$result['pr_id'],
				$result['turno_id'],
				$completo['total'],
				$completo['cerrado'],

				$result['diseno_id'],
				$result['diseno_name'],
				$result['lote_id'],
				$result['lote_name'],
				$result['hora_inicial'],
				$result['hora_final'],
				$result['puestaapunto']?'Si':'No',
				$result['status']==1?'Abierto':'Cerrado',
				$result['user_id'],
				$result['nro_pedido'],
				
			*/
				$lis=0;
				$pos=7;
				foreach ($matrizs as $matriz) {
					array_splice( $item, $pos, 0, (string)$matriz['code'] );
					$pos++;
					$lis++;
					if ($lis>5){
						break;
					}
				}
			
				if ($lis<=5){
					for ($i = 0; $i < (6-$lis); ++$i) {
						array_splice( $item, $pos, 0, "" );
						$pos++;
					}
				}
			
				//
				$vueltas=0;
				$st1=$st2=$st3=$st4="";
				foreach ($stops as $stopx) {
					$fechaInicialSegundos = strtotime($stopx['stop_inicial']);
					$fechaFinalSegundos = strtotime($stopx['stop_final']);
					$dias = ($fechaFinalSegundos - $fechaInicialSegundos) / 60;
					$dias = $dias/60;
					$st1.=$st1!=''?"|":"";
					$st1.=$stopx['stop_final'];
					$st2.=$st2!=''?"|":"";
					$st2.=$stopx['stop_inicial'];
					$st3.=$st3!=''?"|":"";
					$st3.=$dias;
					$st4.=$st4!=''?"|":"";
					$st4.=$stopx['stop_motivo'];
					/*
					
					array_splice( $item, 11, 0, $stopx['stop_final'] );
					array_splice( $item, 11, 0, $stopx['stop_inicial'] );
					array_splice( $item, 11, 0, $dias );
					array_splice( $item, 11, 0, $stopx['stop_motivo'] );
					$datos[]=$item;
					$item=array(
						$result['pr_id'],
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",	
						"",
						"",
						""
					);
					*/
					$vueltas++;
				}	
				array_splice( $item, 20, 0, $st1 );
				array_splice( $item, 20, 0, $st2 );
				array_splice( $item, 20, 0, $st3 );
				array_splice( $item, 20, 0, $st4 );

				//scraps
				$sc=0;
				$this->load->model('dirsismrp/pr');
				$scraps=$this->model_dirsismrp_pr->getScrapxPr($result['pr_id']);
				foreach ($scraps as $scrap) {
					array_push($item, $scrap['scrap']);
					$sc++;
					//defectos
					$defectos=$this->model_dirsismrp_pr->getDefectosxScrap($scrap['prxscrap_id']);
					$defe="";
					if ($defectos){
						foreach ($defectos as $defecto) {
							//array_push($cabeza, "Defectos".$sc);
							//array_push($item, $defecto['code']);
							$defe.=$defecto['code'].",";
						}
					}		
					array_push($item, $defe);
				}
				$datos[]=$item;						
				if ($sc>$scf){
					$scf=$sc;
				}
			
			
				//pesoss
				$pe=0;
				$this->load->model('dirsismrp/pr');
				$pesos=$this->model_dirsismrp_pr->getPesoxPr($result['pr_id']);
				foreach ($pesos as $peso) {
					array_push($item, $peso['peso']);
					array_push($item, $peso['hora']);
					array_push($item, $peso['ctrl']);
					array_push($item, $peso['lote']);
					$pe++;
				}
				$datos[]=$item;						
				if ($pe>$pef){
					$pef=$pe;
				}
			
		}
		for ($i = 1; $i <= $scf; $i++){ 
			array_push($cabeza, "Scrap".$i);
			array_push($cabeza, "Defecto".$i);
		}
		for ($i = 1; $i <= $pef; $i++){ 
			array_push($cabeza, "Peso".$i);
			array_push($cabeza, "Hora".$i);
			array_push($cabeza, "Ctrl".$i);
			array_push($cabeza, "Lote".$i);
		}
		
		array_unshift($datos,$cabeza);

		
		/*
		echo "<pre>";
		print_r($datos);
		echo "<pre>";
		die;
		*/
		
		$row=1;
		
		$archivo = "proceso.xlsx";
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		foreach ($datos as $result) {
			$elem=count($result);
			$col="A";
			for ($i = 0; $i < $elem; ++$i) {
				$objPHPExcel->getActiveSheet()->setCellValue($col.$row,$result[$i]);
				$col++;
				
			}
			
			
			//$objPHPExcel->getActiveSheet()->setCellValue('X1:'.$col.$row,"Matriz");
			
			$row++;
		}
			$objPHPExcel->getActiveSheet()->getStyle('H1:M1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FF8916');	
			$objPHPExcel->getActiveSheet()->getStyle('U1:X1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('EC9CD8');
		/*
		foreach(range('A','AL') as $columnID) {
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		*/
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		//$this->response->setOutput($archivo);
		echo $archivo;
		

	}		

	public function excelbck() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		$this->load->model('dirsismrp/pr');
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date("d-m-Y",strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde = "";
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date("d-m-Y",strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date("d-m-Y");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		$sort = 'p.sector_id,p.date_registro,p.turno_id,p.maqui_id';
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}		

		$filter_data = array(
			'filter_status'   		=> $filter_status,
			'filter_turno_id'   		=> $filter_turno_id,
			'filter_sector_id'   		=> $filter_sector_id,
			'filter_maqui_id'   		=> $filter_maqui_id,
			'filter_date_desde'   	=> $filter_date_desde,
			'filter_date_hasta'   	=> $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
		);
		
		//print_r($filter_data);
		
		$datos=array();
		
		
		$datos[]=array(
			"ID",
			"Fecha",  
			"User",			
			"Turno",
			"Operadores",
			"Cant.Inicial",
			"Cant.Final",
			"Cant.Obj", 
			"Etq.Inicial",    
			"Etq.Final",    
			"Etq.Obj.",
			"Stops Detalle",
			"Tiempo(h)",
			"Stops Inicio",   
			"Fin",
			"Silos",
			"Scrap",
			"Status",
			"Sector ID", 
			"Sector",  
			"Maqui ID",  
			"Maquina",  
			"Maq.Code",			
			"Matrices"
		);
		/*
			"ID", 		
			"Cant Cerrados",  
			"Sector ID",  
			"Sector",  
			"Maqui ID",  
			"Maquina",  
			"Maq.Code",  
			"Ciclos",  
			"Diseño ID",   
			"Diseño",   
			"Lote ID",   
			"lote",
			"Hora Inicial",   
			"Hora Final",   
			"Puesta a Punto?",   
			"Status ID",   
			"User ID",      
			"No Pedido",   
			"Cant.Maqui",
			"Turno ID",
			"Cant x Turno");
		*/
		$this->load->model('dirsiscrud/prstatus');
		$results = $this->model_dirsismrp_pr->getPrs($filter_data);
		//print_r($results);
		
		foreach ($results as $result) {
			$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
			$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
			$matri="";
			foreach ($matrizs as $matriz) {
				//$matri.="(".$matriz['code']."-".$matriz['name'].")";
				if (!empty($matri)){
					$matri.=", ";	
				}				
				$matri.=$matriz['code'];
			}
			$operadors=$this->model_dirsismrp_pr->getOperadorxPr($result['pr_id']);
			$oper="";
			foreach ($operadors as $operador) {
				//$oper.="(".$operador['operador_id']."-".$operador['name'].")";
				if (!empty($oper)){
					$oper.=", ";	
				}
				$oper.=$operador['name'];
			}
			$silos=$this->model_dirsismrp_pr->getSiloxPr($result['pr_id']);
			$silo="";
			foreach ($silos as $silox) {
				//$silo.="(".$silox['silo_id']."-".$silox['name'].")";
				if (!empty($silo)){
					$silo.=", ";	
				}
				$silo.=$silox['name'];
			}
			
			$data_stops=array('filter_pr_id' => $result['pr_id']);
			$stops=$this->model_dirsismrp_pr->getHistories($data_stops);
			

			
			$item=array(
				$result['pr_id'],
				date("d/m/Y",strtotime($result['date_registro'])),
				$result['username'],
				$result['turno_name'],
				$oper,
				$result['qty_inicial'],
				$result['qty_final'],
				$result['qty_obj'],
				$result['etq_inicial'],
				$result['etq_final'],
				$result['etq_obj'],	
				$silo,
				$result['scrap'],
				$result['status'],
				$result['sector_id'],
				$result['sector_name'],
				$result['maqui_id'], 
				$result['maqui_name'],
				$result['maqui_code']
			);
			/*
				$result['pr_id'],
				$result['turno_id'],
				$completo['total'],
				$completo['cerrado'],

				$result['diseno_id'],
				$result['diseno_name'],
				$result['lote_id'],
				$result['lote_name'],
				$result['hora_inicial'],
				$result['hora_final'],
				$result['puestaapunto']?'Si':'No',
				$result['status']==1?'Abierto':'Cerrado',
				$result['user_id'],
				$result['nro_pedido'],
				$result['cant_maqui']
			*/
			foreach ($matrizs as $matriz) {
				array_splice( $item, 21, 0, $matriz['code'] );
			}
				$vueltas=0;
				$st1=$st2=$st3=$st4="";
				foreach ($stops as $stopx) {
					$fechaInicialSegundos = strtotime($stopx['stop_inicial']);
					$fechaFinalSegundos = strtotime($stopx['stop_final']);
					$dias = ($fechaFinalSegundos - $fechaInicialSegundos) / 60;
					$dias = $dias/60;
					$st1.=$st1!=''?"|":"";
					$st1.=$stopx['stop_final'];
					$st2.=$st2!=''?"|":"";
					$st2.=$stopx['stop_inicial'];
					$st3.=$st3!=''?"|":"";
					$st3.=$dias;
					$st4.=$st4!=''?"|":"";
					$st4.=$stopx['stop_motivo'];
					/*
					
					array_splice( $item, 11, 0, $stopx['stop_final'] );
					array_splice( $item, 11, 0, $stopx['stop_inicial'] );
					array_splice( $item, 11, 0, $dias );
					array_splice( $item, 11, 0, $stopx['stop_motivo'] );
					$datos[]=$item;
					$item=array(
						$result['pr_id'],
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"",	
						"",
						"",
						""
					);
					*/
					$vueltas++;
				}	
				array_splice( $item, 11, 0, $st1 );
				array_splice( $item, 11, 0, $st2 );
				array_splice( $item, 11, 0, $st3 );
				array_splice( $item, 11, 0, $st4 );
				$datos[]=$item;						
		}
		/*
		echo "<pre>";
		print_r($datos);
		echo "<pre>";
		*/
		$row=1;
		
		$archivo = "proceso.xlsx";
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		foreach ($datos as $result) {
			//print_r($result);
			$elem=count($result);
			$col="A";
			for ($i = 0; $i < $elem; ++$i) {
				//echo $col;
				//echo $row;
				$objPHPExcel->getActiveSheet()->setCellValue($col.$row,$result[$i]);
				if ($col>21){
				$objPHPExcel->getActiveSheet()->setCellValue($col.'1',"Matriz");
				}
				$col++;
				
			}
			
			$objPHPExcel->getActiveSheet()->getStyle('L'.$row.':O'.$row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FF8916');	
			
			$objPHPExcel->getActiveSheet()->getStyle('X1:'.$col.$row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('EC9CD8');
			//$objPHPExcel->getActiveSheet()->setCellValue('X1:'.$col.$row,"Matriz");
			
			$row++;
		}
		/*
		foreach(range('A','AL') as $columnID) {
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		*/
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		//$this->response->setOutput($archivo);
		echo $archivo;
		

	}	
	
	/*
	public function excel1() {

		
		$this->load->model('dirsismrp/pr');
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date("d-m-Y",strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde = "";
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date("d-m-Y",strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date("d-m-Y");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'p.date_registro,p.sector_id,p.turno_id,m.code';
			$sort = 'm.code,p.date_registro,username,p.sector_id,p.turno_id';
		}
		$sort = 'm.code,p.date_registro,username,p.sector_id,p.turno_id';
		$sort = 'p.sector_id,p.date_registro,p.turno_id,p.maqui_id';
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}		

		$filter_data = array(
			'filter_status'   		=> $filter_status,
			'filter_turno_id'   		=> $filter_turno_id,
			'filter_sector_id'   		=> $filter_sector_id,
			'filter_maqui_id'   		=> $filter_maqui_id,
			'filter_date_desde'   	=> $filter_date_desde,
			'filter_date_hasta'   	=> $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
		);
		
		$this->load->model('dirsiscrud/prstatus');
		$results = $this->model_dirsismrp_pr->getPrs($filter_data);
		
		
		//XLSX
		//$archivo = "stop_".uniqid().".xlsx";
		$archivo = "proceso.xlsx";
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		$row=2;
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$row,  "ID")
				->setCellValue('B'.$row,  "Fecha")
				->setCellValue('C'.$row,  "Turno ID")
				->setCellValue('D'.$row,  "Turno")
				->setCellValue('E'.$row,  "Cant x Turno")
				->setCellValue('F'.$row,  "Cant Cerrados")
				->setCellValue('G'.$row,  "Sector ID")
				->setCellValue('H'.$row,  "Sector")
				->setCellValue('I'.$row,  "Maqui ID")
				->setCellValue('J'.$row,  "Maquina")
				->setCellValue('K'.$row,  "Maq.Code")
				->setCellValue('L'.$row,  "Ciclos")
				->setCellValue('M'.$row,  "Diseño ID")
				->setCellValue('N'.$row,   "Diseño")
				->setCellValue('O'.$row,   "Lote ID")
				->setCellValue('P'.$row,   "lote")
				->setCellValue('Q'.$row,   "Operadores")
				->setCellValue('R'.$row,   "Cant.Inicial")
				->setCellValue('S'.$row,   "Cant.Final")
				->setCellValue('T'.$row,   "Cant.Obj")
				->setCellValue('U'.$row,    "Etq.Inicial")
				->setCellValue('V'.$row,    "Etq.Final")
				->setCellValue('W'.$row,    "Etq.Obj.")
				->setCellValue('X'.$row,   "Hora Inicial")
				->setCellValue('Y'.$row,   "Hora Final")
				->setCellValue('Z'.$row,   "Scrap")
				->setCellValue('AA'.$row,   "Puesta a Punto?")
				->setCellValue('AB'.$row,   "Status ID")
				->setCellValue('AC'.$row,   "Status")
				->setCellValue('AD'.$row,   "User ID")
				->setCellValue('AE'.$row,   "User")
				->setCellValue('AF'.$row,   "Silos")
				->setCellValue('AG'.$row,   "No Pedido")
				->setCellValue('AH'.$row,   "Cant.Maqui")
				->setCellValue('AI'.$row,   "Stops Detalle")
				->setCellValue('AJ'.$row,   "Stops Inicio")
				->setCellValue('AK'.$row,   "Fin")
				->setCellValue('AL'.$row,   "Tiempo(h)");
					
				$objPHPExcel->getActiveSheet()
				->getStyle('AI'.$row.':AL'.$row)
				->getFill()
				->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
				->getStartColor()
				->setARGB('FF8916');			
		$row++;

		

		foreach ($results as $result) {
			$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
			
			$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
			$matri="";
			foreach ($matrizs as $matriz) {
				//$matri.="(".$matriz['code']."-".$matriz['name'].")";
				if (!empty($matri)){
					$matri.=", ";	
				}				
				$matri.=$matriz['code'];
			}
			
			
			$operadors=$this->model_dirsismrp_pr->getOperadorxPr($result['pr_id']);
			$oper="";
			foreach ($operadors as $operador) {
				//$oper.="(".$operador['operador_id']."-".$operador['name'].")";
				if (!empty($oper)){
					$oper.=", ";	
				}
				$oper.=$operador['name'];
			}
			
			$silos=$this->model_dirsismrp_pr->getSiloxPr($result['pr_id']);
			$silo="";
			foreach ($silos as $silox) {
				//$silo.="(".$silox['silo_id']."-".$silox['name'].")";
				if (!empty($silo)){
					$silo.=", ";	
				}
				$silo.=$silox['name'];
			}
			

				
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$row,  $result['pr_id'])
				->setCellValue('B'.$row,  date("d-m-Y", strtotime($result['date_registro'])))
				->setCellValue('C'.$row,  $result['turno_id'])
				->setCellValue('D'.$row,  $result['turno_name'])
				->setCellValue('E'.$row,  $completo['total'])
				->setCellValue('F'.$row,  $completo['cerrado'])
				->setCellValue('G'.$row,  $result['sector_id'])
				->setCellValue('H'.$row,  $result['sector_name'])
				->setCellValue('I'.$row,  $result['maqui_id'])
				->setCellValue('J'.$row,  $result['maqui_name'])
				->setCellValue('K'.$row,  $result['maqui_code'])
				->setCellValue('L'.$row,  $result['maqui_ciclos'])
				->setCellValue('M'.$row,  $result['diseno_id'])
				->setCellValue('N'.$row,   $result['diseno_name'])
				->setCellValue('O'.$row,   $result['lote_id'])
				->setCellValue('P'.$row,   $result['lote_name'])
				->setCellValue('Q'.$row,   $oper)
				->setCellValue('R'.$row,   $result['qty_inicial'])
				->setCellValue('S'.$row,   $result['qty_final'])
				->setCellValue('T'.$row,   $result['qty_obj'])
				->setCellValue('U'.$row,    $result['etq_inicial'])
				->setCellValue('V'.$row,    $result['etq_final'])
				->setCellValue('W'.$row,    $result['etq_obj'])
				->setCellValue('X'.$row,    $result['hora_inicial'])
				->setCellValue('Y'.$row,    $result['hora_final'])
				->setCellValue('Z'.$row,    $result['scrap'])
				->setCellValue('AA'.$row,   $result['puestaapunto']?'Si':'No')
				->setCellValue('AB'.$row,   $result['status'])
				->setCellValue('AC'.$row,   $result['status']==1?'Abierto':'Cerrado')
				->setCellValue('AD'.$row,   $result['user_id'])
				->setCellValue('AE'.$row,   $result['username'])
				->setCellValue('AF'.$row,   $silo)
				->setCellValue('AG'.$row,   $result['nro_pedido'])
				->setCellValue('AH'.$row,   $result['cant_maqui']);
			
   
			
			
			$data_stops=array('filter_pr_id' => $result['pr_id']);
			$stops=$this->model_dirsismrp_pr->getHistories($data_stops);
			$stop="";
			$row2=$row;
			foreach ($stops as $stopx) {
    			$fechaInicialSegundos = strtotime($stopx['stop_inicial']);
    			$fechaFinalSegundos = strtotime($stopx['stop_final']);
				$dias = ($fechaFinalSegundos - $fechaInicialSegundos) / 60;
				$dias = $dias/60;
				$stop.=$stopx['stop_motivo']."(".$stopx['stop_inicial']."/".$stopx['stop_final']."=".$dias."mm.)";
				$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('AI'.$row2,  $stopx['stop_motivo'])
				->setCellValue('AJ'.$row2,  $stopx['stop_inicial'])
				->setCellValue('AK'.$row2,  $stopx['stop_final'])
				->setCellValue('AL'.$row2,  $dias);
				$row2++;
			}			
			$col2='AL'; 
			foreach ($matrizs as $matriz) {
				$col2++;
				$rowh=2;
				$objPHPExcel->getActiveSheet()->setCellValue($col2.$rowh,"Matriz");
				$objPHPExcel->getActiveSheet()->setCellValue($col2.$row,$matriz['code']);
			}			
			$row++;
		}
		foreach(range('A','AL') as $columnID) {
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		//$this->response->setOutput($archivo);
		echo $archivo;
	}	
	*/
	
	
	///MATRIZES
	
	
	
	public function addmatriz() {
		
		
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->addMatriz($this->request->get['pr_id'], $this->request->get['matriz_id']);
		/*
		$json=$this->model_dirsismrp_pr->getMatrizxPr($this->request->get['pr_id']);
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
		*/
	}	
	
	public function delmatrizxpr() {
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->delMatrizxPr($this->request->get['pr_id']);
	}	
	
	public function getmatriz() {
		$data['histories'] = array();
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->getMatrizxPr($this->request->get['pr_id']);
		if (isset($this->request->get['vista'])){
			$vista=$this->request->get['vista'];
		}else{
			$vista=1;
		}
		foreach ($results as $result) {
			$data['histories'][] = array(
				'matriz_id' => $result['matriz_id'],
				'name'  => $result['name'],
				'code' 	=> $result['code'],
				'vista' => $vista
			);
		}
		$this->response->setOutput($this->load->view('dirsismrp/pr_matriz', $data));		
	}	
	
	
	
	
	///OPERADORES
	public function addoperador() {
		
		

		
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->addOperador($this->request->get['pr_id'], $this->request->get['operador_id']);

	}	
	
	public function getoperador() {
		$data['operadors'] = array();
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->getOperadorxPr($this->request->get['pr_id']);
		if (isset($this->request->get['vista'])){
			$vista=$this->request->get['vista'];
		}else{
			$vista=1;
		}
		foreach ($results as $result) {
			$data['operadors'][] = array(
				'operador_id' => $result['operador_id'],
				'name'  => $result['name'],
				'vista' => $vista
			);
		}
		$this->response->setOutput($this->load->view('dirsismrp/pr_operador', $data));		
	}	
	
	//SCRAP
	public function addscrap() {
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->addScrap($this->request->get['pr_id'], $this->request->get['scrap']);
	}
	public function getscrap() {
		$data['scraps'] = array();
		
		$this->load->model('dirsiscrud/defecto');
		$defectos = $this->model_dirsiscrud_defecto->getDefectos();
		
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->getScrapxPr($this->request->get['pr_id']);
		
		foreach ($results as $result) {
			$defe = array();
			foreach ($defectos as $defecto) {
				$defe[] = array(
					"defecto_id" => $defecto['defecto_id'],
					"name" => $defecto['name'],
					"code" => $defecto['code'],
					"select" => $this->model_dirsismrp_pr->getDefectoxScrap($result['prxscrap_id'],$defecto['defecto_id']),
				); 
			}
				
			$data['scraps'][] = array(
				'scrap' => $result['scrap'],
				'prxscrap_id' => $result['prxscrap_id'],
				'defectos' => $defe
			);
		}
		
		$data['pr_id']=$this->request->get['pr_id'];
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->response->setOutput($this->load->view('dirsismrp/pr_scrap', $data));		
	}	
	
	//PESOS
	public function addpeso() {
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->addPeso($this->request->get['pr_id'], $this->request->get['peso']);
	}	
	public function getpeso() {
		$data['pesos'] = array();
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->getPesoxPr($this->request->get['pr_id']);
		foreach ($results as $result) {
			$data['pesos'][] = array(
				"prxpeso_id" => $result['prxpeso_id'],
				"peso" => $result['peso'],
				"lote" => $result['lote'],
				"hora" => $result['hora'],
				"ctrl" => $result['ctrl']
			); 
		}
		$data['pr_id']=$this->request->get['pr_id'];
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('dirsismrp/pr_peso', $data));		
	}	
	
	///SILOS
	public function addsilo() {
		$this->load->model('dirsismrp/pr');
		$this->model_dirsismrp_pr->addSilo($this->request->get['pr_id'], $this->request->get['silo_id']);
	}	
	
	public function getsilo() {
		$data['silos'] = array();
		$this->load->model('dirsismrp/pr');
		$results=$this->model_dirsismrp_pr->getSiloxPr($this->request->get['pr_id']);
		if (isset($this->request->get['vista'])){
			$vista=$this->request->get['vista'];
		}else{
			$vista=1;
		}
		foreach ($results as $result) {
			$data['silos'][] = array(
				'silo_id' => $result['silo_id'],
				'name'  => $result['name'],
				'vista' => $vista
			);
		}
		$this->response->setOutput($this->load->view('dirsismrp/pr_silo', $data));		
	}		
	
	
	
	public function getListitem() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		$this->load->language('dirsismrp/pr');
		if (isset($this->request->get['pr_id'])) {
			$this->load->model('dirsiscrud/prstatus');
			$this->load->model('dirsiscrud/maqui');
			$this->load->model('dirsismrp/pr');
			$filter_pr_id = $this->request->get['pr_id'];
			$data['statuss'][]=array("status" => 1, "name" => 'Cerrado');
			$data['statuss'][]=array("status" => 2, "name" => 'Abierto');
			$result = $this->model_dirsismrp_pr->getPr($filter_pr_id);
			$completo=$this->model_dirsismrp_pr->countstatusPr($result['date_registro'],$result['sector_id'],$result['turno_id']);
			$matrizs=$this->model_dirsismrp_pr->getMatrizxPr($result['pr_id']);
			$operadors=$this->model_dirsismrp_pr->getOperadorxPr($result['pr_id']);
			$silos=$this->model_dirsismrp_pr->getSiloxPr($result['pr_id']);
			$stops=$this->model_dirsismrp_pr->getTotalStops($result['pr_id']);
			$qty_obj=$this->model_dirsiscrud_maqui->getCicloactivo($result['maqui_id']);
			$qty_obj=$qty_obj['ciclos'];
			$data['pr'] = array(
				'pr_id' => $result['pr_id'],
				'date_registro' => date($this->language->get('date_format_short'), strtotime($result['date_registro'])),
				'date_registro_base' => $result['date_registro'],
				'turno_id' => $result['turno_id'],
				'turno_name' => $result['turno_name'],
				'total' => $completo['total'],
				'cerrado' => $completo['cerrado'],
				'sector_id' => $result['sector_id'],
				'sector_name' => $result['sector_name'],
				'cant_maqui' => $result['cant_maqui'],
				'nro_pedido' => $result['nro_pedido'],
				'maqui_id' => $result['maqui_id'],
				'maqui_name' => $result['maqui_name'],
				'maqui_code' => $result['maqui_code'],
				'maqui_ciclos' => $qty_obj,
				'diseno_id' => $result['diseno_id'],
				'diseno_name' => $result['diseno_name'],
				'lote_id' => $result['lote_id'],
				'lote_name' => $result['lote_name'],
				'matriz_id' => $result['matriz_id'],
				'matriz_name' => $result['matriz_name'],
				'matrizs' => $matrizs,
				'operadors' => $operadors,
				'silos' => $silos,
				'operador_id' => $result['operador_id'],
				'operador_name' => $result['operador_name'],
				'qty_inicial' => $result['qty_inicial'],
				'qty_final' => $result['qty_final'],
				'qty_obj' => $qty_obj,
				'etq_inicial' => $result['etq_inicial'],
				'etq_final' => $result['etq_final'],
				'etq_obj' => $result['etq_obj'],
				'hora_inicial' => $result['hora_inicial'],
				'hora_final' => $result['hora_final'],
				'scrap' => $result['scrap'],
				'puestaapunto' => 	$result['puestaapunto']?'Si':'No',
				'stops' 			=> $stops['total'],
				'stopsdanger'	=> $stops['danger'],
				'stopswarning'	=> $stops['warning'],
				'stopssuccess'	=> $stops['success'],									 
				'status'     		=> $result['status'],
				'statusname'     	=> $result['status']==1?'Abierto':'Cerrado',
				'statuscolor'     	=> $result['status']==1?'danger':'success',
				'user_id' => $result['user_id'],
				'username' => $result['username']
			);
			$this->response->setOutput($this->load->view('dirsismrp/pr_list_item', $data));
		}
	}	
	
}


