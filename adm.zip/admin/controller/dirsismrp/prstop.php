<?php
class ControllerDirsismrpPrstop extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsismrp/prstop');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');		

		$this->getList();
	}

	public function delete() {
		$this->load->language('dirsismrp/prstop');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/pr');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $pr_id) {
				$this->model_dirsismrp_pr->deleteHistory($pr_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_turno_id'])) {
				$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
			}
			if (isset($this->request->get['filter_sector_id'])) {
				$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	
	public function excel() {
			error_reporting(E_ALL);
		ini_set('display_errors', '1');	
		
		$this->load->model('dirsismrp/pr');
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date("d-m-Y",strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde = "";
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date("d-m-Y",strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date("d-m-Y");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_registro';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}		

		$filter_data = array(
			'filter_status'   		=> $filter_status,
			'filter_turno_id'   		=> $filter_turno_id,
			'filter_sector_id'   		=> $filter_sector_id,
			'filter_maqui_id'   		=> $filter_maqui_id,
			'filter_date_desde'   	=> $filter_date_desde,
			'filter_date_hasta'   	=> $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => 1,
			'limit'           => 650000
		);
		
		
		//XLSX
		//$archivo = "stop_".uniqid().".xlsx";
		$archivo = "stop.xlsx";
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		$row=2;
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$row,  "ID Stop")
				->setCellValue('B'.$row,  "ID Proceso")
				->setCellValue('C'.$row,  "Fecha")
				->setCellValue('D'.$row,  "Stop Inicial")
				->setCellValue('E'.$row,  "Stop Final")
				->setCellValue('F'.$row,  "Alerta")
				->setCellValue('G'.$row,  "Motivo")
				->setCellValue('H'.$row,  "Fecha Registro")
				->setCellValue('I'.$row,  "Sector")
				->setCellValue('J'.$row,  "Turno")
				->setCellValue('K'.$row,  "Maquina")
				->setCellValue('L'.$row,  "Code Maq")
				->setCellValue('M'.$row,  "Operador")
				->setCellValue('N'.$row,  "Registro")
				->setCellValue('O'.$row,  "ID Status")
				->setCellValue('P'.$row,  "Status");
		$row++;
		$results 	= $this->model_dirsismrp_pr->getHistories($filter_data);
		foreach ($results as $result) {
			
			if ($result['prdate_registro']){
				$dater=$result['prdate_registro'];
			}else{
				$dater=$result['date_registro'];
			}
			$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A'.$row,  $result['pr_history_id'])
				->setCellValue('B'.$row,  $result['pr_id'])
				->setCellValue('C'.$row,  date("d-m-Y", strtotime($result['date_registro'])))
				->setCellValue('D'.$row,  $result['stop_inicial'])
				->setCellValue('E'.$row,  $result['stop_final'])
				->setCellValue('F'.$row,  $result['stop_alerta'])
				->setCellValue('G'.$row,  strip_tags(html_entity_decode($result['stop_motivo'])))
				->setCellValue('H'.$row,  date("d-m-Y", strtotime($dater)))
				->setCellValue('I'.$row,  $result['sector_name'])
				->setCellValue('J'.$row,  $result['turno_name'])
				->setCellValue('K'.$row,  $result['maqui_name'])
				->setCellValue('L'.$row,  $result['maqui_code'])
				->setCellValue('M'.$row,  $result['operador_name'])
				->setCellValue('N'.$row,  $result['username'])
				->setCellValue('O'.$row,  $result['status'])
				->setCellValue('P'.$row,  $result['status']==1?"Pendiente":($result['status']==2?"En Proceso":"Terminado"));
			$row++;
		}
		foreach(range('A','F') as $columnID) {
			$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		//$this->response->setOutput($archivo);
		echo $archivo;
		/*
		$this->session->data['success'] = $this->language->get('text_success');

		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . $url, true));
		*/
	}
	
	protected function getList() {
		
		
		if (isset($this->error['turno_id'])) {
			$data['error_turno_id'] = $this->error['turno_id'];
		} else {
			$data['error_turno_id'] = array();
		}

		if (isset($this->error['sector_id'])) {
			$data['error_sector_id'] = $this->error['sector_id'];
		} else {
			$data['error_sector_id'] = array();
		}
		
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = date("d-m-Y",strtotime($this->request->get['filter_date_desde']));
		} else {
			$filter_date_desde = "";
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = date("d-m-Y",strtotime($this->request->get['filter_date_hasta']));
		} else {
			$filter_date_hasta = date("d-m-Y");
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$filter_turno_id = $this->request->get['filter_turno_id'];
		} else {
			$filter_turno_id = '';
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$filter_sector_id = $this->request->get['filter_sector_id'];
		} else {
			$filter_sector_id = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_registro';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['delete'] = $this->url->link('dirsismrp/prstop/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['excel'] = $this->url->link('dirsismrp/prstop/excel', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['histories'] = array();

		$filter_data = array(
			'filter_status'   => $filter_status,
			'filter_turno_id'   => $filter_turno_id,
			'filter_sector_id'   => $filter_sector_id,
			'filter_maqui_id'   => $filter_maqui_id,
			'filter_date_desde'   => $filter_date_desde,
			'filter_date_hasta'   => $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		$pr_total 	= $this->model_dirsismrp_pr->getTotalHistories($filter_data);
		$results 	= $this->model_dirsismrp_pr->getHistories($filter_data);
		
		 
		foreach ($results as $result) {
			
			$this->load->model('dirsismrp/pr');
			$this->load->model('tool/image');
			$thumb = $this->model_tool_image->resize('no_image.png', 40, 40);
			if (is_file(DIR_IMAGE . "catalog/".$result['stop_image'])) {
				$image = $this->model_tool_image->resize("catalog/".$result['stop_image'], 500, 500);
			} else {
				$image = "";
			}
			
			$pr = array();
			$data['histories'][] = array(
				'pr_history_id' => $result['pr_history_id'],
				'pr_id' 		=> $result['pr_id'],
				'date_registro' => date($this->language->get('date_format_short'), strtotime($result['date_registro'])),
				'stop_inicial' 	=> $result['stop_inicial'],
				'stop_final' 	=> $result['stop_final'],
				'stop_alerta' 	=> $result['stop_alerta'],
				'stop_motivo' 	=> $result['stop_motivo'],
				'stop_image' 	=> $result['stop_image'],
				'image'			=> $image,
				'thumb'			=> $thumb,				
				'prdate_registro' 	=> date($this->language->get('date_format_short'), strtotime($result['prdate_registro'])),
				'sector_name' 	=> $result['sector_name'],
				'turno_name' 	=> $result['turno_name'],
				'maqui_name' 	=> $result['maqui_name'],
				'maqui_code' 	=> $result['maqui_code'],
				'operador_name' 	=> $result['operador_name'],	
				'username' 		=> $result['username'],	
				'status' 		=> $result['status'],
				'statustext' 	=> $result['status']==1?"Pendiente":($result['status']==2?"En Proceso":"Terminado"),
				'statuscolor' 	=> $result['status']==1?"danger":($result['status']==2?"warning":"success"),
				'pr_details' 	=> $pr,
				'edit'       	=> $this->url->link('dirsismrp/prstop/edit', 'user_token=' . $this->session->data['user_token'] . '&pr_id=' . $result['pr_id'] . $url, true)
			);
			
		}
		
		$data['statuss'][]=array( "status" => 1 , "name" => 'Pendiente');
		$data['statuss'][]=array( "status" => 2 , "name" => 'En Proceso');
		$data['statuss'][]=array( "status" => 3 , "name" => 'Terminado');
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$data['sort_pr_history_id'] = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&sort=pr_history_id' . $url, true);
		$data['sort_pr_id'] = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&sort=pr_id' . $url, true);		
		$data['sort_date_registro'] = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&sort=date_registro' . $url, true);
		$data['sort_stop_motivo'] = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&sort=stop_motivo' . $url, true);		
		$data['sort_status'] = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_turno_id'])) {
			$url .= '&filter_turno_id=' . $this->request->get['filter_turno_id'];
		}
		if (isset($this->request->get['filter_sector_id'])) {
			$url .= '&filter_sector_id=' . $this->request->get['filter_sector_id'];
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$url .= '&filter_maqui_id=' . $this->request->get['filter_maqui_id'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $pr_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsismrp/prstop', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($pr_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($pr_total - $this->config->get('config_limit_admin'))) ? $pr_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $pr_total, ceil($pr_total / $this->config->get('config_limit_admin')));
		
		
		
		
		
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;
		$data['filter_status'] = $filter_status;
		$data['filter_turno_id'] = $filter_turno_id;
		$data['filter_sector_id'] = $filter_sector_id;
		$data['filter_maqui_id'] = $filter_maqui_id;
		
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['date_added'] = date("d-m-Y");

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		
		$this->load->model('dirsiscrud/turno');
		$this->load->model('dirsiscrud/sector');
		$this->load->model('dirsiscrud/maqui');
		$data['turnos'] = $this->model_dirsiscrud_turno->getTurnos();
		$data['sectors'] = $this->model_dirsiscrud_sector->getSectors();
		$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis();	
		
		$data['image'] = '';
		$this->load->model('tool/image');
		$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['placeholder'] = $this->model_tool_image->resize('loading.gif', 100, 100);
		$data['directory'] = '';
			
		$this->response->setOutput($this->load->view('dirsismrp/prstop_list', $data));
	}
	
	public function cambiaestado() {
		$this->load->model('dirsismrp/pr');
		$pr_history_id = $this->request->get['pr_history_id'];
		$status = $this->request->get['status'];
		$this->model_dirsismrp_pr->editStatusHistory($pr_history_id,$status);
		
		
		$json = array(
			'status' => $status,
			'statustext' 	=> $status==1?"Pendiente":($status==2?"En Proceso":"Terminado"),
			'statuscolor' 	=> $status==1?"danger":($status==2?"warning":"success")
		);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
	
	
	
//HISTORIAL INICIO
	public function addHc() {
		$result='';
		$this->load->model('dirsismrp/prstop');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$data=$this->request->post;
			$result=$this->model_dirsismrp_prstop->addHc($data);
			
		}
		echo $result;
	}
	
	public function delHc() {
		$this->load->model('dirsismrp/prstop');
		$resul=$this->model_dirsismrp_prstop->delHc($this->request->get['evento_historia_id']);
		return $resul;
	}	
	
	public function getHc() {
		$this->load->model('dirsismrp/prstop');
		$results=$this->model_dirsismrp_prstop->getHc($this->request->get['pr_history_id']);
		
		$data=array();
		foreach ($results as $result) {
			
			$this->load->model('tool/image');
			$thumb = $this->model_tool_image->resize('no_image.png', 40, 40);
			if (is_file(DIR_IMAGE . "catalog/".$result['image_1'])) {
				$image_1 = $this->model_tool_image->resize("catalog/".$result['image_1'], 500, 500);
			} else {
				$image_1 = "";
			}
			if (is_file(DIR_IMAGE . "catalog/".$result['image_2'])) {
				$image_2 = $this->model_tool_image->resize("catalog/".$result['image_2'], 500, 500);
			} else {
				$image_2 = "";
			}
			if (is_file(DIR_IMAGE . "catalog/".$result['image_3'])) {
				$image_3 = $this->model_tool_image->resize("catalog/".$result['image_3'], 500, 500);
			} else {
				$image_3 = "";
			}

			
			$data[] = array( 
					"evento_historia_id" => $result['evento_historia_id'],
					"date_added" => date("d-m-Y",strtotime($result['date_added'])),
					"text" => trim(html_entity_decode($result['text'], ENT_QUOTES, 'UTF-8')),
					"task" => trim(html_entity_decode($result['task'], ENT_QUOTES, 'UTF-8')),
					"user" => $result['user'],
					"hour" => $result['hour'],
					'thumb' => $thumb,
					"image_1" => $image_1,
					"image_2" => $image_2,
					"image_3" => $image_3
				);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));		
	}
//HISTORIAL FIN		
	
}


