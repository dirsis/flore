<?php
class ControllerDirsismrpOt extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsismrp/ot');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/ot');
		
		

		$this->getList();
	}

	public function add() {
		
		$this->load->language('dirsismrp/ot');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/ot');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsismrp_ot->addOt($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsismrp/ot');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/ot');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsismrp_ot->editOt($this->request->get['ot_id'], $this->request->post);
			


			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsismrp/ot');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/ot');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $ot_id) {
				$this->model_dirsismrp_ot->deleteOt($ot_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	public function copy() {
		$this->load->language('dirsismrp/ot');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/ot');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $ot_id) {
				$this->model_dirsismrp_ot->copyOt($ot_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'pd.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsismrp/ot/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('dirsismrp/ot/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsismrp/ot/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['ots'] = array();

		$filter_data = array(
			'filter_status'   => $filter_status,
			'filter_date_desde'   => $filter_date_desde,
			'filter_date_hasta'   => $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		$ot_total = $this->model_dirsismrp_ot->getTotalOts($filter_data);
		
		
		//$this->load->model('catalog/category');
		//$data['categories'] = $this->model_catalog_category->getCategories(['sort' => 'name', 'order' => 'ASC',]);
		
		//$this->load->model('catalog/manufacturer');
		//$data['manufacturers'] = $this->model_catalog_manufacturer->getManufacturers(['sort' => 'name', 'order' => 'ASC',]);
		$this->load->model('dirsiscrud/otstatus');
		$data['otstatuss'] = $this->model_dirsiscrud_otstatus->getOtstatuss();
		$results = $this->model_dirsismrp_ot->getOts($filter_data);
//die;
		foreach ($results as $result) {
			
			
			$otstatus = $this->model_dirsiscrud_otstatus->getOtstatus($result['status']);
			if (!$otstatus){
				$otstatus = array ('name' => "NO DEFINIDO", 'type' => '');
			}
			
			$data['ots'][] = array(
				'ot_id' => $result['ot_id'],
				'date_registro' => date($this->language->get('date_format_short'), strtotime($result['date_registro'])),
				'date_entrega' => date($this->language->get('date_format_short'), strtotime($result['date_entrega'])),
				'pedido' => $result['pedido'],
				'customer_id' => $result['customer_id'],
				'custname' => $result['custname'],
				'responsable_id' => $result['responsable_id'],
				'respname' => $result['respname'],
				'aplica_id' => $result['aplica_id'],
				'material' => $result['material'],
				'tarea' => $result['tarea'],
				'nota' => $result['nota'],
				'product_id' => $result['product_id'],
				'prodname' => $result['prodname'],
				'lote' => $result['lote'],
				'cantidad' => $result['cantidad'],
				'retrabajo' => $result['retrabajo'],
				'retrabajo_t' => $result['retrabajo_t'],
				'puestaapunto' => $result['puestaapunto'],
				'status'     => $otstatus['name'],
				'statuscolor' => $otstatus['type'],
				'edit'       => $this->url->link('dirsismrp/ot/edit', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true)
			);
			
		}

		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['sort_ot_id'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.ot_id' . $url, true);		

		$data['sort_date_registro'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_registro' . $url, true);
		$data['sort_customer_id'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.customer_id' . $url, true);
		$data['sort_responsable_id'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=p.responsable_id' . $url, true);
		$data['sort_tarea'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.tarea' . $url, true);
		$data['sort_date_entrega'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_entrega' . $url, true);
		$data['sort_product_id'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.product_id' . $url, true);
		$data['sort_status'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.status' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $ot_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($ot_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($ot_total - $this->config->get('config_limit_admin'))) ? $ot_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $ot_total, ceil($ot_total / $this->config->get('config_limit_admin')));
		


		
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;
		$data['filter_status'] = $filter_status;
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('dirsismrp/ot_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['ot_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['model'])) {
			$data['error_model'] = $this->error['model'];
		} else {
			$data['error_model'] = '';
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}

		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),

			'href' => $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['ot_id'])) {
			$data['action'] = $this->url->link('dirsismrp/ot/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsismrp/ot/edit', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $this->request->get['ot_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsismrp/ot', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['ot_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$ot_info = $this->model_dirsismrp_ot->getOt($this->request->get['ot_id']);

		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		$this->load->model('user/user');
		$data['responsables'] = $this->model_user_user->getUserslist();
		
		$this->load->model('user/user');
		$data['aplicas'] = $this->model_user_user->getUserslist();		


		if (isset($this->request->post['date_registro'])) {
			$data['date_registro'] = $this->request->post['date_registro'];
		} elseif (isset($ot_info)) {
			$data['date_registro'] = $ot_info['date_registro'];
		} else {
			$data['date_registro'] = date('Y-m-d');
		}
		
		if (isset($this->request->post['date_entrega'])) {
			$data['date_entrega'] = $this->request->post['date_entrega'];
		} elseif (isset($ot_info)) {
			$data['date_entrega'] = $ot_info['date_entrega'];
		} else {
			$data['date_entrega'] = date('Y-m-d');
		} 
		
		if (isset($this->request->post['pedido'])) {
			$data['pedido'] = $this->request->post['pedido'];
		} elseif (isset($ot_info)) {
			$data['pedido'] = $ot_info['pedido'];
		} else {
			$data['pedido'] = '';
		} 		
		
		$data['date_registro']=date("d-m-Y", strtotime($data['date_registro']));
		$data['date_entrega']=date("d-m-Y", strtotime($data['date_entrega']));
		
		if (isset($this->request->post['material'])) {
			$data['material'] = $this->request->post['material'];
		} elseif (isset($ot_info)) {
			$data['material'] = $ot_info['material'];
		} else {
			$data['material'] = '';
		} 		

		if (isset($this->request->post['tarea'])) {
			$data['tarea'] = $this->request->post['tarea'];
		} elseif (isset($ot_info)) {
			$data['tarea'] = $ot_info['tarea'];
		} else {
			$data['tarea'] = '';
		}
		
		if (isset($this->request->post['nota'])) {
			$data['nota'] = $this->request->post['nota'];
		} elseif (isset($ot_info['nota'])) {
			$data['nota'] = $ot_info['nota'];
		} else {
			$data['nota'] = '';
		} 
		
		if (isset($this->request->post['lote'])) {
			$data['lote'] = $this->request->post['lote'];
		} elseif (isset($ot_info['lote'])) {
			$data['lote'] = $ot_info['lote'];
		} else {
			$data['lote'] = '';
		} 	
		
		if (isset($this->request->post['cantidad'])) {
			$data['cantidad'] = $this->request->post['cantidad'];
		} elseif (isset($ot_info['cantidad'])) {
			$data['cantidad'] = $ot_info['cantidad'];
		} else {
			$data['cantidad'] = '1';
		}		
		
		if (isset($this->request->post['retrabajo'])) {
			$data['retrabajo'] = $this->request->post['retrabajo'];
		} elseif (isset($ot_info['retrabajo'])) {
			$data['retrabajo'] = $ot_info['retrabajo'];
		} else {
			$data['retrabajo'] = '0';
		}	
		
		if (isset($this->request->post['retrabajo_t'])) {
			$data['retrabajo_t'] = $this->request->post['retrabajo_t'];
		} elseif (isset($ot_info['retrabajo_t'])) {
			$data['retrabajo_t'] = $ot_info['retrabajo_t'];
		} else {
			$data['retrabajo_t'] = '0';
		}	
		
		if (isset($this->request->post['puestaapunto'])) {
			$data['puestaapunto'] = $this->request->post['puestaapunto'];
		} elseif (isset($ot_info['puestaapunto'])) {
			$data['puestaapunto'] = $ot_info['puestaapunto'];
		} else {
			$data['puestaapunto'] = '';
		}	
		
		if (isset($this->request->post['prodname'])) {
			$data['prodname'] = $this->request->post['prodname'];
		} elseif (isset($ot_info['prodname'])) {
			$data['prodname'] = $ot_info['prodname'];
		} else {
			$data['prodname'] = '';
		}
		
		if (isset($this->request->post['product_id'])) {
			$data['product_id'] = $this->request->post['product_id'];
		} elseif (isset($ot_info['product_id'])) {
			$data['product_id'] = $ot_info['product_id'];
		} else {
			$data['product_id'] = 0;
		}	
		
		if (isset($this->request->post['aplica_id'])) {
			$data['aplica_id'] = $this->request->post['aplica_id'];
		} elseif (isset($ot_info['aplica_id'])) {
			$data['aplica_id'] = $ot_info['aplica_id'];
		} else {
			$data['aplica_id'] = 0;
		}
		
		if (isset($this->request->post['responsable_id'])) {
			$data['responsable_id'] = $this->request->post['responsable_id'];
		} elseif (isset($ot_info['responsable_id'])) {
			$data['responsable_id'] = $ot_info['responsable_id'];
		} else {
			$data['responsable_id'] = 0;
		}	
			
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (isset($ot_info['customer_id'])) {
			$data['customer_id'] = $ot_info['customer_id'];
		} else {
			$data['customer_id'] = 0;
		}	
		
		if (isset($this->request->post['custname'])) {
			$data['custname'] = $this->request->post['custname'];
		} elseif (isset($ot_info['custname'])) {
			$data['custname'] = $ot_info['custname'];
		} else {
			$data['custname'] = '';
		}			

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($ot_info['status'])) {
			$data['status'] = $ot_info['status'];
		} else {
			$data['status'] = '';
		}			
		
		$this->load->model('dirsiscrud/otstatus');
		$data['otstatuss'] = $this->model_dirsiscrud_otstatus->getOtstatuss();		
		
		$this->load->model('catalog/product');
		$data['procesos'] = $this->model_catalog_product->getHrutas($data['product_id']);
		
		if (isset($this->request->post['procesos'])) {
			$procesos = $this->request->post['procesos'];
		} elseif (!empty($ot_info)) {
			$procesos = json_decode($ot_info['procesos'], true);
		} else {
			$procesos = array();
		}
		/*
		print_r($procesos);
		echo "<hr>";
		print_r($data['procesos']);
		echo "<hr>";
		*/
		if (isset($procesos)){
			foreach ($procesos as $proceso) {
				$rec=0;
				foreach ($data['procesos'] as $guia) {
					//print_r($guia);
					if ($guia['hruta_id']==$proceso){
						//print_r($data['procesos'][$rec]['status']);
						$data['procesos'][$rec]['status']=3;
						//die;
						//$data['procesos'][$recor]['status']=$guia['hruta_id']."==".$proceso;
					}
					$rec++;
				}
			}
		}
		//print_r($data['procesos']);
		//echo "<hr>";
		/*	
		*/
		//print_r($data['procesos']);
		//die;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$this->response->setOutput($this->load->view('dirsismrp/ot_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	
	public function cambiastatus() {
		$this->load->language('dirsismrp/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsismrp/ot');
		if (isset($this->request->get['ot_id'])) {
			$ot_id=$this->request->get['ot_id'];
			$otstatus_id=$this->request->get['otstatus_id'];
			$this->model_dirsismrp_ot->cambiaStatus($ot_id,$otstatus_id);
			echo $ot_id.",".$otstatus_id;
		}
	}
	public function cambiatarea() {
		$this->load->language('dirsismrp/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsismrp/ot');
		if (isset($this->request->get['ot_id'])) {
			$ot_id=$this->request->get['ot_id'];
			$tarea=$this->request->get['tarea'];
			$this->model_dirsismrp_ot->cambiaTarea($ot_id,$tarea);
			echo $ot_id.",".$tarea;
		}
	}
	
}

