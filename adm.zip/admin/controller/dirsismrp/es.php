<?php
class ControllerDirsismrpEs extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsismrp/es');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/es');
		
		

		$this->getList();
	}

	public function add() {
		
		$this->load->language('dirsismrp/es');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/es');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsismrp_es->addEs($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true));;
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsismrp/es');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/es');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsismrp_es->editEs($this->request->get['es_id'], $this->request->post);
			


			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsismrp/es');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsismrp/es');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $es_id) {
				$this->model_dirsismrp_es->deleteOt($es_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'pd.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsismrp/es/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsismrp/es/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['ess'] = array();

		$filter_data = array(
			'filter_status'   => $filter_status,
			'filter_date_desde'   => $filter_date_desde,
			'filter_date_hasta'   => $filter_date_hasta,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		$es_total = $this->model_dirsismrp_es->getTotalEss($filter_data);

		
		$results  = $this->model_dirsismrp_es->getEss($filter_data);

		foreach ($results as $result) {
			$data['ess'][] = array(
				'es_id' => $result['es_id'],
				'date_registro' => $result['date_registro'],
				'modo_id' => $result['modo_id'],
				'operador_id' => $result['operador_id'],
				'responsable_id' => $result['responsable_id'],
				'deposito_id' => $result['deposito_id'],
				'ot_id' => $result['ot_id'],
				'nota' => $result['nota'],
				'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit'       => $this->url->link('dirsismrp/es/edit', 'user_token=' . $this->session->data['user_token'] . '&es_id=' . $result['es_id'] . $url, true)
			);
			
		}

		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}		

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_model'] = $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . '&sort=p.model' . $url, true);
		$data['sort_status'] = $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . '&sort=p.status' . $url, true);
		$data['sort_order'] = $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . '&sort=p.sort_order' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $es_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($es_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($es_total - $this->config->get('config_limit_admin'))) ? $es_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $es_total, ceil($es_total / $this->config->get('config_limit_admin')));
		


		
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;
		$data['filter_status'] = $filter_status;
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('dirsismrp/es_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['es_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['error_ot_id'])) {
			$data['error_ot_id'] = $this->error['error_ot_id'];
		} else {
			$data['error_ot_id'] = array();
		}		

		if (isset($this->error['error_responsable_id'])) {
			$data['error_responsable_id'] = $this->error['error_responsable_id'];
		} else {
			$data['error_responsable_id'] = array();
		}

		if (isset($this->error['error_operador_id'])) {
			$data['error_operador_id'] = $this->error['error_operador_id'];
		} else {
			$data['error_operador_id'] = array();
		}

		if (isset($this->error['error_deposito_id'])) {
			$data['error_deposito_id'] = $this->error['error_deposito_id'];
		} else {
			$data['error_deposito_id'] = '';
		}

		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),

			'href' => $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['es_id'])) {
			$data['action'] = $this->url->link('dirsismrp/es/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsismrp/es/edit', 'user_token=' . $this->session->data['user_token'] . '&es_id=' . $this->request->get['es_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsismrp/es', 'user_token=' . $this->session->data['user_token'] . $url, true);

		
		if (isset($this->request->get['es_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$es_info = $this->model_dirsismrp_es->getEs($this->request->get['es_id']);

		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		$this->load->model('user/user');

		if (isset($this->request->post['date_registro'])) {
			$data['date_registro'] = $this->request->post['date_registro'];
		} elseif (isset($es_info)) {
			$data['date_registro'] = $es_info['date_registro'];
		} else {
			$data['date_registro'] = date('Y-m-d');
		}
		
		if (isset($this->request->post['operador_id'])) {
			$data['operador_id'] = $this->request->post['operador_id'];
		} elseif (isset($es_info)) {
			$data['operador_id'] = $es_info['operador_id'];
		} else {
			$data['operador_id'] = '';
		} 		
		
		if (isset($this->request->post['ot_id'])) {
			$data['ot_id'] = $this->request->post['ot_id'];
		} elseif (isset($es_info)) {
			$data['ot_id'] = $es_info['ot_id'];
		} else {
			$data['ot_id'] = '';
		} 		

		if (isset($this->request->post['nota'])) {
			$data['nota'] = $this->request->post['nota'];
		} elseif (isset($es_info['nota'])) {
			$data['nota'] = $es_info['nota'];
		} else {
			$data['nota'] = '';
		} 
		$this->load->model('dirsiscrud/deposito');
		$data['depositos'] = $this->model_dirsiscrud_deposito->getDepositos();
		
		if (isset($this->request->post['responsable_id'])) {
			$data['responsable_id'] = $this->request->post['responsable_id'];
		} elseif (isset($es_info['responsable_id'])) {
			$data['responsable_id'] = $es_info['responsable_id'];
		} else {
			$data['responsable_id'] = '';
		}
		if (isset($this->request->post['deposito_id'])) {
			$data['deposito_id'] = $this->request->post['deposito_id'];
		} elseif (isset($es_info['deposito_id'])) {
			$data['deposito_id'] = $es_info['deposito_id'];
		} else {
			$data['deposito_id'] = $this->model_dirsiscrud_deposito->getDepositoinicial();
		}
		if (isset($this->request->post['modo_id'])) {
			$data['modo_id'] = $this->request->post['modo_id'];
		} elseif (isset($es_info['modo_id'])) {
			$data['modo_id'] = $es_info['modo_id'];
		} else {
			$data['modo_id'] = 1;
		}		
		$data['modos'] = array();
		$data['modos'][] = array('modo_id' => 1,	'name' => 'Entrada');
		$data['modos'][] = array('modo_id' => 2,	'name' => 'Salida');
		
/*			


		$this->load->model('catalog/product');
		$data['procesos'] = $this->model_catalog_product->getHrutas($data['product_id']);
		
		if (isset($this->request->post['procesos'])) {
			$procesos = $this->request->post['procesos'];
		} elseif (!empty($es_info)) {
			$procesos = json_decode($es_info['procesos'], true);
		} else {
			$procesos = array();
		}
		if (isset($procesos)){
			foreach ($procesos as $proceso) {
				$rec=0;
				foreach ($data['procesos'] as $guia) {
					//print_r($guia);
					if ($guia['hruta_id']==$proceso){
						//print_r($data['procesos'][$rec]['status']);
						$data['procesos'][$rec]['status']=3;
						//die;
						//$data['procesos'][$recor]['status']=$guia['hruta_id']."==".$proceso;
					}
					$rec++;
				}
			}
		}
*/		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$this->response->setOutput($this->load->view('dirsismrp/es_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/es')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->request->post['ot_id'] == 0) {
			$this->error['error_ot_id'] = $this->language->get('error_ot_id');
		}		
		
		if ($this->request->post['deposito_id'] == 0) {
			$this->error['error_deposito_id'] = $this->language->get('error_deposito_id');
		}
		if ($this->request->post['responsable_id'] == 0) {
			$this->error['error_responsable_id'] = $this->language->get('error_responsable_id');
		}
		if ($this->request->post['operador_id'] == 0) {
			$this->error['error_operador_id'] = $this->language->get('error_operador_id');
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/es')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'dirsismrp/es')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
}

