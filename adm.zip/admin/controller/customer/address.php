<?php
class ControllerCustomerAddress extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('customer/address');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->editCustoms();
		
		$this->getList();
	}
	public function editCustoms(){
		//REVISA CAMPOS CUSTOM
		$recorre=0;
		$this->load->model('customer/custom_field');
		$this->load->model('customer/address');
		$custom_fields2 = array();
		$filter_data = array(
			'sort'  => 'cf.sort_order',
			'order' => 'ASC'
		);
		$custom_fields = $this->model_customer_custom_field->getCustomFields($filter_data);
		foreach ($custom_fields as $custom_field) {
			if ($custom_field['type']=='date'){
				$value=$custom_field['value'];
				if ($custom_field['value']){
					$value= date('d-m-Y',strtotime($custom_field['value']));
				}
			}else{
				$value= $custom_field['value'];
			}
			$custom_fields2[] = array(
				'custom_field_id'    => $custom_field['custom_field_id'],
				'custom_field_value' => $this->model_customer_custom_field->getCustomFieldValues($custom_field['custom_field_id']),
				'name'               => $custom_field['name'],
				'value'              => $value,
				'type'               => $custom_field['type'],
				'location'           => $custom_field['location'],
				'sort_order'         => $custom_field['sort_order']
			);
		}		
		
		$filter_data=array();
		$results = $this->model_customer_address->getAddresses($filter_data);
		foreach ($results as $result) {
			$address=json_decode($result['custom_field'],true);
			foreach ($custom_fields2 as $custom_field) {
				if ($custom_field['location'] == 'address'){
					$campo="";
					//$custom_field['name'];
					switch ($campo){
						case 'Referencia entre Calles':
							$campo='refedom';
							break;
						case 'Fecha Actualizacion':
							$campo="fechaact";
							break;
						case 'Fecha Bateria';
							$campo="fechabat";
							break;
						case 'Fecha Alta';
							$campo="fechaalta";
							break;
						case 'Fecha Baja';
							$campo="fechabaja";
							break;
						case 'Tipo de Comunicacion';
							$campo="tipocom";
							break;
						case 'N° de CHIP';
							$campo="chip";
							break;
						case 'Empresa';
							$campo="empresa";
							break;							
						case 'N° de Contrato';
							$campo="contrato";
							break;
					}
					if (!empty($campo)){
						$datar = array(
							'customer_id' 	=> $result['customer_id'],
							'address_id'  	=> $result['address_id'],
							'campo'			=> $campo,
							'valor'			=> $address[$custom_field['custom_field_id']],
							'type' 			=> $custom_field['type'] );
						$this->model_customer_address->editPrueba($datar);
						$recorre++;
					}
				}
			}
		}
		return "Reviso ".$recorre;
		//REVISA CAMPOS CUSTOM		
	}
	
	public function refresh(){
		$this->session->data['success']=$this->editCustoms();
		$this->response->redirect($this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'], true));
	}
	
	protected function getList() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		if (isset($this->request->get['filter_id_club'])) {
			$filter_id_club = $this->request->get['filter_id_club'];
		} else {
			$filter_id_club = '';
		}
		if (isset($this->request->get['filter_address_1'])) {
			$filter_address_1 = $this->request->get['filter_address_1'];
		} else {
			$filter_address_1 = '';
		}
		if (isset($this->request->get['filter_zone'])) {
			$filter_zone = $this->request->get['filter_zone'];
		} else {
			$filter_zone = '';
		}		
		if (isset($this->request->get['filter_central'])) {
			$filter_central = $this->request->get['filter_central'];
		} else {
			$filter_central = '';
		}		
		if (isset($this->request->get['filter_empresa'])) {
			$filter_empresa = $this->request->get['filter_empresa'];
		} else {
			$filter_empresa = '';
		}		
		if (isset($this->request->get['filter_chip'])) {
			$filter_chip = $this->request->get['filter_chip'];
		} else {
			$filter_chip = '';
		}		
		if (isset($this->request->get['filter_contrato'])) {
			$filter_contrato = $this->request->get['filter_contrato'];
		} else {
			$filter_contrato = '';
		}		
		if (isset($this->request->get['filter_tipocom'])) {
			$filter_tipocom = $this->request->get['filter_tipocom'];
		} else {
			$filter_tipocom = '';
		}		
		if (isset($this->request->get['filter_refedom'])) {
			$filter_refedom = $this->request->get['filter_refedom'];
		} else {
			$filter_refedom = '';
		}

		if (isset($this->request->get['filter_fechaact1'])) {
			$filter_fechaact1 = $this->request->get['filter_fechaact1'];
		} else {
			$filter_fechaact1 = '';
		}
		
		if (isset($this->request->get['filter_fechaact2'])) {
			$filter_fechaact2 = $this->request->get['filter_fechaact2'];
		} else {
			$filter_fechaact2 = '';
		}		
		
		if (isset($this->request->get['filter_fechabat1'])) {
			$filter_fechabat1 = $this->request->get['filter_fechabat1'];
		} else {
			$filter_fechabat1 = '';
		}
		
		if (isset($this->request->get['filter_fechabat2'])) {
			$filter_fechabat2 = $this->request->get['filter_fechabat2'];
		} else {
			$filter_fechabat2 = '';
		}		
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_id_club'])) {
			$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_address_1'])) {
			$url .= '&filter_address_1=' . urlencode(html_entity_decode($this->request->get['filter_address_1'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_zone'])) {
			$url .= '&filter_zone=' . urlencode(html_entity_decode($this->request->get['filter_zone'], ENT_QUOTES, 'UTF-8'));
		}			
		if (isset($this->request->get['filter_central'])) {
			$url .= '&filter_central=' . urlencode(html_entity_decode($this->request->get['filter_central'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_empresa'])) {
			$url .= '&filter_empresa=' . urlencode(html_entity_decode($this->request->get['filter_empresa'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_chip'])) {
			$url .= '&filter_chip=' . urlencode(html_entity_decode($this->request->get['filter_chip'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_contrato'])) {
			$url .= '&filter_contrato=' . urlencode(html_entity_decode($this->request->get['filter_contrato'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_tipocom'])) {
			$url .= '&filter_tipocom=' . urlencode(html_entity_decode($this->request->get['filter_tipocom'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_refdom'])) {
			$url .= '&filter_refdom=' . urlencode(html_entity_decode($this->request->get['filter_refdom'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechaact1'])) {
			$url .= '&filter_fechaact1=' . urlencode(html_entity_decode($this->request->get['filter_fechaact1'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechaact2'])) {
			$url .= '&filter_fechaact2=' . urlencode(html_entity_decode($this->request->get['filter_fechaact2'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_fechabat1'])) {
			$url .= '&filter_fechabat1=' . urlencode(html_entity_decode($this->request->get['filter_fechabat1'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechabat2'])) {
			$url .= '&filter_fechabat2=' . urlencode(html_entity_decode($this->request->get['filter_fechabat2'], ENT_QUOTES, 'UTF-8'));
		}			
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}else{
			$url .= '&limit=' . $limit;
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		
		
		$this->load->model('customer/custom_field');
		$custom_fields2 = array();
		$filter_data = array(
			'sort'  => 'cf.sort_order',
			'order' => 'ASC'
		);
		$custom_fields = $this->model_customer_custom_field->getCustomFields($filter_data);
		foreach ($custom_fields as $custom_field) {
			if ($custom_field['type']=='date'){
				$value=$custom_field['value'];
				if ($custom_field['value']){
					$value= date('d-m-Y',strtotime($custom_field['value']));
				}
			}else{
				$value= $custom_field['value'];
			}
			$custom_fields2[] = array(
				'custom_field_id'    => $custom_field['custom_field_id'],
				'custom_field_value' => $this->model_customer_custom_field->getCustomFieldValues($custom_field['custom_field_id']),
				'name'               => $custom_field['name'],
				'value'              => $value,
				'type'               => $custom_field['type'],
				'location'           => $custom_field['location'],
				'sort_order'         => $custom_field['sort_order']
			);
		}	
		

		$data['addresss'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_id_club'              => $filter_id_club,
			'filter_address_1'              => $filter_address_1,
			'filter_zone'              => $filter_zone,
			'filter_central'              => $filter_central,
			'filter_empresa'              => $filter_empresa,
			'filter_chip'              => $filter_chip,
			'filter_contrato'              => $filter_contrato,
			'filter_tipocom'              => $filter_tipocom,
			'filter_refedom'              => $filter_refedom,
			'filter_fechaact1'              => $filter_fechaact1,
			'filter_fechaact2'              => $filter_fechaact2,
			'filter_fechabat1'              => $filter_fechabat1,
			'filter_fechabat2'              => $filter_fechabat2,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $limit
		);
/*		
				echo "<pre>";
				print_r($custom_fields2);
				echo "</pre>";		
die;
*/
		$customer_total = $this->model_customer_address->getTotalAddress($filter_data);
		
		$results = $this->model_customer_address->getAddresses($filter_data);

		foreach ($results as $result) {
			$address=json_decode($result['custom_field'],true);
			
			
			foreach($address as $key => $value) {
				$campox=$this->model_customer_custom_field->getCustomField($key);
				if (isset($campox['name'])){
					$campo="";
					switch ($campox['name']){
					case 'Central':
						$campo='central';
						break;
					case 'Referencia entre Calles':
						$campo='refedom';
						break;
					case 'Fecha Actualizacion':
						$campo="fechaact";
						break;
					case 'Fecha Bateria';
						$campo="fechabat";
						break;
					case 'Fecha Alta';
						$campo="fechaalta";
						break;
					case 'Fecha Baja';
						$campo="fechabaja";
						break;
					case 'Tipo de Comunicacion';
						$campo="tipocom";
						break;
					case 'N° de CHIP';
						$campo="chip";
						break;
					case 'Empresa';
						$campo="empresa";
						break;							
					case 'N° de Contrato';
						$campo="contrato";
						break;
					}	
					if ($campo!=""){
						$data_fields=array(
							"campo" => $campo,
							"type" => $campox['type'],
							"valor" => $value,
							"address_id" => $result['address_id'],
							"customer_id" => $result['customer_id']
						);
						/*
						echo "<pre>";
						print_r($data_fields);
						echo "</pre>";
						*/
						$this->model_customer_address->editPrueba($data_fields);
					}	
				}
			}
		}

		$results = $this->model_customer_address->getAddresses($filter_data);
		foreach ($results as $result) {
			$data['addresss'][] = array(
				'customer_id'    => $result['customer_id'],
				'address_id'    => $result['address_id'],
				'id_club'    	=> $result['id_club'],
				'name'           => $result['name'],
				'zone_id'        => $result['zone_id'],
				'zone_name'      => $result['zone_name'],
				'country_id'     => $result['country_id'],
				'country_name'   => $result['country_name'],
				'address_1'      => $result['address_1'],
				'city'           => $result['city'],
				'central'		=>$result['central'],
				'empresa'	=>$result['empresa'],
                'fechaact'	=>$result['fechaact']=='0000-00-00'?'00-00-0000':date("d-m-Y",strtotime($result['fechaact'])),
				'fechaalta'	=>$result['fechaalta'],
				'fechabaja'	=>$result['fechabaja'],
				'fechabat'	=>$result['fechabat']=='0000-00-00'?'':date("d-m-Y",strtotime($result['fechabat'])),
				'chip'		=>$result['chip'],
				'contrato'	=>$result['contrato'],
				'refedom'	=>$result['refedom'],
				'tipocom'	=>$result['tipocom']
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_id_club'])) {
			$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_address_1'])) {
			$url .= '&filter_address_1=' . urlencode(html_entity_decode($this->request->get['filter_address_1'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_zone'])) {
			$url .= '&filter_zone=' . urlencode(html_entity_decode($this->request->get['filter_zone'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_central'])) {
			$url .= '&filter_central=' . urlencode(html_entity_decode($this->request->get['filter_central'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_empresa'])) {
			$url .= '&filter_empresa=' . urlencode(html_entity_decode($this->request->get['filter_empresa'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_chip'])) {
			$url .= '&filter_chip=' . urlencode(html_entity_decode($this->request->get['filter_chip'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_contrato'])) {
			$url .= '&filter_contrato=' . urlencode(html_entity_decode($this->request->get['filter_contrato'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_tipocom'])) {
			$url .= '&filter_tipocom=' . urlencode(html_entity_decode($this->request->get['filter_tipocom'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_refedom'])) {
			$url .= '&filter_refedom=' . urlencode(html_entity_decode($this->request->get['filter_refedom'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_fechaact1'])) {
			$url .= '&filter_fechaact1=' . urlencode(html_entity_decode($this->request->get['filter_fechaact1'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_fechaact2'])) {
			$url .= '&filter_fechaact2=' . urlencode(html_entity_decode($this->request->get['filter_fechaact2'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_fechabat1'])) {
			$url .= '&filter_fechabat1=' . urlencode(html_entity_decode($this->request->get['filter_fechabat1'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_fechabat2'])) {
			$url .= '&filter_fechabat2=' . urlencode(html_entity_decode($this->request->get['filter_fechabat2'], ENT_QUOTES, 'UTF-8'));
		}		
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}else{
			$url .= '&limit=' . $limit;
		}		

		$data['sort_name'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_address_1'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.address_1' . $url, true);		
		$data['sort_city'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.city' . $url, true);		
		$data['sort_zone_id'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.zone_id' . $url, true);		
		$data['sort_id_club'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=c.id_club' . $url, true);		
		$data['sort_country_id'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.country_id' . $url, true);		
		$data['sort_central'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.central' . $url, true);		
		$data['sort_fechaact'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fechaact' . $url, true);		
		$data['sort_fechaalta'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fechaalta' . $url, true);		
		$data['sort_fechabaja'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fechabaja' . $url, true);		
		$data['sort_fechabat'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fechabat' . $url, true);		
		$data['sort_chip'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.chip' . $url, true);		
		$data['sort_contrato'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.contrato' . $url, true);		
		$data['sort_refedom'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.refedom' . $url, true);		
		$data['sort_tipocom'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.tipocom' . $url, true);		
		$data['sort_empresa'] = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . '&sort=a.empresa' . $url, true);				

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_id_club'])) {
			$url .= '&filter_id_club=' . urlencode(html_entity_decode($this->request->get['filter_id_club'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_address_1'])) {
			$url .= '&filter_address_1=' . urlencode(html_entity_decode($this->request->get['filter_address_1'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_zone'])) {
			$url .= '&filter_zone=' . urlencode(html_entity_decode($this->request->get['filter_zone'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_central'])) {
			$url .= '&filter_central=' . urlencode(html_entity_decode($this->request->get['filter_central'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_empresa'])) {
			$url .= '&filter_empresa=' . urlencode(html_entity_decode($this->request->get['filter_empresa'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_chip'])) {
			$url .= '&filter_chip=' . urlencode(html_entity_decode($this->request->get['filter_chip'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_contrato'])) {
			$url .= '&filter_contrato=' . urlencode(html_entity_decode($this->request->get['filter_contrato'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_tipocom'])) {
			$url .= '&filter_tipocom=' . urlencode(html_entity_decode($this->request->get['filter_tipocom'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_refedom'])) {
			$url .= '&filter_refedom=' . urlencode(html_entity_decode($this->request->get['filter_refedom'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechaact1'])) {
			$url .= '&filter_fechaact1=' . urlencode(html_entity_decode($this->request->get['filter_fechaact1'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechaact2'])) {
			$url .= '&filter_fechaact2=' . urlencode(html_entity_decode($this->request->get['filter_fechaact2'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_fechabat1'])) {
			$url .= '&filter_fechabat1=' . urlencode(html_entity_decode($this->request->get['filter_fechabat1'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_fechabat2'])) {
			$url .= '&filter_fechabat2=' . urlencode(html_entity_decode($this->request->get['filter_fechabat2'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}else{
			$url .= '&limit=' . $limit;
		}		

		$pagination = new Pagination();
		$pagination->total = $customer_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		//$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('customer/address', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($customer_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($customer_total - $this->config->get('config_limit_admin'))) ? $customer_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $customer_total, ceil($customer_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_id_club'] = $filter_id_club;
		$data['filter_address_1'] = $filter_address_1;
		$data['filter_zone'] = $filter_zone;
		$data['filter_central'] = $filter_central;
		$data['filter_empresa'] = $filter_empresa;
		$data['filter_chip'] = $filter_chip;
		$data['filter_contrato'] = $filter_contrato;
		$data['filter_tipocom'] = $filter_tipocom;
		$data['filter_refedom'] = $filter_refedom;
		$data['filter_fechaact1'] = $filter_fechaact1;
		$data['filter_fechaact2'] = $filter_fechaact2;
		$data['filter_fechabat1'] = $filter_fechabat1;
		$data['filter_fechabat2'] = $filter_fechabat2;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$data['refresh'] = $this->url->link('customer/address/refresh', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['date_added']=date("d-m-Y");

		$this->response->setOutput($this->load->view('customer/address_list', $data));
	}
	public function editFechaact() {
		$result='';
		$this->load->model('customer/address');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$data=$this->request->post;
			$result=$this->model_customer_address->editFechaact($data);
			
		}
		echo $result;
	}
//HISTORIAL INICIO
	public function addHistoria() {
		$result='';
		$this->load->model('customer/address');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$data=$this->request->post;
			$result=$this->model_customer_address->addHistoria($data);
			
		}
		echo $result;
	}
	
	public function delHistoria() {
		$this->load->model('customer/address');
		$resul=$this->model_customer_address->delHistoria($this->request->get['evento_historia_id']);
		return $resul;
	}	
	
	public function getHistoria() {
		$this->load->model('customer/address');
		$results=$this->model_customer_address->getHistorias($this->request->get['address_id']);
		
		$data=array();
		foreach ($results as $result) {
			$data[] = array( "evento_historia_id" => $result['evento_historia_id'],
							"date_added" => date("d-m-Y",strtotime($result['date_added'])),
							"text" => html_entity_decode($result['text'])
							);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));		
	}
//HISTORIAL FIN

}