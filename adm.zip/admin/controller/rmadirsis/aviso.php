<?php
class ControllerRmadirsisAviso extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('rmadirsis/aviso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/aviso');
		$this->getList();
	}
	
	public function delete() {
		$this->load->language('rmadirsis/aviso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/aviso');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $aviso_id) {
				$this->model_rmadirsis_aviso->delete($aviso_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}	
	
	
	public function revisaraviso() {
		$this->load->language('rmadirsis/aviso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/aviso');
		$this->model_rmadirsis_aviso->revisaraviso();
		$this->session->data['success'] = "Revision Terminada!";
		$url = '';
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}	

	public function enviamail() {
		$this->load->language('rmadirsis/aviso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/aviso');
		if (isset($this->request->get['aviso_id'])){
			$filter_data = array(
				'aviso_id'      	=> $this->request->get['aviso_id'],
				'accion'       			=> $this->request->get['accion']
			);
			$this->model_rmadirsis_aviso->enviamail($filter_data);
			$this->session->data['success'] = "E-mail Enviado";
		}
		$url = '';
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	
	public function enviomasivo() {
		$this->load->language('rmadirsis/aviso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/aviso');
		$results = $this->model_rmadirsis_aviso->getAvisos();
		$envio=0;
		foreach ($results as $result) {		
			$filter_data = array(
				'aviso_id'      	=> $result['aviso_id'],
				'accion'       			=> $this->request->get['accion']
			);
			if ($this->request->get['accion']==1 and $result['pagado']!=1){
				$resultado=$this->model_rmadirsis_aviso->enviamail($filter_data);
				$envio=$envio+$resultado;
			}
			if ($this->request->get['accion']==2 and $result['confirma']!=1){
				$resultado=$this->model_rmadirsis_aviso->enviamail($filter_data);
				$envio=$envio+$resultado;
			}
		}
		$this->session->data['success'] = "Se Enviarion ".$envio." Notificaciones";
		
		$url = '';
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}	
	
	protected function getList() {
			
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		
		$url = '';
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['delete'] = $this->url->link('rmadirsis/aviso/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['avisos'] = array();
		$filter_data = array(
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		
		
		$this->load->model('rmadirsis/aviso');
		$aviso_total = $this->model_rmadirsis_aviso->getTotalAviso($filter_data);
		$results = $this->model_rmadirsis_aviso->getAvisos($filter_data);
		

		foreach ($results as $result) {

			$data['avisos'][] = array(
				'aviso_id'    	 => $result['aviso_id'],
				'turno_id'    	 => $result['turno_id'],
				'customer_id'    	 => $result['customer_id'],
				'namecustomer'    	 => $result['namecustomer'],
				'email'    	 => $result['email'],
				'nameprof'    	 => $result['nameprof'],
				'nameserv'    	 => $result['nameserv'],
				'd_pagado'    	 => $result['pagado']?"Pagado":"A Pagar",
				'd_confirma'    	 => $result['confirma']?"Confirmado":"A Confirmar",
				'pagado'    	 => $result['pagado'],
				'confirma'    	 => $result['confirma'],
				'statusserv'    	 => $result['statusserv'],
				'fecha_inicio' => date("d-m-Y H:i",strtotime($result['fecha_inicio'])),
				'date_added'     => strtotime($result['date_added'])>0?date("d-m-Y", strtotime($result['date_added'])):'',
				'dateconfirma'     => strtotime($result['dateconfirma'])>0?date("d-m-Y H:i", strtotime($result['dateconfirma'])):'',
				'datepagado'     => strtotime($result['datepagado'])>0?date("d-m-Y H:i", strtotime($result['datepagado'])):'',
				'status'         => $result['status'],
				'mailpagado'		=> $result['mailpagado'],
				'mailconfirma'		=> $result['mailconfirma'],
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_aviso_id'] = $this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . '&sort=aviso_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);
		$data['sort_status'] = $this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);

		$url = '';
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $aviso_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/aviso', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($aviso_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($aviso_total - $this->config->get('config_limit_admin'))) ? $aviso_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $aviso_total, ceil($aviso_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('rmadirsis/aviso_list', $data));
	}

	

}