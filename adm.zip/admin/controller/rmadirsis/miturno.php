<?php
class ControllerRmadirsisMiturno extends Controller {
	private $error = array();

	public function index() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');			
		$this->load->language('rmadirsis/miturno');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/miturno');
		$this->getList();
	}
	
	public function pagado() {
		$this->load->model('rmadirsis/miturno');
		$turno_id = $this->request->get['turno_id'];
		$accion   = $this->request->get['accion'];
		$this->model_rmadirsis_miturno->pagado($turno_id,$accion);
		echo $accion;
	}
	public function confirma() {
		
		$this->load->model('rmadirsis/miturno');
		$turno_id=$this->request->get['turno_id'];
		$accion=$this->request->get['accion'];
		$this->model_rmadirsis_miturno->confirma($turno_id,$accion);
		echo $accion;
	}	

	public function liquida() {
		$this->load->model('rmadirsis/miturno');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $turno_id) {
				$this->model_rmadirsis_miturno->liquida($turno_id);
			}
		}
		echo "1";
	}	
	
	public function delete() {
		$this->load->language('rmadirsis/miturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/miturno');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $turno_id) {
				$this->model_rmadirsis_miturno->delete($turno_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}		
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}	
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}	
	
	protected function getList() {
		/*
		echo "<pre>";
		print_r($this->user);
		echo "</pre>";
		*/
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = date("d-m-Y");
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = date("d-m-Y");
		}		
		
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		$this->load->model('rmadirsis/profesional');
		$profesional = $this->model_rmadirsis_profesional->getProfesionalByUser($this->user->getId());	
		if (isset($profesional['profesional_id'])){
			$filter_profesional_id=$profesional['profesional_id'];
			$dataprofesional= array(
				'filter_profesional_id'    => $filter_profesional_id,	
			);
			$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals($dataprofesional);			
		}else{
			$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals();		
			$data['admin']=1;
			
		}
		
		

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}						
		if (!empty($filter_profesional_id)){
			$url .= '&filter_profesional_id=' . $filter_profesional_id;
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}	
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['liquida'] = $this->url->link('rmadirsis/miturno/liquida', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/miturno/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['miturnos'] = array();
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $filter_date_desde,
			'filter_date_hasta'        => $filter_date_hasta,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		
		
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] 		= $this->model_rmadirsis_servicio->getServiciodeprofesionales($filter_profesional_id);
			
			
			
		
		$this->load->model('rmadirsis/agenda');
		$miturno_total = $this->model_rmadirsis_agenda->getTotalAgenda($filter_data);
		$results = $this->model_rmadirsis_agenda->getAgendas($filter_data);
		

		foreach ($results as $result) {
			
			$url=$this->url->link('rmadirsis/agenda/atender', 'user_token=' . $this->session->data['user_token'] . "&turno_id=".$result['turno_id']."&filter_profesional_id=".$result['profesional_id'], true);
			$statusname="Confirmado";
			$color="green";
			$colortext="white";
			switch ($result['status']) {
			/*
			case 2:
				$statusname="Vencido";
				$color="red";
				$colortext="white";
				break;
			*/
			case 3:
				$statusname="Atendido";
				$color="orange";
				$colortext="black";
				$url="";
				break;
			case 4:
				$statusname="Liquidado";
				$color="blue";
				$colortext="white";
				$url="";
				break;
			case 5:
				if ($result['cancelado']==1){
					$statusname="Cancelado";
				}else{
					$statusname="Reasignado";
				}
				$color="grey";
				$colortext="white";
				$url="";
				break;
			}			
			
			
			
			$data['miturnos'][] = array(
				'turno_id'    	 => $result['turno_id'],
				'fecha_inicio'     => date("Y-m-d H.i", strtotime($result['fecha_inicio'])),
				'fecha_fin'     => date("Y-m-d H.i", strtotime($result['fecha_fin'])),
				'profesional_id' => $result['profesional_id'],
				'nameprof'       => $result['nameprof'],
				'servicio_id' 	=> $result['servicio_id'],
				'nameserv'		=> $result['nameserv'],
				'statusserv'		=> $result['statusserv'],
				'customer_id'	 => $result['customer_id'],
				'namecustomer'	 => $result['namecustomer'],
				'pagado'		=>  $result['pagado'],
				'confirma'		=>  $result['confirma'],
				'status'         => $result['status'],
				'statusname'	=> $statusname,
				'color'			=> $color,
				'colortext'		=> $colortext,
				'notificado' => $result['notificado'],
				'cuota'		=> $result['cuota'],
				'cuotas'	=> $result['cuotas'],
				'url'			=> $url
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}			
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_turno_id'] = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.turno_id' . $url, true);
		$data['sort_fecha_inicio'] = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fecha_inicio' . $url, true);
		$data['sort_profesional_id'] 	= $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.profesional_id' . $url, true);	
		$data['sort_servicio_id'] 	= $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.servicio_id' . $url, true);			
		$data['sort_customer_id'] 	= $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.customer_id' . $url, true);			
		$data['sort_status'] = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . '&sort=a.status' . $url, true);

		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $miturno_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($miturno_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($miturno_total - $this->config->get('config_limit_admin'))) ? $miturno_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $miturno_total, ceil($miturno_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_profesional_id'] = $filter_profesional_id;
		$data['filter_servicio_id'] = $filter_servicio_id;
		$data['filter_status'] = $filter_status;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->load->model('rmadirsis/servicio');
		$results = $this->model_rmadirsis_servicio->getServicios();

		foreach ($results as $result) {
			$data['servicios'][] = array(
				'servicio_id'    => $result['servicio_id'],
				'name'           => $result['name']);
		}		
		
		

		$this->response->setOutput($this->load->view('rmadirsis/miturno_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['turno_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['turno_id'])) {
			$data['turno_id'] = $this->request->get['turno_id'];
		} else {
			$data['turno_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['date_added'])) {
			$data['error_date_added'] = $this->error['date_added'];
		} else {
			$data['error_date_added'] = '';
		}
		
		if (isset($this->error['hora'])) {
			$data['error_hora'] = $this->error['hora'];
		} else {
			$data['error_hora'] = '';
		}
		
		if (isset($this->error['profesional_id'])) {
			$data['error_profesional_id'] = $this->error['profesional_id'];
		} else {
			$data['error_profesional_id'] = '';
		}
		
		
		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['turno_id'])) {
			$data['action'] = $this->url->link('rmadirsis/miturno/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('rmadirsis/miturno/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $this->request->get['turno_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$miturno_info=array();
		
		if (isset($this->request->get['turno_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$miturno_info = $this->model_rmadirsis_miturno->getMiturno($this->request->get['turno_id']);
		}
		
		
		$this->load->model('rmadirsis/profesional');
		$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals();
		
		/*
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] = $this->model_rmadirsis_servicio->getServicios();
		*/		
		
	
		//print_r($data['listahoras']);

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($miturno_info)) {
			$data['date_added'] = $miturno_info['date_added'];
		} else {
			$data['date_added'] = date('Y-m-d');
		}
		
		$data['date_added'] = date( "d-m-Y", strtotime( $data['date_added']));
		
		$hora_inicio = '08:00';
		$hora_fin	 = '23:00';
		$intervalo = 20;
		$hora_inicio = new DateTime( $hora_inicio );
    	$hora_fin    = new DateTime( $hora_fin );
    	$hora_fin->modify('+1 second'); 
    	if ($hora_inicio > $hora_fin) {
			$hora_fin->modify('+1 day');
    	}
		$intervalo = new DateInterval('PT'.$intervalo.'M');
		$periodo   = new DatePeriod($hora_inicio, $intervalo, $hora_fin);    
		
		$data['listahoras'] = array();
		foreach( $periodo as $listhora ) {
			$data['listahoras'][] = array(
				'hora'    => $listhora->format('H:i'),
				'name'    => $listhora->format('H:i')
			);
		}

		if (isset($this->request->post['hora'])) {
			$data['hora'] = $this->request->post['hora'];
		} elseif (!empty($miturno_info)) {
			$data['hora'] = $miturno_info['hora'];
		} else {
			$data['hora'] = '';
		}		
		
		if (isset($this->request->post['profesional_id'])) {
			$data['profesional_id'] = $this->request->post['profesional_id'];
		} elseif (!empty($miturno_info)) {
			$data['profesional_id'] = $miturno_info['profesional_id'];
		} elseif (isset($this->request->get['filter_profesional_id'])) {
			$data['profesional_id'] = $this->request->get['filter_profesional_id'];
		} else {
			$data['profesional_id'] = 0;
		}
		
		if (isset($this->request->post['servicio_id'])) {
			$data['servicio_id'] = $this->request->post['servicio_id'];
		} elseif (!empty($miturno_info)) {
			$data['servicio_id'] = $miturno_info['servicio_id'];
		} elseif (isset($this->request->get['filter_servicio_id'])) {
			$data['servicio_id'] = $this->request->get['filter_servicio_id'];
		} else {
			$data['servicio_id'] = 0;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($miturno_info)) {
			$data['status'] = $miturno_info['status'];
		} else {
			$data['status'] = true;
		}
			
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
	
		$this->response->setOutput($this->load->view('rmadirsis/miturno_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/miturno')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		
		if ($this->request->post['hora'] < 1) {
			$this->error['hora'] = $this->language->get('error_hora');
		}		

		return !$this->error;
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'rmadirsis/miturno')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	

}