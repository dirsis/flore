<?php
class ControllerRmadirsisHistorial extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('rmadirsis/historial');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/historial');

		$this->getList();
	}

	public function delete() {
		$this->load->language('rmadirsis/historial');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/historial');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $historial_id) {
				$this->model_rmadirsis_historial->deleteHistorial($historial_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}
			
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . $this->request->get['filter_customer'];
			}			

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}


			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				
			

			$this->response->redirect($this->url->link('rmadirsis/historial', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		if (isset($this->request->get['filter_estado'])) {
			$filter_estado = $this->request->get['filter_estado'];
		} else {
			$filter_estado = '';
		}			
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'historial_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}
		
		$url = '';

		if (isset($this->request->get['filter_customer_id'])) {
			
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/historial', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['delete'] = $this->url->link('rmadirsis/historial/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['historials'] = array();

		$filter_data = array(
			'filter_customer_id'        => $filter_customer_id,
			'filter_estado'        	   	=> $filter_estado,
			'filter_date_desde'        	=> $filter_date_desde,
			'filter_date_hasta'        	=> $filter_date_hasta,
			'sort'                     	=> $sort,
			'order'                    	=> $order,
			'start'                    	=> ($page - 1) * $limit,
			'limit'                    	=> $limit
		);
		
		$this->load->model('tool/image');		
		
		$this->load->model('customer/estadocivil');
		$data['estadocivils'] =$this->model_customer_estadocivil->getEstadocivils();		

		$this->load->model('customer/genero');
		$data['generos'] =$this->model_customer_genero->getGeneros();		

		$this->load->model('customer/actividad');
		$data['actividads'] =$this->model_customer_actividad->getActividads();	
		
		$data['historials']= array();
		$historial_total =0;
		if ($filter_customer_id>0){
			
			//DATOS PERSONALES
			$this->load->model('customer/customer');
			$agenda_info=$this->model_customer_customer->getCustomer($filter_customer_id);
			$data['customer_id'] = $agenda_info['customer_id'];
			$data['firstname'] = $agenda_info['firstname'];
			$data['lastname'] = $agenda_info['lastname'];
			$data['cuit'] = $agenda_info['cuit'];
			$data['email'] = $agenda_info['email'];
			$data['telephone'] = $agenda_info['telephone'];
			$data['status'] = $agenda_info['status'];
			$anexo=$this->model_customer_customer->getCustomeranexo($agenda_info['customer_id']);
				
			$this->load->model('localisation/country');
			$data['countries'] = $this->model_localisation_country->getCountries();				
				
			$data['city']='Cordoba';
			$data['zone_id']=160;
			$data['zone']='Cordoba';
			$data['country_id']=10;
			$data['country']="Argentina";
				
			if ($agenda_info['address_id']){
				$address_info=$this->model_customer_customer->getAddress($agenda_info['address_id']);
				if ($address_info){
					$data['address_1']=$address_info['address_1'];
					$data['city']=$address_info['city'];
					$data['zone_id']=$address_info['zone_id'];
					$data['zone']=$address_info['zone'];
					$data['country_id']=$address_info['country_id'];
					$data['country']=$address_info['country'];
				}
			}
				
				
			$nacimiento = new DateTime($anexo['fechanac']);
   			$ahora = new DateTime(date("Y-m-d"));
   			$diferencia = $ahora->diff($nacimiento);
   			$edad = $diferencia->format("%y");
			
			$data['anexo'] = array (
					"hijos" => $anexo['hijos'],
					"fechanac" => date("d-m-Y",strtotime($anexo['fechanac'])),
					"edad" => $edad,
					"antecedentes" => $anexo['antecedentes'],
					"medicacion" => $anexo['medicacion'],
					"obs" => $anexo['obs'],
					"flia" => $anexo['flia'],
					"vive_id" => $anexo['vive_id'],
					"origen_id" => $anexo['origen_id'],
					"medicacion" => $anexo['medicacion'],
					"genero" => $this->model_customer_genero->getGeneroname($anexo['genero_id']),
					"estadocivil" => $this->model_customer_estadocivil->getEstadocivilname($anexo['estadocivil_id']),
					"actividad" => $this->model_customer_actividad->getActividadname($anexo['actividad_id']),
					"estadocivil_id" => $anexo['estadocivil_id'],
					"actividad_id" => $anexo['actividad_id'],
			);
				
			$data['vives'][] =array('vive_id' => 1, 'name' => 'solo');
			$data['vives'][] =array('vive_id' => 2, 'name' => 'familia');
			$data['vives'][] =array('vive_id' => 3, 'name' => 'amigos');
			$data['vives'][] =array('vive_id' => 4, 'name' => 'asilo');
			$data['vives'][] =array('vive_id' => 5, 'name' => 'hotel');
			$data['vives'][] =array('vive_id' => 6, 'name' => 'otros');

			$data['origens'][] =array('origen_id' => 1, 'name' => 'web');
			$data['origens'][] =array('origen_id' => 2, 'name' => 'instagram');
			$data['origens'][] =array('origen_id' => 3, 'name' => 'facebook');
			$data['origens'][] =array('origen_id' => 4, 'name' => 'amigos');
			$data['origens'][] =array('origen_id' => 5, 'name' => 'paciente');
			$data['origens'][] =array('origen_id' => 6, 'name' => 'publicidad');				
			$data['origens'][] =array('origen_id' => 7, 'name' => 'otros');				
						
			$data['address'] = $this->model_customer_customer->getAddresses($agenda_info['customer_id']);
//FIN DATOS PERSONALES				
			
			$historial_total = $this->model_rmadirsis_historial->getTotalHistorials($filter_data);
			$results = $this->model_rmadirsis_historial->getHistorials($filter_data);
			foreach ($results as $result) {
				
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 40, 40);
			} else {
				$image = "";
			}
				
				$data['historials'][] = array(
							"fecha_registro" => date("d/m/Y h:i",strtotime($result['fecha_registro'])),
							"fecha_registro2" => date("Y-m-d h:i",strtotime($result['fecha_registro'])),
							"fecha" => date("d/m/Y",strtotime($result['fecha'])),
							"historial_id" => $result['historial_id'],
							"customer_id" => $result['customer_id'],
							"servicio_id" => $result['servicio_id'],
							"profesional_id" => $result['profesional_id'],
							"nameprof" => $result['nameprof'],
							"namecustomer" => $result['namecustomer'],
							"nameserv" => $result['nameserv'],
							"pesoactual" => $result['pesoactual'],
							"pesoactual2" => (int)$result['pesoactual'],
							"objetivo" => $result['objetivo'],
							"avance" => $result['avance'],
							"actifisica" => $result['actifisica'],
							"cumplimiento" => $result['cumplimiento'],
							"image" => $image,
							"notaprof" => $result['notaprof'],
							"man" => $result['man'],
							"h20" => $result['h20'],
							"add1" => $result['add1'],
							"lax" => $result['lax'],
							"mie" => $result['mie'],
							"diu" => $result['diu'],
							"mvm" => $result['mvm'],
							"frl" => $result['frl'],
							"rdp" => $result['rdp'],
							"frt" => $result['frt'],
							"rsp" => $result['rsp'],					
							"delete" => $this->url->link('rmadirsis/agenda/deleteHistoria', 'user_token=' . $this->session->data['user_token'] . $url."&historial_id=".$result['historial_id'], true)
				);
				$filter_customer=$result['namecustomer'];
			}
		}
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				

		
			
		$data['sort_historial_id'] = $this->url->link('rmadirsis/historial', 'user_token=' . $this->session->data['user_token'] . '&sort=historial_id' . $url, true);
		$data['sort_status'] = $this->url->link('rmadirsis/historial', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		
		$url = '';
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				
		$data['limit'] = $limit; 
		
		$pagination = new Pagination();
		$pagination->total = $historial_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('rmadirsis/historial', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();
		
		
		

		$data['results'] = sprintf($this->language->get('text_pagination'), ($historial_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($historial_total - $limit)) ? $historial_total : ((($page - 1) * $limit) + $limit), $historial_total, ceil($historial_total / $limit));

		$data['filter_customer'] 		= $filter_customer;
		$data['filter_customer_id'] 	= $filter_customer_id;
		if ($filter_date_desde){
			$data['filter_date_desde'] 	= date("d-m-Y",strtotime($filter_date_desde));
		}
		if ($filter_date_hasta){
			$data['filter_date_hasta'] 	= date("d-m-Y",strtotime($filter_date_hasta));
		}
		$data['filter_estado'] 		= $filter_estado;
		
		//print_r($data);

		$data['sort'] = $sort;
		$data['order'] = $order;
		$data['page'] = $page;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('rmadirsis/historial_list', $data));
	}
	
	
	
	public function verimagenes(){



		$data = array();
		
		if (isset($this->request->get['historial_id'])){
			$historial_images = array();
			$this->load->model('rmadirsis/historial');
			$historial_info = $this->model_rmadirsis_historial->getHistorial($this->request->get['historial_id']);
			$data['image'] = HTTPS_CATALOG . "image/".  $historial_info['image'];

			$this->load->model('tool/image');

			$data['thumb'] = $this->model_tool_image->resize($historial_info['image'], 100, 100);
		
			$historial_images = $this->model_rmadirsis_historial->getHistorialImages($this->request->get['historial_id']);

			$data['historial_images'] = array();
			foreach ($historial_images as $historial_image) {
				if (is_file(DIR_IMAGE . $historial_image['image'])) {
					$image = HTTPS_CATALOG . "image/" . $historial_image['image'];
					$thumb = $historial_image['image'];
				} else {
					$image = '';
					$thumb = 'no_image.png';
				}

				$data['historial_images'][] = array(
					'image'      => $image,
					'thumb'      => $this->model_tool_image->resize($thumb, 100, 100),
					'sort_order' => $historial_image['sort_order']
				);
			}	
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));		
		
	}
	
	
}