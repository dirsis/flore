<?php
class ControllerRmadirsisAgenda extends Controller {
	private $error = array();
	public function index() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');	
		$this->load->language('rmadirsis/agenda');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getList();
		
	}
	
	public function traer(){
		$json = array();
		if (isset($this->request->post['turno_id'])){
			$this->load->model('rmadirsis/agenda');
			$json = $this->model_rmadirsis_agenda->getAgenda($this->request->post['turno_id']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function atendido(){
		if (isset($this->request->post['turno_id'])){
			$this->load->model('rmadirsis/agenda');
			$this->model_rmadirsis_agenda->atendidoAgenda($this->request->post['turno_id']);
			$this->session->data['success'] = $customer_id.")".$this->language->get('text_success');
		}
	}	
	public function atender() {
		$this->load->language('rmadirsis/agenda');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agenda');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {		
			$this->model_rmadirsis_agenda->atenderAgenda($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			
			if (isset($this->request->get['miturno'])) { 
				$url = '';
				if (isset($this->request->get['filter_name'])) {
					$url .= '&filter_name=' . $this->request->get['filter_name'];
				}							
				if (isset($this->request->get['filter_profesional_id'])) {
					$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
				}	
				if (isset($this->request->get['filter_servicio_id'])) {
					$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
				}				
				if (isset($this->request->get['filter_status'])) {
					$url .= '&filter_status=' . $this->request->get['filter_status'];
				}

				if (isset($this->request->get['filter_date_desde'])) {
					$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
				}
				if (isset($this->request->get['filter_periodo'])) {
					$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
				}			


				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}

				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}

				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}

				$this->response->redirect($this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true));				
			}else{
				$url = '';
				if (isset($this->request->get['filter_name'])) {
					$url .= '&filter_name=' . $this->request->get['filter_name'];
				}							
				if (isset($this->request->get['filter_profesional_id'])) {
					$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
				}	
				if (isset($this->request->get['filter_servicio_id'])) {
					$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
				}				
				if (isset($this->request->get['filter_status'])) {
					$url .= '&filter_status=' . $this->request->get['filter_status'];
				}

				if (isset($this->request->get['filter_date_desde'])) {
					$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
				}
				if (isset($this->request->get['filter_periodo'])) {
					$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
				}			


				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}

				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}

				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}

				$this->response->redirect($this->url->link('rmadirsis/agenda', 'user_token=' . $this->session->data['user_token'] . $url, true));
			}
		}

		$this->getForm();
	}
	
	public function reservar() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		$this->load->language('rmadirsis/agenda');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agenda');
		$error="";
		$customer_id=0;
		if ($this->request->post['customer_id']<1){
			$email = $this->request->post['email'];
			if ((utf8_strlen(trim($email)) > 96) || !filter_var(trim($email), FILTER_VALIDATE_EMAIL)) {
			//	$error="!Este mail esta mal ".$email;
			}
			if (!empty($email)){
				$this->load->model('customer/customer');
				$customer_info = $this->model_customer_customer->getCustomerByEmail($email);
				if ($customer_info) {
					$error=$this->language->get('error_exists');
				}
			}
			if (empty($error)){
				$data = array(
					'lastname'  => $this->request->post['lastname'],
					'firstname'  => $this->request->post['firstname'],
					'telephone'  => $this->request->post['telephone'],
					'email'  => $this->request->post['email'],
					'cuit'  => $this->request->post['cuit']
				);	
				$this->load->model('rmadirsis/customer');
				$customer_id=$this->model_rmadirsis_customer->addCustomer($data);	
			}
		}else{
			$customer_id=$this->request->post['customer_id'];
		}
		if ($customer_id>0){
			
			$pagado=0;
			if ($this->request->post['cuota']!=$this->request->post['cuotas']){
				$pagado=1;
			}
			
			$data = array(
					'fechanac'  => $this->request->post['fechanac'],
					'hijos'  => $this->request->post['hijos'],
					'antecedentes'  => $this->request->post['antecedentes'],
					'medicacion'  => $this->request->post['medicacion'],
					'estadocivil_id'  => $this->request->post['estadocivil_id'],
					'actividad_id'  => $this->request->post['actividad_id'],
					'genero_id'  => $this->request->post['genero_id'],
					'servicio_id'  => $this->request->post['servicio_id'],
					'cuota'  => $this->request->post['cuota'],
					'cuotas'  => $this->request->post['cuotas'],
					'customer_id' => $customer_id
				);
			$this->load->model('rmadirsis/customer');
			$this->model_rmadirsis_customer->addCustomeranexo($data);	
			$data = array(
				'fecha_inicio'   => $this->request->post['fecha_inicio'],
				'fecha_fin'      => $this->request->post['fecha_fin'],
				'profesional_id' => $this->request->post['profesional_id'],
				'user_id' 		 => $this->request->post['user_id'],
				'servicio_id' 	 => $this->request->post['servicio_id'],
				'cuota'  => $this->request->post['cuota'],
				'cuotas'  => $this->request->post['cuotas'],				
				'nota' 	 		 => $this->request->post['nota'],
				'customer_id' 	 => $customer_id,
				'pagado'		=> $pagado
			);		
			$this->model_rmadirsis_agenda->reservarAgenda($data);
			$this->session->data['success'] = $this->language->get('text_success');
			$error='';
		}
		echo $error;
	}
	
	public function dropear() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		$this->load->language('rmadirsis/agenda');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agenda');
		$data = array(
			'fecha_inicio'   => $this->request->post['fecha_inicio'],
			'fecha_fin'      => $this->request->post['fecha_fin'],
			'turno_id' => $this->request->post['turno_id']
		);		
		$this->model_rmadirsis_agenda->dropearAgenda($data);
		$this->session->data['success'] = $this->language->get('text_success');
	}
	
	public function cambiaservicio() {
		
		$this->load->language('rmadirsis/agenda');
		
		$this->load->model('rmadirsis/servicio');
		$servicio=$this->model_rmadirsis_servicio->getServicio($this->request->get['servicio_id']);
		
		$data = array(
			'turno_id'    => $this->request->get['turno_id'],
			'servicio_id' => $this->request->get['servicio_id'],
			'customer_id' => $this->request->get['customer_id'],
			'cuota' 	  => 1,
			'cuotas' 	  => $servicio['cuotas']
		);
		$this->load->model('rmadirsis/agenda');
		$sql=$this->model_rmadirsis_agenda->cambiaServicio($data);
		
		$this->session->data['success'] = $this->language->get('text_success');
	}
	
	public function validaragenda() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		$this->load->model('rmadirsis/agenda');
		if (isset($this->request->post['turno_id'])){
			$turno_id=$this->request->post['turno_id'];
		}else{
			$turno_id="";
		}
		$data = array(
			'fecha_inicio'   => $this->request->post['fecha_inicio'],
			'fecha_fin'      => $this->request->post['fecha_fin'],
			'profesional_id' => $this->request->post['profesional_id'],
			'turno_id' 		 => $turno_id
		);		
		$result=$this->model_rmadirsis_agenda->validarAgenda($data);
		echo $result;
	}
	public function agendar() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		$this->load->language('rmadirsis/agenda');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agenda');
		//VERIFICA SI SACA O PONE
		
		$data = array(
			'fecha_inicio'   => $this->request->post['fecha_inicio'],
			'fecha_fin'      => $this->request->post['fecha_fin'],
			'profesional_id' => $this->request->post['profesional_id'],
			'user_id' => $this->user->getId()
		);		
		$result=$this->model_rmadirsis_agenda->validarAgenda($data);
		if ($result==0){
			$this->model_rmadirsis_agenda->agendarAgenda($data);
			$this->session->data['success'] = $this->language->get('text_success');
		}
	}
	
	public function releeagenda(){
		$json = array();
		$filter_status="";
		/*
		if (isset($this->request->get['filter_status'])){
			$filter_status=$this->request->get['filter_status'];
		}
		*/
		$filter_profesional_id="";
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id=$this->request->get['filter_profesional_id'];
		}
		if (!empty($this->session->data['filter_profesional_id'])) {
			$filter_profesional_id=$this->session->data['filter_profesional_id'];
		}
		
		
		if (!empty($filter_profesional_id)) {
			$filter_data = array(
				'filter_profesional_id'    => $filter_profesional_id,
				'filter_status'         => $filter_status ,
				'start'                    => 1,
				'limit'                    => 1000
			);			
			$this->load->model('rmadirsis/agenda');
			
			//NO VENCE AGENDA X LORELEY
			if ($this->config->get('config_funciones_turnovencer')){
				$this->model_rmadirsis_agenda->actualizarAgenda();
			}
			
			if ($this->config->get('config_funciones_turnoagenda')){
				$results = $this->model_rmadirsis_agenda->getTurnoagendasxprofesional($filter_data);
			}else{
				$results = $this->model_rmadirsis_agenda->getTurnoagendasxarmado($filter_data);
			}
			foreach ($results as $result) {
				 $json[] = array(
				  'start'   => $result['fecha_inicio'],
				  'end'   => $result['fecha_fin'],
				  'color' => 'lightblue',
 				  'display' => 'background',
				  'extraParams' => array( 'status' => -1 ),
				 );
			}			

			//print_r($filter_data);
			
			$results = $this->model_rmadirsis_agenda->getAgendas($filter_data);
			foreach ($results as $result) {
				$color="green";
				$textcolor="white";
				if ($result['status']==1){
					if ($this->config->get('config_funciones_controlpagado')){
						if ($result['pagado']==0) { 
							$color="red"; 
							$textcolor="white";
						}
					}
					if ($this->config->get('config_funciones_controlconfirma')){
						if ($result['confirma']==0) { 
							$color="red"; 
							$textcolor="white";
						}
					}
				}
				if ($result['status']==3) { $color="orange"; $textcolor="black";}
				if ($result['status']==4) { $color="blue"; $textcolor="white";}
				if ($result['status']==5) { $color="grey"; $textcolor="white";}
				//if ($result['statusserv']==2) { $color="red"; $textcolor="white";}
				
				 $json[] = array(
				  'id'   => $result['turno_id'],
				  'title'   => $result['namecustomer'],
				  'start'   => $result['fecha_inicio'],
				  'end'   => $result['fecha_fin'],
				  'color' => $color,
				  'textColor' => $textcolor,
				  'extraParams' => array( 'status' => $result['status'] ),
				  'icon' => $result['notificado']>0 ? 'envelope' : ''
				 );
			}
			
			//				  'constraint' => 'availableForMeeting', //BLOQUEA EL ARRASTRE DE DIA
			
		}	
		 
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		//echo json_encode($json);
	}
	public function actualizarcustomer(){
		
		$json = array();
		//print_r($this->request->post);
		//die;
		$this->load->model('customer/customer');
		if ($this->request->post['customer_id']>0){
			$data = array(
				'lastname'  => $this->request->post['lastname'],
            	'firstname'  => $this->request->post['firstname'],
            	'telephone'  => $this->request->post['telephone'],
            	'email'  => $this->request->post['email'],
				'cuit'  => $this->request->post['cuit'],
				'address_1'  => $this->request->post['address_1'],
				'city'  => $this->request->post['city'],
				'zone_id'  => $this->request->post['zone_id'],
				'country_id'  => $this->request->post['country_id']
			);	
		//print_r($data);
		//die;
			$this->model_customer_customer->editCustomeragenda($this->request->post['customer_id'],$data);
			
			$data = array(
				'fechanac'  => $this->request->post['fechanac'],
				'hijos'  => $this->request->post['hijos'],
				'antecedentes'  => $this->request->post['antecedentes'],
				'medicacion'  => $this->request->post['medicacion'],
				'estadocivil_id'  => $this->request->post['estadocivil_id'],
				'actividad_id'  => $this->request->post['actividad_id'],
				'genero_id'  => $this->request->post['genero_id'],
				'obs'  => $this->request->post['obs'],
				'flia'  => $this->request->post['flia'],
				'vive_id'  => $this->request->post['vive_id'],
				'origen_id'  => $this->request->post['origen_id'],
				'customer_id' => $this->request->post['customer_id']
			);
			$this->model_customer_customer->editCustomeranexo($this->request->post['customer_id'],$data);
			
			
			$agenda_info=$this->model_customer_customer->getCustomer($this->request->post['customer_id']);
			$anexo=$this->model_customer_customer->getCustomeranexo($this->request->post['customer_id']);
			$nacimiento = new DateTime($anexo['fechanac']);
			$ahora = new DateTime(date("Y-m-d"));
			$diferencia = $ahora->diff($nacimiento);
			$edad = $diferencia->format("%y");

			$json = array(
				'customer_id' => $agenda_info['customer_id'],
				'firstname' => $agenda_info['firstname'],
				'lastname' => $agenda_info['lastname'],
				'cuit' => $agenda_info['cuit'],
				'email' => $agenda_info['email'],
				'telephone' => $agenda_info['telephone'],
				'hijos' => $anexo['hijos'],
				'fechanac' => date('d-m-Y',strtotime($anexo['fechanac'])),
				'edad' => $edad,
				'antecedentes' => $anexo['antecedentes'],
				'medicacion' => $anexo['medicacion'],
				'genero' => $anexo['genero'],
				'estadocivil' => $anexo['estadocivil'],
				'actividad' => $anexo['actividad']
			);			
		}	
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		//echo json_encode($json);		
	}
	
	public function cancelar() {
		if (isset($this->request->post['turno_id'])) {
			$this->load->model('rmadirsis/agenda');
			$this->model_rmadirsis_agenda->cancelarAgenda($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
		}
	}
	
	public function notificar() {
		if (isset($this->request->post['turno_id'])) {
			$this->load->model('rmadirsis/agenda');
			$this->model_rmadirsis_agenda->notificarAgenda($this->request->post['turno_id']);
			//$this->session->data['success'] = $this->language->get('text_success');
		}
	}	

	public function deletehistorial() {
		if (isset($this->request->post['historial_id'])) {
			$this->load->model('rmadirsis/agenda');
			$this->model_rmadirsis_agenda->deleteHistorial($this->request->post['historial_id']);
			$this->session->data['success'] = $this->language->get('text_success');
		}
	}
	
	protected function getList() {
		
	
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}

		if (isset($this->request->get['filter_periodo'])) {
			$filter_periodo = $this->request->get['filter_periodo'];
		} else {
			$filter_periodo = '2';
		}
		
		if (isset($this->request->get['filter_inicialview'])) {
			$filter_inicialview = $this->request->get['filter_inicialview'];
		} else {
			$filter_inicialview = 'timeGridWeek';
		}
		
		if (isset($this->request->get['filter_inicialdate'])) {
			$filter_inicialdate = date("Y-m-d",strtotime($this->request->get['filter_inicialdate']));
		} else {
			$filter_inicialdate = date("Y-m-d");
		}
		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}	
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_periodo'])) {
			$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
		}		
		if (isset($filter_inicialdate)) {
			$url .= '&filter_inicialdate=' . $filter_inicialdate;
		}		
		if (isset($filter_inicialview)) {
			$url .= '&filter_inicialview=' . $filter_inicialview;
		}		


		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/agenda', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('rmadirsis/agenda/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('rmadirsis/agenda/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/agenda/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		
		$this->load->model('rmadirsis/servicio');
		
		
		$this->load->model('rmadirsis/profesional');
		$profesional = $this->model_rmadirsis_profesional->getProfesionalByUser($this->user->getId());	
		//print_r($profesional);
		if (isset($profesional['user_id'])){
			$filter_profesional_id=$profesional['profesional_id'];
			$dataprofesional= array(
				'filter_profesional_id'    => $filter_profesional_id,	
			);
			$data['profesionals'] 	= $this->model_rmadirsis_profesional->getProfesionals($dataprofesional);			
			$data['servicios'] 		= $this->model_rmadirsis_servicio->getServiciodeprofesionales($filter_profesional_id);
			$this->session->data['filter_profesional_id']=$filter_profesional_id;		
		}else{
			$data['niveladmin']='1';
			$data['profesionals'] 	= $this->model_rmadirsis_profesional->getProfesionals();		
			//$data['servicios'] 		= $this->model_rmadirsis_servicio->getServicios();
			$data['servicios'] 		= $this->model_rmadirsis_servicio->getServiciodeprofesionales($filter_profesional_id);
			$this->session->data['filter_profesional_id']="";
		}
			
		/*
		$data['agendas'] = array();
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $filter_date_desde,
			'filter_periodo'        	=> $filter_periodo,
			'filter_date_hasta'        => $filter_date_desde,
			'filter_cancelado'        => '1',
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		$this->load->model('rmadirsis/agenda');
		//$agenda_total = $this->model_rmadirsis_agenda->getTotalAgendas($filter_data);
		$results = $this->model_rmadirsis_agenda->getAgendas($filter_data);
		
		foreach ($results as $result) {
			$data['agendas'][] = array(
				'turno_id'    	 => $result['turno_id'],
				'fecha_inicio'     => $result['fecha_inicio'],
				'fecha_fin'     => $result['fecha_fin'],
				'profesional_id' => $result['profesional_id'],
				'servicio_id' => $result['servicio_id'],
				'nameserv'		=> $result['nameserv'],
				'nameprof'       => $result['nameprof'],
				'namecustomer'		 => $result['namecustomer'],
				'dni'		 	=> $result['dni'],
				'status'         => $result['status'],
				'reservar'		 => $this->url->link('rmadirsis/agenda/reservar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'atender'        => $this->url->link('rmadirsis/agenda/atender', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'cerrar'        => $this->url->link('rmadirsis/agenda/cerrar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'recuperar'		 => $this->url->link('rmadirsis/agenda/recuperar', 'user_token=' . $this->session->data['user_token'] . '&turno_id='  . $result['turno_id'] . $url, true),
				'edit'           => $this->url->link('rmadirsis/agenda/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true)
			);
		}
		
		$filter_data = array(
			'filter_profesional_id'    => $filter_profesional_id
		);		
		$results = $this->model_rmadirsis_agenda->getTurnoagendas($filter_data);
		
		$data['turnoagendas'] = array();
		foreach ($results as $result) {
			$data['turnoagendas'][] = array(
				'fecha_inicio'     => $result['fecha_inicio'],
				'fecha_fin'     => $result['fecha_fin']
			);
		}		
		*/
		if (!empty($filter_profesional_id)){
			$data['releeagenda']='index.php?route=rmadirsis/agenda/releeagenda&user_token='.$this->session->data['user_token'] . $url;
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$data['filter_inicialview']= $filter_inicialview; 
		$data['filter_inicialdate']= $filter_inicialdate;
		$data['filter_name'] = $filter_name;
		$data['filter_profesional_id'] = $filter_profesional_id;
		$data['filter_servicio_id'] = $filter_servicio_id;
		$data['filter_status'] = $filter_status;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_periodo'] = $filter_periodo;
		$data['filter_date_hasta'] = $filter_date_desde;
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->load->model('customer/customer');
		$data['customers'] =$this->model_customer_customer->getCustomers();		

		$this->load->model('customer/estadocivil');
		$data['estadocivils'] =$this->model_customer_estadocivil->getEstadocivils();		

		$this->load->model('customer/genero');
		$data['generos'] =$this->model_customer_genero->getGeneros();		

		$this->load->model('customer/actividad');
		$data['actividads'] =$this->model_customer_actividad->getActividads();		
		
		
		

		if ($this->config->get('config_funciones_turnohistoria')){
			$data['atiende']=1;
			$data['marcaatendido']=0;
		}else{
			$data['atiende']=0;
			$data['marcaatendido']=1;
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$data['slotMinTime'] = "09:00";
		$data['slotMaxTime'] = "19:00";
		$data['slotDuration'] = "00:15:00";
		$data['user_id'] = $this->user->getId();
		
		if ($this->config->get('config_funciones_controlpagado')){
			$data['controlpagado']=1;
		}
		if ($this->config->get('config_funciones_controlconfirma')){		
			$data['controlconfirma']=1;
		}

		$this->response->setOutput($this->load->view('rmadirsis/agenda_list', $data));
	}

	protected function getForm() {

		error_reporting(E_ALL);
		ini_set('display_errors', '1');

		$data['text_form'] = !isset($this->request->get['turno_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['turno_id'])) {
			$data['turno_id'] = $this->request->get['turno_id'];
		} else {
			$data['turno_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['date_added'])) {
			$data['error_date_added'] = $this->error['date_added'];
		} else {
			$data['error_date_added'] = '';
		}
		
		if (isset($this->error['hora'])) {
			$data['error_hora'] = $this->error['hora'];
		} else {
			$data['error_hora'] = '';
		}
		
		if (isset($this->error['servicio_id'])) {
			$data['error_servicio_id'] = $this->error['servicio_id'];
		} else {
			$data['error_servicio_id'] = '';
		}		
		
		if (isset($this->error['profesional_id'])) {
			$data['error_profesional_id'] = $this->error['profesional_id'];
		} else {
			$data['error_profesional_id'] = '';
		}
		
		
		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}						
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['miturno'])) {
			$url .= '&miturno=' . $this->request->get['miturno'];
		}
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/agenda', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$data['action'] = $this->url->link('rmadirsis/agenda/atender', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $this->request->get['turno_id'] . $url, true);
		if (isset($this->request->get['miturno'])) {
			$data['cancel'] = $this->url->link('rmadirsis/miturno', 'user_token=' . $this->session->data['user_token'] . $url, true);
		}else{
			$data['cancel'] = $this->url->link('rmadirsis/agenda', 'user_token=' . $this->session->data['user_token'] . $url, true);
		}
		$agenda_info=array();
		
		
		$this->load->model('customer/customer');
		$this->load->model('customer/genero');
		$this->load->model('customer/estadocivil');
		$this->load->model('customer/actividad');
		
		if (isset($this->request->get['turno_id'])){
			$agenda_info = $this->model_rmadirsis_agenda->getAgenda($this->request->get['turno_id']);
			if ($agenda_info){
				$data['fecha_inicio'] = date( "d-m-Y H:i", strtotime( $agenda_info['fecha_inicio']));
				$data['fecha_fin'] = date( "d-m-Y H:i", strtotime( $agenda_info['fecha_fin']));
				$data['profesional_id'] = $agenda_info['profesional_id'];
				$data['servicio_id'] = $agenda_info['servicio_id'];
				$data['nameserv'] = $agenda_info['nameserv'];
				$data['customer_id'] = $agenda_info['customer_id'];
				$data['nameprof'] = $agenda_info['nameprof'];
				$data['namecustomer'] = $agenda_info['namecustomer'];
				$data['firstname'] = $agenda_info['firstname'];
				$data['lastname'] = $agenda_info['lastname'];
				$data['cuit'] = $agenda_info['cuit'];
				$data['email'] = $agenda_info['email'];
				$data['telephone'] = $agenda_info['telephone'];
				$data['status'] = $agenda_info['status'];
				$data['cancelado'] = $agenda_info['cancelado'];
				$data['nota'] = $agenda_info['nota'];
				$data['turno_user_id'] = $agenda_info['user_id'];
				$data['atenc_user_id'] = $this->user->getId();
				$anexo=$this->model_customer_customer->getCustomeranexo($agenda_info['customer_id']);
				
				$this->load->model('localisation/country');
				$data['countries'] = $this->model_localisation_country->getCountries();				
				
				$data['city']='Cordoba';
				$data['zone_id']=160;
				$data['zone']='Cordoba';
				$data['country_id']=10;
				$data['country']="Argentina";
				
				if ($agenda_info['address_id']){
					$address_info=$this->model_customer_customer->getAddress($agenda_info['address_id']);
					if ($address_info){
						$data['address_1']=$address_info['address_1'];
						$data['city']=$address_info['city'];
						$data['zone_id']=$address_info['zone_id'];
						$data['zone']=$address_info['zone'];
						$data['country_id']=$address_info['country_id'];
						$data['country']=$address_info['country'];
					}
				}
				
				
 				$nacimiento = new DateTime($anexo['fechanac']);
    			$ahora = new DateTime(date("Y-m-d"));
    			$diferencia = $ahora->diff($nacimiento);
    			$edad = $diferencia->format("%y");
				
				$data['anexo'] = array (
					"hijos" => $anexo['hijos'],
					"fechanac" => date("d-m-Y",strtotime($anexo['fechanac'])),
					"edad" => $edad,
					"antecedentes" => $anexo['antecedentes'],
					"medicacion" => $anexo['medicacion'],
					"obs" => $anexo['obs'],
					"flia" => $anexo['flia'],
					"vive_id" => $anexo['vive_id'],
					"origen_id" => $anexo['origen_id'],
					"medicacion" => $anexo['medicacion'],
					"genero" => $this->model_customer_genero->getGeneroname($anexo['genero_id']),
					"estadocivil" => $this->model_customer_estadocivil->getEstadocivilname($anexo['estadocivil_id']),
					"actividad" => $this->model_customer_actividad->getActividadname($anexo['actividad_id']),
					"estadocivil_id" => $anexo['estadocivil_id'],
					"actividad_id" => $anexo['actividad_id'],
				);
				
				$this->load->model('customer/estadocivil');
				$data['estadocivils'] =$this->model_customer_estadocivil->getEstadocivils();		

				$this->load->model('customer/genero');
				$data['generos'] =$this->model_customer_genero->getGeneros();		

				$this->load->model('customer/actividad');
				$data['actividads'] =$this->model_customer_actividad->getActividads();	

				$this->load->model('customer/medicacion');
				$data['medicacions'] =$this->model_customer_medicacion->getMedicacions();	

				$this->load->model('customer/origen');
				$data['origens'] =$this->model_customer_origen->getOrigens();	

				$this->load->model('customer/vive');
				$data['vives'] =$this->model_customer_vive->getVives();					
				
				$data['address'] = $this->model_customer_customer->getAddresses($agenda_info['customer_id']);
				
				$results = $this->model_rmadirsis_agenda->getHistorials($agenda_info['customer_id']);
				
				$data['historials']= array();
				foreach ($results as $result) {
					$data['historials'][] = array(
						"fecha_registro" => date("d/m/Y h:i",strtotime($result['fecha_registro'])),
						"fecha_registro2" => date("Y-m-d h:i",strtotime($result['fecha_registro'])),
						"fecha" => date("d/m/Y",strtotime($result['fecha'])),
						"historial_id" => $result['historial_id'],
						"customer_id" => $result['customer_id'],
						"servicio_id" => $result['servicio_id'],
						"profesional_id" => $result['profesional_id'],
						"nameprof" => $result['nameprof'],
						"namecustomer" => $result['namecustomer'],
						"nameserv" => $result['nameserv'],
						"pesoactual" => $result['pesoactual'],
						"pesoactual2" => (int)$result['pesoactual'],
						"objetivo" => $result['objetivo'],
						"avance" => $result['avance'],
						"actifisica" => $result['actifisica'],
						"man" => $result['man'],
						"h20" => $result['h20'],
						"add1" => $result['add1'],
						"lax" => $result['lax'],
						"mie" => $result['mie'],
						"diu" => $result['diu'],
						"mvm" => $result['mvm'],
						"frl" => $result['frl'],
						"rdp" => $result['rdp'],
						"frt" => $result['frt'],
						"rsp" => $result['rsp'],
						"delete" => $this->url->link('rmadirsis/agenda/deleteHistoria', 'user_token=' . $this->session->data['user_token'] . $url."&historial_id=".$result['historial_id'], true)
					);
				}
				
				//estadisticas
				$data['controles'] 		= $this->model_rmadirsis_agenda->getHistorialcantidad($agenda_info['customer_id']);
				$result 	= $this->model_rmadirsis_agenda->getHistorialpesoinicial($agenda_info['customer_id']);
				$data['pesoinicial'] = $result['peso'];
				$data['fechapesoinicial'] = $result['fecha'];
				
				
				$result 	= $this->model_rmadirsis_agenda->getHistorialpesoactual($agenda_info['customer_id']);
				$data['pesoactual'] 	= $result['peso'];
				$data['fechapesoactual'] = $result['fecha'];
				
				
				$data['pesoobjetivo'] 	= $this->model_rmadirsis_agenda->getHistorialpesoobjetivo($agenda_info['customer_id']);
				$data['talla'] 			= $this->model_rmadirsis_agenda->getHistorialtalla($agenda_info['customer_id']);
				
				$data['objetivo'] 	= $data['pesoinicial'] - $data['pesoobjetivo'];
				$data['pendiente'] 	= $data['pesoactual'] - $data['pesoobjetivo'];
				$data['avance'] 	= $data['pesoinicial'] - $data['pesoactual'];
				
				if ($data['talla']!=0){
					$data['imc'] 	= round($data['pesoactual'] / ($data['talla']*$data['talla']),2);
					
					if ($data['imc']<18.5) {
						$data['valoracion']='Bajo';
					}elseif ($data['imc']<24.9) {
						$data['valoracion']='Normal';
					}elseif ($data['imc']<29.9) {
						$data['valoracion']='Sobrepeso';
					}elseif ($data['imc']<34.9) {
						$data['valoracion']='Obeso Nivel I';
					}elseif ($data['imc']<39.9) {
						$data['valoracion']='Obeso Nivel II';
					}else{	
						$data['valoracion']='Obeso Nivel III';
					}
				}
				
				$data['dias'] 	= $this->model_rmadirsis_agenda->getHistorialdias($agenda_info['customer_id']);
				
				
				
				
				$data['image'] = '';
				$this->load->model('tool/image');
				$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
				$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
				$data['agenda_images'] = array();
				
			}
		}
		
		$data['raiz'] = HTTPS_CATALOG;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$data['datosedit'] = 1;
		$data['hc'] 		= $this->load->view('rmadirsis/historial_hc', $data);
		$data['datos'] 		= $this->load->view('rmadirsis/historial_datos', $data);
		$data['edicion'] 	= $this->load->view('rmadirsis/historial_edicion', $data);		
		$data['tipo']=1;
		if ($data['dias']!=0){
			$data['tipo']=2;
			if ($anexo['servicio_id']==0){
				$data['tipo']=3;
			}
		}
		//$data['tipo']=3;
		$this->response->setOutput($this->load->view('rmadirsis/agenda_form', $data));
	}
	
	
	
	public function historial() {
		error_reporting(E_ALL);
		ini_set('display_errors', '1');	
		$this->load->language('rmadirsis/historial');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->getHistorial();
		
	}	
	protected function getHistorial() {

		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['date_added'])) {
			$data['error_date_added'] = $this->error['date_added'];
		} else {
			$data['error_date_added'] = '';
		}
		if (isset($this->error['hora'])) {
			$data['error_hora'] = $this->error['hora'];
		} else {
			$data['error_hora'] = '';
		}
		if (isset($this->error['servicio_id'])) {
			$data['error_servicio_id'] = $this->error['servicio_id'];
		} else {
			$data['error_servicio_id'] = '';
		}		
		
		if (isset($this->error['profesional_id'])) {
			$data['error_profesional_id'] = $this->error['profesional_id'];
		} else {
			$data['error_profesional_id'] = '';
		}
		$url = '';
		
		if (isset($this->request->get['customer_id'])) {
			$url .= '&customer_id=' . $this->request->get['customer_id'];
		}				
		$customer_id=$this->request->get['customer_id'];
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/agenda/historial', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$this->load->model('customer/customer');
		$this->load->model('customer/genero');
		$this->load->model('customer/estadocivil');
		$this->load->model('customer/actividad');
		$agenda_info=$this->model_customer_customer->getCustomer($customer_id);
		if ($agenda_info){
			$data['customer_id'] = $agenda_info['customer_id'];
			$data['namecustomer'] = $agenda_info['firstname'].",".$agenda_info['lastname'];
			$data['firstname'] = $agenda_info['firstname'];
			$data['lastname'] = $agenda_info['lastname'];
			$data['cuit'] = $agenda_info['cuit'];
			$data['email'] = $agenda_info['email'];
			$data['telephone'] = $agenda_info['telephone'];
			$anexo=$this->model_customer_customer->getCustomeranexo($customer_id);
			$this->load->model('localisation/country');
			$data['countries'] = $this->model_localisation_country->getCountries();				
			$data['city']='Cordoba';
			$data['zone_id']=160;
			$data['zone']='Cordoba';
			$data['country_id']=10;
			$data['country']="Argentina";
			if ($agenda_info['address_id']){
				$address_info=$this->model_customer_customer->getAddress($agenda_info['address_id']);
				if ($address_info){
					$data['address_1']=$address_info['address_1'];
					$data['city']=$address_info['city'];
					$data['zone_id']=$address_info['zone_id'];
					$data['zone']=$address_info['zone'];
					$data['country_id']=$address_info['country_id'];
					$data['country']=$address_info['country'];
				}
			}
			$nacimiento = new DateTime($anexo['fechanac']);
   			$ahora = new DateTime(date("Y-m-d"));
   			$diferencia = $ahora->diff($nacimiento);
   			$edad = $diferencia->format("%y");
			$data['anexo'] = array (
				"hijos" => $anexo['hijos'],
				"fechanac" => date("d-m-Y",strtotime($anexo['fechanac'])),
				"edad" => $edad,
				"antecedentes" => $anexo['antecedentes'],
				"medicacion" => $anexo['medicacion'],
				"obs" => $anexo['obs'],
				"flia" => $anexo['flia'],
				"vive_id" => $anexo['vive_id'],
				"origen_id" => $anexo['origen_id'],
				"medicacion" => $anexo['medicacion'],
				"genero" => $this->model_customer_genero->getGeneroname($anexo['genero_id']),
				"estadocivil" => $this->model_customer_estadocivil->getEstadocivilname($anexo['estadocivil_id']),
				"actividad" => $this->model_customer_actividad->getActividadname($anexo['actividad_id']),
				"estadocivil_id" => $anexo['estadocivil_id'],
				"actividad_id" => $anexo['actividad_id'],
			);
			$this->load->model('customer/estadocivil');
			$data['estadocivils'] =$this->model_customer_estadocivil->getEstadocivils();		

			$this->load->model('customer/genero');
			$data['generos'] =$this->model_customer_genero->getGeneros();		

			$this->load->model('customer/actividad');
			$data['actividads'] =$this->model_customer_actividad->getActividads();	

			$this->load->model('customer/medicacion');
			$data['medicacions'] =$this->model_customer_medicacion->getMedicacions();	

			$this->load->model('customer/origen');
			$data['origens'] =$this->model_customer_origen->getOrigens();	

			$this->load->model('customer/vive');
			$data['vives'] =$this->model_customer_vive->getVives();					
				
			$data['address'] = $this->model_customer_customer->getAddresses($agenda_info['customer_id']);
			
			$this->load->model('rmadirsis/agenda');
			$results = $this->model_rmadirsis_agenda->getHistorials($agenda_info['customer_id']);
				
			$data['historials']= array();
			foreach ($results as $result) {
				$data['historials'][] = array(
					"fecha_registro" => date("d/m/Y h:i",strtotime($result['fecha_registro'])),
					"fecha_registro2" => date("Y-m-d h:i",strtotime($result['fecha_registro'])),
					"fecha" => date("d/m/Y",strtotime($result['fecha'])),
					"historial_id" => $result['historial_id'],
					"customer_id" => $result['customer_id'],
					"servicio_id" => $result['servicio_id'],
					"profesional_id" => $result['profesional_id'],
					"nameprof" => $result['nameprof'],
					"namecustomer" => $result['namecustomer'],
					"nameserv" => $result['nameserv'],
					"pesoactual" => $result['pesoactual'],
					"pesoactual2" => (int)$result['pesoactual'],
					"objetivo" => $result['objetivo'],
					"avance" => $result['avance'],
					"actifisica" => $result['actifisica'],
					"man" => $result['man'],
					"h20" => $result['h20'],
					"add1" => $result['add1'],
					"lax" => $result['lax'],
					"mie" => $result['mie'],
					"diu" => $result['diu'],
					"mvm" => $result['mvm'],
					"frl" => $result['frl'],
					"rdp" => $result['rdp'],
					"frt" => $result['frt'],
					"rsp" => $result['rsp'],
					"delete" => $this->url->link('rmadirsis/agenda/deleteHistoria', 'user_token=' . $this->session->data['user_token'] . $url."&historial_id=".$result['historial_id'], true)
				);
			}
				
			//estadisticas
			$data['controles'] 		= $this->model_rmadirsis_agenda->getHistorialcantidad($agenda_info['customer_id']);
			$result 	= $this->model_rmadirsis_agenda->getHistorialpesoinicial($agenda_info['customer_id']);
			$data['pesoinicial'] = $result['peso'];
			$data['fechapesoinicial'] = $result['fecha'];
				
				
			$result 	= $this->model_rmadirsis_agenda->getHistorialpesoactual($agenda_info['customer_id']);
			$data['pesoactual'] 	= $result['peso'];
			$data['fechapesoactual'] = $result['fecha'];
				
				
			$data['pesoobjetivo'] 	= $this->model_rmadirsis_agenda->getHistorialpesoobjetivo($agenda_info['customer_id']);
			$data['talla'] 			= $this->model_rmadirsis_agenda->getHistorialtalla($agenda_info['customer_id']);

			$data['objetivo'] 	= $data['pesoinicial'] - $data['pesoobjetivo'];
			$data['pendiente'] 	= $data['pesoactual'] - $data['pesoobjetivo'];
			$data['avance'] 	= $data['pesoinicial'] - $data['pesoactual'];
				
			if ($data['talla']!=0){
				$data['imc'] 	= round($data['pesoactual'] / ($data['talla']*$data['talla']),2);

				if ($data['imc']<18.5) {
					$data['valoracion']='Bajo';
				}elseif ($data['imc']<24.9) {
					$data['valoracion']='Normal';
				}elseif ($data['imc']<29.9) {
					$data['valoracion']='Sobrepeso';
				}elseif ($data['imc']<34.9) {
					$data['valoracion']='Obeso Nivel I';
				}elseif ($data['imc']<39.9) {
					$data['valoracion']='Obeso Nivel II';
				}else{	
					$data['valoracion']='Obeso Nivel III';
				}
			}
				
			$data['dias'] 	= $this->model_rmadirsis_agenda->getHistorialdias($agenda_info['customer_id']);


			$data['image'] = '';
			$this->load->model('tool/image');
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['agenda_images'] = array();
				
		}
		
		$data['raiz'] = HTTPS_CATALOG;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$data['hc'] 		= $this->load->view('rmadirsis/historial_hc', $data);
		$data['datos'] 		= $this->load->view('rmadirsis/historial_datos', $data);
		$data['edicion'] 	= $this->load->view('rmadirsis/historial_edicion', $data);
		
		$this->response->setOutput($this->load->view('rmadirsis/historial_form', $data));
	}
	
	
	

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/agenda')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		/*
		if ($this->request->post['hora'] < 1) {
			$this->error['hora'] = $this->language->get('error_hora');
		}
		*/
		
		if ($this->request->post['servicio_id']<0) {
			$this->error['servicio_id'] = $this->language->get('error_servicio_id');
		}		

		return !$this->error;
	}
	
	
	
	public function addmedicacion() {
		if (isset($this->request->get['name'])) {
			$this->load->model('customer/medicacion');
			$this->model_customer_medicacion->addMedicacion($this->request->get['name']);
		}
		
		$this->load->model('customer/medicacion');
		$results = $this->model_customer_medicacion->getMedicacions();			
		foreach ($results as $result) {
			$json[] = array(
					'name'       => $result['name']
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}
		array_multisort($sort_order, SORT_ASC, $json);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
	public function addactividad() {
		if (isset($this->request->get['name'])) {
			$this->load->model('customer/actividad');
			$this->model_customer_actividad->addActividad($this->request->get['name']);
		}
		
		$this->load->model('customer/actividad');
		$results = $this->model_customer_actividad->getActividads();			
		foreach ($results as $result) {
			$json[] = array(
					'name'       => $result['name']
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}
		array_multisort($sort_order, SORT_ASC, $json);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	public function addorigen() {
		if (isset($this->request->get['name'])) {
			$this->load->model('customer/origen');
			$this->model_customer_origen->addOrigen($this->request->get['name']);
		}
		
		$this->load->model('customer/origen');
		$results = $this->model_customer_origen->getOrigens();			
		foreach ($results as $result) {
			$json[] = array(
					'name'       => $result['name']
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}
		array_multisort($sort_order, SORT_ASC, $json);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
	public function addvive() {
		if (isset($this->request->get['name'])) {
			$this->load->model('customer/vive');
			$this->model_customer_vive->addVive($this->request->get['name']);
		}
		
		$this->load->model('customer/vive');
		$results = $this->model_customer_vive->getVives();			
		foreach ($results as $result) {
			$json[] = array(
					'name'       => $result['name']
			);
		}
		$sort_order = array();
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}
		array_multisort($sort_order, SORT_ASC, $json);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
}
