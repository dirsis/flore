<?php
class ControllerRmadirsisProfesional extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('rmadirsis/profesional');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/profesional');

		$this->getList();
	}

	public function add() {
		$this->load->language('rmadirsis/profesional');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/profesional');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_rmadirsis_profesional->addProfesional($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}
/*
			if (isset($this->request->get['filter_profesional_group_id'])) {
				$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
			}
*/
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}


			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('rmadirsis/profesional');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/profesional');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			$this->model_rmadirsis_profesional->editProfesional($this->request->get['profesional_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}
/*
			if (isset($this->request->get['filter_profesional_group_id'])) {
				$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
			}
*/
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('rmadirsis/profesional');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/profesional');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $profesional_id) {
				$this->model_rmadirsis_profesional->deleteProfesional($profesional_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}
/*
			if (isset($this->request->get['filter_profesional_group_id'])) {
				$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
			}
*/
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}
/*
		if (isset($this->request->get['filter_profesional_group_id'])) {
			$filter_profesional_group_id = $this->request->get['filter_profesional_group_id'];
		} else {
			$filter_profesional_group_id = '';
		}
*/
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}
/*
		if (isset($this->request->get['filter_profesional_group_id'])) {
			$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
		}
*/
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('rmadirsis/profesional/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/profesional/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->load->model('setting/store');

		$stores = $this->model_setting_store->getStores();
		
		$data['profesionals'] = array();

		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);

		$profesional_total = $this->model_rmadirsis_profesional->getTotalProfesionals($filter_data);

		$results = $this->model_rmadirsis_profesional->getProfesionals($filter_data);

		foreach ($results as $result) {
			$store_data = array();
			$store_data[] = array(
				'name' => $this->config->get('config_name'),
				'href' => $this->url->link('rmadirsis/profesional/login', 'user_token=' . $this->session->data['user_token'] . '&profesional_id=' . $result['profesional_id'] . '&store_id=0', true)
			);
			foreach ($stores as $store) {
				$store_data[] = array(
					'name' => $store['name'],
					'href' => $this->url->link('rmadirsis/profesional/login', 'user_token=' . $this->session->data['user_token'] . '&profesional_id=' . $result['profesional_id'] . '&store_id=' . $result['store_id'], true)
				);
			}
			$data['profesionals'][] = array(
				'profesional_id'    => $result['profesional_id'],
				'name'           => $result['name'],
				'email'          => $result['email'],
				'telephone'          => $result['telephone'],
				'status'         => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'store'          => $store_data,
				'edit'           => $this->url->link('rmadirsis/profesional/edit', 'user_token=' . $this->session->data['user_token'] . '&profesional_id=' . $result['profesional_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}
/*
		if (isset($this->request->get['filter_profesional_group_id'])) {
			$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
		}
*/
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_email'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_telephone'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . '&sort=c.telephone' . $url, true);		
		$data['sort_status'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		$data['sort_date_added'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . '&sort=c.date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}
/*
		if (isset($this->request->get['filter_profesional_group_id'])) {
			$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
		}
*/
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $profesional_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($profesional_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($profesional_total - $this->config->get('config_limit_admin'))) ? $profesional_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $profesional_total, ceil($profesional_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_email'] = $filter_email;
		//$data['filter_profesional_group_id'] = $filter_profesional_group_id;
		$data['filter_status'] = $filter_status;
		$data['filter_date_added'] = $filter_date_added;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('rmadirsis/profesional_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['profesional_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['profesional_id'])) {
			$data['profesional_id'] = $this->request->get['profesional_id'];
		} else {
			$data['profesional_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['firstname'])) {
			$data['error_firstname'] = $this->error['firstname'];
		} else {
			$data['error_firstname'] = '';
		}

		if (isset($this->error['lastname'])) {
			$data['error_lastname'] = $this->error['lastname'];
		} else {
			$data['error_lastname'] = '';
		}

		if (isset($this->error['email'])) {
			$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}
		
		if (isset($this->error['www'])) {
			$data['error_www'] = $this->error['www'];
		} else {
			$data['error_www'] = '';
		}		

		if (isset($this->error['telephone'])) {
			$data['error_telephone'] = $this->error['telephone'];
		} else {
			$data['error_telephone'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}
/*
		if (isset($this->request->get['filter_profesional_group_id'])) {
			$url .= '&filter_profesional_group_id=' . $this->request->get['filter_profesional_group_id'];
		}
*/
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['profesional_id'])) {
			$data['action'] = $this->url->link('rmadirsis/profesional/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('rmadirsis/profesional/edit', 'user_token=' . $this->session->data['user_token'] . '&profesional_id=' . $this->request->get['profesional_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('rmadirsis/profesional', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['profesional_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$profesional_info = $this->model_rmadirsis_profesional->getProfesional($this->request->get['profesional_id']);
		}
		
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] = array();
		$filter_data = array(
			'filter_status'              => '1',
			'sort' => 'name',
			'order' => 'DESC',
			'start' => 0,
			'limit' => 100
		);
		
		$results = $this->model_rmadirsis_servicio->getServicios($filter_data);
		
		
		foreach ($results as $result) {
			if ($result['status']=='1') $status=$this->language->get('text_enabled');
			if ($result['status']=='0') $status=$this->language->get('text_disabled');
			if ($result['status']=='2') $status=$this->language->get('text_deleted');
			$data['servicios'][] = array(
				'servicio_id'    => $result['servicio_id'],
				'name'   	=> $result['name'],
				'status'     => $this->model_rmadirsis_servicio->getServicio_por_profesional($result['servicio_id'],$data['profesional_id'])
			);
		}

		if (isset($this->request->post['firstname'])) {
			$data['firstname'] = $this->request->post['firstname'];
		} elseif (!empty($profesional_info)) {
			$data['firstname'] = $profesional_info['firstname'];
		} else {
			$data['firstname'] = '';
		}

		if (isset($this->request->post['lastname'])) {
			$data['lastname'] = $this->request->post['lastname'];
		} elseif (!empty($profesional_info)) {
			$data['lastname'] = $profesional_info['lastname'];
		} else {
			$data['lastname'] = '';
		}

		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} elseif (!empty($profesional_info)) {
			$data['email'] = $profesional_info['email'];
		} else {
			$data['email'] = '';
		}
		
		if (isset($this->request->post['www'])) {
			$data['www'] = $this->request->post['www'];
		} elseif (!empty($profesional_info)) {
			$data['www'] = $profesional_info['www'];
		} else {
			$data['www'] = '';
		}		

		if (isset($this->request->post['telephone'])) {
			$data['telephone'] = $this->request->post['telephone'];
		} elseif (!empty($profesional_info)) {
			$data['telephone'] = $profesional_info['telephone'];
		} else {
			$data['telephone'] = '';
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($profesional_info)) {
			$data['status'] = $profesional_info['status'];
		} else {
			$data['status'] = true;
		}
		
		if (isset($this->request->post['user_id'])) {
			$data['user_id'] = $this->request->post['user_id'];
		} elseif (!empty($profesional_info)) {
			$data['user_id'] = $profesional_info['user_id'];
		} else {
			$data['user_id'] = '';
		}		

		$this->load->model('localisation/country');
		$data['countries'] = $this->model_localisation_country->getCountries();
		
		if (isset($this->request->post['address_1'])) {
			$data['address_1'] = $this->request->post['address_1'];
		} elseif (!empty($profesional_info)) {
			$data['address_1'] = $profesional_info['address_1'];
		} else {
			$data['address_1'] = '';
		}
		
		if (isset($this->request->post['city'])) {
			$data['city'] = $this->request->post['city'];
		} elseif (!empty($profesional_info)) {
			$data['city'] = $profesional_info['city'];
		} else {
			$data['city'] = '';
		}
		
		if (isset($this->request->post['postcode'])) {
			$data['postcode'] = $this->request->post['postcode'];
		} elseif (!empty($profesional_info)) {
			$data['postcode'] = $profesional_info['postcode'];
		} else {
			$data['postcode'] = '';
		}
		
		if (isset($this->request->post['country_id'])) {
			$data['country_id'] = $this->request->post['country_id'];
		} elseif (!empty($profesional_info)) {
			$data['country_id'] = $profesional_info['country_id'];
		} else {
			$data['country_id'] = '10';
		}		
		
		if (isset($this->request->post['zone_id'])) {
			$data['zone_id'] = $this->request->post['zone_id'];
		} elseif (!empty($profesional_info)) {
			$data['zone_id'] = $profesional_info['zone_id'];
		} else {
			$data['zone_id'] = '160';
		}	
		
		if (isset($this->request->post['lun_status'])) {
			$data['lun_status'] = $this->request->post['lun_status'];
		} elseif (!empty($profesional_info)) {
			$data['lun_status'] = $profesional_info['lun_status'];
		} else {
			$data['lun_status'] = '1';
		}		
		
		if (isset($this->request->post['mar_status'])) {
			$data['mar_status'] = $this->request->post['mar_status'];
		} elseif (!empty($profesional_info)) {
			$data['mar_status'] = $profesional_info['mar_status'];
		} else {
			$data['mar_status'] = '1';
		}		

		if (isset($this->request->post['mie_status'])) {
			$data['mie_status'] = $this->request->post['mie_status'];
		} elseif (!empty($profesional_info)) {
			$data['mie_status'] = $profesional_info['mie_status'];
		} else {
			$data['mie_status'] = '1';
		}		

		if (isset($this->request->post['jue_status'])) {
			$data['jue_status'] = $this->request->post['jue_status'];
		} elseif (!empty($profesional_info)) {
			$data['jue_status'] = $profesional_info['jue_status'];
		} else {
			$data['jue_status'] = '1';
		}		
		if (isset($this->request->post['vie_status'])) {
			$data['vie_status'] = $this->request->post['vie_status'];
		} elseif (!empty($profesional_info)) {
			$data['vie_status'] = $profesional_info['vie_status'];
		} else {
			$data['vie_status'] = '1';
		}		
		
		if (isset($this->request->post['lun_ini'])) {
			$data['lun_ini'] = $this->request->post['lun_ini'];
		} elseif (!empty($profesional_info)) {
			$data['lun_ini'] = $profesional_info['lun_ini'];
		} else {
			$data['lun_ini'] = '09:00';
		}
		if (isset($this->request->post['mar_ini'])) {
			$data['mar_ini'] = $this->request->post['mar_ini'];
		} elseif (!empty($profesional_info)) {
			$data['mar_ini'] = $profesional_info['mar_ini'];
		} else {
			$data['mar_ini'] = '09:00';
		}
		if (isset($this->request->post['mie_ini'])) {
			$data['mie_ini'] = $this->request->post['mie_ini'];
		} elseif (!empty($profesional_info)) {
			$data['mie_ini'] = $profesional_info['mie_ini'];
		} else {
			$data['mie_ini'] = '09:00';
		}
		if (isset($this->request->post['jue_ini'])) {
			$data['jue_ini'] = $this->request->post['jue_ini'];
		} elseif (!empty($profesional_info)) {
			$data['jue_ini'] = $profesional_info['jue_ini'];
		} else {
			$data['jue_ini'] = '09:00';
		}
		if (isset($this->request->post['vie_ini'])) {
			$data['vie_ini'] = $this->request->post['vie_ini'];
		} elseif (!empty($profesional_info)) {
			$data['vie_ini'] = $profesional_info['vie_ini'];
		} else {
			$data['vie_ini'] = '09:00';
		}
		
		
		if (isset($this->request->post['lun_fin'])) {
			$data['lun_fin'] = $this->request->post['lun_fin'];
		} elseif (!empty($profesional_info)) {
			$data['lun_fin'] = $profesional_info['lun_fin'];
		} else {
			$data['lun_fin'] = '09:00';
		}
		if (isset($this->request->post['mar_fin'])) {
			$data['mar_fin'] = $this->request->post['mar_fin'];
		} elseif (!empty($profesional_info)) {
			$data['mar_fin'] = $profesional_info['mar_fin'];
		} else {
			$data['mar_fin'] = '09:00';
		}
		if (isset($this->request->post['mie_fin'])) {
			$data['mie_fin'] = $this->request->post['mie_fin'];
		} elseif (!empty($profesional_info)) {
			$data['mie_fin'] = $profesional_info['mie_fin'];
		} else {
			$data['mie_fin'] = '09:00';
		}
		if (isset($this->request->post['jue_fin'])) {
			$data['jue_fin'] = $this->request->post['jue_fin'];
		} elseif (!empty($profesional_info)) {
			$data['jue_fin'] = $profesional_info['jue_fin'];
		} else {
			$data['jue_fin'] = '09:00';
		}
		if (isset($this->request->post['vie_fin'])) {
			$data['vie_fin'] = $this->request->post['vie_fin'];
		} elseif (!empty($profesional_info)) {
			$data['vie_fin'] = $profesional_info['vie_fin'];
		} else {
			$data['vie_fin'] = '09:00';
		}
		
		$this->load->model('user/user');
		$data['users'] = $this->model_user_user->getUsers();		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('rmadirsis/profesional_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/profesional')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['firstname']) < 1) || (utf8_strlen(trim($this->request->post['firstname'])) > 32)) {
			$this->error['firstname'] = $this->language->get('error_firstname');
		}

		if ((utf8_strlen($this->request->post['lastname']) < 1) || (utf8_strlen(trim($this->request->post['lastname'])) > 32)) {
			$this->error['lastname'] = $this->language->get('error_lastname');
		}

		if ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			$this->error['email'] = $this->language->get('error_email');
		}

		if ((utf8_strlen($this->request->post['telephone']) < 3) || (utf8_strlen($this->request->post['telephone']) > 32)) {
			$this->error['telephone'] = $this->language->get('error_telephone');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		/*
		print_r($this->error);
		die;
		*/

		return !$this->error;
	}
	

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'rmadirsis/profesional')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_email'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			if (isset($this->request->get['filter_email'])) {
				$filter_email = $this->request->get['filter_email'];
			} else {
				$filter_email = '';
			}
			
			$this->load->model('rmadirsis/profesional');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'filter_email'     => $filter_email,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_rmadirsis_profesional->getProfesionals($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'profesional_id'       => $result['profesional_id'],
					'name'              => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'firstname'         => $result['firstname'],
					'lastname'          => $result['lastname'],
					'email'             => $result['email'],
					'telephone'         => $result['telephone'],
					'www'         => $result['www'],
					'address'           => $this->model_rmadirsis_profesional->getAddresses($result['profesional_id'])
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	

}