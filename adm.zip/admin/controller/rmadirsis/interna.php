<?php
class ControllerRmadirsisInterna extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('rmadirsis/interna');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/interna');

		$this->getList();
	}

	public function add() {
		
		$this->load->language('rmadirsis/interna');
		$this->document->setTitle($this->language->get('heading_title'));		
		$this->load->model('rmadirsis/interna');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_rmadirsis_interna->addInterna($this->request->post);

			$this->session->data['success']  = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->post['evento_id'])) {
				$url .= '&evento_id=' . $this->request->post['evento_id'];
			}
			$this->response->redirect($this->url->link('rmadirsis/interna/add', 'user_token=' . $this->session->data['user_token'] . $url, true));
/*			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_paciente_id'])) {
				$filter_paciente_id = $this->request->get['filter_paciente_id'];
			} else {
				$filter_paciente_id = '';
			}		
			if (isset($this->request->get['filter_paciente'])) {
				$filter_paciente = $this->request->get['filter_paciente'];
			} else {
				$filter_paciente = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}			

			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente'])) {
				$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente_id'])) {
				$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			

			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url, true));
*/			
		}

		$this->getForm();
	}
/*
	public function edit() {
		$this->load->language('rmadirsis/interna');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/interna');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_rmadirsis_interna->editInterna($this->request->get['interna_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_paciente_id'])) {
				$filter_paciente_id = $this->request->get['filter_paciente_id'];
			} else {
				$filter_paciente_id = '';
			}		
			if (isset($this->request->get['filter_paciente'])) {
				$filter_paciente = $this->request->get['filter_paciente'];
			} else {
				$filter_paciente = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}			

			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente'])) {
				$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente_id'])) {
				$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('rmadirsis/interna');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/interna');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $interna_id) {
				$this->model_rmadirsis_interna->deleteInterna($interna_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			
			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_paciente_id'])) {
				$filter_paciente_id = $this->request->get['filter_paciente_id'];
			} else {
				$filter_paciente_id = '';
			}		
			if (isset($this->request->get['filter_paciente'])) {
				$filter_paciente = $this->request->get['filter_paciente'];
			} else {
				$filter_paciente = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}		
			
			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente'])) {
				$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_paciente_id'])) {
				$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		$data['filter_name']=$filter_name;
		if (isset($this->request->get['filter_paciente_id'])) {
			$filter_paciente_id = $this->request->get['filter_paciente_id'];
		} else {
			$filter_paciente_id = '';
		}		
		$data['filter_paciente_id']=$filter_paciente_id;
		
		if (isset($this->request->get['filter_paciente'])) {
			$filter_paciente = $this->request->get['filter_paciente'];
		} else {
			$filter_paciente = '';
		}
		$data['filter_paciente']=$filter_paciente;
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}		
		$data['filter_date_added']=$filter_date_added;
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente'])) {
			$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente_id'])) {
			$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('rmadirsis/interna/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/interna/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['internas'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_paciente_id'          => $filter_paciente_id,
			'filter_paciente'          => $filter_paciente,
			'filter_date_added'        => $filter_date_added,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$interna_total = $this->model_rmadirsis_interna->getTotalInternas();
			

		$results = $this->model_rmadirsis_interna->getInternas($filter_data);

		foreach ($results as $result) {

			if ($result['status']=='1') $status=$this->language->get('text_enabled');
			if ($result['status']=='0') $status=$this->language->get('text_disabled');
			if ($result['status']=='2') $status=$this->language->get('text_deleted');
			
			
			$data['internas'][] = array(
				'interna_id'     => $result['interna_id'],
				'name'   		=> $result['name'],
				'paciente_id'   => $result['paciente_id'],
				'paciente'   	=> $result['paciente'],
				'servicio'   	=> $result['servicio'],
				'diagno'   		=> $result['diagno'],
				'tratamiento'	=> $result['tratamiento'],
				'date_modify'   => $result['date_modify'],
				'status'     	=> $status,
				'date_added'	=> date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'internacion'   => $this->url->link('rmadirsis/interna/add', 'user_token=' . $this->session->data['user_token'] . '&interna_id=' . $result['interna_id'] . $url, true),
				'edit'       	=> $this->url->link('rmadirsis/interna/edit', 'user_token=' . $this->session->data['user_token'] . '&interna_id=' . $result['interna_id'] . $url, true)
			);
		}
		

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente'])) {
			$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente_id'])) {
			$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_paciente'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=paciente' . $url, true);
		$data['sort_servicio'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=servicio' . $url, true);
		$data['sort_diagno'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=diagno' . $url, true);		
		$data['sort_status'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
		$data['sort_date_added'] = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente'])) {
			$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente_id'])) {
			$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $interna_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($interna_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($interna_total - $this->config->get('config_limit_admin'))) ? $interna_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $interna_total, ceil($interna_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('rmadirsis/interna_list', $data));
	}
*/
	protected function getForm() {
		
		if (isset($this->request->get['evento_id']) and !isset($this->request->get['interna_id'])) {
			$data['evento_id']=$this->request->get['evento_id'];
			$this->load->model('rmadirsis/interna');
			$interna_info = $this->model_rmadirsis_interna->getInternaByEvento($data['evento_id']);
			if (empty($interna_info)) {
				$this->load->model('rmadirsis/evento');
				$evento_info = $this->model_rmadirsis_evento->getEvento($data['evento_id']);
				$data['text_form'] = $this->language->get('text_add');
			}else{
				$data['text_form'] = $this->language->get('text_edit');
				$data['interna_id']=$interna_info['interna_id'];
			}
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
		if (isset($this->error['paciente'])) {
			$data['error_paciente'] = $this->error['paciente'];
		} else {
			$data['error_paciente'] = '';
		}
		if (isset($this->error['date_modify'])) {
			$data['error_date_modify'] = $this->error['date_modify'];
		} else {
			$data['error_date_modify'] = '';
		}		
		$url = '';
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente'])) {
			$url .= '&filter_paciente=' . urlencode(html_entity_decode($this->request->get['filter_paciente'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_paciente_id'])) {
			$url .= '&filter_paciente_id=' . $this->request->get['filter_paciente_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/interna', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['interna_id'])) {
			$data['action'] = $this->url->link('rmadirsis/interna/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('rmadirsis/interna/edit', 'user_token=' . $this->session->data['user_token'] . '&interna_id=' . $this->request->get['interna_id'] . $url, true);
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}				

		if (isset($this->request->get['interna_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$interna_info = $this->model_rmadirsis_interna->getInterna($this->request->get['interna_id']);
			
		}
		
		if (isset($this->request->post['evento_id'])) {
			$data['evento_id'] = $this->request->post['evento_id'];
		} elseif (!empty($interna_info)) {
			$data['evento_id'] = $interna_info['evento_id'];
		} elseif (!empty($evento_info)) {
			$data['evento_id'] = $evento_info['evento_id'];			
		} else {
			$data['evento_id'] = '';
		}		

		$data['cancel'] = $this->url->link('rmadirsis/evento', 'user_token=' . $this->session->data['user_token'] . '&evento_id='.$data['evento_id'], true);

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($interna_info)) {
			$data['name'] = $interna_info['name'];
		} else {
			$data['name'] = '';
		}
		
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] = $this->model_rmadirsis_servicio->getServicios();

		if (isset($this->request->post['servicio_id'])) {
			$data['servicio_id'] = $this->request->post['servicio_id'];
		} elseif (!empty($interna_info)) {
			$data['servicio_id'] = $interna_info['servicio_id'];
		} elseif (!empty($evento_info)) {			
			$data['servicio_id'] = $evento_info['servicio_id'];
		} else {
			$data['servicio_id'] = '';
		}

		$this->load->model('rmadirsis/diagno');
		$data['diagnos'] = $this->model_rmadirsis_diagno->getDiagnos();

		if (isset($this->request->post['diagno_id'])) {
			$data['diagno_id'] = $this->request->post['diagno_id'];
		} elseif (!empty($interna_info)) {
			$data['diagno_id'] = $interna_info['diagno_id'];
		} elseif (!empty($evento_info)) {
			$data['diagno_id'] = $evento_info['diagno_id'];
		} else {
			$data['diagno_id'] = '';
		}

		$this->load->model('rmadirsis/tratamiento');
		$data['tratamientos'] = $this->model_rmadirsis_tratamiento->getTratamientos();

		if (isset($this->request->post['tratamiento_id'])) {
			$data['tratamiento_id'] = $this->request->post['tratamiento_id'];
		} elseif (!empty($interna_info)) {
			$data['tratamiento_id'] = $interna_info['tratamiento_id'];
		} elseif (!empty($evento_info)) {
			$data['tratamiento_id'] = $evento_info['tratamiento_id'];
		} else {
			$data['tratamiento_id'] = '';
		}		

		$this->load->model('rmadirsis/profesional');
		$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals();
		
		if (isset($this->request->post['profesional_id'])) {
			$data['profesional_id'] = $this->request->post['profesional_id'];
		} elseif (!empty($interna_info)) {
			$data['profesional_id'] = $interna_info['profesional_id'];
		} elseif (!empty($evento_info)) {
			$data['profesional_id'] = $evento_info['profesional_id'];
		} else {
			$data['profesional_id'] = '';
		}
		
		if (isset($this->request->post['comment'])) {
			$data['comment'] = $this->request->post['comment'];
		} elseif (!empty($interna_info)) {
			$data['comment'] = $interna_info['comment'];
		} else {
			$data['comment'] = '';
		}
		
		if (isset($this->request->post['paciente_id'])) {
			$data['paciente_id'] = $this->request->post['paciente_id'];
		} elseif (!empty($interna_info)) {
			$data['paciente_id'] = $interna_info['paciente_id'];
		} elseif (!empty($evento_info)) {
			$data['paciente_id'] = $evento_info['paciente_id'];
		} else {
			$data['paciente_id'] = '';
		}
		
		if (isset($data['paciente_id'])){
			$this->load->model('admdirsis/paciente');
			$paciente_info = $this->model_admdirsis_paciente->getPaciente($data['paciente_id']);
			if (!empty($paciente_info)){
				$data['paciente']=$paciente_info['name'];
				$data['paciente_id']=$paciente_info['paciente_id'];
			}else{
				$data['paciente'] = '';
				
			}
		}
		
		if (isset($data['profesional_id'])){
			$this->load->model('rmadirsis/profesional');
			$profesional_info = $this->model_rmadirsis_profesional->getProfesional($data['profesional_id']);
			if (!empty($profesional_info)){
				$data['profesional']=$profesional_info['name'];
				$data['profesional_id']=$profesional_info['profesional_id'];
			}else{
				$data['profesional'] = '';
				$data['profesional_id']= '';
			}
		}		
		

		
		if (isset($this->request->post['date_modify'])) {
			$data['date_modify'] = $this->request->post['date_modify'];
		} elseif (!empty($interna_info)) {
			$data['date_modify'] = $interna_info['date_modify'];
		} else {
			$data['date_modify'] = date("Y-m-d"); 
		}
		
		$data['date_hoy'] = date("Y-m-d"); 
		
		//print_r($data);
		if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($interna_info)) {
			$data['image'] = $interna_info['image'];
		} else {
			$data['image'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($interna_info) && $interna_info['image'] && is_file(DIR_IMAGE . $interna_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($interna_info['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		
		
		// Images
		if (isset($this->request->post['interna_image'])) {
			$interna_images = $this->request->post['interna_image'];
		} elseif (isset($this->request->get['interna_id'])) {
			$interna_images = $this->model_rmadirsis_interna->getInternaImages($this->request->get['interna_id']);
		} elseif (isset($data['interna_id'])) {
			$interna_images = $this->model_rmadirsis_interna->getInternaImages($data['interna_id']);
		} else {
			$interna_images = array();
		}

		
		$data['interna_images'] = array();

		foreach ($interna_images as $interna_image) {
			if (is_file(DIR_IMAGE . $interna_image['image'])) {
				$image = $interna_image['image'];
				$thumb = $interna_image['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}

			$data['interna_images'][] = array(
				'image'      => $image,
				'thumb'      => $this->model_tool_image->resize($thumb, 100, 100),
				'comment' 	 => $interna_image['comment'],
				'date_added' => $interna_image['date_added']
			);
		}
		

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($interna_info)) {
			$data['status'] = $interna_info['status'];
		} else {
			$data['status'] = 1;
		}
		$data['user_token'] = $this->session->data['user_token'];
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('rmadirsis/interna_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/interna')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->request->post['paciente_id']<=0){
			$this->error['paciente'] = $this->language->get('error_paciente');
		}
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 20)) {
			$this->error['name'] = $this->language->get('error_name');
		}		

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'rmadirsis/interna')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['selected'] as $interna_id) {
			if ($this->interna->getId() == $interna_id) {
				$this->error['warning'] = $this->language->get('error_account');
			}
		}

		return !$this->error;
	}
	
	
}
	
