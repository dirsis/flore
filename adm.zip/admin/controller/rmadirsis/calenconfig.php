<?php
class ControllerRmadirsisCalendario extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('rmadirsis/calendario');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/calendario');
		$this->getList();
	}

	public function add() {
		$this->load->language('rmadirsis/calendario');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/calendario');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_rmadirsis_calendario->addCalendario($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			
			
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			$this->model_rmadirsis_calendario->editCalendario($this->request->get['turno_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function atender() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if ($this->request->get['turno_id']) {
			$this->model_rmadirsis_calendario->atenderCalendario($this->request->get['turno_id']);
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function cerrar() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if ($this->request->get['turno_id']) {
			$this->model_rmadirsis_calendario->cerrarCalendario($this->request->get['turno_id']);
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function recuperar() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if ($this->request->get['turno_id']) {
			$this->model_rmadirsis_calendario->recuperarCalendario($this->request->get['turno_id']);
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function reservar() {
		$this->load->language('rmadirsis/calendario');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/calendario');
		$turno_id=$this->request->get['turno_id'];
		$name=$this->request->get['name'];
		$dni=$this->request->get['dni'];
		$osocial=$this->request->get['osocial'];
		$precio=$this->request->get['precio'];
		$telephone=$this->request->get['telephone'];
		$nota=$this->request->get['nota'];
		$this->model_rmadirsis_calendario->reservarCalendario($turno_id,$name,$telephone,$dni,$osocial,$precio,$nota);
		
		
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = "";
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function copy() {
		
		
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = date("Y-m-d");
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		$filter_periodo='1';
		$page = 1;
		$this->load->language('rmadirsis/calendario');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/calendario');
		
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $filter_date_desde,
			'filter_periodo'        	=> $filter_periodo,
			'filter_date_hasta'        => $filter_date_desde,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		
		//print_r($filter_data);
		
		$fecha=$this->request->get['fecha_final'];
		$results = $this->model_rmadirsis_calendario->getCalendarios($filter_data);
		//print_r($results);
		foreach ($results as $result) {		
			$this->model_rmadirsis_calendario->copyCalendario($result['turno_id'],$fecha);
		}
	}
	
	
	
	public function libera() {
			
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $tarea_id) {
				$this->model_rmadirsis_calendario->liberaCalendario($tarea_id);
			}
		}
	}
	
	public function clonar() {
		if (isset($this->request->get['turno_id'])){
			$this->load->model('rmadirsis/calendario');
			$this->session->data['success'] = 'Clonado con exito!';
			
			
			$turno_id=$this->request->get['turno_id'];
			$laps=$this->request->get['laps'];
			$this->model_rmadirsis_calendario->clonarCalendario($turno_id,$laps);
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}	
	
	
	public function eliminar() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if (isset($this->request->get['turno_id'])) {
			$this->model_rmadirsis_calendario->deleteCalendario($this->request->get['turno_id']);
			//die;
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
						if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));			
		}
		
		$this->getList();
	}

	public function delete() {
		$this->load->language('rmadirsis/calendario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/calendario');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $turno_id) {
				$this->model_rmadirsis_calendario->deleteCalendario($turno_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
						if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_periodo'])) {
				$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
	
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = date("d-m-Y");
		}

		if (isset($this->request->get['filter_periodo'])) {
			$filter_periodo = $this->request->get['filter_periodo'];
		} else {
			$filter_periodo = '2';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . $this->request->get['filter_name'];
		}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}	
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_periodo'])) {
			$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
		}			


		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('rmadirsis/calendario/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('rmadirsis/calendario/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/calendario/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

/*
		$data['calendarios'] = array();
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $filter_date_desde,
			'filter_periodo'        	=> $filter_periodo,
			'filter_date_hasta'        => $filter_date_desde,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		$this->load->model('rmadirsis/servicio');
		$this->load->model('rmadirsis/calendario');
		$calendario_total = $this->model_rmadirsis_calendario->getTotalCalendarios($filter_data);
		$results = $this->model_rmadirsis_calendario->getCalendarios($filter_data);
		
		foreach ($results as $result) {
			
			$customer=$result['name'];
			$dni=$result['dni'];
			$osocial='';
			
			if ($result['customer_id']>0){
				$this->load->model('customer/customer');
				$customers=$this->model_customer_customer->getCustomer($result['customer_id']);
				if (isset($customers['name'])){
					$customer=$customers['name'];
					$dni=$customers['cuit'];
					$osocial=$customers['osocial'];
				}
			}
			
			
			$recuperar=$atender="";
			if ($result['status']=='1'){
				$statusname='Libre';
			}elseif($result['status']=='2'){
				$statusname="Reservado";
			}else{
				$statusname=$this->language->get('text_disabled');
			}
			
			if ($result['servicio_id']){
				$servicioname=$this->model_rmadirsis_servicio->getServicio($result['servicio_id']);
			}else{
				$servicioname['name']='';
			}
			$data['calendarios'][] = array(
				'turno_id'    	 => $result['turno_id'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'profesional_id' => $result['profesional_id'],
				'servicio_id' => $result['servicio_id'],
				'nameserv'		=> $servicioname['name'],
				'nameprof'       => $result['nameprof'],
				'hora'           => $result['hora'],
				'customer'		 => $result['name'],
				'dni'		 	=> $result['dni'],
				'osocial'		 => $osocial,
				'status'         => $result['status'],
				'statusname'     => $statusname,
				'reservar'		 => $this->url->link('rmadirsis/calendario/reservar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'atender'        => $this->url->link('rmadirsis/calendario/atender', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'cerrar'        => $this->url->link('rmadirsis/calendario/cerrar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'recuperar'		 => $this->url->link('rmadirsis/calendario/recuperar', 'user_token=' . $this->session->data['user_token'] . '&turno_id='  . $result['turno_id'] . $url, true),
				'edit'           => $this->url->link('rmadirsis/calendario/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true)
			);
		}
		//print_r($data['calendarios']);
*/		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		/*
		$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}			
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_periodo'])) {
			$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_turno_id'] = $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.turno_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.date_added' . $url, true);
		$data['sort_hora'] 		= $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.hora' . $url, true);
		$data['sort_profesional_id'] 	= $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.profesional_id' . $url, true);	
		$data['sort_servicio_id'] 	= $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.servicio_id' . $url, true);			
		$data['sort_customer_id'] 	= $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.customer_id' . $url, true);			
		$data['sort_status'] = $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.status' . $url, true);

		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_periodo'])) {
			$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $calendario_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($calendario_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($calendario_total - $this->config->get('config_limit_admin'))) ? $calendario_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $calendario_total, ceil($calendario_total / $this->config->get('config_limit_admin')));
		*/

		$data['filter_name'] = $filter_name;
		$data['filter_profesional_id'] = $filter_profesional_id;
		$data['filter_servicio_id'] = $filter_servicio_id;
		$data['filter_status'] = $filter_status;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_periodo'] = $filter_periodo;
		$data['filter_date_hasta'] = $filter_date_desde;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->load->model('rmadirsis/profesional');
		$results = $this->model_rmadirsis_profesional->getProfesionals();

		foreach ($results as $result) {
			$data['profesionals'][] = array(
				'profesional_id'    => $result['profesional_id'],
				'name'           => $result['name']);
		}
		
		$this->load->model('rmadirsis/servicio');
		$results = $this->model_rmadirsis_servicio->getServicios();

		foreach ($results as $result) {
			$data['servicios'][] = array(
				'servicio_id'    => $result['servicio_id'],
				'name'           => $result['name'],
				'color'           => $result['color']);
		}	
		
		
		$json = array();
		$fecha=date("Y-m-d",strtotime($filter_date_desde));
		if ($filter_periodo=='1') {
				//MENSUAL
				$ano=date("Y", strtotime($filter_date_desde));
				$mes=date("m", strtotime($filter_date_desde));
				$primero=date("d-m-Y", strtotime($ano."-".$mes."-01"));
				for ($i = 0; $i <= 31; $i++) {
						$fecha = date("d-m-Y",strtotime($primero."+ ".$i." days")); 
						if (date("m", strtotime($fecha))!=$mes){
							break;
						}
					
						$fecha2 = date("Y-m-d",strtotime($fecha)); 
					
					
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $fecha2,
			'filter_periodo'        	=> $filter_periodo,
			'filter_date_hasta'        => $fecha2,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);					
						$json2= $this->tomacale($filter_data);
						$json[] = array(
							'fecha' => $fecha,
							'agenda' => $json2
						);
				}
		}
		if ($filter_periodo=='2') {
				$primero=$fecha;
				for ($i = 0; $i <= 6; $i++) {
					
						
					$fecha = date("d-m-Y",strtotime($primero."+ ".$i." days")); 
					$fecha2 = date("Y-m-d",strtotime($primero."+ ".$i." days")); 
					
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $fecha2,
			'filter_periodo'        	=> $filter_periodo,
			'filter_date_hasta'        => $fecha2,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		$json2= $this->tomacale($filter_data);			
					
						$json[] = array(
							'fecha' => $fecha,
							'agenda' => $json2
						);
				}
		}
		if ($filter_periodo=='3') {
				//MENSUAL
				$filter_data = array(
					'filter_name'    => $filter_name,
					'filter_profesional_id'    => $filter_profesional_id,
					'filter_servicio_id'    => $filter_servicio_id,
					'filter_status'            => $filter_status,
					'filter_date_desde'        => $fecha,
					'filter_periodo'        	=> $filter_periodo,
					'filter_date_hasta'        => $fecha,
					'sort'                     => $sort,
					'order'                    => $order,
					'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
					'limit'                    => $this->config->get('config_limit_admin')
				);			
				$json2= $this->tomacale($filter_data);
				$json[] = array(
							'fecha' => date("d-m-Y",strtotime($fecha)),
							'agenda' => $json2
				);
		}	
		
		$data['json']=$json;
		$this->response->setOutput($this->load->view('rmadirsis/calendario_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['turno_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['turno_id'])) {
			$data['turno_id'] = $this->request->get['turno_id'];
		} else {
			$data['turno_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['date_added'])) {
			$data['error_date_added'] = $this->error['date_added'];
		} else {
			$data['error_date_added'] = '';
		}
		
		if (isset($this->error['hora'])) {
			$data['error_hora'] = $this->error['hora'];
		} else {
			$data['error_hora'] = '';
		}
		
		if (isset($this->error['servicio_id'])) {
			$data['error_servicio_id'] = $this->error['servicio_id'];
		} else {
			$data['error_servicio_id'] = '';
		}		
		
		if (isset($this->error['profesional_id'])) {
			$data['error_profesional_id'] = $this->error['profesional_id'];
		} else {
			$data['error_profesional_id'] = '';
		}
		
		
		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_periodo'])) {
			$url .= '&filter_periodo=' . $this->request->get['filter_periodo'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['turno_id'])) {
			$data['action'] = $this->url->link('rmadirsis/calendario/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('rmadirsis/calendario/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $this->request->get['turno_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('rmadirsis/calendario', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$calendario_info=array();
		
		if (isset($this->request->get['turno_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$calendario_info = $this->model_rmadirsis_calendario->getCalendario($this->request->get['turno_id']);
		}
		
		
		$this->load->model('rmadirsis/profesional');
		$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals();
		
		/*
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] = $this->model_rmadirsis_servicio->getServicios();
		*/
		
		
	
		//print_r($data['listahoras']);

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($calendario_info)) {
			$data['date_added'] = $calendario_info['date_added'];
		} else {
			$data['date_added'] = date('Y-m-d');
		}
		
		$data['date_added'] = date( "d-m-Y", strtotime( $data['date_added']));
		
		/*
		$hora_inicio = '08:00';
		$hora_fin	 = '23:00';
		$intervalo = 20;
		$hora_inicio = new DateTime( $hora_inicio );
    	$hora_fin    = new DateTime( $hora_fin );
    	$hora_fin->modify('+1 second'); 
    	if ($hora_inicio > $hora_fin) {
			$hora_fin->modify('+1 day');
    	}
		
		$intervalo = new DateInterval('PT'.$intervalo.'M');
		$periodo   = new DatePeriod($hora_inicio, $intervalo, $hora_fin);    
		
		$data['listahoras'] = array();
		foreach( $periodo as $listhora ) {
			$data['listahoras'][] = array(
				'hora'    => $listhora->format('H:i'),
				'name'    => $listhora->format('H:i')
			);
		}
		*/
		$data['listahoras'] = array();
		foreach (range(8, 23, 1) as $numero) {
			$data['listahoras'][] = array(
				'name'    => substr("0".$numero,-2)
			);
		}		
		$data['listaminutos'] = array();
		foreach (range(0, 50, 10) as $numero) {
			$data['listaminutos'][] = array(
				'name'    => substr("0".$numero,-2)
			);
		}		

		if (isset($this->request->post['hora'])) {
			$data['hora'] = $this->request->post['hora'];
		} elseif (!empty($calendario_info)) {
			$data['hora'] = $calendario_info['hora'];
		} else {
			$data['hora'] = '10:00';
		}		
		
		if (isset($this->request->post['profesional_id'])) {
			$data['profesional_id'] = $this->request->post['profesional_id'];
		} elseif (!empty($calendario_info)) {
			$data['profesional_id'] = $calendario_info['profesional_id'];
		} elseif (isset($this->request->get['filter_profesional_id'])) {
			$data['profesional_id'] = $this->request->get['filter_profesional_id'];
		} else {
			$data['profesional_id'] = 0;
		}
		
		if (isset($this->request->post['servicio_id'])) {
			$data['servicio_id'] = $this->request->post['servicio_id'];
		} elseif (!empty($calendario_info)) {
			$data['servicio_id'] = $calendario_info['servicio_id'];
		} elseif (isset($this->request->get['filter_servicio_id'])) {
			$data['servicio_id'] = $this->request->get['filter_servicio_id'];
		} else {
			$data['servicio_id'] = 0;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($calendario_info)) {
			$data['status'] = $calendario_info['status'];
		} else {
			$data['status'] = true;
		}
			
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
	
		$this->response->setOutput($this->load->view('rmadirsis/calendario_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/calendario')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		/*
		if ($this->request->post['hora'] < 1) {
			$this->error['hora'] = $this->language->get('error_hora');
		}
		*/
		
		if ($this->request->post['servicio_id']<0) {
			$this->error['servicio_id'] = $this->language->get('error_servicio_id');
		}		

		return !$this->error;
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'rmadirsis/calendario')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	
	
	/*
	public function getCalendario() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = date('d-m-Y');
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		
		$json = array();
		if (isset($this->request->get['accion'])) {
			$fecha=date("Y-m-d",strtotime($this->request->get['filter_date_desde']));
			if ($this->request->get['accion']=='1') {
				//MENSUAL
				$ano=date("Y", strtotime($this->request->get['filter_date_desde']));
				$mes=date("m", strtotime($this->request->get['filter_date_desde']));
				$primero=date("d-m-Y", strtotime($ano."-".$mes."-01"));
				//print_r($mes);
				for ($i = 0; $i <= 31; $i++) {
						$fecha = date("d-m-Y",strtotime($primero."+ ".$i." days")); 
						if (date("m", strtotime($fecha))!=$mes){
							break;
						}
					
						$fecha2 = date("Y-m-d",strtotime($fecha)); 
					
		$filter_data = array(
			'filter_name'    			=> $filter_name,
			'filter_profesional_id'    	=> $filter_profesional_id,
			'filter_servicio_id'    	=> $filter_servicio_id,
			'filter_status'            	=> $filter_status,
			'filter_date_desde'        	=> $fecha,
			'filter_date_hasta'        	=> $fecha,
			'sort'                     	=> $sort,
			'order'                    	=> $order,
			'start'                    	=> ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    	=> $this->config->get('config_limit_admin')
		);
					
						$json2= $this->tomacale($filter_data);
						$json[] = array(
							'fecha' => $fecha,
							'agenda' => $json2
						);
				}
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($json));
				
			}
			if ($this->request->get['accion']=='2') {
				$primero=$fecha;
				for ($i = 0; $i <= 6; $i++) {
		$filter_data = array(
			'filter_name'    			=> $filter_name,
			'filter_profesional_id'    	=> $filter_profesional_id,
			'filter_servicio_id'    	=> $filter_servicio_id,
			'filter_status'            	=> $filter_status,
			'filter_date_desde'        	=> $fecha,
			'filter_date_hasta'        	=> $fecha,
			'sort'                     	=> $sort,
			'order'                    	=> $order,
			'start'                    	=> ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    	=> $this->config->get('config_limit_admin')
		);					
						$json2= $this->tomacale($filter_data);
						$fecha = date("d-m-Y",strtotime($primero."+ ".$i." days")); 
						$json[] = array(
							'fecha' => $fecha,
							'agenda' => $json2
						);
				}
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($json));
				
			}
			if ($this->request->get['accion']=='3') {
				//MENSUAL
		$filter_data = array(
			'filter_name'    			=> $filter_name,
			'filter_profesional_id'    	=> $filter_profesional_id,
			'filter_servicio_id'    	=> $filter_servicio_id,
			'filter_status'            	=> $filter_status,
			'filter_date_desde'        	=> $fecha,
			'filter_date_hasta'        	=> $fecha,
			'sort'                     	=> $sort,
			'order'                    	=> $order,
			'start'                    	=> ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    	=> $this->config->get('config_limit_admin')
		);				
				$json2= $this->tomacale($filter_data);
				$json[] = array(
							'fecha' => date("d-m-Y",strtotime($fecha)),
							'agenda' => $json2
				);
				$this->response->addHeader('Content-Type: application/json');
				$this->response->setOutput(json_encode($json));
				
			}			
		}
	}
	*/
	public function tomacale($filter_data){
		//print_r($filter_data);
		
		$json = array();
		$this->load->model('rmadirsis/calendario');
		$results = $this->model_rmadirsis_calendario->getCalendarios($filter_data);
	
		foreach ($results as $result) {
			$customer=$result['name'];
			$nota=$result['nota'];
			$dni=$result['dni'];
			$telephone=$osocial='';
			
			if ($result['customer_id']>0){
				$this->load->model('customer/customer');
				$customers=$this->model_customer_customer->getCustomer($result['customer_id']);
				if (isset($customers['name'])){
					$customer=$customers['name'];
					$dni=$customers['cuit'];
					$telephone=$customers['telephone'];
					$osocial=$customers['osocial'];
				}
			}
			$recuperar=$atender="";
			if ($result['status']=='1'){
				$statusname='Libre';
			}elseif($result['status']=='2'){
				$statusname="Reservado";
			}else{
				$statusname=$this->language->get('text_disabled');
			}
			$this->load->model('rmadirsis/servicio');
			if ($result['servicio_id']){
				$servicioname=$this->model_rmadirsis_servicio->getServicio($result['servicio_id']);
			}else{
				$servicioname['name']='';
				$servicioname['color']='#fff';
			}
			$url="";
			$json[] = array(
				'turno_id'    	 => $result['turno_id'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'profesional_id' => $result['profesional_id'],
				'servicio_id' => $result['servicio_id'],
				'nameserv'		=> $servicioname['name'],
				'colorserv'		=> $servicioname['color'],
				'nameprof'       => $result['nameprof'],
				'hora'           => $result['hora'],
				'customer'		 => $result['name'],
				'dni'		 	=> $result['dni'],
				'osocial'		 => $osocial,
				'telephone'		 => $telephone,
				'nota'				=> $nota,
				'status'         => $result['status'],
				'statusname'     => $statusname,
				'reservar'		 => $this->url->link('rmadirsis/calendario/reservar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'atender'        => $this->url->link('rmadirsis/calendario/atender', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'cerrar'        => $this->url->link('rmadirsis/calendario/cerrar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'recuperar'		 => $this->url->link('rmadirsis/calendario/recuperar', 'user_token=' . $this->session->data['user_token'] . '&turno_id='  . $result['turno_id'] . $url, true),
				'edit'           => $this->url->link('rmadirsis/calendario/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true)
			);
		}	
		return $json;
	}	
}
