<?php
class ControllerRmadirsisAgendaturno extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('rmadirsis/agendaturno');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agendaturno');
		$this->getList();
	}

	public function add() {
		$this->load->language('rmadirsis/agendaturno');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agendaturno');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_rmadirsis_agendaturno->addAgendaturno($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			$this->model_rmadirsis_agendaturno->editAgendaturno($this->request->get['turno_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
			if (isset($this->request->get['filter_profesional_id'])) {
				$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
			}	
			if (isset($this->request->get['filter_servicio_id'])) {
				$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
			}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function atender() {
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');

		if ($this->request->get['turno_id']) {
			$this->model_rmadirsis_agendaturno->atenderAgendaturno($this->request->get['turno_id']);
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function recuperar() {
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');

		if ($this->request->get['turno_id']) {
			$this->model_rmadirsis_agendaturno->recuperarAgendaturno($this->request->get['turno_id']);
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}			
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function reservar() {
		$this->load->language('rmadirsis/agendaturno');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('rmadirsis/agendaturno');
		$turno_id=$this->request->get['turno_id'];
		$name=$this->request->get['name'];
		$dni=$this->request->get['dni'];
		$osocial=$this->request->get['osocial'];
		$this->model_rmadirsis_agendaturno->reservarAgendaturno($turno_id,$name,$dni,$osocial);
		
		
		
		$this->session->data['success'] = $this->language->get('text_success');
		$url = "";
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function copy() {
			
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');
		
		$fecha=$this->request->get['fecha'];

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $tarea_id) {
				$this->model_rmadirsis_agendaturno->copyAgendaturno($tarea_id,$fecha);
			}
		}
	}
	
	public function libera() {
			
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $tarea_id) {
				$this->model_rmadirsis_agendaturno->liberaAgendaturno($tarea_id);
			}
		}
	}
	
	public function clonar() {
		if (isset($this->request->get['turno_id'])){
			$this->load->model('rmadirsis/agendaturno');
			$turno_id=$this->request->get['turno_id'];
			$laps=$this->request->get['laps'];
			$this->model_rmadirsis_agendaturno->clonarAgendaturno($turno_id,$laps);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}							
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}	

	public function delete() {
		$this->load->language('rmadirsis/agendaturno');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('rmadirsis/agendaturno');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $turno_id) {
				$this->model_rmadirsis_agendaturno->deleteAgendaturno($turno_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
						if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}				
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$filter_profesional_id = $this->request->get['filter_profesional_id'];
		} else {
			$filter_profesional_id = '';
		}
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$filter_servicio_id = $this->request->get['filter_servicio_id'];
		} else {
			$filter_servicio_id = '';
		}		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		
		
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}	
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('rmadirsis/agendaturno/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('rmadirsis/agendaturno/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('rmadirsis/agendaturno/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['agendaturnos'] = array();
		$filter_data = array(
			'filter_name'    => $filter_name,
			'filter_profesional_id'    => $filter_profesional_id,
			'filter_servicio_id'    => $filter_servicio_id,
			'filter_status'            => $filter_status,
			'filter_date_desde'        => $filter_date_desde,
			'filter_date_hasta'        => $filter_date_hasta,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);
		
		$this->load->model('rmadirsis/servicio');
		$agendaturno_total = $this->model_rmadirsis_agendaturno->getTotalAgendaturnos($filter_data);
		$results = $this->model_rmadirsis_agendaturno->getAgendaturnos($filter_data);
		
		foreach ($results as $result) {
			
			/*
			$customer=$result['name'];
			if ($result['customer_id']>0){
				$customers=$this->model_rmadirsis_agendaturno->putTurnoregistrado($result['turno_id']);
				if (isset($customers['name'])){
					$customer=$customers['name'];
				}else{
					$customer='';
				}
			}
			*/
			
			$customer=$result['name'];
			$dni=$result['dni'];
			$osocial='';
			
			if ($result['customer_id']>0){
				$this->load->model('customer/customer');
				$customers=$this->model_customer_customer->getCustomer($result['customer_id']);
				if (isset($customers['name'])){
					$customer=$customers['name'];
					$dni=$customers['cuit'];
					$osocial=$customers['osocial'];
				}
			}
			
			
			$recuperar=$atender="";
			if ($result['status']=='1'){
				$statusname='Libre';
			}elseif($result['status']=='2'){
				$statusname="Reservado";
			}else{
				$statusname=$this->language->get('text_disabled');
			}
			
			if ($result['servicio_id']){
				$servicioname=$this->model_rmadirsis_servicio->getServicio($result['servicio_id']);
			}else{
				$servicioname['name']='';
			}
			$data['agendaturnos'][] = array(
				'turno_id'    	 => $result['turno_id'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'profesional_id' => $result['profesional_id'],
				'servicio_id' => $result['servicio_id'],
				'nameserv'		=> $servicioname['name'],
				'nameprof'       => $result['nameprof'],
				'hora'           => $result['hora'],
				'customer'		 => $result['name'],
				'dni'		 	=> $result['dni'],
				'osocial'		 => $osocial,
				'status'         => $result['status'],
				'statusname'     => $statusname,
				'reservar'		 => $this->url->link('rmadirsis/agendaturno/reservar', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'atender'        => $this->url->link('rmadirsis/agendaturno/atender', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true),
				'recuperar'		 => $this->url->link('rmadirsis/agendaturno/recuperar', 'user_token=' . $this->session->data['user_token'] . '&turno_id='  . $result['turno_id'] . $url, true),
				'edit'           => $this->url->link('rmadirsis/agendaturno/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $result['turno_id'] . $url, true)
			);
		}
		//print_r($data['agendaturnos']);
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}			
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_turno_id'] = $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.turno_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.date_added' . $url, true);
		$data['sort_hora'] 		= $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.hora' . $url, true);
		$data['sort_profesional_id'] 	= $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.profesional_id' . $url, true);	
		$data['sort_servicio_id'] 	= $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.servicio_id' . $url, true);			
		$data['sort_customer_id'] 	= $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.customer_id' . $url, true);			
		$data['sort_status'] = $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . '&sort=xd_turno.status' . $url, true);

		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $agendaturno_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($agendaturno_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($agendaturno_total - $this->config->get('config_limit_admin'))) ? $agendaturno_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $agendaturno_total, ceil($agendaturno_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_profesional_id'] = $filter_profesional_id;
		$data['filter_servicio_id'] = $filter_servicio_id;
		$data['filter_status'] = $filter_status;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		

		$this->load->model('rmadirsis/profesional');
		$results = $this->model_rmadirsis_profesional->getProfesionals();

		foreach ($results as $result) {
			$data['profesionals'][] = array(
				'profesional_id'    => $result['profesional_id'],
				'name'           => $result['name']);
		}
		
		$this->load->model('rmadirsis/servicio');
		$results = $this->model_rmadirsis_servicio->getServicios();

		foreach ($results as $result) {
			$data['servicios'][] = array(
				'servicio_id'    => $result['servicio_id'],
				'name'           => $result['name']);
		}		
		
		

		$this->response->setOutput($this->load->view('rmadirsis/agendaturno_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['turno_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['turno_id'])) {
			$data['turno_id'] = $this->request->get['turno_id'];
		} else {
			$data['turno_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['date_added'])) {
			$data['error_date_added'] = $this->error['date_added'];
		} else {
			$data['error_date_added'] = '';
		}
		
		if (isset($this->error['hora'])) {
			$data['error_hora'] = $this->error['hora'];
		} else {
			$data['error_hora'] = '';
		}
		
		if (isset($this->error['profesional_id'])) {
			$data['error_profesional_id'] = $this->error['profesional_id'];
		} else {
			$data['error_profesional_id'] = '';
		}
		
		
		$url = '';
		
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}						
		
		if (isset($this->request->get['filter_profesional_id'])) {
			$url .= '&filter_profesional_id=' . $this->request->get['filter_profesional_id'];
		}	
		
		
		if (isset($this->request->get['filter_servicio_id'])) {
			$url .= '&filter_servicio_id=' . $this->request->get['filter_servicio_id'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['turno_id'])) {
			$data['action'] = $this->url->link('rmadirsis/agendaturno/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('rmadirsis/agendaturno/edit', 'user_token=' . $this->session->data['user_token'] . '&turno_id=' . $this->request->get['turno_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('rmadirsis/agendaturno', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$agendaturno_info=array();
		
		if (isset($this->request->get['turno_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$agendaturno_info = $this->model_rmadirsis_agendaturno->getAgendaturno($this->request->get['turno_id']);
		}
		
		
		$this->load->model('rmadirsis/profesional');
		$data['profesionals'] = $this->model_rmadirsis_profesional->getProfesionals();
		
		/*
		$this->load->model('rmadirsis/servicio');
		$data['servicios'] = $this->model_rmadirsis_servicio->getServicios();
		*/		
		
	
		//print_r($data['listahoras']);

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($agendaturno_info)) {
			$data['date_added'] = $agendaturno_info['date_added'];
		} else {
			$data['date_added'] = date('Y-m-d');
		}
		
		$data['date_added'] = date( "d-m-Y", strtotime( $data['date_added']));
		
		$hora_inicio = '08:00';
		$hora_fin	 = '23:00';
		$intervalo = 20;
		$hora_inicio = new DateTime( $hora_inicio );
    	$hora_fin    = new DateTime( $hora_fin );
    	$hora_fin->modify('+1 second'); 
    	if ($hora_inicio > $hora_fin) {
			$hora_fin->modify('+1 day');
    	}
		$intervalo = new DateInterval('PT'.$intervalo.'M');
		$periodo   = new DatePeriod($hora_inicio, $intervalo, $hora_fin);    
		
		$data['listahoras'] = array();
		foreach( $periodo as $listhora ) {
			$data['listahoras'][] = array(
				'hora'    => $listhora->format('H:i'),
				'name'    => $listhora->format('H:i')
			);
		}

		if (isset($this->request->post['hora'])) {
			$data['hora'] = $this->request->post['hora'];
		} elseif (!empty($agendaturno_info)) {
			$data['hora'] = $agendaturno_info['hora'];
		} else {
			$data['hora'] = '';
		}		
		
		if (isset($this->request->post['profesional_id'])) {
			$data['profesional_id'] = $this->request->post['profesional_id'];
		} elseif (!empty($agendaturno_info)) {
			$data['profesional_id'] = $agendaturno_info['profesional_id'];
		} elseif (isset($this->request->get['filter_profesional_id'])) {
			$data['profesional_id'] = $this->request->get['filter_profesional_id'];
		} else {
			$data['profesional_id'] = 0;
		}
		
		if (isset($this->request->post['servicio_id'])) {
			$data['servicio_id'] = $this->request->post['servicio_id'];
		} elseif (!empty($agendaturno_info)) {
			$data['servicio_id'] = $agendaturno_info['servicio_id'];
		} elseif (isset($this->request->get['filter_servicio_id'])) {
			$data['servicio_id'] = $this->request->get['filter_servicio_id'];
		} else {
			$data['servicio_id'] = 0;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($agendaturno_info)) {
			$data['status'] = $agendaturno_info['status'];
		} else {
			$data['status'] = true;
		}
			
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
	
		$this->response->setOutput($this->load->view('rmadirsis/agendaturno_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'rmadirsis/agendaturno')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		
		if ($this->request->post['hora'] < 1) {
			$this->error['hora'] = $this->language->get('error_hora');
		}		

		return !$this->error;
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'rmadirsis/agendaturno')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	

}