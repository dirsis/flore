<?php
class ControllerDirsiscrudCompo extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrud/compo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/product');

		$this->getList();
	}

	public function add() {
		
		$product_id=$this->request->get['product_id'];
		$relacion_id=$this->request->get['relacion_id'];
		$quantity=$this->request->get['quantity'];

		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->addCompo($product_id,$relacion_id,$quantity);
		echo $result;
	}
	public function delete() {
		$compo_id=$this->request->get['compo_id'];
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->deleteCompo($compo_id);
		echo $result;
	}
	protected function getList() {
		
		if (isset($this->request->get['product_id'])) {
			$product_id=$this->request->get['product_id'];
			
			$url='';
			$url='&product_id'.$product_id;
			
			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('dirsiscrud/compo', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);


			$data['base'] = $this->model_catalog_product->getProduct($product_id);
			
			
			$results = $this->model_catalog_product->getCompos($product_id);
			$data['compos'] = array();
			foreach ($results as $result) {
				$data['compos'][] = array(
					'compo_id' => $result['compo_id'],
					'model' => $result['model'],
					'product_id' => $result['product_id'],
					'relacion_id' => $result['relacion_id'],
					'quantity' => $result['quantity'],
					'name'       => $result['name']
				);
			}
			
			
			
			$data['products'] = array();

			$filter_data = array();

			$this->load->model('tool/image');
			$product_total = $this->model_catalog_product->getTotalProducts($filter_data);
			$results = $this->model_catalog_product->getProducts($filter_data);
			
			foreach ($results as $result) {
				if (is_file(DIR_IMAGE . $result['image'])) {
					$image = $this->model_tool_image->resize($result['image'], 40, 40);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 40, 40);
				}
				$category =  $this->model_catalog_product->getProductCategories($result['product_id']);
				$data['products'][] = array(
					'product_id' => $result['product_id'],
					'image'      => $image,
					'manufacturer_name' => $result['manufacturer_name'],
					'category'   => $category,  /// Filter By Category
					'name'       => $result['name'],
					'model'      => $result['model'],
					'isbn'      	=> $result['isbn'],
					'upc'      		=> $result['upc'],
					'jan'      		=> $result['jan'],
					'quantity'   => $result['quantity'],
					'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				);
			}
			
			
			$data['user_token'] = $this->session->data['user_token'];

			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];

				unset($this->session->data['success']);
			} else {
				$data['success'] = '';
			}

			if (isset($this->request->post['selected'])) {
				$data['selected'] = (array)$this->request->post['selected'];
			} else {
				$data['selected'] = array();
			}

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			$this->response->setOutput($this->load->view('dirsiscrud/compo_list', $data));
		}
	}

}

