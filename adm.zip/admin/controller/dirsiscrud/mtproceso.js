// JavaScript Document
function editstatus(mtproceso_id,mtstatus_id,boton,user_token){
		
		$(boton).LoadingOverlay('show');
		var url = 'index.php?route=dirsiscrud/mtproceso/editstatus&user_token='+user_token;
		
	
		$.ajax({
			url: url,
			data: {
				mtstatus_id: mtstatus_id,
				mtproceso_id: mtproceso_id
			},
			type:'post',
			dataType: 'json',
			success: function(json) {
				$(boton).LoadingOverlay('hide');
				/*
				if (json['mtstatus_id']){
					$(boton).unbind('click');
					$(boton).css("border","");
					$(boton).css("border","2px solid "+json['mtstatuscolor']);
					$(boton).html(json['mtstatusname']);
					recargaresumen(user_token);
					$(boton).bind("click", function(){
   						editstatus(mtproceso_id,json['mtstatus_id'],this,user_token);
					});					
				}
				$(boton).blur();
				*/
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});

}
function editvalidado(mtproceso_id,validado,boton,user_token){
		$(boton).LoadingOverlay('show');
		var url = 'index.php?route=dirsiscrud/mtproceso/editvalidado&user_token='+user_token;
		var valida= validado==1?0:1;
		$.ajax({
			url: url,
			data: {
				validado: valida,
				mtproceso_id: mtproceso_id
			},
			type:'post',
			dataType: 'text',
			success: function(json) {
				$(boton).LoadingOverlay('hide');
				if (validado==1){
					$(boton).css("border-top","2px solid red");
					$(boton).html("No");
				}else{
					$(boton).css("border-top","2px solid green");
					$(boton).html("Si");
					
				}
				
				$(boton).unbind('click');
				$(boton).click(function(){
					editvalidado(mtproceso_id,valida,this);
				});
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});

} 
function editconfirma(mtproceso_id,confirmado,boton,user_token){
		$(boton).LoadingOverlay('show');
		var url = 'index.php?route=dirsiscrud/mtproceso/editconfirma&user_token='+user_token;
		var confirma= confirmado==1?0:1;
		$.ajax({
			url: url,
			data: {
				confirmado: confirma,
				mtproceso_id: mtproceso_id
			},
			type:'post',
			dataType: 'text',
			success: function(json) {
				$(boton).LoadingOverlay('hide');
				if (confirmado==1){
					$(boton).css("border-top","2px solid red");
					$(boton).html("No");
				}else{
					$(boton).css("border-top","2px solid green");
					$(boton).html("Si");
					
				}
				
				$(boton).unbind('click');
				$(boton).click(function(){
					editconfirma(mtproceso_id,confirma,this);
				});
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});

}  




function recargaresumen(user_token){
		$("#resumen").LoadingOverlay('show');
  		var url = 'index.php?route=dirsiscrud/mtproceso/recargaresumen&user_token='+user_token;
		var html='';
		$.ajax({
		  url: url,
		  dataType: 'json',
		  success: function(json) {
			  //console.log(json);
			if (json['status'] && json['status'] != '') {
			  for (i = 0; i < json['status'].length; i++) {
      			html+='<div class="col-md-3 col-sm-3 col-xs-6">';
				html+='<div class="panel panel-primary" style="border-top: 2px solid '+json['status'][i]['mtstatuscolor']+';min-height:100px;">';
				html+='<a href="'+json['status'][i]['filter']+'">';
				html+='<div class="panel-body">';
				html+='<h1 class="text-center">'+json['status'][i]['cantidad']+'</h1>';
				html+='<h4 class="text-center">'+json['status'][i]['mtstatus']+'</h4>';
				html+='</div></a>';
				html+='</div>';
				html+='</div>';
			  }
			}
			if (json['manutentor'] && json['manutentor'] != '') {
     		  html+='<div class="col-md-12 col-xs-12">';
			  for (i = 0; i < json['manutentor'].length; i++) {
				html+='<a href="'+json['manutentor'][i]['filter']+'"';
				html+=' class="btn btn-primary">'
				html+=json['manutentor'][i]['name'];
				html+=' <span class="badge">'+json['manutentor'][i]['cantidad']+'</span>';
				html+='</a>|';
			  }
			  html+='</div>';
			}
		    $("#resumen").html(html);
		  },
		  error: function(xhr, ajaxOptions, thrownError) {
			alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
		  }
		});	
		
		$("#resumen").LoadingOverlay('hide');
}


function recargarresumenmanutentor2(user_token){
	var url = 'index.php?route=dirsiscrud/mtproceso/recargarresumenmanutentor3&user_token='+user_token;
	$('#resumenmanutentor3').load(url);
}



function carga_listitem(user_token,sort,order){
	
	$("#listitem2").LoadingOverlay('show');
	var url = 'index.php?route=dirsiscrud/mtproceso/getListitem&user_token='+user_token;
    var filter_motivo = $('input[name=\'filter_motivo\']').val();
    if (filter_motivo) {
      url += '&filter_motivo=' + encodeURIComponent(filter_motivo);
    }
    var filter_maqui_id = $('input[name=\'filter_maqui_id\']').val();
    if (filter_maqui_id) {
      url += '&filter_maqui_id=' + encodeURIComponent(filter_maqui_id);
    }	
    var filter_maqui = $('input[name=\'filter_maqui\']').val();
    if (filter_maqui) {
      url += '&filter_maqui=' + encodeURIComponent(filter_maqui);
    }
    var filter_manutentor = $('select[name=\'filter_manutentor\']').val();
    if (filter_manutentor) {
      url += '&filter_manutentor=' + encodeURIComponent(filter_manutentor);
    }	
    var filter_mtstatus_id = $('select[name=\'filter_mtstatus_id\']').val();
    if (filter_mtstatus_id !== '') {
      url += '&filter_mtstatus_id=' + encodeURIComponent(filter_mtstatus_id); 
    }
    var filter_date_desde = $('input[name=\'filter_date_desde\']').val();
    if (filter_date_desde) {
      url += '&filter_date_desde=' + encodeURIComponent(filter_date_desde);
    }
    var filter_date_hasta = $('input[name=\'filter_date_hasta\']').val();
    if (filter_date_hasta) {
      url += '&filter_date_hasta=' + encodeURIComponent(filter_date_hasta);
    }
	url += '&sort=' + encodeURIComponent(sort);
	url += '&order=' + encodeURIComponent(order);
   
	//return;
	//alert(url);
	//console.log(url);
	$('#listitem2').load(url);
	$("#listitem2").LoadingOverlay('hide');
}


 
function grabahistory(user_token){
		var url = 'index.php?route=dirsiscrud/mtproceso/addhistory&user_token='+user_token;
		var mtproceso_id 	= $('#modal-mtproceso_id').val();
		var tarea 			= $('#modal-tarea').val();
		var material 			= $('#modal-material').val();
		var motivo 			= $('#modal-motivo').val();
		var date_added 		= $('#modal-date-added').val();
		var date_init 		= $('#modal-date-init').val();
		var date_fin 		= $('#modal-date-fin').val();

		//var arr = $('[name="manutentor[]"]:checked').map(function(){		  return this.value;		}).get();
		//var manutentor = arr.join(',');
	
		var arr = $('[name="manutentor[]"]').map(function(){		  return this.value;		}).get();
		var manutentor = arr.join(',');
	
		//console.log(manutentor);
		//return;
		//$('#arr').text(JSON.stringify(arr));
		//var manutentor_id   = $('#modal-manutentor-id').val();
		//var mtstatus_id   	= $('#modal-mtstatus-id').val();
		var image_1 		= $("#image_1").val();
		var image_2 		= $("#image_2").val();
		var image_3 		= $("#image_3").val();
		
		if (motivo==""){
			$('#modal-group-motivo').addClass("has-error");
			return;
		}else{
			$('#modal-group-motivo').removeClass("has-error");
		}	
		if (tarea==""){
			$('#modal-group-tarea').addClass("has-error");
			return;
		}else{
			$('#modal-group-tarea').removeClass("has-error");
		}

		
		$("#form-addhistory").LoadingOverlay('show');
	
		//url=url+"&motivo="+motivo+"&tarea="+tarea+"&date_added="+date_added+"&manutentor_id="+manutentor_id+"&image_1="+image_1+"&image_2="+image_2+"&image_3="+image_3+"&mtproceso_id="+mtproceso_id+"&mtstatus_id="+mtstatus_id;
		//alert(url);
		//console.log(url);
		//return;
	 
		$.ajax({
			url: url,
			data: {
				motivo: motivo,
				tarea: tarea,
				material: material,
				date_added: date_added,
				date_init: date_init,
				date_fin: date_fin,
				manutentor: manutentor,
				image_1: image_1,
				image_2: image_2,
				image_3: image_3,
				mtproceso_id: mtproceso_id, 
				//mtstatus_id: mtstatus_id
			},
			type:'post',
			dataType: 'text',
			success: function(json) {
				//console.log(json);
				recargahistory(mtproceso_id,user_token);
				limpiaradd();
				$("#form-addhistory").LoadingOverlay('hide');
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});	
	}
	
	
function delhistory(mtproceso_id ,mtprocesohistory_id,user_token) {
		var url = 'index.php?route=dirsiscrud/mtproceso/delhistory&user_token='+user_token+'&mtprocesohistory_id='+mtprocesohistory_id;
		$.ajax({
			url: url,
			type:'post',
			dataType: 'text',
			success: function(json) {
				recargahistory(mtproceso_id,user_token );
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
			}
		});		
		
	};	
	
function limpiaradd(){
		$('#modal-tarea').val('');
		$('#modal-motivo').val('');
		$('#modal-manutentor-id').val('');
	}
  



function recargahistory(mtproceso_id,user_token){
	
	var url = 'index.php?route=dirsiscrud/mtproceso/gethistory&user_token='+user_token+'&mtproceso_id='+mtproceso_id;
	var html='';
	$.ajax({
		url: url,
		dataType: 'json',
		success: function(json) {
			if (json && json != '') {
				//$("#tablehistory").LoadingOverlay('show');
				for (i = 0; i < json.length; i++) {
					html+='<div class="list-group"><div class="list-group-item">';
					html+='<div class="pull-right"><a onclick="delhistory('+mtproceso_id+','+json[i]['mtprocesohistory_id']+','+"'"+user_token+"'"+')" data-toggle="tooltip" title="Eliminar" class="btn btn-danger"><i class="fa fa-trash"></i></a></div>';
					html+='<h3><i class="fa fa-tags"></i> '+json[i]['motivo']+'</h3>';
					html+='<h4><i class="fa fa-tasks"></i> '+json[i]['tarea']+'</h4>';
					html+='<p><i class="fa fa-calendar"></i> '+json[i]['date_added']+'</p>';
					html+='<p><i class="fa fa-user"></i> '+json[i]['manutentor_name']+'</p>';
					html+='<table><tr>';
					if (json[i]['image_1']){
					html+='<td><a href="'+json[i]['image_1']+'" target="_blank"><i class="fa fa-eye"></i></a></td>';
					}
					if (json[i]['image_2']){
					html+='<td><a href="'+json[i]['image_1']+'" target="_blank"><i class="fa fa-eye"></i></a></td>';
					}
					if (json[i]['image_3']){
					html+='<td><a href="'+json[i]['image_1']+'" target="_blank"><i class="fa fa-eye"></i></a></td>';
					}
					html+='</tr></table></div></div>';
				}


				$("#tablehistory").html(html);
				//$("#tablehistory").LoadingOverlay('hide');
			}
			},
			error: function(xhr, ajaxOptions, thrownError) {
			alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
		}
	});	
}
