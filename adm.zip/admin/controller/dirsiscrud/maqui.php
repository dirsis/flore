<?php
class ControllerDirsiscrudMaqui extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrud/maqui');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/maqui');

		$this->getList();
	}

	public function add() {
		$this->load->language('dirsiscrud/maqui');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/maqui');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsiscrud_maqui->addMaqui($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsiscrud/maqui');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/maqui');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			$this->model_dirsiscrud_maqui->editMaqui($this->request->get['maqui_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsiscrud/maqui');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/maqui');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $maqui_id) {
				$this->model_dirsiscrud_maqui->deleteMaqui($maqui_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
						
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'm.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsiscrud/maqui/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsiscrud/maqui/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['maquis'] = array();

		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);

		$maqui_total = $this->model_dirsiscrud_maqui->getTotalMaquis($filter_data);

		$results = $this->model_dirsiscrud_maqui->getMaquis($filter_data);
		
		

		foreach ($results as $result) {
			$matrizs=$this->model_dirsiscrud_maqui->getCiclosactivosxmaqui($result['maqui_id']);
			
			$ciclos	=$this->model_dirsiscrud_maqui->getCicloactivo($result['maqui_id']);
			$data['maquis'][] = array(
				'maqui_id'    => $result['maqui_id'],
				'name'           => $result['name'],
				'descrip'        => $result['descrip'],
				'code'           => $result['code'],
				'type'           => $result['type'],
				'ciclos'         => $result['ciclos'],
				//'lciclos'         => $ciclos['type']==1 ? "Ciclos" : "Etiquetas",
				'tciclos'         => $result['tciclos'], //$ciclos['ciclos'],
				'tconsumo'         => $result['tconsumo'], //$ciclos['consumo'],
				'matrizs' 		=> $matrizs,
				'status'         => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'edit'           => $this->url->link('dirsiscrud/maqui/edit', 'user_token=' . $this->session->data['user_token'] . '&maqui_id=' . $result['maqui_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_maqui_id'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=m.maqui_id' . $url, true);
		$data['sort_name'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=m.name' . $url, true);
		$data['sort_status'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=m.status' . $url, true);
		$data['sort_type'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=type' . $url, true);
		$data['sort_code'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=code' . $url, true);
$data['sort_ciclos'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=m.ciclos' . $url, true);		
		$data['sort_date_added'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . '&sort=m.date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $maqui_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($maqui_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($maqui_total - $this->config->get('config_limit_admin'))) ? $maqui_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $maqui_total, ceil($maqui_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_status'] = $filter_status;
		$data['filter_date_added'] = $filter_date_added;
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrud/maqui_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['maqui_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['maqui_id'])) {
			$data['maqui_id'] = $this->request->get['maqui_id'];
		} else {
			$data['maqui_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['maqui_id'])) {
			$data['action'] = $this->url->link('dirsiscrud/maqui/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscrud/maqui/edit', 'user_token=' . $this->session->data['user_token'] . '&maqui_id=' . $this->request->get['maqui_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsiscrud/maqui', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['maqui_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$maqui_info = $this->model_dirsiscrud_maqui->getMaqui($this->request->get['maqui_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($maqui_info)) {
			$data['name'] = $maqui_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['descrip'])) {
			$xdescrip = $this->request->post['descrip'];
		} elseif (!empty($maqui_info)) {
			$xdescrip = $maqui_info['descrip'];
		} else {
			$xdescrip = '';
		}		
		
		$data['descrips']=array();
		
		$this->load->model('user/user');
		$users = $this->model_user_user->getUsers();
		
		
		foreach ($users as $user) {
			if (isset($this->request->get['maqui_id'])){
				$ok = $this->model_dirsiscrud_maqui->getUsersxMaqui($this->request->get['maqui_id'],$user['user_id']);
			}else{
				$ok = 0;
			}
			$data['descrips'][]=array(
						'user_id' => $user['user_id'],
						'username' => $user['username'],
						'selected' => $ok );
		}
		
		
		//print_r($data['descrips']);
		
		if (isset($this->request->post['code'])) {
			$data['code'] = $this->request->post['code'];
		} elseif (!empty($maqui_info)) {
			$data['code'] = $maqui_info['code'];
		} else {
			$data['code'] = '';
		}
		
		if (isset($this->request->post['type'])) {
			$data['type'] = $this->request->post['type'];
		} elseif (!empty($maqui_info)) {
			$data['type'] = $maqui_info['type'];
		} else {
			$data['type'] = '';
		}	
		
		if (isset($this->request->post['ciclos'])) {
			$data['ciclos'] = $this->request->post['ciclos'];
		} elseif (!empty($maqui_info)) {
			$data['ciclos'] = $maqui_info['ciclos'];
		} else {
			$data['ciclos'] = '';
		}	
		
		if (isset($this->request->post['equipo_id'])) {
			$data['equipo_id'] = $this->request->post['equipo_id'];
		} elseif (!empty($maqui_info)) {
			$data['equipo_id'] = $maqui_info['equipo_id'];
		} else {
			$data['equipo_id'] = '';
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($maqui_info)) {
			$data['status'] = $maqui_info['status'];
		} else {
			$data['status'] = true;
		}

		
		$this->load->model('dirsiscrud/equipo');
		$data['equipos'] = $this->model_dirsiscrud_equipo->getEquipos();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrud/maqui_form', $data));
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'dirsiscrud/maqui')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 1) || (utf8_strlen(trim($this->request->post['name'])) > 200)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
	

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsiscrud/maqui')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			$this->load->model('dirsiscrud/maqui');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_dirsiscrud_maqui->getMaquis($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'maqui_id'    => $result['maqui_id'],
					'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'code'        => strip_tags(html_entity_decode($result['code'], ENT_QUOTES, 'UTF-8')),
					'status'      => $result['status']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	

	
	
	public function ciclos() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$this->load->language('dirsiscrud/maqui');
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->load->model('dirsiscrud/maqui');
		
		if (isset($this->request->get['maqui_id'])) {
			$data['maqui_id'] = $this->request->get['maqui_id'];
			$maqui_info=$this->model_dirsiscrud_maqui->getMaqui($data['maqui_id']);
		} else {
			$data['maqui_id'] = 0;
		}
		if (isset($maqui_info['name'])) {
			$data['maqui_name'] = $maqui_info['name'];
		} else {
			$data['maqui_name'] = $data['maqui_id'];
		}
		
		/*
		$data["date_added"]=date("d-m-Y");
		*/
		
		
		$data["type"]=1;
		$data["ciclos"]= $data["consumo"]=$data['maqui_ciclo_id'] = 0;
		$data["date_added"]=date("d-m-Y");
		$data["motivo"]="";
		
		if (isset($this->request->get['maqui_ciclo_id'])) {
			$data['maqui_ciclo_id'] = $this->request->get['maqui_ciclo_id'];
			$result = $this->model_dirsiscrud_matriz->getCiclo($data['maqui_ciclo_id'] );
			if ($result){
				$data["date_added"]=date("d-m-Y",strtotime($result['date_added']));
				$data["ciclos"]=$result['ciclos'];
				$data["motivo"]=$result['motivo'];
				$data["type"]=$result['type'];
			}
		}
		//print_r($data);
		$this->load->model('dirsiscrud/matriz');
		$matrizs = $this->model_dirsiscrud_matriz->getMatrizs();
		
		$this->load->model('dirsismrp/pr');
		$data['matrizs'] = array();
		foreach ($matrizs as $matriz) {
			$ok = 0;
			if ($matriz['status']!=0){
				$data['matrizs'][]=array(
				'matriz_id' => $matriz['matriz_id'],
				'name' => $matriz['name'],
				'code' => $matriz['code'],
				'selected' => $ok );
			}
		}
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('dirsiscrud/maqui_ciclo_form', $data));
	}
	public function getciclo(){
		
		$this->load->model('dirsiscrud/maqui');
		$ciclo = $this->model_dirsiscrud_maqui->getCiclo($this->request->get['maqui_ciclo_id']);
		$json =array('maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type'],
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'consumo' => $ciclo['consumo']
			);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function getmatrizxciclo(){
	
		
		$json =array();
		if (isset($this->request->get['maqui_ciclo_id'])) {
			$this->load->model('dirsiscrud/maqui');
			$json = $this->model_dirsiscrud_maqui->getMatrizxCiclo($this->request->get['maqui_ciclo_id'] );
		}		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));			
	}
	
	public function ciclo_history_pr() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);	
		$this->load->language('dirsiscrud/maqui');
		
		$data['ciclosfin']=$data['ciclos']=array();
		
		$data['maqui_id']=$this->request->get['maqui_id'];
		
		
		$data_filter = array (
			'filter_maqui_id' => $this->request->get['maqui_id']
		);
		$this->load->model('dirsiscrud/maqui');
		$cicloss = $this->model_dirsiscrud_maqui->getCiclos($data_filter);
		foreach ($cicloss as $ciclo) {
			
			$this->load->model('dirsiscrud/matriz');
			$matrizs = $this->model_dirsiscrud_maqui->getMatrizxCiclo($ciclo['maqui_ciclo_id']);
			if ($ciclo['status']==3){
				//finalizados
				$data['ciclosfin'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'matrizs' 		=> $matrizs,
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			}else{
				$data['ciclos'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'matrizs' 		=> $matrizs,
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			}
		};
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('dirsiscrud/maqui_ciclo_history_pr', $data));
	}
	
	
	public function ciclo_history() {
		
		
				ini_set('display_errors', 1);
		error_reporting(E_ALL);	
		
		
		$this->load->language('dirsiscrud/maqui');
		
		$data['ciclosfin']=$data['ciclos']=array();
		
		$data['maqui_id']=$this->request->get['maqui_id'];
		
		
		$data_filter = array (
			'filter_maqui_id' => $this->request->get['maqui_id']
		);
		$this->load->model('dirsiscrud/maqui');
		$cicloss = $this->model_dirsiscrud_maqui->getCiclos($data_filter);
		foreach ($cicloss as $ciclo) {
			
			$this->load->model('dirsiscrud/matriz');
			$matrizs = $this->model_dirsiscrud_maqui->getMatrizxCiclo($ciclo['maqui_ciclo_id']);
			if ($ciclo['status']==3){
				//finalizados
				$data['ciclosfin'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'matrizs' 		=> $matrizs,
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			}else{
				$data['ciclos'][]=array(
						'maqui_ciclo_id' => $ciclo['maqui_ciclo_id'],
						'date_added' => date("d-m-Y",strtotime($ciclo['date_added'])),
						'maqui_id' => $ciclo['maqui_id'],
						'motivo' => $ciclo['motivo'],
						'type' => $ciclo['type']=='1'?'Ciclos':'Etiquetas',
						'ciclos' => $ciclo['ciclos'],
						'status' => $ciclo['status'],
						'matrizs' 		=> $matrizs,
						'btn' => $ciclo['status']==0?'Activo':'--',
						'consumo' => $ciclo['consumo']
				);
			}
		};
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('dirsiscrud/maqui_ciclo_history', $data));
	}
	public function addciclos() {
		$this->load->language('dirsiscrud/maqui');
		$this->load->model('dirsiscrud/maqui');
		if ($this->request->post['maqui_ciclo_id']!=0){
			$this->model_dirsiscrud_maqui->editCiclos($this->request->post,$this->request->post['maqui_ciclo_id']);
		}else{
			$this->model_dirsiscrud_maqui->addCiclos($this->request->post,$this->request->get['maqui_id']);
		}
		$json['success'] = $this->language->get('text_success');
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function deleteciclos() {
		$this->load->language('dirsiscrud/maqui');
		$this->load->model('dirsiscrud/maqui');
		$this->model_dirsiscrud_maqui->deleteCiclos($this->request->get['maqui_ciclo_id']);
		$json['success'] = $this->language->get('text_success');
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	
	
	public function delciclosall() {
		

		$this->load->model('dirsismrp/pr');
		
		$this->model_dirsismrp_pr->delMatrizxPr($this->request->get['pr_id']);
	}
	

	public function statusciclos() {
		$this->load->language('dirsiscrud/maqui');
		$this->load->model('dirsiscrud/maqui');
		$json['sql']=$this->model_dirsiscrud_maqui->statusCiclos($this->request->get['maqui_id'],$this->request->get['maqui_ciclo_id'],$this->request->get['status']);
		$json['success'] = $this->language->get('text_success');
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function resetciclos() {
		$this->load->language('dirsiscrud/maqui');
		$this->load->model('dirsiscrud/maqui');
		$json['sql']=$this->model_dirsiscrud_maqui->resetCiclos($this->request->get['maqui_id'],$this->request->get['maqui_ciclo_id']);
		$json['success'] = $this->language->get('text_success');
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	
	
	
	
	public function addmatriz() {

		$this->load->model('dirsiscrud/maqui');
		$this->model_dirsiscrud_maqui->addMatriz($this->request->get['maqui_ciclo_id'],$this->request->get['matriz_id']);
	}	
	
	public function deletematriz() {

		$this->load->model('dirsiscrud/maqui');
		$this->model_dirsiscrud_maqui->deleteMatriz($this->request->get['cicloxmatriz_id']);
	}	
		
	
	public function getmatriz() {

		$data['histories'] = array();
		$this->load->model('dirsiscrud/maqui');
		$results=$this->model_dirsiscrud_maqui->getMatrizxCiclo($this->request->get['maqui_ciclo_id']);
		if (isset($this->request->get['vista'])){
			$vista=$this->request->get['vista'];
		}else{
			$vista=1;
		}
		foreach ($results as $result) {
			$data['histories'][] = array(
				'cicloxmatriz_id' => $result['cicloxmatriz_id'],
				'matriz_id' => $result['matriz_id'],
				'name'  => $result['name'],
				'code' 	=> $result['code'],
				'vista' => $vista
			);
		}
		$data['maqui_ciclo_id'] = $this->request->get['maqui_ciclo_id'];
		$data['user_token'] = $this->session->data['user_token'];
		$this->response->setOutput($this->load->view('dirsiscrud/ciclo_matriz', $data));		
	}	
	
		
		
	
	
	
	
	
	
	
}