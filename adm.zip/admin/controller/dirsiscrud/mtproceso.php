<?php
class ControllerDirsiscrudMtproceso extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');

		$this->getList();
	}

	public function revisar() {
		$this->load->model('dirsiscrud/mtproceso');
		$this->model_dirsiscrud_mtproceso->revisar();
	}
		
	
	public function mover() {
		$this->load->model('dirsiscrud/mtproceso');
		if (isset($this->request->get['accion'])){
			$this->model_dirsiscrud_mtproceso->moverMtproceso($this->request->get['mtproceso_id'], $this->request->get['accion']);
		}else{
			$this->model_dirsiscrud_mtproceso->moverMtproceso2($this->request->get['mtproceso_id'], $this->request->get['sort_order']);
		}
		echo "ok";
	}
	
	
	public function add() {
		
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsiscrud_mtproceso->addMtproceso($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			

			
			if (isset($this->request->get['accion'])) {
				$this->response->redirect($this->url->link($this->request->get['accion'], 'user_token=' . $this->session->data['user_token'], true));
			}else{
				$url = '';
				if (isset($this->request->get['filter_motivo'])) {
					$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
				}
				if (isset($this->request->get['filter_maqui_id'])) {
					$url .= '&filter_maqui_id=' . urlencode(html_entity_decode($this->request->get['filter_maqui_id'], ENT_QUOTES, 'UTF-8'));
				}	
				
				if (isset($this->request->get['filter_manutentor'])) {
					$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
				}
				
				if (isset($this->request->get['filter_mtstatus_id'])) {
					$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
				}
				if (isset($this->request->get['filter_date_desde'])) {
					$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
				}
				if (isset($this->request->get['filter_date_hasta'])) {
					$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
				}			
				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}
				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}
				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}
				$this->response->redirect($this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true));
			}
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			$this->model_dirsiscrud_mtproceso->editMtproceso($this->request->get['mtproceso_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			if (isset($this->request->get['accion'])) {
				$this->response->redirect($this->url->link($this->request->get['accion'], 'user_token=' . $this->session->data['user_token'], true));
			}else{
				$url = '';
				if (isset($this->request->get['filter_motivo'])) {
					$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
				}
				if (isset($this->request->get['filter_maqui_id'])) {
					$url .= '&filter_maqui_id=' . urlencode(html_entity_decode($this->request->get['filter_maqui_id'], ENT_QUOTES, 'UTF-8'));
				}
				
				if (isset($this->request->get['filter_manutentor'])) {
					$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
				}
				
				if (isset($this->request->get['filter_mtstatus_id'])) {
					$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
				}
				if (isset($this->request->get['filter_date_desde'])) {
					$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
				}
				if (isset($this->request->get['filter_date_hasta'])) {
					$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
				}
				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}
				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}
				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}
				$this->response->redirect($this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true));
			}
		}

		$this->getForm();
	}
	
	public function editstatus() {
		
		
			//print_r($this->request->get);
			$this->load->model('dirsiscrud/mtproceso');
			$json=$this->model_dirsiscrud_mtproceso->editstatusMtproceso($this->request->get);
		
		return;
		
		/*
		$data=array("mtstatus_id" => 4,
				   "mtproceso_id" => 11);
		$this->load->model('dirsiscrud/mtproceso');
		$json=$this->model_dirsiscrud_mtproceso->editstatusMtproceso($data);
		print_r($json);
		die;
		*/
		 
		
		/*
		$json=array();
		$this->load->language('dirsiscrud/mtproceso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/mtproceso');
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$json=$this->model_dirsiscrud_mtproceso->editstatusMtproceso($this->request->post);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
		*/
		
	}
	
	public function editconfirma() {
		

		
		$this->load->language('dirsiscrud/mtproceso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/mtproceso');
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$this->model_dirsiscrud_mtproceso->editconfirmaMtproceso($this->request->post);
		}
	}
	public function editvalidado() {
		

		
		$this->load->language('dirsiscrud/mtproceso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/mtproceso');
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			$this->model_dirsiscrud_mtproceso->editvalidadoMtproceso($this->request->post);
		}
	}	

	public function delete() {
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $mtproceso_id) {
				$this->model_dirsiscrud_mtproceso->deleteMtproceso($mtproceso_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_motivo'])) {
				$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
			}
			
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . urlencode(html_entity_decode($this->request->get['filter_maqui_id'], ENT_QUOTES, 'UTF-8'));
			}
			
			if (isset($this->request->get['filter_manutentor'])) {
				$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
			}			
			

			if (isset($this->request->get['filter_mtstatus_id'])) {
				$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}

			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	public function copy() {
		

		
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');

		if (isset($this->request->get['mtproceso_id'])) {
			$this->model_dirsiscrud_mtproceso->copyMtproceso($this->request->get['mtproceso_id']);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_motivo'])) {
				$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_maqui_id'])) {
				$url .= '&filter_maqui_id=' . urlencode(html_entity_decode($this->request->get['filter_maqui_id'], ENT_QUOTES, 'UTF-8'));
			}
			
			if (isset($this->request->get['filter_manutentor'])) {
				$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
			}			

			if (isset($this->request->get['filter_mtstatus_id'])) {
				$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}

			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	
	public function excel() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		if (isset($this->request->get['filter_motivo'])) {
			$filter_motivo = $this->request->get['filter_motivo'];
		} else {
			$filter_motivo = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$filter_manutentor = $this->request->get['filter_manutentor'];
		} else {
			$filter_manutentor = '';
		}		

		if (isset($this->request->get['filter_mtstatus_id'])) {
			$filter_mtstatus_id = $this->request->get['filter_mtstatus_id'];
		} else {
			$filter_mtstatus_id = '';
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'maquina';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$filter_data = array(
			'filter_motivo'          => $filter_motivo,
			'filter_maqui_id'        => $filter_maqui_id,
			'filter_manutentor'        => $filter_manutentor,
			'filter_mtstatus_id'     => $filter_mtstatus_id,
			'filter_date_desde'      => $filter_date_desde,
			'filter_date_hasta'      => $filter_date_hasta,
			'sort'                   => $sort,
			'order'                  => $order
		);
		
		$this->load->model('dirsiscrud/mtproceso');
		$mtproceso_total = $this->model_dirsiscrud_mtproceso->getTotalMtprocesos($filter_data);
		$results = $this->model_dirsiscrud_mtproceso->getMtprocesos($filter_data);

		
		$datos[]=array(
			"ID",
			"Tarea",  
			"Fecha Registro", 
			"Pedido Por",
			"Registrado Por",  
			"Motivo",			
			"Estado",
			"Maquina",
			"Fecha Prom.",
			"Fecha Vto.",
			"Confirmado",
			"Confirmador",
			"Fecha Conf.",
			"Validado",
			"Validador",
			"Fecha Valid."
		);
		
		foreach ($results as $result) {
			$datos[] = array(
				$result['mtproceso_id'],
				$result['tarea'],
				date("d-m-Y", strtotime($result['date_added'])),
				$result['user_pedidoname'],
				$result['user_registroname'],
				$result['motivo'],
				$result['mtstatus'],
				$result['maqui_id']?$result['maqui_name']:"",
				date("d-m-Y", strtotime($result['date_prome'])),
				date("d-m-Y", strtotime($result['date_vto'])),
				$result['confirmado']?"SI":"NO",
				$result['confirmado']?date("d-m-Y", strtotime($result['date_conf'])):"",
				$result['confirmado']?$result['user_confname']:"",
				$result['validado']?"SI":"NO",
				$result['validado']?date("d-m-Y", strtotime($result['date_valid'])):"",
				$result['validado']?$result['user_validname']:""
			);
		}
		
		$this->generaexcel("mantenimiento",$datos);
	}
	function generaexcel($titulo,$datos){
		$row=1;
		$archivo = $titulo.".xlsx";
		if (file_exists($archivo)){
			unlink($archivo);
		}
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		foreach ($datos as $result) {
			//print_r($result);
			$elem=count($result);
			
			
			$col="A";
			for ($i = 0; $i < $elem; ++$i) {
				$ubi=$col.$row;
				//echo $ubi;
				
				$objPHPExcel->getActiveSheet()->setCellValue($ubi,$result[$i]);
				$col++;
				
			}
			//echo "<hr>";
			$row++;
		}
		
		
		//$posfin=chr(65+($elem-1));
		$col--;
		$objPHPExcel->getActiveSheet()->getStyle('A1:'.$col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FF8916');	

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		echo $archivo;
	}

	protected function getList() {
		
		$data[ 'nivel' ] = 9;
		$this->load->model( 'user/user' );
		$user_info = $this->model_user_user->getUser( $this->user->getId() );
		if ( $user_info ) {
			$nivel = $user_info[ 'user_group_nivel' ];
			$data[ 'nivel' ] = $nivel;
		}
		
		if (isset($this->request->get['filter_motivo'])) {
			$filter_motivo = $this->request->get['filter_motivo'];
		} else {
			$filter_motivo = '';
		}
		if (isset($this->request->get['filter_maqui_id'])) {
			$filter_maqui_id = $this->request->get['filter_maqui_id'];
		} else {
			$filter_maqui_id = '';
		}
		if (isset($this->request->get['filter_maqui'])) {
			$filter_maqui = $this->request->get['filter_maqui'];
		} else {
			$filter_maqui = '';
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$filter_manutentor = $this->request->get['filter_manutentor'];
		} else {
			$filter_manutentor = '';
		}
		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$filter_mtstatus_id = $this->request->get['filter_mtstatus_id'];
		} else {
			$filter_mtstatus_id = '';
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'm.date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}		

		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$url1=$url."&code=1";
		$data['add'] = $this->url->link('dirsiscrud/mtproceso/add', 'user_token=' . $this->session->data['user_token'] . $url1, true);
		
		$url2=$url."&code=2";
		$data['add2'] = $this->url->link('dirsiscrud/mtproceso/add', 'user_token=' . $this->session->data['user_token'] . $url2, true);
		
		$data['delete'] = $this->url->link('dirsiscrud/mtproceso/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_mtproceso_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.mtproceso_id' . $url, true);
		$data['sort_motivo'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.motivo' . $url, true);
		$data['sort_maqui'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.maqui' . $url, true);
		
		$data['sort_user_pedido'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.user_pedido' . $url, true);
		$data['sort_user_registro'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.user_registro' . $url, true);
		
		$data['sort_mtstatus_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.mtstatus_id' . $url, true);
		$data['sort_tarea_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.tarea_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.date_added' . $url, true);
		$data['sort_order'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.sort_order' . $url, true);		

		$url = '';

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}	
		
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}		

		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
/*
		$pagination = new Pagination();
		$pagination->total = $mtproceso_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($mtproceso_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($mtproceso_total - $this->config->get('config_limit_admin'))) ? $mtproceso_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $mtproceso_total, ceil($mtproceso_total / $this->config->get('config_limit_admin')));
*/
		$data['filter_motivo'] = $filter_motivo;
		$data['filter_maqui'] = $filter_maqui;
		$data['filter_manutentor'] = $filter_manutentor;
		$data['filter_mtstatus_id'] = $filter_mtstatus_id;
		$data['filter_date_hasta'] = $data['filter_date_desde'] = "";
		if (!empty($filter_date_desde)){
			$data['filter_date_desde'] = date("d-m-Y",strtotime($filter_date_desde));
		}
		if (!empty($filter_date_hasta)){
			$data['filter_date_hasta'] = date("d-m-Y",strtotime($filter_date_hasta));
		}
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->load->model('dirsiscrud/mtstatus');
		$data['mtstatuss'] = $this->model_dirsiscrud_mtstatus->getMtstatuss();	
		
/*
			$this->load->model('dirsiscrud/operador');
			$data['operadors'] = $this->model_dirsiscrud_operador->getOperadors();
*/
			$this->load->model('dirsiscrud/manutentor');
			$data['manutentors'] = $this->model_dirsiscrud_manutentor->getManutentors();

		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrud/mtproceso_list', $data));
	}
	
	public function getListitem() {
		
		
		ini_set('display_errors', 1);
		error_reporting(E_ALL);			
		
		$this->load->language('dirsiscrud/mtproceso');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrud/mtproceso');		
		
		if (isset($this->request->get['filter_motivo'])) {
			$filter_motivo = $this->request->get['filter_motivo'];
		} else {
			$filter_motivo = '';
		}
		if (isset($this->request->get['filter_maqui'])) {
			$filter_maqui = $this->request->get['filter_maqui'];
		} else {
			$filter_maqui = '';
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$filter_manutentor = $this->request->get['filter_manutentor'];
		} else {
			$filter_manutentor = '';
		}		
		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$filter_mtstatus_id = $this->request->get['filter_mtstatus_id'];
		} else {
			$filter_mtstatus_id = '';
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'm.date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		
		
		$data['sort_mtproceso_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.mtproceso_id' . $url, true);
		$data['sort_motivo'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.motivo' . $url, true);
		$data['sort_maqui'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.maqui' . $url, true);
		
		$data['sort_user_pedido'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.user_pedido' . $url, true);
		$data['sort_user_registro'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.user_registro' . $url, true);
		
		$data['sort_mtstatus_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.mtstatus_id' . $url, true);
		$data['sort_tarea_id'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.tarea_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.date_added' . $url, true);
		$data['sort_order'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&sort=m.sort_order' . $url, true);
		
		$url = '';
		
		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['mtprocesos'] = array();
		$filter_data = array(
			'filter_motivo'            => $filter_motivo,
			'filter_maqui'             => $filter_maqui,
			'filter_manutentor'             => $filter_manutentor,
			'filter_mtstatus_id'       => $filter_mtstatus_id,
			'filter_date_desde'        => $filter_date_desde,
			'filter_date_hasta'        => $filter_date_hasta,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);

		$mtproceso_total = $this->model_dirsiscrud_mtproceso->getTotalMtprocesos($filter_data);
		//print_r($filter_data);
		$results = $this->model_dirsiscrud_mtproceso->getMtprocesos($filter_data);
		foreach ($results as $result) {
			
			if ($result['tarea_id']!=2){
				$edit=$this->url->link('dirsiscrud/mtproceso/edit', 'user_token=' . $this->session->data['user_token'] . '&mtproceso_id=' . $result['mtproceso_id'] . $url. '&code=2', true);
			}else{
				$edit=$this->url->link('dirsiscrud/mtproceso/edit', 'user_token=' . $this->session->data['user_token'] . '&mtproceso_id=' . $result['mtproceso_id'] . $url. '&code=1', true);
			}
				
			if (empty($result['maqui'])){
				$maqui=$result['maqui_name'];
				if ($result['maqui_id']!=0){
					$this->model_dirsiscrud_mtproceso->editmaquiMtproceso($result['mtproceso_id'],$result['maqui_name']);
				}
			}else{
				$maqui=$result['maqui'];
			}
				
			$data['mtprocesos'][] = array(
				'mtproceso_id'    => $result['mtproceso_id'],
				'sort_order'    => $result['sort_order'],
				'histories'    => $result['histories'],
				'tarea_id'           => $result['tarea_id'],
				'tarea'           => $result['tarea'],
				'tareacolor'           => $result['tareacolor'],
				'date_added'     	=> date("d-m-Y H:i", strtotime($result['date_added'])),
				'user_pedido'           => $result['user_pedido'],
				'user_pedidoname'           => $result['user_pedidoname'],
				'user_asig'           => $result['user_asig'],
				'user_asigname'           => $result['user_asigname'],
				'user_registroname'           => $result['user_registroname'],
				'user_registro'           => $result['user_registro'],
				'oper_asig'           => $result['oper_asig'],
				'motivolong'           => $result['motivo'],
				'motivo'           => 
				utf8_substr(trim(strip_tags(html_entity_decode($result['motivo'], ENT_QUOTES, 'UTF-8'))), 0, 25) . '..',				
				'pr_id'         => $result['mtstatus_id'],
				'maqui_id'         => $result['maqui_id'],
				'maqui_name'         => $maqui,
				'date_prome'         => date("d-m-Y", strtotime($result['date_prome'])),
				'date_vto'         => date("d-m-Y", strtotime($result['date_vto'])),
				'mtstatus_id'         => $result['mtstatus_id'],
				'mtstatus'         => $result['mtstatus'],
				'mtstatuscolor'      => $result['mtstatuscolor'],
				'ciclico_id'         => $result['ciclico_id'],
				'confirmado'         => $result['confirmado'],
				'date_conf'         => date("d-m-Y", strtotime($result['date_conf'])),
				'user_conf'         => $result['user_conf'],
				'validado'         => $result['validado'],
				'date_valid'         => date("d-m-Y", strtotime($result['date_valid'])),
				'user_valid'         => $result['user_valid'],
				'copy'           => $this->url->link('dirsiscrud/mtproceso/copy', 'user_token=' . $this->session->data['user_token'] . '&mtproceso_id=' . $result['mtproceso_id'] . $url, true),
				'edit'           => $edit
			);
		}
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $mtproceso_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($mtproceso_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($mtproceso_total - $this->config->get('config_limit_admin'))) ? $mtproceso_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $mtproceso_total, ceil($mtproceso_total / $this->config->get('config_limit_admin')));

		$data['filter_motivo'] = $filter_motivo;
		$data['filter_maqui'] = $filter_maqui;
		$data['filter_manutentor'] = $filter_manutentor;
		$data['filter_mtstatus_id'] = $filter_mtstatus_id;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->response->setOutput($this->load->view('dirsiscrud/mtproceso_listitem', $data));
	}

	protected function getForm() {
		
		

		
		$data['text_form'] = !isset($this->request->get['mtproceso_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['mtproceso_id'])) {
			$data['mtproceso_id'] = $this->request->get['mtproceso_id'];
		} else {
			$data['mtproceso_id'] = 0;
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['motivo'])) {
			$data['error_motivo'] = $this->error['motivo'];
		} else {
			$data['error_motivo'] = '';
		}
		
		if (isset($this->error['tarea_id'])) {
			$data['error_tarea_id'] = $this->error['tarea_id'];
		} else {
			$data['error_tarea_id'] = '';
		}		
		
		if (isset($this->error['user_pedido'])) {
			$data['error_user_pedido'] = $this->error['user_pedido'];
		} else {
			$data['error_user_pedido'] = '';
		}	
		
		if (isset($this->error['ciclico_id'])) {
			$data['error_ciclico_id'] = $this->error['ciclico_id'];
		} else {
			$data['error_ciclico_id'] = '';
		}	
		
		if (isset($this->error['mtstatus_id'])) {
			$data['error_mtstatus_id'] = $this->error['mtstatus_id'];
		} else {
			$data['error_mtstatus_id'] = '';
		}			

		$url = '';

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_maqui'])) {
			$url .= '&filter_maqui=' . urlencode(html_entity_decode($this->request->get['filter_maqui'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_manutentor'])) {
			$url .= '&filter_manutentor=' . urlencode(html_entity_decode($this->request->get['filter_manutentor'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_mtstatus_id'])) {
			$url .= '&filter_mtstatus_id=' . $this->request->get['filter_mtstatus_id'];
		}
		
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		if (isset($this->request->get['accion'])) {
			$data['cancel'] = $this->url->link($this->request->get['accion'], 'user_token=' . $this->session->data['user_token'] . $url, true);
			$url.= "&accion=".$this->request->get['accion'];
		}else{
			$data['cancel'] = $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . $url, true);
		}		

		if (!isset($this->request->get['mtproceso_id'])) {
			$data['action'] = $this->url->link('dirsiscrud/mtproceso/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscrud/mtproceso/edit', 'user_token=' . $this->session->data['user_token'] . '&mtproceso_id=' . $this->request->get['mtproceso_id'] . $url, true);
		}
		

		
		
		if (isset($this->request->post['pr_id'])) {$data['pr_id'] = $this->request->post['pr_id'];} elseif (!empty($mtproceso_info)) {$data['pr_id'] = $mtproceso_info['pr_id'];} else {$data['pr_id'] = '';}
		

		if (isset($this->request->get['mtproceso_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$mtproceso_info = $this->model_dirsiscrud_mtproceso->getMtproceso($this->request->get['mtproceso_id']);
		}
		
		if (isset($this->request->get['code'])) {
			$data['code'] = $this->request->get['code'];
		}else{
			$data['code'] = '1';
		}		
		
		if (isset($this->request->post['tarea_id'])) {
			$data['tarea_id'] = $this->request->post['tarea_id'];
		} elseif (!empty($mtproceso_info)) {
			$data['tarea_id'] = $mtproceso_info['tarea_id'];
		} else {
			$data['tarea_id'] = '1';
		}

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($mtproceso_info)) {
			$data['date_added'] = date("d-m-Y",strtotime($mtproceso_info['date_added']));
		} else {
			$data['date_added'] = date("d-m-Y");
		}
		
		
		
		if (isset($this->request->post['equipo_id'])) {
			$data['equipo_id'] = $this->request->post['equipo_id'];
		} elseif (!empty($mtproceso_info)) {
			$data['equipo_id'] = $mtproceso_info['equipo_id'];
		} else {
			$data['equipo_id'] = '';
		}
		
//BUSCANAME DE MAQUI		
		if (isset($this->request->post['maqui_id'])) {
			$data['maqui_id'] = $this->request->post['maqui_id'];
		} elseif (!empty($mtproceso_info)) {
			$data['maqui_id'] = $mtproceso_info['maqui_id'];
		} else {
			$data['maqui_id'] = '';
		}
		
		if (isset($this->request->post['maqui'])) {
			$data['maqui'] = $this->request->post['maqui'];
		} elseif (!empty($mtproceso_info)) {
			$data['maqui'] = $mtproceso_info['maqui'];
		} else {
			$data['maqui'] = '';
		}
		
		if (isset($this->request->post['motivo'])) {
			$data['motivo'] = $this->request->post['motivo'];
		} elseif (!empty($mtproceso_info)) {
			$data['motivo'] = $mtproceso_info['motivo'];
		} else {
			$data['motivo'] = '';
		}
		
		if (isset($this->request->post['parado'])) {
			$data['parado'] = $this->request->post['parado'];
		} elseif (!empty($mtproceso_info)) {
			$data['parado'] = $mtproceso_info['parado'];
		} else {
			$data['parado'] = '0';
		}	
		
		if (isset($this->request->post['image_1'])) {
			$data['image_1'] = $this->request->post['image_1'];
		} elseif (!empty($mtproceso_info)) {
			$data['image_1'] = $mtproceso_info['image_1'];
		} else {
			$data['image_1'] = '';
		}			
		
		
		$this->load->model('tool/image');
		$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['placeholder'] = $this->model_tool_image->resize('loading.gif', 100, 100);
		$data['directory'] = '';
		
		if (is_file(DIR_IMAGE . "catalog/".$data['image_1'])) {
			$data['thumb'] = $this->model_tool_image->resize("catalog/".$data['image_1'], 100, 100);
		}
		

		$data['user_pedido'] = $this->user->getUsername();
		
		if (isset($this->request->post['user_registro'])) {$data['user_registro'] = $this->request->post['user_registro'];} elseif (!empty($mtproceso_info)) {$data['user_registro'] = $mtproceso_info['user_registro'];} else {$data['user_registro'] = '';}
		
		if (isset($this->request->post['date_prome'])) {$data['date_prome'] = $this->request->post['date_prome'];} elseif (!empty($mtproceso_info)) {$data['date_prome'] = date("d-m-Y",strtotime($mtproceso_info['date_prome']));} else {$data['date_prome'] = date("d-m-Y");}
		
		if (isset($this->request->post['date_vto'])) {$data['date_vto'] = $this->request->post['date_vto'];} elseif (!empty($mtproceso_info)) {$data['date_vto'] = date("d-m-Y",strtotime($mtproceso_info['date_vto']));} else {$data['date_vto'] = date("d-m-Y");}
		
		if (isset($this->request->post['mtstatus_id'])) {$data['mtstatus_id'] = $this->request->post['mtstatus_id'];} elseif (!empty($mtproceso_info)) {$data['mtstatus_id'] = $mtproceso_info['mtstatus_id'];} else {$data['mtstatus_id'] = $this->config->get('config_mtstatus_default');}
		
		if (isset($this->request->post['ciclico_id'])) {$data['ciclico_id'] = $this->request->post['ciclico_id'];} elseif (!empty($mtproceso_info)) {$data['ciclico_id'] = $mtproceso_info['ciclico_id'];} else {$data['ciclico_id'] = $this->config->get('config_ciclico_default');}
			
		if (isset($this->request->post['confirmado'])) {$data['confirmado'] = $this->request->post['confirmado'];} elseif (!empty($mtproceso_info)) {$data['confirmado'] = $mtproceso_info['confirmado'];} else {$data['confirmado'] = '';}
		
		if (isset($this->request->post['validado'])) {$data['validado'] = $this->request->post['validado'];} elseif (!empty($mtproceso_info)) {$data['validado'] = $mtproceso_info['validado'];} else {$data['validado'] = '';}
		
		if (isset($this->request->post['date_conf'])) {$data['date_conf'] = $this->request->post['date_conf'];} elseif (!empty($mtproceso_info)) {$data['date_conf'] = $mtproceso_info['date_conf'];} else {$data['date_conf'] = '';}
		
		if (isset($this->request->post['user_conf'])) {$data['user_conf'] = $this->request->post['user_conf'];} elseif (!empty($mtproceso_info)) {$data['user_conf'] = $mtproceso_info['user_conf'];} else {$data['user_conf'] = '';}
		
		if (isset($this->request->post['date_valid'])) {$data['date_valid'] = $this->request->post['date_valid'];} elseif (!empty($mtproceso_info)) {$data['date_valid'] = $mtproceso_info['date_valid'];} else {$data['date_valid'] = '';}
		
		if (isset($this->request->post['user_valid'])) {$data['user_valid'] = $this->request->post['user_valid'];} elseif (!empty($mtproceso_info)) {$data['user_valid'] = $mtproceso_info['user_valid'];} else {$data['user_valid'] = '';}
		
		if (isset($this->request->post['motivo'])) {$data['motivo'] = $this->request->post['motivo'];} elseif (!empty($mtproceso_info)) {$data['motivo'] = $mtproceso_info['motivo'];} else {$data['motivo'] = '';}
		
		if (isset($this->request->post['config_operador'])) {
			$data['config_operador'] = json_decode($this->request->post['config_operador'], true);
		} elseif (!empty($mtproceso_info)) {
			$data['config_operador'] = json_decode($mtproceso_info['oper_asig'], true);
		} else {
			$data['config_operador'] = '';
		}
		
//GRILLA DE MATRIZ			
		$this->load->model('dirsiscrud/ciclico');
		$data['ciclicos'] = $this->model_dirsiscrud_ciclico->getCiclicos();
		$this->load->model('dirsiscrud/tarea');
		$data['tareas'] = $this->model_dirsiscrud_tarea->getTareas();
		$this->load->model('dirsiscrud/manutentor');
		$data['manutentors'] = $this->model_dirsiscrud_manutentor->getManutentors();	
		//$this->load->model('dirsiscrud/mtproceso');
		//$data['mtprocesos'] = $this->model_dirsiscrud_mtproceso->getMtprocesos();
		$this->load->model('dirsiscrud/mtstatus');
		$data['mtstatuss'] = $this->model_dirsiscrud_mtstatus->getMtstatuss();	
		
		$this->load->model('dirsiscrud/equipo');
		$data['equipos'] = $this->model_dirsiscrud_equipo->getEquipos();		
		
		$this->load->model('dirsiscrud/maqui');
		$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis();		
		
		$this->load->model('dirsiscrud/matriz');
		$data['matrizs'] = $this->model_dirsiscrud_matriz->getMatrizs();
		
		

		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$data['user_token'] = $this->session->data['user_token'];

		if ($data['tarea_id'] ==1) {
			$this->response->setOutput($this->load->view('dirsiscrud/mtproceso_formcorrectivo', $data));	
		}else{
			$this->response->setOutput($this->load->view('dirsiscrud/mtproceso_formpreventivo', $data));	
		}
		
	}

	protected function validateForm() {
		
		if (!$this->user->hasPermission('modify', 'dirsiscrud/mtproceso')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*
		if ($this->request->post['tarea_id'] == 0){
			$this->error['tarea_id'] = $this->language->get('error_tarea_id');
		}
		
		if ($this->request->post['user_pedido'] == 0){
			$this->error['user_pedido'] = $this->language->get('error_user_pedido');
		}	

		if ($this->request->post['ciclico_id'] == 0){
			$this->error['ciclico_id'] = $this->language->get('error_ciclico_id');
		}			
		
		if ((utf8_strlen($this->request->post['motivo']) < 1) || (utf8_strlen(trim($this->request->post['motivo'])) > 200)) {
			$this->error['motivo'] = $this->language->get('error_motivo');
		}	
		
		if ($this->request->post['mtstatus_id'] == 0){
			$this->error['mtstatus_id'] = $this->language->get('error_mtstatus_id');
		}		
*/		

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
	

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsiscrud/mtproceso')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function getmtprocesoperfil() {
		
		$this->load->language('dirsiscrud/mtproceso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/mtproceso');
		
		if (isset($this->request->get['mtproceso_id'])) {
			$mtproceso_info = $this->model_dirsiscrud_mtproceso->getMtproceso($this->request->get['mtproceso_id']);
			if ($mtproceso_info){
				$data['mtproceso_id'] = $mtproceso_info['mtproceso_id'];
				$data['tarea_id'] = $mtproceso_info['tarea_id'];
				$data['date_added'] = date("d-m-Y H:i",strtotime($mtproceso_info['date_added']));
				if (!is_null($mtproceso_info['date_status'])){
					$data['date_status'] = date("d-m-Y H:i",strtotime($mtproceso_info['date_status']));				
				}
				
				$data['equipo_id'] = $mtproceso_info['equipo_id'];
				$data['equipo'] = $mtproceso_info['equipo'];
				
				$data['maqui_id'] = $mtproceso_info['maqui_id'];
				$data['maqui'] = $mtproceso_info['maqui'];
				
				$data['user_registro'] = $mtproceso_info['user_registro'];
				$data['date_prome'] = date("d-m-Y",strtotime($mtproceso_info['date_prome']));
				$data['date_vto'] = date("d-m-Y",strtotime($mtproceso_info['date_vto']));

				$data['mtstatus_id'] = $mtproceso_info['mtstatus_id'];
				$data['ciclico_id'] = $mtproceso_info['ciclico_id'];
				$data['confirmado'] = $mtproceso_info['confirmado'];
				$data['validado'] = $mtproceso_info['validado'];
				$data['date_conf'] = $mtproceso_info['date_conf'];
				$data['user_conf'] = $mtproceso_info['user_conf'];
				$data['date_valid'] = $mtproceso_info['date_valid'];
				$data['user_valid'] = $mtproceso_info['user_valid'];
				$data['motivo'] = $mtproceso_info['motivo'];
				$data['config_operador'] = json_decode($mtproceso_info['oper_asig'], true);
$this->load->model('tool/image');
				$this->load->model('dirsiscrud/mtstatus');
				$data['mtstatuss'] = $this->model_dirsiscrud_mtstatus->getMtstatuss();	
				
				
				if ($mtproceso_info['image_1']!=''){

					
					$thumb = $this->model_tool_image->resize('no_image.png', 40, 40);
if (is_file(DIR_IMAGE . "catalog/".$mtproceso_info['image_1'])) {
	$image_1 = $this->model_tool_image->resize("catalog/".$mtproceso_info['image_1'], 500, 500);
} else {
	$image_1 = "";
}
					$data['image_1'] =$image_1;
				}
				
				

				$data['user_token'] = $this->session->data['user_token'];

				$this->response->setOutput($this->load->view('dirsiscrud/mtprocesoperfil_modal', $data));	
			}
		
		}
	}
	
	//RESUMEN
	
	
	public function recargarresumenmanutentor2() {
		$this->load->model('dirsiscrud/mtproceso');
		$json['manutentor'] = $this->model_dirsiscrud_mtproceso->getResumenmanutentor2();
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function recargarresumenmanutentor3() {
		$this->load->model('dirsiscrud/mtproceso');
		
		//$json['manutentors2'] = $this->model_dirsiscrud_mtproceso->getResumenmanutentor2();
		
		$data['manutentors3'] = $this->model_dirsiscrud_mtproceso->getResumenmanutentor3();
		
		$this->response->setOutput($this->load->view('dirsiscrud/mtproceso_rm3', $data));
	}
	
	
	public function recargaresumen() {
		$this->load->model('dirsiscrud/mtproceso');
		$results = $this->model_dirsiscrud_mtproceso->getMtrprocesos();
		$json = array();
		foreach ($results as $result) {
			$json['status'][] = array(
				'mtstatus_id' => $result['mtstatus_id'],
				'mtstatuscolor' => $result['mtstatuscolor'],
				'mtstatus' => $result['mtstatus'],
				'cantidad' => $result['cantidad'],
				'filter' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&filter_mtstatus_id=' . $result['mtstatus_id'], true)
			);
		}	
		$results = $this->model_dirsiscrud_mtproceso->getMtrprocesosxmanutentor();
		$json['sql'][]=$results;
		$name="";
		$cantidad=$vuelta=0;
		foreach ($results as $result) {
			if ($name!=$result['name'] and $vuelta!=0){
				if (trim($result['name'])!=''){
					$json['manutentor'][] = array(
					'name' => $name,
					'cantidad' => $cantidad,
					'filter' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&filter_manutentor=' . $name, true));
				}
				$name=$result['name'];
				$cantidad=0;
			}
			$cantidad++;
			$vuelta++;
		}		
		if ($cantidad!=0){
			$json['manutentor'][] = array(
				'name' => $name,
				'cantidad' => $cantidad,
				'filter' => $this->url->link('dirsiscrud/mtproceso', 'user_token=' . $this->session->data['user_token'] . '&filter_manutentor=' . $name, true));
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	//HISTORY
	public function edithistory() {
		
		$this->load->language('dirsiscrud/mtproceso');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/mtproceso');
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->request->get['mtproceso_id'])){
			$data['mtproceso_id']=$this->request->get['mtproceso_id'];
			$data['date_added'] =date("d-m-Y");
			
			
			/*
			$this->load->model('dirsiscrud/operador');
			$data['operadors'] = $this->model_dirsiscrud_operador->getOperadors();

			$this->load->model('dirsiscrud/manutentor');
			$data['manutentors'] = $this->model_dirsiscrud_manutentor->getManutentors();
			*/
			$data['image'] = '';
			$this->load->model('tool/image');
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['placeholder'] = $this->model_tool_image->resize('loading.gif', 100, 100);
			$data['directory'] = '';
			
			$this->load->model('dirsiscrud/mtstatus');
			$data['mtstatuss'] = $this->model_dirsiscrud_mtstatus->getMtstatuss();
			
			$this->response->setOutput($this->load->view('dirsiscrud/mtprocesohistory_modal', $data));
		}
	}
	
	public function gethistorycontar() {
		$acum=0;
		$this->load->model('dirsiscrud/mtproceso');
		if (isset($this->request->get['mtproceso_id'])){
			$results = $this->model_dirsiscrud_mtproceso->getMtprocesohistory($this->request->get['mtproceso_id']);
			foreach ($results as $result) {
				$acum=$acum+1;
			}
		}
		echo $acum;
	}
	public function gethistory() {
	
		
				ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		$json=array();
		$this->load->model('dirsiscrud/mtproceso');
		if (isset($this->request->get['mtproceso_id'])){
			$this->load->model('tool/image');
			
			$results = $this->model_dirsiscrud_mtproceso->getMtprocesohistory($this->request->get['mtproceso_id']);
			foreach ($results as $result) {
				
				$thumb = $this->model_tool_image->resize('no_image.png', 40, 40);
				if (is_file(DIR_IMAGE . "catalog/".$result['image_1'])) {
					$image_1 = $this->model_tool_image->resize("catalog/".$result['image_1'], 500, 500);
				} else {
					$image_1 = "";
				}
				if (is_file(DIR_IMAGE . "catalog/".$result['image_2'])) {
					$image_2 = $this->model_tool_image->resize("catalog/".$result['image_2'], 500, 500);
				} else {
					$image_2 = "";
				}
				if (is_file(DIR_IMAGE . "catalog/".$result['image_3'])) {
					$image_3 = $this->model_tool_image->resize("catalog/".$result['image_3'], 500, 500);
				} else {
					$image_3 = "";
				}

				$json[] = array(
					'mtproceso_id'    => $result['mtproceso_id'],
					'manutentor_id'    => $result['manutentor_id'],
					'manutentor_name'    => $this->model_dirsiscrud_mtproceso->getMtprocesohistory_manutenores($result['manutentor']),
					'motivo'           => trim(html_entity_decode($result['motivo'], ENT_QUOTES, 'UTF-8')),
					'tarea'           => trim(html_entity_decode($result['tarea'], ENT_QUOTES, 'UTF-8')),
					'date_added'     => date("d-m-Y", strtotime($result['date_added'])),
					'mtprocesohistory_id'    => $result['mtprocesohistory_id'],
					'user_id'    => $result['user_id'],
					'status'    => $result['status'],
					'thumb' => $thumb,
					"image_1" => $image_1,
					"image_2" => $image_2,
					"image_3" => $image_3				
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));			

	}
	public function addhistory() {
		$results=0;
		if (isset($this->request->post)){
			$this->load->model('dirsiscrud/mtproceso');
			$results=$this->model_dirsiscrud_mtproceso->addMtprocesohistory($this->request->post);
		}
		echo $results;
	}
	
	public function delhistory() {
		if (isset($this->request->get['mtprocesohistory_id'])){
			$this->load->model('dirsiscrud/mtproceso');
			$this->model_dirsiscrud_mtproceso->delMtprocesohistory($this->request->get['mtprocesohistory_id']);
		}
	}	
	

}