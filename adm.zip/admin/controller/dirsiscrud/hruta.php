<?php
class ControllerDirsiscrudHruta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrud/hruta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/product');

		$this->getList();
	}

	public function add() {
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->addHruta($this->request->get);
		echo $result;
	}
	public function delete() {
		$hruta_id=$this->request->get['hruta_id'];
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->deleteHruta($hruta_id);
		echo $result;
	}
	public function get() {
		$hruta_id=$this->request->get['hruta_id'];
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->getHruta($hruta_id);
		$json[] = array(
			'hruta_id' => $result['hruta_id'],
			'orden' => $result['orden'],
			'product_id' => $result['product_id'],
			'maqui_id' => $result['maqui_id'],
			'dispo_id' => $result['dispo_id'],
			'operadores' => $result['operadores'],
			'plano' => $result['plano'],
			'ttp' => $result['ttp'],
			'obs' => $result['obs'],
			'relacion_id' => $result['relacion_id'],
			'code'       => $result['code'],
			'name'       => $result['name'],
			'compo'       => $result['compo'],
		);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}	
	public function getproceso() {
		$product_id=$this->request->get['product_id'];
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->getHrutas($product_id);
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($result));
		
	}	
	
	public function tocaproceso() {
		
		$product_id=$this->request->get['product_id'];
		$hruta_id=$this->request->get['hruta_id'];
		$orden=$this->request->get['orden'];
		$accion=$this->request->get['accion'];
		$this->load->model('catalog/product');
		$result = $this->model_catalog_product->tocaHruta($product_id,$hruta_id,$orden,$accion);
		echo $result;
	}

	protected function getList() {
		
		if (isset($this->request->get['product_id'])) {
			$product_id=$this->request->get['product_id'];
			
			$url='';
			$url='&product_id'.$product_id;
			
			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('dirsiscrud/hruta', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);


			$data['base'] = $this->model_catalog_product->getProduct($product_id);
			
			
			$results = $this->model_catalog_product->getHrutas($product_id);
			$data['hrutas'] = array();
			foreach ($results as $result) {
				$data['hrutas'][] = array(
					'hruta_id' => $result['hruta_id'],
					'orden' => $result['orden'],
					'product_id' => $result['product_id'],
					'maqui_name' => $result['maqui_id']? $result['maqui_name'] : '',
					'dispo_name' => $result['dispo_id']? $result['dispo_name'] : '',
					'operadores' => $result['operadores'],
					'plano' => $result['plano'],
					'ttp' => $result['ttp'],
					'obs' => $result['obs'],
					'relacion_id' => $result['relacion_id'],
					'code'       => $result['code'],
					'name'       => $result['name']
				);
			}
			
			
			
			$data['products'] = array();
			$filter_data = array();
			$this->load->model('dirsiscrud/proceso');
			$results = $this->model_dirsiscrud_proceso->getProcesos($filter_data);
			
			$url="&product_id=".$product_id;
			
			foreach ($results as $result) {
				$data['products'][] = array(
					'proceso_id' => $result['proceso_id'],
					'name'       => $result['name'],
					'code'       => $result['code'],
					'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')
				);
			}
			
			
			$this->load->model('dirsiscrud/maqui');
			$data['maquis'] = $this->model_dirsiscrud_maqui->getMaquis(['sort' => 'name', 'order' => 'ASC',]);

			$this->load->model('dirsiscrud/dispo');
			$data['dispos'] = $this->model_dirsiscrud_dispo->getDispos(['sort' => 'name', 'order' => 'ASC',]);			
		
			$this->load->model('catalog/product');
			$data['compos'] = $this->model_catalog_product->getCompos($product_id);
			
			//print_r($data['compos']);
			
			$data['user_token'] = $this->session->data['user_token'];

			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
			} else {
				$data['error_warning'] = '';
			}

			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];

				unset($this->session->data['success']);
			} else {
				$data['success'] = '';
			}

			if (isset($this->request->post['selected'])) {
				$data['selected'] = (array)$this->request->post['selected'];
			} else {
				$data['selected'] = array();
			}

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			$this->response->setOutput($this->load->view('dirsiscrud/hruta_list', $data));
		}
	}
	
}

