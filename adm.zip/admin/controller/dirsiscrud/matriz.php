<?php
class ControllerDirsiscrudMatriz extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrud/matriz');
		$this->document->setTitle($this->language->get('heading_title'));
		$data['heading_code'] = $this->language->get('heading_code');
		$this->load->model('dirsiscrud/matriz');
		$this->getList();
	}

	public function add() {
		$this->load->language('dirsiscrud/matriz');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/matriz');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_dirsiscrud_matriz->addMatriz($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_clien'])) {
				$filter_clien = $this->request->get['filter_clien'];
			} else {
				$filter_clien = '';
			}
			if (isset($this->request->get['filter_code'])) {
				$filter_code = $this->request->get['filter_code'];
			} else {
				$filter_code = '';
			}			
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}			
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_code'])) {
				$url .= '&filter_code=' . urlencode(html_entity_decode($this->request->get['filter_code'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_clien'])) {
				$url .= '&filter_clien=' . urlencode(html_entity_decode($this->request->get['filter_clien'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsiscrud/matriz');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/matriz');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			

			
			$this->model_dirsiscrud_matriz->editMatriz($this->request->get['matriz_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_code'])) {
				$filter_code = $this->request->get['filter_code'];
			} else {
				$filter_code = '';
			}
			if (isset($this->request->get['filter_clien'])) {
				$filter_clien = $this->request->get['filter_clien'];
			} else {
				$filter_clien = '';
			}
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_code'])) {
				$url .= '&filter_code=' . urlencode(html_entity_decode($this->request->get['filter_code'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_clien'])) {
				$url .= '&filter_clien=' . urlencode(html_entity_decode($this->request->get['filter_clien'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	public function delete() {
		$this->load->language('dirsiscrud/matriz');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/matriz');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $matriz_id) {
				$this->model_dirsiscrud_matriz->deleteMatriz($matriz_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_code'])) {
				$filter_code = $this->request->get['filter_code'];
			} else {
				$filter_code = '';
			}
			if (isset($this->request->get['filter_clien'])) {
				$filter_clien = $this->request->get['filter_clien'];
			} else {
				$filter_clien = '';
			}
			
			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_code'])) {
				$url .= '&filter_code=' . urlencode(html_entity_decode($this->request->get['filter_code'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['filter_clien'])) {
				$url .= '&filter_clien=' . urlencode(html_entity_decode($this->request->get['filter_clien'], ENT_QUOTES, 'UTF-8'));
			}		
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		$data['filter_name ']=$filter_name ;
		if (isset($this->request->get['filter_code'])) {
			$filter_code = $this->request->get['filter_code'];
		} else {
			$filter_code = '';
		}
		$data['filter_code']=$filter_code;
		if (isset($this->request->get['filter_clien'])) {
			$filter_clien = $this->request->get['filter_clien'];
		} else {
			$filter_clien = '';
		}
		$data['filter_clien']=$filter_clien;
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_code'])) {
			$url .= '&filter_code=' . urlencode(html_entity_decode($this->request->get['filter_code'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_clien'])) {
			$url .= '&filter_clien=' . urlencode(html_entity_decode($this->request->get['filter_clien'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$data['add'] = $this->url->link('dirsiscrud/matriz/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsiscrud/matriz/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['matrizs'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_code'              => $filter_code,
			'filter_clien'              => $filter_clien,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$matriz_total = $this->model_dirsiscrud_matriz->getTotalMatrizs();
		$results = $this->model_dirsiscrud_matriz->getMatrizs($filter_data);
		foreach ($results as $result) {
			$status="";
			if ($result['status']=='1') $status=$this->language->get('text_enabled');
			if ($result['status']=='0') $status=$this->language->get('text_disabled');
			$data['matrizs'][] = array(
				'matriz_id'    => $result['matriz_id'],
				'name'   	=> $result['name'],
				'code'   	=> $result['code'],
				'descrip'   	=> $result['descrip'],
				'clien'   	=> $result['clien'],
				'bocas'   	=> $result['bocas'],
				'status'     => $status,
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'edit'       => $this->url->link('dirsiscrud/matriz/edit', 'user_token=' . $this->session->data['user_token'] . '&matriz_id=' . $result['matriz_id'] . $url, true)
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);	
		$data['sort_code'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=code' . $url, true);	
		$data['sort_descrip'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=descrip' . $url, true);	
		$data['sort_bocas'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=bocas' . $url, true);	
		$data['sort_clien'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=clien' . $url, true);	
		$data['sort_status'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
		$data['sort_date_added'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $matriz_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($matriz_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($matriz_total - $this->config->get('config_limit_admin'))) ? $matriz_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $matriz_total, ceil($matriz_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		
		$data['import'] = $this->url->link('dirsiscrud/matriz/upload', 'user_token=' . $this->session->data['user_token'], true);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrud/matriz_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['matriz_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
		
		if (isset($this->error['clien'])) {
			$data['error_clien'] = $this->error['clien'];
		} else {
			$data['error_clien'] = '';
		}
		if (isset($this->error['descrip'])) {
			$data['error_descrip'] = $this->error['descrip'];
		} else {
			$data['error_descrip'] = '';
		}
		if (isset($this->error['bocas'])) {
			$data['error_bocas'] = $this->error['bocas'];
		} else {
			$data['error_bocas'] = '';
		}
		if (isset($this->error['code'])) {
			$data['error_code'] = $this->error['code'];
		} else {
			$data['error_code'] = '';
		}		

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['matriz_id'])) {
			$data['action'] = $this->url->link('dirsiscrud/matriz/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscrud/matriz/edit', 'user_token=' . $this->session->data['user_token'] . '&matriz_id=' . $this->request->get['matriz_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsiscrud/matriz', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['matriz_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$matriz_info = $this->model_dirsiscrud_matriz->getMatriz($this->request->get['matriz_id']);
		}
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($matriz_info)) {
			$data['name'] = $matriz_info['name'];
		} else {
			$data['name'] = '';
		}
		if (isset($this->request->post['clien'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($matriz_info)) {
			$data['name'] = $matriz_info['name'];
		} else {
			$data['name'] = '';
		}
		if (isset($this->request->post['code'])) {
			$data['code'] = $this->request->post['code'];
		} elseif (!empty($matriz_info)) {
			$data['code'] = $matriz_info['code'];
		} else {
			$data['code'] = '';
		}
		if (isset($this->request->post['clien'])) {
			$data['clien'] = $this->request->post['clien'];
		} elseif (!empty($matriz_info)) {
			$data['clien'] = $matriz_info['clien'];
		} else {
			$data['clien'] = '';
		}
		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($matriz_info)) {
			$data['descrip'] = $matriz_info['descrip'];
		} else {
			$data['descrip'] = '';
		}	
		if (isset($this->request->post['bocas'])) {
			$data['bocas'] = $this->request->post['bocas'];
		} elseif (!empty($matriz_info)) {
			$data['bocas'] = $matriz_info['bocas'];
		} else {
			$data['bocas'] = '';
		}			
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($matriz_info)) {
			$data['status'] = $matriz_info['status'];
		} else {
			$data['status'] = 1;
		}
		
		
		if (isset($this->request->post['equipo_id'])) {
			$data['equipo_id'] = $this->request->post['equipo_id'];
		} elseif (!empty($matriz_info)) {
			$data['equipo_id'] = $matriz_info['equipo_id'];
		} else {
			$data['equipo_id'] = '';
		}		
	 
		//print_r($matriz_info);
			
		if (isset($this->request->post['sector_id'])) {
			$data['sector_id'] = $this->request->post['sector_id'];
		} elseif (!empty($matriz_info)) {
			$data['sector_id'] = $matriz_info['sector_id'];
		} else {
			$data['sector_id'] = '';
		}		
		
		$this->load->model('dirsiscrud/equipo');
		$data['equipos'] = $this->model_dirsiscrud_equipo->getEquipos();		
		
		$this->load->model('dirsiscrud/sector');
		$data_filter = array ();
		$data['sectors'] = $this->model_dirsiscrud_sector->getSectors($data_filter);		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('dirsiscrud/matriz_form', $data));
	}

	protected function validateForm() {
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 120)) {
			$this->error['name'] = $this->language->get('error_name');
		}		
		if ((utf8_strlen($this->request->post['code']) < 3) || (utf8_strlen($this->request->post['code']) > 120)) {
			$this->error['code'] = $this->language->get('error_code');
		}				
		return !$this->error;
	}

	protected function validateDelete() {
		
		if (!$this->user->hasPermission('modify', 'dirsiscrud/matriz')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		return !$this->error;
	}
	
	
	public function getMatriz() {
		$json =array();
		if (isset($this->request->get['matriz_id'])) {
			$this->load->model('dirsiscrud/matriz');
			$json = $this->model_dirsiscrud_matriz->getMatriz($this->request->get['matriz_id']);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}
	
	
	
	
	public function upload() {
		$this->load->language('dirsiscrud/matriz');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrud/matriz');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validateUploadForm())) {
			if ((isset( $this->request->files['upload'] )) && (is_uploaded_file($this->request->files['upload']['tmp_name']))) {
				$this->load->model('setting/setting');
				$file = $this->request->files['upload']['tmp_name'];
				$data = array();
				$result=$this->model_dirsiscrud_matriz->upload($file,$data);
				if ($result){
					
					$suceso="Se proceso con exito!";
					$suceso.="-Alta:".$result['subieron'];
					$suceso.="-Editadas:".$result['actualizaron'];
					$suceso.="-Recorridas:".$result['recorrieron'];
					
					$this->session->data['success'] = $suceso;
				}else{
					$this->session->data['warning'] = "Algo salio mal, :(";
				}
			}
		}
		$this->getList();
	}	
	
	
	protected function validateUploadForm() {
		if (!isset($this->request->files['upload']['name'])) {
			if (isset($this->error['warning'])) {
				$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_name' );
			} else {
				$this->error['warning'] = $this->language->get( 'error_upload_name' );
			}
		} else {
			$ext = strtolower(pathinfo($this->request->files['upload']['name'], PATHINFO_EXTENSION));
			if (($ext != 'xls') && ($ext != 'xlsx') && ($ext != 'ods')) {
				if (isset($this->error['warning'])) {
					$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_ext' );
				} else {
					$this->error['warning'] = $this->language->get( 'error_upload_ext' );
				}
			}
		}
		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}	
	
	
	public function autocomplete() {
			error_reporting(E_ALL);
			ini_set('display_errors', '1');
			$json = array();
			if (isset($this->request->get['filter_name'])) {
				if (isset($this->request->get['filter_name'])) {
					$filter_name = $this->request->get['filter_name'];
				} else {
					$filter_name = '';
				}
				if (isset($this->request->get['filter_sector_id'])) {
					$filter_sector_id = $this->request->get['filter_sector_id'];
				} else {
					$filter_sector_id = '';
				}				
				$this->load->model('dirsiscrud/matriz');

				$filter_data = array(
					'filter_name'      => $filter_name,
					'filter_user_id'	=> $this->user->isLogged(),
					'filter_sector_id'	=> $filter_sector_id,
					'start'            => 0,
					'limit'            => 140
				);

				$results = $this->model_dirsiscrud_matriz->getMatrizs($filter_data);
				foreach ($results as $result) {
					$json[] = array(
						'matriz_id'       => $result['matriz_id'],
						'name'              => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
						'code'			=> $result['code']
					);
				}
			}
			$sort_order = array();
			foreach ($json as $key => $value) {
				$sort_order[$key] = $value['name'];
			}
			array_multisort($sort_order, SORT_ASC, $json);
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}		
	}
	
