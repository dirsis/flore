<?php
class ControllerDirsisexcelIntegra extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsisexcel/integra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsisexcel/integra');
		
		$this->getList();
		//$this->getUpload();
	}
	
	public function leerprueba(){
		if (isset($this->request->get['posicion'])) {
			$posicion=$this->request->get['posicion'];
		}else{
			$posicion=0;
		}
		$this->load->model('dirsisexcel/integra');
		$result=$this->model_dirsisexcel_integra->leerprueba($posicion);
		$posicion=$posicion+3;
		echo $result;
	}
	
	public function prueba() {
				$data = array(
					"integra_id" => 1
				);
		$this->load->model('dirsisexcel/integra');
				$result=$this->model_dirsisexcel_integra->upload('',$data);
	}
	
	public function bajada() {
		$this->load->language('dirsisexcel/integra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsisexcel/integra');
		$this->getUpload();
	}	

	public function add() {
		$this->load->language('dirsisexcel/integra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsisexcel/integra');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsisexcel_integra->addIntegra($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';	
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	public function edit() {
		$this->load->language('dirsisexcel/integra');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisexcel/integra');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsisexcel_integra->editIntegra($this->request->get['integra_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	public function delete() {
		$this->load->language('dirsisexcel/integra');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisexcel/integra');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $integra_id) {
				
				$this->model_dirsisexcel_integra->deleteIntegra($integra_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
		
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsisexcel/integra/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsisexcel/integra/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['bajada'] = $this->url->link('dirsisexcel/integra/bajada', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		
		
		$data['import'] = $this->url->link('dirsisexcel/integra/upload', 'user_token=' . $this->session->data['user_token'], true);

		$data['integras'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$integra_total = $this->model_dirsisexcel_integra->getTotalIntegras();

		$results = $this->model_dirsisexcel_integra->getIntegras($filter_data);

		foreach ($results as $result) {
			$data['integras'][] = array(
				'integra_id' => $result['integra_id'],
				'name'        => $result['name'],
				'edit'        => $this->url->link('dirsisexcel/integra/edit', 'user_token=' . $this->session->data['user_token'] . '&integra_id=' . $result['integra_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . '&sort=dd.name' . $url, true);
		$data['sort_date_added'] = $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . '&sort=d.date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $integra_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($integra_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($integra_total - $this->config->get('config_limit_admin'))) ? $integra_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $integra_total, ceil($integra_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsisexcel/integra_list', $data));
	}
	
	public function referencias(){
		$this->load->model('dirsisexcel/integra');
		$json=array();
		$results = $this->model_dirsisexcel_integra->getReferenciasxCustomer($this->request->get['integra_id'],$this->request->get['customer_id']);
		if ($results){
			foreach ($results as $result) {
				$json[] = array(
						'referencia' => $result['referencia'],
						'date_added'        => date("m/Y",strtotime($result['date_added'])),
						'date_registro'        => $result['date_registro'],
						'registros'        => $result['registros']
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
		
	}
	
	public function getUpload() {
		
		
		

error_reporting(E_ALL);
ini_set('display_errors', '1');

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		if (isset($this->request->get['integra_id'])) {
			$integra_id=$this->request->get['integra_id'];
		}elseif (isset($this->request->post['integra_id'])) {		
			$integra_id=$this->request->post['integra_id'];
		}
		if (isset($this->request->get['customer_id'])) {
			$data['customer_id']=$this->request->get['customer_id'];
		}elseif (isset($this->request->post['customer_id'])) {		
			$data['customer_id']=$this->request->post['customer_id'];
		}
		$data['delete']=1;
		$data['date_added'] = date("d-m-Y"); 		
		
		if (isset($integra_id)) {
			$url .= '&integra_id=' . $integra_id;
		}

		$this->load->model('customer/customer');
		$data['customers']=$this->model_customer_customer->getCustomers();
		/*
		if (isset($data['customer_id'])) {
			$this->load->model('customer/customer');
			$result = $this->model_customer_customer->getCustomer($data['customer_id']);
			if (isset($result)) {
				$data['customer']=$result['name'];
			}
			$url .= '&customer_id=' . $data['customer_id'];
		}		
		*/
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['import'] = $this->url->link('dirsisexcel/integra/upload', 'user_token=' . $this->session->data['user_token'], true);
		
		$data['integras'] = array();
		if (isset($integra_id)) {
			$data['integra_id'] = $integra_id;
			$result = $this->model_dirsisexcel_integra->getIntegra($data['integra_id']);
			$data['integras'][] = array(
				'integra_id' => $result['integra_id'],
				'name'        => $result['name'],
				'edit'        => $this->url->link('dirsisexcel/integra/edit', 'user_token=' . $this->session->data['user_token'] . '&integra_id=' . $result['integra_id'] . $url, true)
			);		
			
			$data['pidecustomer']=$result['customer'];
		}else{
			$filter_data = array(
				'sort'  => $sort,
				'order' => $order,
				'start' => ($page - 1) * $this->config->get('config_limit_admin'),
				'limit' => $this->config->get('config_limit_admin')
			);

			$results = $this->model_dirsisexcel_integra->getIntegras($filter_data);

			foreach ($results as $result) {
				$data['integras'][] = array(
					'integra_id' => $result['integra_id'],
					'name'        => $result['name'],
					'edit'        => $this->url->link('dirsisexcel/integra/edit', 'user_token=' . $this->session->data['user_token'] . '&integra_id=' . $result['integra_id'] . $url, true)
				);
			}
		}
			$data['referencias']=array();
			$results = $this->model_dirsisexcel_integra->getReferencias($data['integra_id']);
		
			if ($results){
				foreach ($results as $result) {
					$data['referencias'][] = array(
						'referencia' => $result['referencia'],
						'date_added'        => date("m/Y",strtotime($result['date_added'])),
						'date_registro'        => $result['date_registro'],
						'registros'        => $result['registros']
					);
				}
			}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}


		$url = '';
		
		if (isset($integra_id)) {
			$url .= '&integra_id=' . $integra_id;
		}		
		if (isset($data['customer_id'])){
			$url .= '&customer_id=' . $data['customer_id'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$data['cancel'] = $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->response->setOutput($this->load->view('dirsisexcel/integra_upload', $data));
	}
	
	

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['integra_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		
		if (isset($this->error['filename'])) {
			$data['error_filename'] = $this->error['filename'];
		} else {
			$data['error_filename'] = '';
		}		

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}		
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		
		$url = '';
		
		if (isset($this->request->get['integra_id'])) {
			$url .= '&integra_id=' . $this->request->get['integra_id'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] , true)
		);
		if (!isset($this->request->get['integra_id'])) {
			$data['action'] = $this->url->link('dirsisexcel/integra/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsisexcel/integra/edit', 'user_token=' . $this->session->data['user_token'] . '&integra_id=' . $this->request->get['integra_id'] . $url, true);
		}
		
		$data['cancel'] = $this->url->link('dirsisexcel/integra', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['integra_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$integra_info = $this->model_dirsisexcel_integra->getIntegra($this->request->get['integra_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['integra_id'])) {
			$data['integra_id'] = $this->request->get['integra_id'];
		} else {
			$data['integra_id'] = 0;
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($integra_info)) {
			$data['name'] = $integra_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['rowini'])) {
			$data['rowini'] = $this->request->post['rowini'];
		} elseif (!empty($integra_info)) {
			$data['rowini'] = $integra_info['rowini'];
		} else {
			$data['rowini'] = '0';
		}
		if (isset($this->request->post['colini'])) {
			$data['colini'] = $this->request->post['colini'];
		} elseif (!empty($integra_info)) {
			$data['colini'] = $integra_info['colini'];
		} else {
			$data['colini'] = '0';
		}
		if (isset($this->request->post['hoja'])) {
			$data['hoja'] = $this->request->post['hoja'];
		} elseif (!empty($integra_info)) {
			$data['hoja'] = $integra_info['hoja'];
		} else {
			$data['hoja'] = '0';
		}
		if (isset($this->request->post['tabla'])) {
			$data['tabla'] = $this->request->post['tabla'];
		} elseif (!empty($integra_info)) {
			$data['tabla'] = $integra_info['tabla'];
		} else {
			$data['tabla'] = '';
		}
		if (isset($this->request->post['customer'])) {
			$data['customer'] = $this->request->post['customer'];
		} elseif (!empty($integra_info)) {
			$data['customer'] = $integra_info['customer'];
		} else {
			$data['customer'] = '0';
		}		
		if (isset($this->request->post['campos'])) {
			$data['campos'] = $this->request->post['campos'];
		} elseif (!empty($integra_info)) {
			$data['campos'] = $integra_info['campos'];
		} else {
			$data['campos'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsisexcel/integra_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsisexcel/integra')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 128)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsisexcel/integra')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function deleteReferencia() {
		$this->load->language('dirsisexcel/integra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsisexcel/integra');
		if ($this->request->get['referencia']) {
			$this->model_dirsisexcel_integra->deleteReferencia($this->request->get['referencia'],$this->request->get['integra_id']);
			$this->session->data['success'] = "Se elimino referencia con exito!";
		}
		$this->getUpload();
	}	
	public function upload() {
		$this->load->language('dirsisexcel/integra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsisexcel/integra');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validateUploadForm())) {
		//if (($this->request->server['REQUEST_METHOD'] == 'POST')){
			if ((isset( $this->request->files['upload'] )) && (is_uploaded_file($this->request->files['upload']['tmp_name']))) {
				
				$this->load->model('setting/setting');
				$file = $this->request->files['upload']['tmp_name'];
				$data = array(
					"integra_id" => $this->request->post['integra_id'],
					"customer_id" => isset($this->request->post['customer_id']) ? $this->request->post['customer_id']: 0,
					"referencia" => $this->request->post['referencia'],
					"date_added" => $this->request->post['date_added'],
					"delete" => $this->request->post['delete'],
					"comprob_id" => $this->config->get('config_factura_comprob_id'),
					"fpago_id" => $this->config->get('config_factura_fpago_id'),
					"status" => $this->config->get('config_factura_status_id'),
					"product_id" => $this->config->get('config_factura_product_id')
				);
				$result=$this->model_dirsisexcel_integra->upload($file,$data);
				if ($result){
					 $suceso="Se proceso con exito ".$result['subieron']." Subieron de ".$result['recorrieron']." Procesados ";
					if ($result['referencia']){
						$suceso.="(errores: <a href='".$result['referencia'].".txt' target='_blank'>Archivo</a>)";
					}
					$this->session->data['success'] = $suceso;
				}else{
					$this->session->data['warning'] = "Algo salio mal, :(";
				}
			}
		}
		$this->getUpload();
	}
	
	public function autocomplete() {
		$json = array();

		$this->load->model('dirsisexcel/integra');
		$data['integras'] = array();
		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);
		$results = $this->model_dirsisexcel_integra->getIntegras($filter_data);
		foreach ($results as $result) {
			$json[] = array(
				'integra_id' => $result['integra_id'],
				'name'        => $result['name']
			);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validateUploadForm() {
		if (!isset($this->request->files['upload']['name'])) {
			if (isset($this->error['warning'])) {
				$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_name' );
			} else {
				$this->error['warning'] = $this->language->get( 'error_upload_name' );
			}
		} else {
			$ext = strtolower(pathinfo($this->request->files['upload']['name'], PATHINFO_EXTENSION));
			if (($ext != 'xls') && ($ext != 'xlsx') && ($ext != 'ods')) {
				if (isset($this->error['warning'])) {
					$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_ext' );
				} else {
					$this->error['warning'] = $this->language->get( 'error_upload_ext' );
				}
			}
		}
		if ($this->request->post['pidecustomer']=='si') {		
			if (!isset($this->request->post['customer_id'])) {	
				if (isset($this->error['warning'])) {
					$this->error['warning'] .= "<br>" . $this->language->get( 'error_customer' );
				} else {
					$this->error['warning'] = $this->language->get( 'error_customer' );
				}
			}
		}
		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}	
}