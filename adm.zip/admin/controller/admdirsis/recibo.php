<?php
class ControllerAdmdirsisRecibo extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/recibo');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/recibo');
		$this->getForm();
	}

	public function add() {
		$this->load->language('admdirsis/recibo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/recibo');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_admdirsis_recibo->addRecibo($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			//$this->error['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] , true));
		}else{
			$this->getForm();
		}	
	}

	public function edit() {
		$this->load->language('admdirsis/recibo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/recibo');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_recibo->editRecibo($this->request->get['contab_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			
			//$this->error['success'] = $this->language->get('text_success');
			
//https://ppnotes.com/adm/admin/index.php?route=admdirsis/estado&user_token=By8LJyISnGzh8acsbi4Kxmqea9TSc540&filter_customer_id=62&filter_customer=ASES%20EMPIRE%20%3F%20935788&filter_date_added=2021-01-10&filter_date_begin=2021-01-10
			$url="&filter_customer_id=".$this->request->post['customer_id'];
			$url.="&filter_customer=".$this->request->post['customer'];
			$url.="&filter_date_begin=".$this->request->post['date_added'];
			
			$this->response->redirect($this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token']. $url , true));
			
			//$this->response->redirect($this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] , true));
		}else{
			$this->getForm();
		}
	}

	public function delete() {
		$this->load->language('admdirsis/recibo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/recibo');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $recibo_id) {
				$this->model_admdirsis_recibo->deleteRecibo($recibo_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_recibo_group_id'])) {
				$url .= '&filter_recibo_group_id=' . $this->request->get['filter_recibo_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	public function unlock() {
		$this->load->language('admdirsis/recibo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/recibo');

		if (isset($this->request->get['email']) && $this->validateUnlock()) {
			$this->model_admdirsis_recibo->deleteLoginAttempts($this->request->get['email']);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_recibo_group_id'])) {
				$url .= '&filter_recibo_group_id=' . $this->request->get['filter_recibo_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getForm() {
		$data['text_form'] = $this->language->get('text_add');

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['success'])) {
			$data['error_success'] = $this->error['success'];
		} else {
			$data['error_success'] = '';
		}
		
		if (isset($this->error['comment'])) {
			$data['error_comment'] = $this->error['comment'];
		} else {
			$data['error_comment'] = '';
		}

		if (isset($this->error['total'])) {
			$data['error_total'] = $this->error['total'];
		} else {
			$data['error_total'] = '';
		}
		
		if (isset($this->error['customer'])) {
			$data['error_customer'] = $this->error['customer'];
		} else {
			$data['error_customer'] = '';
		}
		
		if (isset($this->error['fpago'])) {
			$data['error_fpago'] = $this->error['fpago'];
		} else {
			$data['error_fpago'] = '';
		}		

		$url = '';

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		
		if (!isset($this->request->get['contab_id'])) {
			$data['action'] = $this->url->link('admdirsis/recibo/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/recibo/edit', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $this->request->get['contab_id'] . $url, true);
		}
		
		
		$data['cancel'] = $this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		if (isset($this->request->get['contab_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$recibo_info = $this->model_admdirsis_recibo->getRecibo($this->request->get['contab_id']);
		}		
		
		if (isset($this->request->post['contab_id'])) {
			$data['contab_id'] = $this->request->post['contab_id'];
		} elseif (!empty($recibo_info)) {
			$data['contab_id'] = $recibo_info['contab_id'];
		} else {
			$data['contab_id'] = "";
		}		

		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($recibo_info)) {
			$data['date_added'] = date("Y-m-d", strtotime($recibo_info['date_added']));
		} else {
			$data['date_added'] = date("Y-m-d");  
		}		
		
		//CUSTOMER
		if (isset($this->request->post['customer'])) {
			$data['customer'] = $this->request->post['customer'];
		} elseif (!empty($recibo_info)) {
			$data['customer'] = $recibo_info['customer'];
		} else {
			$data['customer'] = '';
		}	

		if (isset($this->request->get['filter_customer'])) {
			$data['customer'] = $this->request->get['filter_customer'];
		}	
		//CUSTOMER_ID
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($recibo_info)) {
			$data['customer_id'] = $recibo_info['customer_id'];
		} else {
			$data['customer_id'] = '';
		}		

		if (isset($this->request->get['filter_customer_id'])) {
			$data['customer_id'] = $this->request->get['filter_customer_id'];
		}	
		//FPAGO
		if (isset($this->request->post['fpago'])) {
			$data['fpago'] = $this->request->post['fpago'];
		} elseif (!empty($recibo_info)) {
			$data['fpago'] = $recibo_info['fpago'];
		} else {
			$data['fpago'] = '';
		}	

		if (isset($this->request->get['filter_fpago'])) {
			$data['fpago'] = $this->request->get['filter_fpago'];
		}	
		//FPAGO_ID
		if (isset($this->request->post['fpago_id'])) {
			$data['fpago_id'] = $this->request->post['fpago_id'];
		} elseif (!empty($recibo_info)) {
			$data['fpago_id'] = $recibo_info['fpago_id'];
		} else {
			$data['fpago_id'] = '';
		}		

		if (isset($this->request->get['filter_fpago_id'])) {
			$data['fpago_id'] = $this->request->get['filter_fpago_id'];
		}			
		
		if (isset($this->request->post['total'])) {
			$data['total'] = $this->request->post['total'];
		} elseif (!empty($recibo_info)) {
			$data['total'] = number_format($recibo_info['total'],2,'.','');
		} else {
			$data['total'] = '';
		}

		if (isset($this->request->post['comment'])) {
			$data['comment'] = $this->request->post['comment'];
		} elseif (!empty($recibo_info)) {
			$data['comment'] = $recibo_info['comment'];
		} else {
			$data['comment'] = '';
		}
		
		//$data['action'] = $this->url->link('admdirsis/recibo/add', 'user_token=' . $this->session->data['user_token'], true);
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/recibo_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/recibo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['customer_id']) < 1) {
			$this->error['customer'] = $this->language->get('error_customer');
		}
		
		if (utf8_strlen($this->request->post['fpago_id']) < 1) {
			$this->error['fpago'] = $this->language->get('error_fpago');
		}		
		
		if ((utf8_strlen($this->request->post['total']) < 1) || (utf8_strlen(trim($this->request->post['total'])) > 32)) {
			$this->error['total'] = $this->language->get('error_total');
		}

		if ((utf8_strlen($this->request->post['comment']) < 1) || (utf8_strlen(trim($this->request->post['comment'])) > 32)) {
			$this->error['comment'] = $this->language->get('error_comment');
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/recibo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateUnlock() {
		if (!$this->user->hasPermission('modify', 'admdirsis/recibo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function ip() {
		$this->load->language('admdirsis/recibo');

		$this->load->model('admdirsis/recibo');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['ips'] = array();

		$results = $this->model_admdirsis_recibo->getIps($this->request->get['recibo_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['ips'][] = array(
				'ip'         => $result['ip'],
				'total'      => $this->model_admdirsis_recibo->getTotalRecibosByIp($result['ip']),
				'date_added' => date('d/m/y', strtotime($result['date_added'])),
				'filter_ip'  => $this->url->link('admdirsis/recibo', 'user_token=' . $this->session->data['user_token'] . '&filter_ip=' . $result['ip'], true)
			);
		}

		$ip_total = $this->model_admdirsis_recibo->getTotalIps($this->request->get['recibo_id']);

		$pagination = new Pagination();
		$pagination->total = $ip_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/recibo/ip', 'user_token=' . $this->session->data['user_token'] . '&recibo_id=' . $this->request->get['recibo_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($ip_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($ip_total - 10)) ? $ip_total : ((($page - 1) * 10) + 10), $ip_total, ceil($ip_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/recibo_ip', $data));
	}

}