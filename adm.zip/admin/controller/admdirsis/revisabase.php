<?php
class ControllerAdmdirsisRevisabase extends Controller {
	private $error = array();

	public function index() {
		die;
		$this->getList();
		
	}
	public function getList() {
		$data = array();
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}
		$this->response->setOutput($this->load->view('admdirsis/revisabase_list', $data));
	}
}
				

								
																
