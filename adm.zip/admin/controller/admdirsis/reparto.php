<?php
class ControllerAdmdirsisReparto extends Controller {
	private $error = array();

	public function index() {
	
		$this->load->language('admdirsis/reparto');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/reparto');
		$this->getList();
	}

	public function add() {
		
		$this->load->language('admdirsis/reparto');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/reparto');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_reparto->addReparto($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_estadoenvio_id'])) {
				$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/reparto');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/reparto');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_reparto->editReparto($this->request->get['reparto_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/reparto');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/reparto');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $reparto_id) {
				$this->model_admdirsis_reparto->deleteReparto($reparto_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_origen'])) {
				$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
			}
			
			if (isset($this->request->get['filter_estadoenvio_id'])) {
				$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
			}
			
			if (isset($this->request->get['filter_modoenvio'])) {
				$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	public function copy() {
		$this->load->language('admdirsis/reparto');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/reparto');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $reparto_id) {
				$this->model_admdirsis_reparto->copyReparto($reparto_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_origen'])) {
				$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
			}
			
			if (isset($this->request->get['filter_estadoenvio_id'])) {
				$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
			}
			
			if (isset($this->request->get['filter_modoenvio'])) {
				$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	
	public function leerrepartos() {
		$ruta="dirsis/upload";
		$recorre=0;
		if (is_dir($ruta)){
			$this->load->model('admdirsis/reparto');
			$gestor = opendir($ruta);
			while (($archivo = readdir($gestor)) !== false)  {
				$ruta_completa = $ruta . "/" . $archivo;			
				if ($archivo != "." && $archivo != "..") {
					if (is_dir($ruta_completa)) {
					} else {
						
						$fp = fopen($ruta_completa, "rb");
						$datos = fread($fp, filesize($ruta_completa));
						fclose($fp);
						$json=json_decode($datos,JSON_OBJECT_AS_ARRAY);
						$registro = $this->model_admdirsis_reparto->getRepartoxorigen($json['origen']);
						if ($registro==0){
							//var_dump($json);
							$this->model_admdirsis_reparto->addReparto($json);
							$recorre++;
						}
                	}
            	}
        	}
        	closedir($gestor);
		}
		echo $recorre;
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		
		if (isset($this->request->get['filter_origen'])) {
			$filter_origen = $this->request->get['filter_origen'];
		} else {
			$filter_origen = '';
		}		

		if (isset($this->request->get['filter_estadoenvio_id'])) {
			$filter_estadoenvio_id = $this->request->get['filter_estadoenvio_id'];
		} else {
			$filter_estadoenvio_id = '';
		}
		
		if (isset($this->request->get['filter_modoenvio_id'])) {
			$filter_modoenvio_id = $this->request->get['filter_modoenvio_id'];
		} else {
			$filter_modoenvio_id = '';
		}		
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'p.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_origen'])) {
			$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_estadoenvio_id'])) {
			$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
		}

		if (isset($this->request->get['filter_modoenvio'])) {
			$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
		}		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/reparto/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['copy'] = $this->url->link('admdirsis/reparto/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/reparto/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['repartos'] = array();

		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_estadoenvio_id'   => $filter_estadoenvio_id,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		
		$reparto_total = $this->model_admdirsis_reparto->getTotalRepartos($filter_data);
		$results = $this->model_admdirsis_reparto->getRepartos($filter_data);

		foreach ($results as $result) {
			$data['repartos'][] = array(
				'reparto_id' => $result['reparto_id'],
				'name'       => $result['name'],
				'dni'       => $result['dni'],
				'telefono'     => $result['telefono'],
				'correo'     => $result['correo'],
				'origen'     => $result['origen'],
				'notauser'     => $result['notauser'],
				'fecha_registro'     => date($this->language->get('date_format_short'), strtotime($result['fecha_registro'])),
				'fecha_entrega'     => $result['fecha_entrega']!='0000-00-00 00:00:00' ? date($this->language->get('date_format_short'), strtotime($result['fecha_entrega'])) : '',
				'modoenvio_id'     => $result['modoenvio_id'],
				'modoenvio'     => $result['modoenvio'],
				'bultos'     => $result['bultos'],
				'estadoenvio_id'     => $result['estadoenvio_id'],
				'estadoenvio'     => $result['estadoenvio'],
				'edit'       => $this->url->link('admdirsis/reparto/edit', 'user_token=' . $this->session->data['user_token'] . '&reparto_id=' . $result['reparto_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}
		$data['estadoenvios_defa']='';
		$data['estadoenvios'] = $this->model_admdirsis_reparto->getEstadoenvios(['sort' => 'orden', 'order' => 'ASC',]);
		foreach ($data['estadoenvios'] as $result) {
			if ($result['defa']==1){
				$data['estadoenvios_defa']=$result['estadoenvio_id'];
			}
		}
		$data['modoenvios'] = $this->model_admdirsis_reparto->getModoenvios(['sort' => 'orden', 'order' => 'ASC',]);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_origen'])) {
			$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_estadoenvio_id'])) {
			$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
		}

		if (isset($this->request->get['filter_modoenvio'])) {
			$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_reparto_id'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.reparto_id' . $url, true);
		$data['sort_origen'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.origen' . $url, true);
		$data['sort_name'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.name' . $url, true);
		$data['sort_correo'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.correo' . $url, true);
		$data['sort_telefono'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.telefono' . $url, true);
		$data['sort_dni'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.dni' . $url, true);
		$data['sort_bultos'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.bultos' . $url, true);
		$data['sort_fecha_entrega'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.fecha_entrega' . $url, true);
		$data['sort_fecha_registro'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.fecha_registro' . $url, true);
		$data['sort_notauser'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.notauser' . $url, true);
		$data['sort_modoenvio_id'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.modoenvio_id' . $url, true);
		$data['sort_estadoenvio_id'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . '&sort=p.estadoenvio_id' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_origen'])) {
			$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_estadoenvio_id'])) {
			$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
		}

		if (isset($this->request->get['filter_modoenvio'])) {
			$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
		}
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $reparto_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($reparto_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($reparto_total - $this->config->get('config_limit_admin'))) ? $reparto_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $reparto_total, ceil($reparto_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_origen'] = $filter_origen;
		$data['filter_estadoenvio_id'] = $filter_estadoenvio_id;
		$data['filter_modoenvio_id'] = $filter_modoenvio_id;
		if (!empty($filter_estadoenvio_id)){
			$data['estadoenvios_defa']='';
		}
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/reparto_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['reparto_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_origen'])) {
			$url .= '&filter_origen=' . urlencode(html_entity_decode($this->request->get['filter_origen'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_estadoenvio_id'])) {
			$url .= '&filter_estadoenvio_id=' . $this->request->get['filter_estadoenvio_id'];
		}

		if (isset($this->request->get['filter_modoenvio'])) {
			$url .= '&filter_modoenvio_id=' . $this->request->get['filter_modoenvio_id'];
		}
		
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),

			'href' => $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['reparto_id'])) {
			$data['action'] = $this->url->link('admdirsis/reparto/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/reparto/edit', 'user_token=' . $this->session->data['user_token'] . '&reparto_id=' . $this->request->get['reparto_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/reparto', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['reparto_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$reparto_info = $this->model_admdirsis_reparto->getReparto($this->request->get['reparto_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		if (isset($this->request->post['origen'])) {
			$data['origen'] = $this->request->post['origen'];
		} elseif (!empty($reparto_info)) {
			$data['origen'] = $reparto_info['origen'];
		} else {
			$data['origen'] = '';
		}		

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($reparto_info)) {
			$data['name'] = $reparto_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['dni'])) {
			$data['dni'] = $this->request->post['dni'];
		} elseif (!empty($reparto_info)) {
			$data['dni'] = $reparto_info['dni'];
		} else {
			$data['dni'] = '';
		}

		if (isset($this->request->post['telefono'])) {
			$data['telefono'] = $this->request->post['telefono'];
		} elseif (!empty($reparto_info)) {
			$data['telefono'] = $reparto_info['telefono'];
		} else {
			$data['telefono'] = '';
		}
		
		if (isset($this->request->post['correo'])) {
			$data['correo'] = $this->request->post['correo'];
		} elseif (!empty($reparto_info)) {
			$data['correo'] = $reparto_info['correo'];
		} else {
			$data['correo'] = '';
		}		
		
		if (isset($this->request->post['bultos'])) {
			$data['bultos'] = $this->request->post['bultos'];
		} elseif (!empty($reparto_info)) {
			$data['bultos'] = $reparto_info['bultos'];
		} else {
			$data['bultos'] = '1';
		}		

		if (isset($this->request->post['notauser'])) {
			$data['notauser'] = $this->request->post['notauser'];
		} elseif (!empty($reparto_info)) {
			$data['notauser'] = $reparto_info['notauser'];
		} else {
			$data['notauser'] = '';
		}

		
		if (isset($this->request->post['fecha_registro'])) {
			$data['fecha_registro'] = $this->request->post['fecha_registro'];
		} elseif (!empty($product_info)) {
			$data['fecha_registro'] = ($product_info['fecha_registro'] != '0000-00-00') ? $product_info['fecha_registro'] : '';
		} else {
			$data['fecha_registro'] = date('Y-m-d');
		}
		
		
		if (isset($this->request->post['modoenvio_id'])) {
			$data['modoenvio_id'] = $this->request->post['modoenvio_id'];
		} elseif (!empty($reparto_info)) {
			$data['modoenvio_id'] = $reparto_info['modoenvio_id'];
		} else {
			$data['modoenvio_id'] = '';
		}

		if (isset($this->request->post['fecha_entrega'])) {
			$data['fecha_entrega'] = $this->request->post['fecha_entrega'];
		} elseif (!empty($product_info)) {
			$data['fecha_entrega'] = ($product_info['fecha_entrega'] != '0000-00-00') ? $product_info['fecha_entrega'] : '';
		} else {
			$data['fecha_entrega'] = '';
		}


		if (isset($this->request->post['estadoenvio_id'])) {
			$data['estadoenvio_id'] = $this->request->post['estadoenvio_id'];
		} elseif (!empty($reparto_info)) {
			$data['estadoenvio_id'] = $reparto_info['estadoenvio_id'];
		} else {
			$data['estadoenvio_id'] = '';
		}

		$data['estadoenvios'] = $this->model_admdirsis_reparto->getEstadoenvios(['sort' => 'name', 'order' => 'ASC',]);
		$data['modoenvios'] = $this->model_admdirsis_reparto->getModoenvios(['sort' => 'name', 'order' => 'ASC',]);
		//print_r($data['modoenvios']);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('admdirsis/reparto_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/reparto')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ((utf8_strlen($this->request->post['origen']) < 1) || (utf8_strlen($this->request->post['origen']) > 100)) {
			$this->error['warning'] = $this->language->get('error_origen');
		}		

		if ((utf8_strlen($this->request->post['name']) < 1) || (utf8_strlen($this->request->post['name']) > 100)) {
			$this->error['warning'] = $this->language->get('error_name');
		}
		if ((utf8_strlen($this->request->post['dni']) < 1) || (utf8_strlen($this->request->post['dni']) > 13)) {
			$this->error['warning'] = $this->language->get('error_dni');
		}
		if ((utf8_strlen($this->request->post['fecha_registro']) < 1) || (utf8_strlen($this->request->post['fecha_registro']) > 12)) {
			$this->error['warning'] = $this->request->post['fecha_registro'].$this->language->get('error_fecha_registro');
		}
		/*
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		*/
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/reparto')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'admdirsis/reparto')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	
}

