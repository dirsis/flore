<?php
class ControllerAdmdirsisPaciente extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/paciente');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/paciente');

		$this->getList();
	}

	public function addexpress() {
		$this->load->model('admdirsis/paciente');
		$data = array(
			'name'      => $this->request->get['name'],
			'customer_id'     => $this->request->get['customer_id']
		);
		$results = $this->model_admdirsis_paciente->addPacienteexpress($data);
		echo $results;
	}
	
	public function add() {
		

		
		$this->load->language('admdirsis/paciente');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/paciente');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_admdirsis_paciente->addPaciente($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_customer_id'])) {
				$filter_customer_id = $this->request->get['filter_customer_id'];
			} else {
				$filter_customer_id = '';
			}		
			if (isset($this->request->get['filter_customer'])) {
				$filter_customer = $this->request->get['filter_customer'];
			} else {
				$filter_customer = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}			

			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			

			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('admdirsis/paciente');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/paciente');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_paciente->editPaciente($this->request->get['paciente_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_customer_id'])) {
				$filter_customer_id = $this->request->get['filter_customer_id'];
			} else {
				$filter_customer_id = '';
			}		
			if (isset($this->request->get['filter_customer'])) {
				$filter_customer = $this->request->get['filter_customer'];
			} else {
				$filter_customer = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}			

			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			


			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/paciente');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/paciente');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $paciente_id) {
				
				$this->model_admdirsis_paciente->deletePaciente($paciente_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			
			
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}
			if (isset($this->request->get['filter_customer_id'])) {
				$filter_customer_id = $this->request->get['filter_customer_id'];
			} else {
				$filter_customer_id = '';
			}		
			if (isset($this->request->get['filter_customer'])) {
				$filter_customer = $this->request->get['filter_customer'];
			} else {
				$filter_customer = '';
			}
			if (isset($this->request->get['filter_date_added'])) {
				$filter_date_added = $this->request->get['filter_date_added'];
			} else {
				$filter_date_added = '';
			}		
			
			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}
		$data['filter_name']=$filter_name;
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}		
		$data['filter_customer_id']=$filter_customer_id;
		
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}
		$data['filter_customer']=$filter_customer;
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}		
		$data['filter_date_added']=$filter_date_added;
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/paciente/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/paciente/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['pacientes'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_customer_id'          => $filter_customer_id,
			'filter_customer'          => $filter_customer,
			'filter_date_added'        => $filter_date_added,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);
		
		
		
		$this->load->model('admdirsis/paciente_group');
		$this->load->model('admdirsis/paciente_sgroup');

		$paciente_total = $this->model_admdirsis_paciente->getTotalPacientes();

		$results = $this->model_admdirsis_paciente->getPacientes($filter_data);

		foreach ($results as $result) {
			
			if ($result['status']=='1') $status=$this->language->get('text_enabled');
			if ($result['status']=='0') $status=$this->language->get('text_disabled');
			if ($result['status']=='2') $status=$this->language->get('text_deleted');
			

		
			$data['pacientes'][] = array(
				'paciente_id'    => $result['paciente_id'],
				'name'   => $result['name'],
				'customer_id'   => $result['customer_id'],
				'customer'   => $result['customer'],
				'paciente_group'   => $result['groupname'],
				'paciente_sgroup'   => $result['sgroupname'],
				'fecha_nacio'   => $result['fecha_nacio'],
				'status'     => $status,
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'evento'       => $this->url->link('rmadirsis/evento/add', 'user_token=' . $this->session->data['user_token'] . '&paciente_id=' . $result['paciente_id'] . $url, true),
				'edit'       => $this->url->link('admdirsis/paciente/edit', 'user_token=' . $this->session->data['user_token'] . '&paciente_id=' . $result['paciente_id'] . $url, true)
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_customer'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
		$data['sort_paciente_group'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=paciente_group' . $url, true);
		$data['sort_paciente_sgroup'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=paciente_sgroup' . $url, true);		
		$data['sort_status'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
		$data['sort_date_added'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $paciente_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($paciente_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($paciente_total - $this->config->get('config_limit_admin'))) ? $paciente_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $paciente_total, ceil($paciente_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/paciente_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['paciente_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['customer'])) {
			$data['error_customer'] = $this->error['customer'];
		} else {
			$data['error_customer'] = '';
		}

		if (isset($this->error['fecha_nacio'])) {
			$data['error_fecha_nacio'] = $this->error['fecha_nacio'];
		} else {
			$data['error_fecha_nacio'] = '';
		}		

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['paciente_id'])) {
			$data['action'] = $this->url->link('admdirsis/paciente/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/paciente/edit', 'user_token=' . $this->session->data['user_token'] . '&paciente_id=' . $this->request->get['paciente_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/paciente', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['paciente_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$paciente_info = $this->model_admdirsis_paciente->getPaciente($this->request->get['paciente_id']);
		}
//print_r($paciente_info);
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($paciente_info)) {
			$data['name'] = $paciente_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['paciente_group_id'])) {
			$data['paciente_group_id'] = $this->request->post['paciente_group_id'];
		} elseif (!empty($paciente_info)) {
			$data['paciente_group_id'] = $paciente_info['paciente_group_id'];
		} else {
			$data['paciente_group_id'] = '';
		}
		
		$this->load->model('admdirsis/paciente_group');

		$data['paciente_groups'] = $this->model_admdirsis_paciente_group->getPacienteGroups();
		
		if (isset($this->request->post['paciente_sgroup_id'])) {
			$data['paciente_sgroup_id'] = $this->request->post['paciente_sgroup_id'];
		} elseif (!empty($paciente_info)) {
			$data['paciente_sgroup_id'] = $paciente_info['paciente_sgroup_id'];
		} else {
			$data['paciente_sgroup_id'] = '';
		}		
		
		//$this->load->model('admdirsis/paciente_sgroup');

		//$data['paciente_sgroups'] = $this->model_admdirsis_paciente_sgroup->getPacienteSgroups();
				
		
		
		if (isset($this->request->post['customer_id'])) {
			$data['customer_id'] = $this->request->post['customer_id'];
		} elseif (!empty($paciente_info)) {
			$data['customer_id'] = $paciente_info['customer_id'];
		} else {
			$data['customer_id'] = '';
		}
		
		if (isset($this->request->get['filter_customer_id'])) {
			$data['customer_id'] = $this->request->get['filter_customer_id'];
		}
		if (isset($data['customer_id'])){
			$this->load->model('customer/customer');
			$customer_info = $this->model_customer_customer->getCustomer($data['customer_id']);
//			print_r($customer_info);

			if (!empty($customer_info)){
				$data['customer']=$customer_info['name'];
			}else{
				$data['customer'] = '';
			}



		}

		if (isset($this->request->post['fecha_nacio'])) {
			$data['fecha_nacio'] = date("d-m-Y",strtotime($this->request->post['fecha_nacio']));
		} elseif (!empty($paciente_info)) {
			$data['fecha_nacio'] = date("d-m-Y",strtotime($paciente_info['fecha_nacio']));
		} else {
			$data['fecha_nacio'] = '';
		}
		$data['edad'] = $this->calculaEdad($data['fecha_nacio']);
		
		//print_r($data);
		if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($paciente_info)) {
			$data['image'] = $paciente_info['image'];
		} else {
			$data['image'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($paciente_info) && $paciente_info['image'] && is_file(DIR_IMAGE . $paciente_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($paciente_info['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($paciente_info)) {
			$data['status'] = $paciente_info['status'];
		} else {
			$data['status'] = 1;
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/paciente_form', $data));
	}

	protected function validateForm() {
		/*
		if (!$this->paciente->hasPermission('modify', 'admdirsis/paciente')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		*/
		if ($this->request->post['customer_id']<=0){
			$this->error['customer'] = $this->language->get('error_customer');
		}
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 120)) {
			$this->error['name'] = $this->language->get('error_name');
		}		

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/paciente')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

/*		foreach ($this->request->post['selected'] as $paciente_id) {
			if ($this->paciente->getId() == $paciente_id) {
				$this->error['warning'] = $this->language->get('error_account');
			}
		}
*/
		return !$this->error;
	}
	
	protected function verEdad(){
	  $edad=calculaEdad($this->request->get['fecha_nacio']);
	  //print_r($edad);
	  return $edad;
	}	
	
	public function calculaEdad(){
		if (isset($this->request->get['fecha'])) {
			$date1 = date('Y-m-d', strtotime($this->request->get['fecha']));
			$date1 = date_create_from_format('Y-m-d', $date1);
			$date2 = date_create_from_format('Y-m-d', date('Y-m-d'));
			$diff = (array) date_diff($date1, $date2);
	  		echo json_encode($diff);
		}
	}
	
	public function autocomplete() {
			$json = array();

			if (isset($this->request->get['filter_name'])) {
				if (isset($this->request->get['filter_name'])) {
					$filter_name = $this->request->get['filter_name'];
				} else {
					$filter_name = '';
				}
				$this->load->model('admdirsis/paciente');

				$filter_data = array(
					'filter_name'      => $filter_name,
					'start'            => 0,
					'limit'            => 15
				);

				$results = $this->model_admdirsis_paciente->getPacientes($filter_data);

				foreach ($results as $result) {
					$json[] = array(
						'paciente_id'       => $result['paciente_id'],
						'name'              => strip_tags(html_entity_decode($result['name']." < ".$result['customer'], ENT_QUOTES, 'UTF-8')),
						'namesolo'              => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
						'customer_id'       => $result['customer_id'],
						'customer'              => strip_tags(html_entity_decode($result['customer'], ENT_QUOTES, 'UTF-8'))
					);
				}
			}

			$sort_order = array();

			foreach ($json as $key => $value) {
				$sort_order[$key] = $value['name'];
			}

			array_multisort($sort_order, SORT_ASC, $json);

			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}		

		public function getpacientexcustomer() {
			$json = array();
			if (isset($this->request->get['customer_id'])) {
				$this->load->model('admdirsis/paciente');
				$filter_data = array(
					'filter_customer_id'      => $this->request->get['customer_id'],
					'start'            => 0,
					'limit'            => 1000
				);			
				$results = $this->model_admdirsis_paciente->getPacientes($filter_data);
				foreach ($results as $result) {
					$json[] = array(
						'paciente_id'       => $result['paciente_id'],
						'name'				=> $result['name']
					);
				}
			}
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
		}	

	
	}
	
