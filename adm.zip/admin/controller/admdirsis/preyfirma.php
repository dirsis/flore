<?php
class ControllerAdmdirsisPreyfirma extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/preyfirma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/preyfirma');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/preyfirma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/preyfirma');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_preyfirma->addPreyfirma($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/preyfirma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/preyfirma');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_preyfirma->editPreyfirma($this->request->get['preyfirma_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/preyfirma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/preyfirma');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $preyfirma_id) {
				$this->model_admdirsis_preyfirma->deletePreyfirma($preyfirma_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/preyfirma/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/preyfirma/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['preyfirmas'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$preyfirma_total = $this->model_admdirsis_preyfirma->getTotalPreyfirmas();

		$results = $this->model_admdirsis_preyfirma->getPreyfirmas($filter_data);

		foreach ($results as $result) {
			$data['preyfirmas'][] = array(
				'preyfirma_id' => $result['preyfirma_id'],
				'name'          => $result['name'],
				'estado'          => $result['estado'],
				'd_estado'          => $result['d_estado'],
				'aplica'          => $result['aplica'],
				'd_aplica'          => $result['d_aplica'],								
				'edit'          => $this->url->link('admdirsis/preyfirma/edit', 'user_token=' . $this->session->data['user_token'] . '&preyfirma_id=' . $result['preyfirma_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_estado'] = $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $preyfirma_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($preyfirma_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($preyfirma_total - $this->config->get('config_limit_admin'))) ? $preyfirma_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $preyfirma_total, ceil($preyfirma_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/preyfirma_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['preyfirma_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['preyfirma_id'])) {
			$data['action'] = $this->url->link('admdirsis/preyfirma/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/preyfirma/edit', 'user_token=' . $this->session->data['user_token'] . '&preyfirma_id=' . $this->request->get['preyfirma_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/preyfirma', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['preyfirma_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$preyfirma_info = $this->model_admdirsis_preyfirma->getPreyfirma($this->request->get['preyfirma_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($preyfirma_info)) {
			$data['name'] = $preyfirma_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['estado'])) {
			$data['estado'] = $this->request->post['estado'];
		} elseif (!empty($preyfirma_info)) {
			$data['estado'] = $preyfirma_info['estado'];
		} else {
			$data['estado'] = '';
		}	
		
		
		if (isset($this->request->post['aplica'])) {
			$data['aplica'] = $this->request->post['aplica'];
		} elseif (!empty($preyfirma_info)) {
			$data['aplica'] = $preyfirma_info['aplica'];
		} else {
			$data['aplica'] = '';
		}	


		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($preyfirma_info['permission']['access'])) {
			$data['access'] = $preyfirma_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($preyfirma_info['permission']['modify'])) {
			$data['modify'] = $preyfirma_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/preyfirma_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/preyfirma')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 200)) {
			$this->error['name'] = $this->language->get('error_name');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/preyfirma')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $preyfirma_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($preyfirma_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			$this->load->model('admdirsis/preyfirma');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_preyfirma->getPreyfirmas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'preyfirma_id' => $result['preyfirma_id'],
					'name'     => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'estado'    => $result['estado'],
					'aplica'    => $result['aplica']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}