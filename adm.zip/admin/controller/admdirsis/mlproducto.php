<?php
class ControllerAdmdirsisMlproducto extends Controller {
	private $error = array();
	public function leerproducto() {
		$json = '0';
		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		if (isset($this->request->get['item'])){
			$item=$this->request->get['item'];	
		}else{
			$item=0;
		}
		if (isset($this->request->get['items'])){
			$items=$this->request->get['items'];	
		}else{
			$items=1;
		}		
		if (isset($this->request->get['filter_mla'])) {
			$mla=$this->request->get['filter_mla'];
			if (!empty($mla)){
				$this->load->model('admdirsis/plataforma');
				$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
				foreach ($results as $result) {
					//print_r($result);
					//die;
					if ($result['code']=='MELI'){
						$this->load->model('admdirsis/mlproducto');
						$results2 = $this->model_admdirsis_mlproducto->getLeerproducto($mla,$result);
						$json=$results2;

					}
				}
			}
		}
		$porc=round($item*100/$items);
		logs( $json."|".$item."|".$items );
		echo $json."|".$item."|".$items."|".$porc;
	}
	public function leerproductoajeno() {
		$json = '0';
		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		if (isset($this->request->get['item'])){
			$item=$this->request->get['item'];	
		}else{
			$item=0;
		}
		if (isset($this->request->get['items'])){
			$items=$this->request->get['items'];	
		}else{
			$items=1;
		}		
		if (isset($this->request->get['filter_mla'])) {
			$mla=$this->request->get['filter_mla'];
			if (!empty($mla)){
				$this->load->model('admdirsis/plataforma');
				$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
				foreach ($results as $result) {
					//print_r($result);
					//die;
					if ($result['code']=='MELI'){
						$this->load->model('admdirsis/mlproducto');
						$results2 = $this->model_admdirsis_mlproducto->getLeerproductoajeno($mla,$result);
						$json=$results2;
					}
				}
			}
		}
		$porc=round($item*100/$items);
		logs( $json."|".$item."|".$items );
		echo $json."|".$item."|".$items."|".$porc;
	}
	public function leerproductoclonar() {
		//
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$json = '0';
		$filter_data = array(
			'filter_marketplace'  => 'MELI',
			'filter_code'  => 'MELI'
		);		
		if (isset($this->request->get['item'])){
			$item=$this->request->get['item'];	
		}else{
			$item=0;
		}
		if (isset($this->request->get['items'])){
			$items=$this->request->get['items'];	
		}else{
			$items=1;
		}		
		if (isset($this->request->get['items'])){
			$items=$this->request->get['items'];	
		}else{
			$items=1;
		}		
		if (isset($this->request->get['filter_marketplace'])){
			$filter_marketplace=$this->request->get['filter_marketplace'];	
		}else{
			$filter_marketplace='';
		}		
		if (isset($this->request->get['filter_marketplace'])){
			$filter_marketplace=$this->request->get['filter_marketplace'];	
		}else{
			$filter_marketplace='';
		}		
		if (isset($this->request->get['filter_mla'])) {
			$mla=$this->request->get['filter_mla'];
			if (!empty($mla)){
				$this->load->model('admdirsis/plataforma');
				$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
				foreach ($results as $result) {
					if ($result['code']=='MELI'){
						if (empty($filter_marketplace) or $filter_marketplace=$result['marketplace']){
							$this->load->model('admdirsis/mlproducto');
							$results2 = $this->model_admdirsis_mlproducto->getLeerproductoclonar($mla,$result);
							//print_r("resul:".$results2);
							$json.=$results2;
						}
					}
				}
			}
		}
		$porc=round($item*100/$items);
		echo $json."|".$item."|".$items."|".$porc;
	}
	
	
	
	
	public function leercsvproducto() {
		//echo "ver";
		$json = '';
		$filter_data = array(
			'filter_code'  => 'MELI'
		);			
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		//print_r($results);
		if ( isset( $_FILES[ 'archivo' ][ 'name' ] ) ) {
		} else {
			echo 'Debe Indicar Archivo a subir';
			die;
		}
		$archivo=$_FILES[ 'archivo' ][ 'name' ];
		$ruta = "dirsis/upload/" . $_FILES[ 'archivo' ][ 'name' ];
		move_uploaded_file( $_FILES[ "archivo" ][ "tmp_name" ], $ruta );
		if ( is_file( $ruta ) ) {
			$fp = fopen($ruta, "r");
			while (!feof($fp)){
				$linea = fgets($fp);
				$porciones = explode(";", $linea);
				$mla=trim($porciones[0]);
				//echo "leer mla:".$mla."-";
				//
				$this->load->model('admdirsis/mlproducto');
				foreach ($results as $result) {
					if (strpos($mla,'MLA')!== false){
						if ($result['code']=='MELI'){
							$results2 = $this->model_admdirsis_mlproducto->getLeerproducto($mla,$result);
							$json.="(".$mla."-R:".$results2.")<br>";
							//"-OK/n";
						}
					}else{
						//$json.="-Salto ".$mla;
					}
				}
				//
				
			}
			fclose($fp);			
		}
		echo $json;
	}
	public function listacsv() {
		$archivo=$_FILES[ 'archivo2' ][ 'name' ];
		$json = '';
		$ruta = "dirsis/upload/" . $_FILES[ 'archivo2' ][ 'name' ];
		move_uploaded_file( $_FILES[ "archivo2" ][ "tmp_name" ], $ruta );
		if ( is_file( $ruta ) ) {
			$fp = fopen($ruta, "r");
			while (!feof($fp)){
				$linea = fgets($fp);
				$porciones = explode(";", $linea);
				$mla=trim($porciones[0]);
				$json.=$mla."|";				
			}
			fclose($fp);			
		}
		echo $json;
	}	
	public function listacsv2() {
		$archivo=$_FILES[ 'file2' ][ 'name' ];
		$json = '';
		$ruta = "dirsis/upload/" . $_FILES[ 'file2' ][ 'name' ];
		move_uploaded_file( $_FILES[ "file2" ][ "tmp_name" ], $ruta );
		if ( is_file( $ruta ) ) {
			$fp = fopen($ruta, "r");
			while (!feof($fp)){
				$linea = fgets($fp);
				$porciones = explode(";", $linea);
				$mla=trim($porciones[0]);
				$json.=$mla."|";				
			}
			fclose($fp);			
		}
		echo $json;
	}	
	
	
	public function traermlas() {
		
		$json = array();
		if (isset($this->request->get['plataforma_id'])){
			$plataforma_id=$this->request->get['plataforma_id'];
			$this->load->model('admdirsis/mlproducto');
			$json = $this->model_admdirsis_mlproducto->getListarmlas($plataforma_id);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function rasparmeli() {
		$scroll=array();
		if (isset($this->request->get['plataforma_id'])){
			$valor=$this->request->get['plataforma_id'];
			$scroll=$this->request->get['scroll'];
			$this->load->model('admdirsis/mlproducto');
			$scroll = $this->model_admdirsis_mlproducto->getRasparmeli($valor,$scroll,0);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($scroll));
	}
	
	public function actualizarmelixmla() {
		$resul='fallo';
		if (isset($this->request->get['mla'])){
			$valor=$this->request->get['mla'];
			$this->load->model('admdirsis/mlproducto');
			$resul = $this->model_admdirsis_mlproducto->getActualizamelixmla($valor);
		}
		echo $resul;
	}	
	public function actualizarmeli() {
		if (file_exists('log.txt')){
			unlink('log.txt');
		}
		$resul="";
		if (isset($_REQUEST['selected'])){
			foreach ($_REQUEST['selected'] as &$valor) {
				$resul.=$valor;
				$this->load->model('admdirsis/mlproducto');
				$result = $this->model_admdirsis_mlproducto->getActualizameli($valor);
			}
		}
		echo $resul;
	}
	public function actualizar() {
		if (isset($this->request->get['plataforma_id'])){
			$plataforma_id=$this->request->get['plataforma_id'];	
			$this->load->model('admdirsis/plataforma');
			$json = $this->model_admdirsis_plataforma->getPlataforma($plataforma_id);		
			echo $json['code'];
		}else{
			echo "0";
		}
		//$this->response->addHeader('Content-Type: application/json');
		//$this->response->setOutput(json_encode($json));		
	}
	function logs( $sql ) {
		$outputBuffer = fopen( 'log.txt', 'a' );
		fwrite( $outputBuffer, $sql . PHP_EOL );
		fclose( $outputBuffer );
	}

	public function leercategoria() {
		$this->load->model('admdirsis/mlproducto');
		$name=$categ='';
		if (isset($this->request->get['categ'])){
			$categ=$this->request->get['categ'];
		}
		if (isset($this->request->get['name'])){
			$name=$this->request->get['name'];
		}
		$results = $this->model_admdirsis_mlproducto->getLeercategoria($categ);
		$tabla=array();
		if ($results){
			foreach ($results as &$result){
				$tabla[]=array('id' => $result['id'], 'name' => $result['name'] , 'child' => $result['child']);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($tabla));		
	}
	public function subirproductoameli() {
		$json=array();
		$filter_data = array(
			'filter_marketplace'  => 'MELI',
			'filter_code'  => 'MELI'
		);		
		if (isset($this->request->get['product_id'])){
			$product_id=$this->request->get['product_id'];
			$categ=$this->request->get['categ'];
			$this->session->data['categ-defa']=$categ;
			$this->load->model('admdirsis/plataforma');
			$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
			foreach ($results as $result) {
				if ($result['code']=='MELI'){
					$this->load->model('admdirsis/mlproducto');
					$json = $this->model_admdirsis_mlproducto->putSubirproductoameli($product_id,$categ,$result);
					if (isset($json['id'])){
						$json2=$this->model_admdirsis_mlproducto->aplicaMlaaproduct($product_id,$json['id']);
					}
				}
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}	