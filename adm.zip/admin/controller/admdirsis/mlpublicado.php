<?php
class ControllerAdmdirsisMlpublicado extends Controller {
	private $error = array();

	public function index() {
		
	
		$this->load->language('admdirsis/mlpublicado');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlpublicado');
	
		$this->getList();
	}	
	public function delete() {
		$this->load->language('admdirsis/mlpublicado');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlpublicado');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {

			foreach ($this->request->post['selected'] as $mlpublicado_id){
				$this->model_admdirsis_mlpublicado->deleteProduct($mlpublicado_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_fecha'])) {
				$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_title'])) {
				$url .= '&filter_title=' . urlencode(html_entity_decode($this->request->get['filter_title'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_mla'])) {
				$url .= '&filter_mla=' . urlencode(html_entity_decode($this->request->get['filter_mla'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_categoryname'])) {
				$url .= '&filter_categoryname=' . urlencode(html_entity_decode($this->request->get['filter_categoryname'], ENT_QUOTES, 'UTF-8'));
			}			

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}	
	
	
	protected function getList() {
		
		if (isset($this->request->get['filter_fecha'])) {
			$filter_fecha = $this->request->get['filter_fecha'];
		} else {
			$filter_fecha = '';
		}
		if (isset($this->request->get['filter_title'])) {
			$filter_title = $this->request->get['filter_title'];
		} else {
			$filter_title = '';
		}
		if (isset($this->request->get['filter_mla'])) {
			$filter_mla = $this->request->get['filter_mla'];
		} else {
			$filter_mla = '';
		}
		if (isset($this->request->get['filter_categoryname'])) {
			$filter_categoryname = $this->request->get['filter_categoryname'];
		} else {
			$filter_categoryname = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'fecha';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_title'])) {
			$url .= '&filter_title=' . urlencode(html_entity_decode($this->request->get['filter_title'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_mla'])) {
			$url .= '&filter_mla=' . urlencode(html_entity_decode($this->request->get['filter_mla'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_categoryname'])) {
			$url .= '&filter_categoryname=' . urlencode(html_entity_decode($this->request->get['filter_categoryname'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['delete'] = $this->url->link('admdirsis/mlpublicado/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['products'] = array();
		$filter_data = array(
			'filter_fecha'	  => $filter_fecha,
			'filter_title'	  => $filter_title,
			'filter_mla'	  => $filter_mla,
			'filter_categoryname'	  => $filter_categoryname,
			'filter_status'   => $filter_status,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin')
		);
		
		

		
		$product_total = $this->model_admdirsis_mlpublicado->getTotalProducts($filter_data);

		$results = $this->model_admdirsis_mlpublicado->getProducts($filter_data);
		foreach ($results as $result) {
			$data['products'][] = array(
				'productmeli_id' => $result['productmeli_id'],
				'plataforma_id' => $result['plataforma_id'],
				'image'  => $result['image'],
				'link'  => $result['link'],
				'mla' 		 => $result['mla'],
				'sku'   	 => $result['sku'],
				'title'   	 => $result['title'],
				'fechaalta'      => $result['fechaalta'],
				'category_id' => $result['category_id'],
				'categoryname' => $result['categoryname'],
				'precio'      => $this->currency->format($result['precio'], $this->config->get('config_currency')),
				'stock'   		=> $result['stock'],
				'ventas'   		=> $result['ventas'],
				'status'     => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit'       => $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token']. $url, true),
				'pvp2'		=> isset($result['pvp2']) ? ' /<span style="color:red">'.$this->currency->format($result['pvp2'], $this->config->get('config_currency')).'</span>' : '',
				'qty'		=> isset($result['qty']) ? ' /<span style="color:red">'.$result['qty'].'</span>' : ''
			);
		}
		
		
		$data['plataformas'] = array();
		$filter_data = array(
			'filter_code'  => 'MELI'
		);
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		foreach ($results as $result) {
			$data['plataformas'][] = array(
				'plataforma_id' => $result['plataforma_id'],
				'marketplace'          => $result['marketplace'],
			);
		}
		

		
		
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_title'])) {
			$url .= '&filter_title=' . urlencode(html_entity_decode($this->request->get['filter_title'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_mla'])) {
			$url .= '&filter_mla=' . urlencode(html_entity_decode($this->request->get['filter_mla'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_categoryname'])) {
			$url .= '&filter_categoryname=' . urlencode(html_entity_decode($this->request->get['filter_categoryname'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_fechaalta'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fechaalta' . $url, true);
		$data['sort_plataforma_id'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.plataforma_id' . $url, true);
		$data['sort_sku'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.sku' . $url, true);
		$data['sort_mla'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.mla' . $url, true);
		$data['sort_title'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.title' . $url, true);
		$data['sort_precio'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.precioe' . $url, true);
		$data['sort_stock'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.stock' . $url, true);
		$data['sort_ventas'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.ventas' . $url, true);
		$data['sort_category_id'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.category_id' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . '&sort=a.status' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_fecha'])) {
			$url .= '&filter_fecha=' . urlencode(html_entity_decode($this->request->get['filter_fecha'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_title'])) {
			$url .= '&filter_title=' . urlencode(html_entity_decode($this->request->get['filter_title'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_mla'])) {
			$url .= '&filter_mla=' . urlencode(html_entity_decode($this->request->get['filter_mla'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_categoryname'])) {
			$url .= '&filter_categoryname=' . urlencode(html_entity_decode($this->request->get['filter_categoryname'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/mlpublicado', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
	
		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));
		


		$data['filter_fecha'] = $filter_fecha;
		$data['filter_title'] = $filter_title;
		$data['filter_mla'] = $filter_mla;
		$data['filter_categoryname'] = $filter_categoryname;
		$data['filter_status'] = $filter_status;
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		

		$this->response->setOutput($this->load->view('admdirsis/mlpublicado_list', $data));
	}	
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/mlpublicado')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	
	
	public function leermeli() {
		$json = ' Se revisaron: ';
		$valor=$this->request->get['plataforma_id'];
		if (isset($this->request->get['scroll'])){
			$scroll=$this->request->get['scroll'];
		}else{
			$scroll='';
		}
		if (isset($this->request->get['total'])){
			$total=$this->request->get['total'];
		}else{
			$total=0;
		}	
		if (isset($this->request->get['offset'])){
			$offset=$this->request->get['offset'];
		}else{
			$offset=0;
		}		
		if (isset($this->request->get['recorridos'])){
			$recorridos=$this->request->get['recorridos'];
		}else{
			$recorridos=0;
		}		

		/*
		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		$this->load->model('setting/setting');	
		$store_id = $this->config->get('config_store_id');
		$store_name = $this->config->get('config_name');
		$store_url = $this->config->get('config_url');
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		$this->load->model('admdirsis/mlproducto');
		foreach ($results as $result) {
			if (isset($result)){
				$valor = $result['plataforma_id'];
		*/
				$this->load->model('admdirsis/mlproducto');
				$scrollr = $this->model_admdirsis_mlproducto->getRasparmeli($valor,$scroll,$total,$offset,$recorridos);
		/*		
			}
			break;
		}
		*/
		echo $scrollr['scroll'],",".$scrollr['total'].",".$scrollr['offset'].",".$scrollr['recorridos'];
		//echo $scrollr['scroll_id'].",".$scrollr['paging']['total'].",".$scrollr['recorridos'];
	}
}