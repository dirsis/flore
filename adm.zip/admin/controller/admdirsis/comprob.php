<?php
class ControllerAdmdirsisComprob extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/comprob');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/comprob');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/comprob');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/comprob');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_comprob->addComprob($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/comprob');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/comprob');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_comprob->editComprob($this->request->get['comprob_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/comprob');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/comprob');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $comprob_id) {
				$this->model_admdirsis_comprob->deleteComprob($comprob_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/comprob/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/comprob/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['comprobs'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$comprob_total = $this->model_admdirsis_comprob->getTotalComprobs();

		$results = $this->model_admdirsis_comprob->getComprobs($filter_data);

		foreach ($results as $result) {
			$data['comprobs'][] = array(
				'comprob_id' => $result['comprob_id'],
				'name'          => $result['name'],
				'estado'          => $result['estado'],
				'baseimp'          => $result['baseimp'],
				'd_estado'          => $result['d_estado'],
				'ctacte'          => $result['ctacte'],
				'd_ctacte'          => $result['d_ctacte'],				
				'stock'          => $result['stock'],				
				'd_stock'          => $result['d_stock'],				
				'd_caja'          => $result['d_caja'],
				'afip'          => $result['afip'],
				'product_id'          => $result['product_id'],
				'edit'          => $this->url->link('admdirsis/comprob/edit', 'user_token=' . $this->session->data['user_token'] . '&comprob_id=' . $result['comprob_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_estado'] = $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $comprob_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($comprob_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($comprob_total - $this->config->get('config_limit_admin'))) ? $comprob_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $comprob_total, ceil($comprob_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/comprob_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['comprob_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['comprob_id'])) {
			$data['action'] = $this->url->link('admdirsis/comprob/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/comprob/edit', 'user_token=' . $this->session->data['user_token'] . '&comprob_id=' . $this->request->get['comprob_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/comprob', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['comprob_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$comprob_info = $this->model_admdirsis_comprob->getComprob($this->request->get['comprob_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($comprob_info)) {
			$data['name'] = $comprob_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['estado'])) {
			$data['estado'] = $this->request->post['estado'];
		} elseif (!empty($comprob_info)) {
			$data['estado'] = $comprob_info['estado'];
		} else {
			$data['estado'] = '';
		}	
		
		if (isset($this->request->post['baseimp'])) {
			$data['baseimp'] = $this->request->post['baseimp'];
		} elseif (!empty($comprob_info)) {
			$data['baseimp'] = $comprob_info['baseimp'];
		} else {
			$data['baseimp'] = '';
		}	
		
		if (isset($this->request->post['ctacte'])) {
			$data['ctacte'] = $this->request->post['ctacte'];
		} elseif (!empty($comprob_info)) {
			$data['ctacte'] = $comprob_info['ctacte'];
		} else {
			$data['ctacte'] = '';
		}	

		if (isset($this->request->post['stock'])) {
			$data['stock'] = $this->request->post['stock'];
		} elseif (!empty($comprob_info)) {
			$data['stock'] = $comprob_info['stock'];
		} else {
			$data['stock'] = '';
		}	
		
		if (isset($this->request->post['afip'])) {
			$data['afip'] = $this->request->post['afip'];
		} elseif (!empty($comprob_info)) {
			$data['afip'] = $comprob_info['afip'];
		} else {
			$data['afip'] = '';
		}		

		if (isset($this->request->post['product_id'])) {
			$data['product_id'] = $this->request->post['product_id'];
		} elseif (!empty($comprob_info)) {
			$data['product_id'] = $comprob_info['product_id'];
		} else {
			$data['product_id'] = '';
		}
		
		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($comprob_info['permission']['access'])) {
			$data['access'] = $comprob_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($comprob_info['permission']['modify'])) {
			$data['modify'] = $comprob_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/comprob_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/comprob')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/comprob')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $comprob_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($comprob_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			$this->load->model('admdirsis/comprob');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_comprob->getComprobs($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'comprob_id' => $result['comprob_id'],
					'name'     => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'estado'    => $result['estado'],
					'baseimp'    => $result['baseimp'],
					'ctacte'    => $result['ctacte'],
					'stock'    => $result['stock'],
					'afip'    => $result['afip']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}