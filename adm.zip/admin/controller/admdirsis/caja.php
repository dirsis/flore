<?php
class ControllerAdmdirsisCaja extends Controller {
	private $error = array();
	

	public function index() {
		
		

		
		date_default_timezone_set('America/Buenos_Aires');
		$this->load->language('admdirsis/caja');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/caja');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/caja');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/caja');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_caja->addCaja($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = '';
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			$this->response->redirect($this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/caja');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/caja');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_caja->editCaja($this->request->get['caja_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/caja');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/caja');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $caja_id) {
				$this->model_admdirsis_caja->deleteCaja($caja_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'caja_id';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/caja/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/caja/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['cajas'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		

		
		$caja_total = $this->model_admdirsis_caja->getTotalCajas();
//print_r($filter_data);
		$results = $this->model_admdirsis_caja->getCajas($filter_data);

		foreach ($results as $result) {
			$this->load->model('admdirsis/contab');		
			$results2 = $this->model_admdirsis_contab->getContabcaja($result['caja_id']);
			$venta=$cobranza=$retiro=$gasto=$efectivo=$transf=$tarjeta=$ctacte=0;
			if ($results){
				foreach ($results2 as $result2) {
					if ($result2['caja']==4){
						$cobranza=$cobranza+$result2['total'];
					}
					if ($result2['caja']==3){
						$venta=$venta+$result2['total'];
					}
					if ($result2['caja']==2){
						$retiro=$retiro+=$result2['total'];
					}
					if ($result2['caja']==1){
						$gasto=$gasto+$result2['total'];
					}

					if ($result2['tipo']==4){
						$ctacte=$ctacte+$result2['total'];
					}
					if ($result2['tipo']==3){
						$transf=$transf+$result2['total'];
					}
					if ($result2['tipo']==2){
						$tarjeta=$tarjeta+$result2['total'];
					}
					if ($result2['tipo']==1){
						$efectivo=$efectivo+$result2['total'];
					}				
				}
			}
			
			$data['cajas'][] = array(
			'caja_id' 		=> $result['caja_id'],
  			'user_id' 		=> $result['user_id'],
			'username' 		=> $result['username'],
  			'location_id' 	=> $result['location_id'],
  			'fechaapertura' => date("d-m-Y h:i",strtotime($result['fechaapertura'])),
  			'fechacierre' 	=> $result['status']=='1'?date("d-m-Y h:i",strtotime($result['fechacierre'])):'',
  			'turno' 		=> $result['turno'],
  			'saldoarrastre' => $this->currency->format($result['saldoarrastre'], $this->config->get('config_currency')),
  			'saldoinicial' 	=> $this->currency->format($result['saldoinicial'], $this->config->get('config_currency')),
  			'saldofinal' 	=> $this->currency->format($result['saldofinal'], $this->config->get('config_currency')),
  			'venta' 	=> $this->currency->format($venta, $this->config->get('config_currency')),
  			'cobranza' 	=> $this->currency->format($cobranza, $this->config->get('config_currency')),
  			'efectivo' 	=> $this->currency->format($efectivo, $this->config->get('config_currency')),
  			'tarjeta' 	=> $this->currency->format($tarjeta, $this->config->get('config_currency')),
  			'transf' 	=> $this->currency->format($transf, $this->config->get('config_currency')),
  			'ctacte' 	=> $this->currency->format($ctacte, $this->config->get('config_currency')),
  			'saldofinal' 	=> $this->currency->format($result['saldofinal'], $this->config->get('config_currency')),
  			'saldofinal' 	=> $this->currency->format($result['saldofinal'], $this->config->get('config_currency')),
			'finalcaja' 	=> $this->currency->format($result['finalcaja'], $this->config->get('config_currency')),
  			'loteuser' 		=> $this->currency->format($result['loteuser'], $this->config->get('config_currency')),
  			'notauser' 		=> $result['notauser'],
  			'notasuper' 	=> $result['notasuper'],
  			'status' 		=> $result['status'],				
			'edit'          => $this->url->link('admdirsis/caja/edit', 'user_token=' . $this->session->data['user_token'] . '&caja_id=' . $result['caja_id'] . $url, true),
			'detalle'          => $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&filter_caja_id=' . $result['caja_id'] . $url, true)				
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
	$data['sort_caja_id'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=caja_id' . $url, true);
	$data['sort_user_id'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=user_id' . $url, true);
	$data['sort_location_id'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=location_id' . $url, true);
	$data['sort_fechaapertura'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=fechaapertura' . $url, true);
	$data['sort_fechacierre'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=fechacierre' . $url, true);
	$data['sort_turno'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=turno' . $url, true);
	$data['sort_notauser'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . '&sort=notauser' . $url, true);
	
		

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $caja_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($caja_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($caja_total - $this->config->get('config_limit_admin'))) ? $caja_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $caja_total, ceil($caja_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/caja_list', $data));
	}

	protected function getForm() {
		
		
		ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
		
		
		$data['text_form'] = !isset($this->request->get['caja_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);



		$data['cancel'] = $this->url->link('admdirsis/caja', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		
		$data['user_id'] = $this->user->getId();
		$this->load->model('user/user');
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			$data['username'] = $user_info['username'];	
			$data['location_id'] = $user_info['location_id'];	
		}
		if (isset($this->request->get['caja_id'])) {
			$caja_info = $this->model_admdirsis_caja->getCaja($this->request->get['caja_id']);
			if ($caja_info['status']=='0'){
				$this->model_admdirsis_caja->getCajaAsocialibre($data['user_id'] ,$caja_info['caja_id']);
			}
		}else{
			$caja_info = $this->model_admdirsis_caja->getCajavigente($data['user_id']);
			if (!empty($caja_info)) {
				$this->model_admdirsis_caja->getCajaAsocialibre($data['user_id'] ,$caja_info['caja_id']);
			}
		}

		if (isset($this->request->post['caja_id'])) {
			$data['caja_id'] = $this->request->post['caja_id'];
		} elseif (!empty($caja_info)) {
			$data['caja_id'] = $caja_info['caja_id'];
		} else {
			$data['caja_id'] = '0';
		}
		
		if ($data['caja_id']==0) {
			$data['action'] = $this->url->link('admdirsis/caja/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/caja/edit', 'user_token=' . $this->session->data['user_token'] . '&caja_id=' . $data['caja_id'] . $url, true);
		}
		
		
		if (isset($this->request->post['location_id'])) {
			$data['location_id'] = $this->request->post['location_id'];
		} elseif (!empty($caja_info)) {
			$data['location_id'] = $caja_info['location_id'];
		} else {
			//$data['location_id'] = '';
		}
		
		if (isset($this->request->post['user_id'])) {
			$data['user_id'] = $this->request->post['user_id'];
		} elseif (!empty($caja_info)) {
			$data['user_id'] = $caja_info['user_id'];
		} else {
			//$data['user_id'] = $'';
		}
 
		if (isset($this->request->post['fechaapertura'])) {
			$data['fechaapertura'] = $this->request->post['fechaapertura'];
		} elseif (!empty($caja_info)) {
			$data['fechaapertura'] = date('d-m-y h:m',strtotime($caja_info['fechaapertura']));
		} else {
			$data['fechaapertura'] = date('d-m-y h:m');
		}
		
		if (isset($this->request->post['fechacierre'])) {
			$data['fechacierre'] = $this->request->post['fechacierre'];
		} elseif (!empty($caja_info)) {
			$data['fechacierre'] = $caja_info['fechacierre'];
		} else {
			if ($data['caja_id']!=0){
				$data['fechacierre'] = date('d-m-y h:m');
			}
		}
		
		if (isset($this->request->post['turno'])) {
			$data['turno'] = $this->request->post['turno'];
		} elseif (!empty($caja_info)) {
			$data['turno'] = $caja_info['turno'];
		} else {
			$data['turno'] = '1';
		}
		
		if (isset($this->request->post['saldoarrastre'])) {
			$data['saldoarrastre'] = $this->request->post['saldoarrastre'];
			$data['saldoarrastre2']=$this->request->post['saldoarrastre'];
		} elseif (!empty($caja_info)) {
			$data['saldoarrastre'] = $this->currency->format($caja_info['saldoarrastre'], $this->config->get('config_currency'));
			$data['saldoarrastre2'] = $caja_info['saldoarrastre'];
		} else {
			$data['saldoarrastre'] = '';
			$data['saldoarrastre2']=0;
		}
		

				
		$saldoinicial=0;
		if (isset($this->request->post['saldoinicial'])) {
			$data['saldoinicial'] = $this->request->post['saldoinicial'];
			$saldoinicial = (int)$this->request->post['saldoinicial'];
		} elseif (!empty($caja_info)) {
			$data['saldoinicial'] = $this->currency->format($caja_info['saldoinicial'], $this->config->get('config_currency'));
			$saldoinicial=(int)$caja_info['saldoinicial'];
		} else {
			$data['saldoinicial'] = 0;
		}
		$data['saldoinicial2']=$saldoinicial;
		
		if (isset($this->request->post['finalcaja'])) {
			$data['finalcaja'] = $this->request->post['finalcaja'];
		} elseif (!empty($caja_info)) {
			$data['finalcaja'] = intval($caja_info['finalcaja']);
		} else {
			$data['finalcaja'] = '';
		}
		
/*		
		
		if (isset($this->request->post['saldofinal'])) {
			$data['saldofinal'] = $this->request->post['saldofinal'];
		} elseif (!empty($caja_info)) {
			$data['saldofinal'] = $this->currency->format($caja_info['saldofinal'], $this->config->get('config_currency'));
		} else {
			$data['saldofinal'] = '';
		}
*/
		
		if (isset($this->request->post['loteuser'])) {
			$data['loteuser'] = $this->request->post['loteuser'];
		} elseif (!empty($caja_info)) {
			$data['loteuser'] = intval($caja_info['loteuser']);
		} else {
			$data['loteuser'] = '';
		}
		
		if (isset($this->request->post['notauser'])) {
			$data['notauser'] = $this->request->post['notauser'];
		} elseif (!empty($caja_info)) {
			$data['notauser'] = $caja_info['notauser'];
		} else {
			$data['notauser'] = '';
		}
		
		if (isset($this->request->post['notasuper'])) {
			$data['notasuper'] = $this->request->post['notasuper'];
		} elseif (!empty($caja_info)) {
			$data['notasuper'] = $caja_info['notasuper'];
		} else {
			$data['notasuper'] = '';
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($caja_info)) {
			$data['status'] = $caja_info['status'];
		} else {
			$data['status'] = '';
		}		
		
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->load->model('localisation/location');
		$results = $this->model_localisation_location->getLocations();	
		
		foreach ($results as $result) {
			$data['locations'][] = array(
				'location_id' => $result['location_id'],
				'name'          => $result['name']
			);
		}		
		
		if ($data['caja_id']!=0){
			$this->load->model('admdirsis/contab');		
			$results = $this->model_admdirsis_contab->getContabcaja($data['caja_id']);
			$venta=$cobranza=$retiro=$gasto=$efectivo=$transf=$tarjeta=$ctacte=0;
			if ($results){
				foreach ($results as $result) {
					if ($result['caja']==4){
						$cobranza=$cobranza+$result['total'];
					}
					if ($result['caja']==3){
						$venta=$venta+$result['total'];
					}
					if ($result['caja']==2){
						$retiro=$retiro+=$result['total'];
					}
					if ($result['caja']==1){
						$gasto=$gasto+$result['total'];
					}

					if ($result['tipo']==4){
						$ctacte=$ctacte+$result['total'];
					}
					if ($result['tipo']==3){
						$transf=$transf+$result['total'];
					}
					if ($result['tipo']==2){
						$tarjeta=$tarjeta+$result['total'];
					}
					if ($result['tipo']==1){
						$efectivo=$efectivo+$result['total'];
					}				
				}
			}

			$data['venta'] = $venta;
			$data['tarjeta'] = $tarjeta;
			$data['transf'] = $transf;
			$data['efectivo'] = $efectivo;
			$data['cobranza'] = $cobranza;
			$data['gasto'] = $gasto;
			$data['retiro'] = $retiro;
			$data['ctacte'] = $ctacte;
			$saldofinal = ($saldoinicial+$efectivo)-($gasto+$retiro);
			$data['saldofinal'] = $this->currency->format($saldofinal, $this->config->get('config_currency'));
		}else{
			$saldoarrastre=$this->model_admdirsis_caja->getSaldoArrastre($data['user_id']);
			$data['saldoarrastre'] = $this->currency->format($saldoarrastre, $this->config->get('config_currency'));
			$data['saldoarrastre2'] = $saldoarrastre;			
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/caja_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/caja')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}
*/		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/caja')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $caja_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($caja_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			$this->load->model('admdirsis/caja');

			$filter_data = array(
				'filter_name'      => $filter_name,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_caja->getCajas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'caja_id' => $result['caja_id'],
					'name'     => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'letra'    => $result['letra']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}