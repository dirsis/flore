<?php
class ControllerAdmdirsisPreciosvencidos extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/preciosvencidos');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/preciosvencidos');

		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		
		if (isset($this->request->get['filter_codigo'])) {
			$filter_codigo = $this->request->get['filter_codigo'];
		} else {
			$filter_codigo = '';
		}		
		
		if (isset($this->request->get['filter_idarticulo'])) {
			$filter_idarticulo = $this->request->get['filter_idarticulo'];
		} else {
			$filter_idarticulo = '';
		}	
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}				
		
		if (isset($this->request->get['filter_grupo'])) {
			$filter_grupo = $this->request->get['filter_grupo'];
		} else {
			$filter_grupo = '';
		}

		if (isset($this->request->get['filter_sgrupo'])) {
			$filter_sgrupo = $this->request->get['filter_sgrupo'];
		} else {
			$filter_sgrupo = '';
		}
		if (isset($this->request->get['filter_ssgrupo'])) {
			$filter_ssgrupo = $this->request->get['filter_ssgrupo'];
		} else {
			$filter_ssgrupo = '';
		}
		if (isset($this->request->get['filter_sssgrupo'])) {
			$filter_sssgrupo = $this->request->get['filter_sssgrupo'];
		} else {
			$filter_sssgrupo = '';
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = date('Y-m-d', strtotime('-1 month'));
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'subtotal';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}		

		if (isset($this->request->get['filter_codigo'])) {
			$url .= '&filter_codigo=' . $this->request->get['filter_codigo'];
		}		

		if (isset($this->request->get['filter_grupo'])) {
			$url .= '&filter_grupo=' . urlencode(html_entity_decode($this->request->get['filter_grupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sgrupo'])) {
			$url .= '&filter_sgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_ssgrupo'])) {
			$url .= '&filter_ssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_ssgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_sssgrupo'])) {
			$url .= '&filter_sssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sssgrupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$limite=100; //$this->config->get('config_limit_admin');

		$data['preciosvencidoss'] = array();

		$filter_data = array(
			'filter_codigo'  => $filter_codigo,
			'filter_descrip'  => $filter_descrip,
			'filter_grupo'	     => $filter_grupo,
			'filter_sgrupo'	     => $filter_sgrupo,
			'filter_ssgrupo'	     => $filter_ssgrupo,
			'filter_sssgrupo'	     => $filter_sssgrupo,
			'filter_date_desde'      => $filter_date_desde,
			'filter_date_hasta'   	 => $filter_date_hasta,
			'sort'                   => $sort,
			'order'                  => $order,
			'start'                  => ($page - 1) * $limite,
			'limit'                  => $limite
		);

		$order_total = $this->model_admdirsis_preciosvencidos->getTotalPreciosvencidoss($filter_data);
		
		$results = $this->model_admdirsis_preciosvencidos->getPreciosvencidoss($filter_data);
		foreach ($results as $result) {
			$data['preciosvencidoss'][] = array(
				'art_id'     => $result['art_id'],
				'idarticulo'    => $result['idarticulo'],
				'codigo'  		=> $result['codigo'],
				'descrip'      	=> $result['descrip'],
				'grupo'      	=> $result['grupo'],
				'sgrupo'      	=> $result['sgrupo'],
				'ssgrupo'      	=> $result['ssgrupo'],
				'sssgrupo'      => $result['sssgrupo'],
				'stock'      	=> $result['stock'],
				'costo'         => number_format($result['costo'],2,",","."),
				'venta'         => number_format($result['venta'],2,",","."),
				'fechaact1'      => $result['fechaact'],
				'fechaact'      =>substr(trim($result['fechaact']),-2)."/".substr($result['fechaact'],5,2)."/".substr($result['fechaact'],1,4),
				'estado'      	=> $result['estado'],
			);
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}
		
		if (isset($this->request->get['filter_codigo'])) {
			$url .= '&filter_codigo=' . $this->request->get['filter_codigo'];
		}	
		
		if (isset($this->request->get['filter_idarticulo'])) {
			$url .= '&filter_idarticulo=' . $this->request->get['filter_idarticulo'];
		}		
		
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}	
		
		
		if (isset($this->request->get['filter_grupo'])) {
			$url .= '&filter_grupo=' . urlencode(html_entity_decode($this->request->get['filter_grupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sgrupo'])) {
			$url .= '&filter_sgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_ssgrupo'])) {
			$url .= '&filter_ssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_ssgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_sssgrupo'])) {
			$url .= '&filter_sssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sssgrupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_usuario'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=usuario' . $url, true);
		$data['sort_idarticulo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=idarticulo' . $url, true);
		$data['sort_codigo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=codigo' . $url, true);
		$data['sort_grupo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=grupo' . $url, true);
		$data['sort_sgrupo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=sgrupo' . $url, true);
		$data['sort_ssgrupo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=ssgrupo' . $url, true);
		$data['sort_sssgrupo'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=sssgrupo' . $url, true);
		$data['sort_total'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=total' . $url, true);
		$data['sort_fechaact'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=fechaact' . $url, true);
		$data['sort_descrip'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=descrip' . $url, true);
		$data['sort_cantidad'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=cantidad' . $url, true);
		$data['sort_subtotal'] = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . '&sort=subtotal' . $url, true);
		$url = '';

		if (isset($this->request->get['filter_codigo'])) {
			$url .= '&filter_codigo=' . $this->request->get['filter_codigo'];
		}	
		
		if (isset($this->request->get['filter_idarticulo'])) {
			$url .= '&filter_idarticulo=' . $this->request->get['filter_idarticulo'];
		}
		
		if (isset($this->request->get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $this->request->get['filter_descrip'];
		}		
		
		if (isset($this->request->get['filter_grupo'])) {
			$url .= '&filter_grupo=' . urlencode(html_entity_decode($this->request->get['filter_grupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_sgrupo'])) {
			$url .= '&filter_sgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_ssgrupo'])) {
			$url .= '&filter_ssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_ssgrupo'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_sssgrupo'])) {
			$url .= '&filter_sssgrupo=' . urlencode(html_entity_decode($this->request->get['filter_sssgrupo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}

		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $limite;
		$pagination->url = $this->url->link('admdirsis/preciosvencidos', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $limite) + 1 : 0, ((($page - 1) * $limite) > ($order_total - $limite)) ? $order_total : ((($page - 1) * $limite) + $limite), $order_total, ceil($order_total / $limite));

		$data['filter_codigo'] = $filter_codigo;
		$data['filter_idarticulo'] = $filter_idarticulo;	
		$data['filter_descrip'] = $filter_descrip;			
		$data['filter_grupo'] = $filter_grupo;
		$data['filter_sgrupo'] = $filter_sgrupo;
		$data['filter_ssgrupo'] = $filter_ssgrupo;
		$data['filter_sssgrupo'] = $filter_sssgrupo;
		$data['filter_date_desde'] = $filter_date_desde;
		$data['filter_date_hasta'] = $filter_date_hasta;

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		//die;

		$this->response->setOutput($this->load->view('admdirsis/preciosvencidos_list', $data));
	}
		
}
