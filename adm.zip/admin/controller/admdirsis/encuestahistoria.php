<?php
class ControllerAdmdirsisEncuestahistoria extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		$this->getList();
	}
	
	public function delete() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $product_id) {
				$this->model_admdirsis_encuesta->deleteEncuestahistorial($product_id);
				//print_r($product_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_tema'])) {
				$url .= '&filter_tema=' . $this->request->get['filter_tema'];
			}

			if (isset($this->request->get['filter_username'])) {
				$url .= '&filter_username=' . $this->request->get['filter_username'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}		

			if (isset($this->request->get['filter_date_init'])) {
				$url .= '&filter_date_init=' . $this->request->get['filter_date_init'];
			}

			if (isset($this->request->get['filter_date_end'])) {
				$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
			}		

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}	

	protected function getList() {
		
		if (isset($this->request->get['filter_tema'])) {
			$filter_tema = $this->request->get['filter_tema'];
		} else {
			$filter_tema = '';
		}
		
		if (isset($this->request->get['filter_username'])) {
			$filter_username = $this->request->get['filter_username'];
		} else {
			$filter_username = '';
		}
		
		if (isset($this->request->get['filter_ip'])) {
			$filter_ip = $this->request->get['filter_ip'];
		} else {
			$filter_ip = '';
		}	
		
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = $this->request->get['filter_date_init'];
		} else {
			$filter_date_init = '';
		}	
		
		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = $this->request->get['filter_date_end'];
		} else {
			$filter_date_end = '';
		}			
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'b.tema';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_tema'])) {
			$url .= '&filter_tema=' . $this->request->get['filter_tema'];
		}
		
		if (isset($this->request->get['filter_username'])) {
			$url .= '&filter_username=' . $this->request->get['filter_username'];
		}
		
		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}		
		
		if (isset($this->request->get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $this->request->get['filter_date_init'];
		}

		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}		
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['delete'] = $this->url->link('admdirsis/encuestahistoria/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['turneros'] = array();

		$filter_data = array(
			'filter_tema' => $filter_tema,
			'filter_username' => $filter_username,
			'filter_ip' => $filter_ip,
			'filter_date_init' => $filter_date_init,
			'filter_date_end' => $filter_date_end,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$encuestahistorials_total = $this->model_admdirsis_encuesta->getTotalEncuestahistorials();

		$results = $this->model_admdirsis_encuesta->getEncuestahistorials($filter_data);

		foreach ($results as $result) {
			$data['encuestahistorials'][] = array(
				'encuestahistorial_id' 	=> $result['encuestahistorial_id'],
				'encuesta_id' 			=> $result['encuesta_id'],
				'tema'          		=> $result['tema'],
				'fecha'    				=> date($this->language->get('date_format_short'), strtotime($result['fecha'])),
				'username'   			=> $result['username'],
				'voto'		   			=> $result['voto'],
				'ip'     				=> $result['ip'],
				'status'          		=> $result['status']);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		
		if (isset($this->request->get['filter_tema'])) {
			$url .= '&filter_tema=' . $this->request->get['filter_tema'];
		}
		
		if (isset($this->request->get['filter_username'])) {
			$url .= '&filter_username=' . $this->request->get['filter_username'];
		}
		
		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}		

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_tema'] = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . '&sort=a.tema' . $url, true);
		$data['sort_username'] = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . '&sort=b.username' . $url, true);
		$data['sort_voto'] = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . '&sort=a.voto' . $url, true);
		$data['sort_fecha'] = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . '&sort=a.fecha' . $url, true);
		$data['sort_ip'] = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . '&sort=ip' . $url, true);

		
		$url = '';
		
		if (isset($this->request->get['filter_tema'])) {
			$url .= '&filter_tema=' . $this->request->get['filter_tema'];
		}
		
		if (isset($this->request->get['filter_username'])) {
			$url .= '&filter_username=' . $this->request->get['filter_username'];
		}
		
		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}		
		
		if (isset($this->request->get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $this->request->get['filter_date_init'];
		}

		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $encuestahistorials_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/encuestahistoria', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($encuestahistorials_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($encuestahistorials_total - $this->config->get('config_limit_admin'))) ? $encuestahistorials_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $encuestahistorials_total, ceil($encuestahistorials_total / $this->config->get('config_limit_admin')));

		$data['filter_ip'] = $filter_ip;
		$data['filter_username'] = $filter_username;
		$data['filter_tema'] = $filter_tema;
		$data['filter_date_init'] = $filter_date_init;
		$data['filter_date_end'] = $filter_date_end;
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/encuestahistoria_list', $data));
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/encuestahistoria')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
}