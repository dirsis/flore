<?php
class ControllerAdmdirsisPlataforma extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/plataforma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/plataforma');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/plataforma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/plataforma');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_admdirsis_plataforma->addPlataforma($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/plataforma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/plataforma');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_plataforma->editPlataforma($this->request->get['plataforma_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/plataforma');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/plataforma');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $plataforma_id) {
				$this->model_admdirsis_plataforma->deletePlataforma($plataforma_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'marketplace';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/plataforma/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/plataforma/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['plataformas'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$plataforma_total = $this->model_admdirsis_plataforma->getTotalPlataformas();

		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);

		foreach ($results as $result) {
			$data['plataformas'][] = array(
				'plataforma_id' => $result['plataforma_id'],
				'marketplace'          => $result['marketplace'],
				'code'          => $result['code'],
				'client_id'          => $result['client_id'],
				'secret_id'          => $result['secret_id'],
				'token_id'          => $result['token_id'],
				'stock_base'          => $result['stock_base'],
				'precio_base'          => $result['precio_base'],
				'dto_base'          => $result['dto_base'],
				'script_stock'          => $result['script_stock'],
				'estado'          => $result['estado'],
				'edit'          => $this->url->link('admdirsis/plataforma/edit', 'user_token=' . $this->session->data['user_token'] . '&plataforma_id=' . $result['plataforma_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_marketplace'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=marketplace' . $url, true);
		$data['sort_code'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=code' . $url, true);		
		$data['sort_client_id'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=client_id' . $url, true);
		$data['sort_stock_base'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=stock_base' . $url, true);
		$data['sort_precio_base'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=precio_base' . $url, true);
		$data['sort_dto_base'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=dto_base' . $url, true);
		$data['sort_estado'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $plataforma_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($plataforma_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($plataforma_total - $this->config->get('config_limit_admin'))) ? $plataforma_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $plataforma_total, ceil($plataforma_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$data['user_token'] = $this->session->data['user_token'];

		$this->response->setOutput($this->load->view('admdirsis/plataforma_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['plataforma_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['marketplace'])) {
			$data['error_marketplace'] = $this->error['marketplace'];
		} else {
			$data['error_marketplace'] = '';
		}
		
		if (isset($this->error['code'])) {
			$data['error_code'] = $this->error['code'];
		} else {
			$data['error_code'] = '';
		}
		
		if (isset($this->error['client_id'])) {
			$data['error_client_id'] = $this->error['client_id'];
		} else {
			$data['error_client_id'] = '';
		}
		
		if (isset($this->error['secret_id'])) {
			$data['error_secret_id'] = $this->error['secret_id'];
		} else {
			$data['error_secret_id'] = '';
		}		
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['plataforma_id'])) {
			$data['action'] = $this->url->link('admdirsis/plataforma/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/plataforma/edit', 'user_token=' . $this->session->data['user_token'] . '&plataforma_id=' . $this->request->get['plataforma_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/plataforma', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['plataforma_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$plataforma_info = $this->model_admdirsis_plataforma->getPlataforma($this->request->get['plataforma_id']);
		}

		if (isset($this->request->post['marketplace'])) {
			$data['marketplace'] = $this->request->post['marketplace'];
		} elseif (!empty($plataforma_info)) {
			$data['marketplace'] = $plataforma_info['marketplace'];
		} else {
			$data['marketplace'] = '';
		}
		
		if (isset($this->request->post['code'])) {
			$data['code'] = $this->request->post['code'];
		} elseif (!empty($plataforma_info)) {
			$data['code'] = $plataforma_info['code'];
		} else {
			$data['code'] = '';
		}
		
		if (isset($this->request->post['client_id'])) {
			$data['client_id'] = $this->request->post['client_id'];
		} elseif (!empty($plataforma_info)) {
			$data['client_id'] = $plataforma_info['client_id'];
		} else {
			$data['client_id'] = '';
		}		
		
		if (isset($this->request->post['secret_id'])) {
			$data['secret_id'] = $this->request->post['secret_id'];
		} elseif (!empty($plataforma_info)) {
			$data['secret_id'] = $plataforma_info['secret_id'];
		} else {
			$data['secret_id'] = '';
		}		
				
		if (isset($this->request->post['token_id'])) {
			$data['token_id'] = $this->request->post['token_id'];
		} elseif (!empty($plataforma_info)) {
			$data['token_id'] = $plataforma_info['token_id'];
		} else {
			$data['token_id'] = '';
		}
		
		if (isset($this->request->post['stock_base'])) {
			$data['stock_base'] = $this->request->post['stock_base'];
		} elseif (!empty($plataforma_info)) {
			$data['stock_base'] = $plataforma_info['stock_base'];
		} else {
			$data['stock_base'] = '';
		}
		
		if (isset($this->request->post['precio_base'])) {
			$data['precio_base'] = $this->request->post['precio_base'];
		} elseif (!empty($plataforma_info)) {
			$data['precio_base'] = $plataforma_info['precio_base'];
		} else {
			$data['precio_base'] = '';
		}
		
		if (isset($this->request->post['dto_base'])) {
			$data['dto_base'] = $this->request->post['dto_base'];
		} elseif (!empty($plataforma_info)) {
			$data['dto_base'] = $plataforma_info['dto_base'];
		} else {
			$data['dto_base'] = '';
		}
		
		if (isset($this->request->post['script_stock'])) {
			$data['script_stock'] = $this->request->post['script_stock'];
		} elseif (!empty($plataforma_info)) {
			$data['script_stock'] = $plataforma_info['script_stock'];
		} else {
			$data['script_stock'] = '';
		}		
		
		
		
		if (isset($this->request->post['estado'])) {
			$data['estado'] = $this->request->post['estado'];
		} elseif (!empty($plataforma_info)) {
			$data['estado'] = $plataforma_info['estado'];
		} else {
			$data['estado'] = '';
		}		

		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($plataforma_info['permission']['access'])) {
			$data['access'] = $plataforma_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($plataforma_info['permission']['modify'])) {
			$data['modify'] = $plataforma_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/plataforma_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/plataforma')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['marketplace']) < 3) || (utf8_strlen($this->request->post['marketplace']) > 64)) {
			$this->error['marketplace'] = $this->language->get('error_marketplace');
		}
		
/*
		if ((utf8_strlen($this->request->post['estado']) < 3) || (utf8_strlen($this->request->post['estado']) > 64)) {
			$this->error['estado'] = $this->language->get('error_estado');
		}		
*/		

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/plataforma')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $plataforma_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($plataforma_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_marketplace'])) {
			if (isset($this->request->get['filter_marketplace'])) {
				$filter_marketplace = $this->request->get['filter_marketplace'];
			} else {
				$filter_marketplace = '';
			}

			$this->load->model('admdirsis/plataforma');

			$filter_data = array(
				'filter_marketplace'      => $filter_marketplace,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'plataforma_id' => $result['plataforma_id'],
					'marketplace'     => strip_tags(html_entity_decode($result['marketplace'], ENT_QUOTES, 'UTF-8')),
					'code'    => $result['code'],
					'client_id'    => $result['client_id'],
					'secret_id'    => $result['secret_id'],
					'token_id'    => $result['token_id'],
					'stock_base'    => $result['stock_base'],
					'precio_base'    => $result['precio_base'],
					'dto_base'    => $result['dto_base'],
					'script_stock'    => $result['script_stock'],
					'estado'    => $result['estado']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['marketplace'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}