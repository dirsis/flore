<?php
class ControllerAdmdirsisAlerta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/alerta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/alerta');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/alerta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/alerta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_alerta->addAlerta($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			
			$url = '';

			if (isset($this->request->get['filter_alerta_id'])) {
				$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
			}		

			if (isset($this->request->get['filter_motivo'])) {
				$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

		
			$this->response->redirect($this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true));
			
		}
		$this->getForm();		
	}

	public function edit() {
		$this->load->language('admdirsis/alerta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/alerta');
		
		$alerta_id=$this->request->get['alerta_id'];
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_alerta->editAlerta($alerta_id,$this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			
			
			$url = '';

			if (isset($this->request->get['filter_alerta_id'])) {
				$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
			}		

			if (isset($this->request->get['filter_motivo'])) {
				$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}


			$this->response->redirect($this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true));
			
		}

		$this->getForm();
	}
	
	public function delete() {
		
		
		$this->load->language('admdirsis/alerta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/alerta');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $alerta_id) {
				$this->model_admdirsis_alerta->deleteAlerta($alerta_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');
			
			$url = '';

			if (isset($this->request->get['filter_alerta_id'])) {
				$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
			}		

			if (isset($this->request->get['filter_motivo'])) {
				$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();

	}
			
	protected function getList() {
		if (isset($this->request->get['filter_alerta_id'])) {
			$filter_alerta_id = $this->request->get['filter_alerta_id'];
		} else {
			$filter_alerta_id = '';
		}
		
		if (isset($this->request->get['filter_motivo'])) {
			$filter_motivo = $this->request->get['filter_motivo'];
		} else {
			$filter_motivo = '';
		}
		
		if (isset($this->request->get['filter_desde'])) {
			$filter_desde = $this->request->get['filter_desde'];
		} else {
			$filter_desde = '';
		}		
		
		if (isset($this->request->get['filter_hasta'])) {
			$filter_hasta = $this->request->get['filter_hasta'];
		} else {
			$filter_hasta = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'vence';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_alerta_id'])) {
			$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
		}		
		
		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/alerta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = str_replace('&amp;', '&', $this->url->link('admdirsis/alerta/delete', 'user_token=' . $this->session->data['user_token'] . $url, true));

		$data['alertas'] = array();

		$filter_data = array(
			'filter_alerta_id'      => $filter_alerta_id,
			'filter_motivo'  		=> $filter_motivo,
			'filter_desde'	     	=> $filter_desde,
			'filter_hasta'	     	=> $filter_hasta,
			'filter_status'    		=> $filter_status,
			'sort'                  => $sort,
			'order'                 => $order,
			'start'                 => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                 => $this->config->get('config_limit_admin')
		);

		$alerta_total = $this->model_admdirsis_alerta->getTotalAlertas($filter_data);

		$results = $this->model_admdirsis_alerta->getAlertas($filter_data);

		foreach ($results as $result) {
			
			$statuscolor=$this->language->get('text_vigentecolor');
			$statustext=$this->language->get('text_vigente');
			if ($result['status']==1){
				$statuscolor=$this->language->get('text_vencidacolor');
				$statustext=$this->language->get('text_vencida');
			}
			if ($result['status']==2){
				$statuscolor=$this->language->get('text_terminadocolor');
				$statustext=$this->language->get('text_terminado');
			}
			$data['alertas'][] = array(
				'alerta_id'     => $result['alerta_id'],
				'customer_id'  	=> $result['customer_id'],
				'customer'  	=> $result['customer'],
				'email'		  	=> str_replace(",","<br>",$result['email']),
				'correo'		=> $this->url->link('admdirsis/alerta/correo', 'user_token=' . $this->session->data['user_token'] . '&alerta_id=' . $result['alerta_id'] . $url, true),
				'telephone'  	=> $result['telephone'],
				'motivo'  		=> $result['motivo'],
				'vence'      	=> date("d-m-Y",strtotime($result['vence'])),
				'editano'      => $this->url->link('admdirsis/alerta/editvence', 'user_token=' . $this->session->data['user_token'] . '&vence=365&alerta_id=' . $result['alerta_id'] . $url, true),
				'editmes'      => $this->url->link('admdirsis/alerta/editvence', 'user_token=' . $this->session->data['user_token'] . '&vence=30&alerta_id=' . $result['alerta_id'] . $url, true),
				'editsiete'      => $this->url->link('admdirsis/alerta/editvence', 'user_token=' . $this->session->data['user_token'] . '&vence=7&alerta_id=' . $result['alerta_id'] . $url, true),				
				'vencecolor'	=> $result['vence']<date("Y-m-d") ? 'danger' : 'success',
				'ciclica'      	=> $result['ciclica']==1 ? $this->language->get('text_unica') : $this->language->get('text_ciclica'),
				'statustext'  		=> $statustext,
				'statuscolor'	=> $statuscolor,
				'status'		=> $result['status'],
				'edit'          => $this->url->link('admdirsis/alerta/edit', 'user_token=' . $this->session->data['user_token'] . '&alerta_id=' . $result['alerta_id'] . $url, true)
			);
		}
		//print_r($data['alertas']);
		$result = $this->model_admdirsis_alerta->getTotalxstatus();

		$data['plazos'] = array(
				'vencido'  		=> $result['vencido'],
				'urlvencido'  		=> $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&filter_hasta='.date("d-m-Y",strtotime(date("Y-m-d")."- 1 day")). $url, true),
				'semana1'      	=> $result['semana1'],
				'urlsemana1'  		=> $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&filter_desde='.date("d-m-Y"). '&filter_hasta='.date("d-m-Y",strtotime(date("Y-m-d")."+ 1 week")). $url, true),
				'semana2'      	=> $result['semana2'],
				'urlsemana2'  		=> $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&filter_desde='.date("d-m-Y",strtotime(date("Y-m-d")."+ 1 week")). $url, true)
		);
		

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_alerta_id'])) {
			$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
		}		
		
		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}		

		if (isset($this->request->get['filter_hasta'])) {
			$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
		}		

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['sort_order'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.alerta_id' . $url, true);
		$data['sort_customer_id'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.customer_id' . $url, true);
		$data['sort_motivo'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.motivo' . $url, true);
		$data['sort_vence'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.vence' . $url, true);
		$data['sort_ciclica'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.ciclica' . $url, true);		
		$data['sort_status'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . '&sort=a.status' . $url, true);
	
		$url = '';

		if (isset($this->request->get['filter_alerta_id'])) {
			$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
		}		
		
		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}	
		if (isset($this->request->get['filter_hasta'])) {
			$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
		}	
		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $alerta_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($alerta_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($alerta_total - $this->config->get('config_limit_admin'))) ? $alerta_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $alerta_total, ceil($alerta_total / $this->config->get('config_limit_admin')));

		$data['filter_alerta_id'] = $filter_alerta_id;
		$data['filter_motivo'] = $filter_motivo;
		$data['filter_desde'] = $filter_desde;
		$data['filter_hasta'] = $filter_hasta;
		$data['filter_status'] = $filter_status;
		
		$data['date_added'] = date("d-m-Y");

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/alerta_list', $data));
	}
		
	public function getForm() {
		$data['text_form'] = !isset($this->request->get['alerta_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		

		$url = '';

		if (isset($this->request->get['filter_alerta_id'])) {
			$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
		}
		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}		
		if (isset($this->request->get['filter_hasta'])) {
			$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
		}		

		if (isset($this->request->get['filter_vence'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_status_id'])) {
			$url .= '&filter_status_id=' . $this->request->get['filter_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['cancel'] = $this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['alerta_id'])) {
			$alerta_info = $this->model_admdirsis_alerta->getAlerta($this->request->get['alerta_id']);
		}
		//print_r($alerta_info);
		if (!empty($alerta_info)) {
			$data['alerta_id'] = $this->request->get['alerta_id'];
			$data['motivo'] = $alerta_info['motivo'];
			$data['customer_id'] = $alerta_info['customer_id'];
			$data['customer'] = $alerta_info['customer'];
			$data['vence'] =  date("d-m-Y", strtotime($alerta_info['vence']));
			$data['ciclica'] = $alerta_info['ciclica'];
			$data['status'] = $alerta_info['status'];
			$data['date_added'] = date("d-m-Y", strtotime($alerta_info['date_added']));
		} else {
			$data['alerta_id'] = 0;
			$data['customer_id'] = 0;
			$data['customer'] = "";
			$data['motivo'] = "";
			$data['vence'] = date("d-m-Y");
			$data['ciclica'] = 0;
			$data['status'] = 0;
			$data['date_added'] = date("d-m-Y");
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/alerta_form', $data));
	}
	
	
	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/alerta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['motivo']) < 3) || (utf8_strlen($this->request->post['motivo']) > 164)) {
			$this->error['motivo'] = $this->language->get('error_motivo');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/alerta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*
		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $alerta_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($alerta_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}
*/
		return !$this->error;
	}	

	
	public function correo() {
		
		$alerta_id=$this->request->get['alerta_id'];
		$url = '&filter_alerta_id=' . $alerta_id;
		$this->response->redirect($this->url->link('marketing/contact', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function cambiaestado() {
		$this->load->model('admdirsis/alerta');
		$alerta_id = $this->request->get['alerta_id'];
		$status = $this->request->get['status'];
		$this->model_admdirsis_alerta->cambiarStatus($alerta_id,$status);
		echo "1";
	}
	public function editTelephone() {
		$this->load->model('customer/customer');
		$customer_id = $this->request->get['customer_id'];
		$telephone = $this->request->get['telephone'];
		$this->model_customer_customer->editTelephone($customer_id,$telephone);
		echo "1";
	}	
	public function editVence() {
		$this->load->model('admdirsis/alerta');
		$alerta_id = $this->request->get['alerta_id'];
		$vence = $this->request->get['vence'];
		$this->model_admdirsis_alerta->editVence($alerta_id,$vence);

		$this->session->data['success'] = $this->language->get('text_success');

		$url = '';

		if (isset($this->request->get['filter_alerta_id'])) {
			$url .= '&filter_alerta_id=' . $this->request->get['filter_alerta_id'];
		}		

		if (isset($this->request->get['filter_motivo'])) {
			$url .= '&filter_motivo=' . urlencode(html_entity_decode($this->request->get['filter_motivo'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}


		$this->response->redirect($this->url->link('admdirsis/alerta', 'user_token=' . $this->session->data['user_token'] . $url, true));		
		
	}	
	
	
		public function correoAbre() {
			$resul=array();
			if (isset($this->request->get['alerta_id'])){
				$this->load->model('admdirsis/alerta');
				$resul = $this->model_admdirsis_alerta->getAlerta($this->request->get['alerta_id']);
			}
 
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($resul));
		}
	
		public function correoEnvia() {
			$resuldo='';
			$this->load->language('admdirsis/alerta');
			if (isset($this->request->post['alerta_id'])){
				$this->load->model('admdirsis/alerta');
				$resul = $this->model_admdirsis_alerta->getAlerta($this->request->post['alerta_id']);
				if ($resul){
					
					$store_name = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
					$subject = sprintf($this->language->get('text_subject'), $store_name);
					
					$mail = new Mail($this->config->get('config_mail_engine'));
					$mail->parameter = $this->config->get('config_mail_parameter');
					$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
					$mail->smtp_username = $this->config->get('config_mail_smtp_username');
					$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
					$mail->smtp_port = $this->config->get('config_mail_smtp_port');
					$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
	
					$mail->setTo($resul['email']);
					$mail->setTo('dirsis@gmail.com');
					$mail->setFrom($this->config->get('config_email'));
					$mail->setSender($store_name);
					$mail->setSubject($subject);
					$mail->setText($this->request->post['mensaje']);
					$resuldo=$mail->send();					
				}
			}
			if (empty($resuldo)){
				echo '1';
			}else{
				echo '0';
			}
		}	
	
	
	
	
	
//HISTORIAL INICIO
	public function addHistoria() {
		$result='';
		$this->load->model('admdirsis/alerta');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$data=$this->request->post;
			$result=$this->model_admdirsis_alerta->addHistoria($data);
			
		}
		echo $result;
	}
	
	public function delHistoria() {
		$this->load->model('admdirsis/alerta');
		$resul=$this->model_admdirsis_alerta->delHistoria($this->request->get['evento_historia_id']);
		return $resul;
	}	
	
	public function getHistoria() {
		$this->load->model('admdirsis/alerta');
		$results=$this->model_admdirsis_alerta->getHistorias($this->request->get['alerta_id']);
		
		$data=array();
		foreach ($results as $result) {
			$data[] = array( "evento_historia_id" => $result['evento_historia_id'],
							"date_added" => date("d-m-Y",strtotime($result['date_added'])),
							"text" => html_entity_decode($result['text'])
							);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));		
	}
//HISTORIAL FIN	

}
				

								
																
