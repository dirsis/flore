<?php
class ControllerAdmdirsisContab extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');

		$this->getList();
	}
	
	public function getXLSX(){
		$this->load->model('admdirsis/contab');
		$datos = array();
		if (!isset($_REQUEST['pasos'])){
			if ( !isset( $_FILES[ 'file' ][ 'name' ] ) ) {
				$datos[]=array("error" => 'Seleccione un archivo XLS o XLSX');
			}else{
				if ( substr( $_FILES[ 'file' ][ 'name' ], -4 ) != '.xls' and substr( $_FILES[ 'file' ][ 'name' ], -5 ) != '.xlsx' ) {
					$datos[]=array("error" => 'Seleccione un archivo XLS o XLSX');
				}else{
					$archivo = $_FILES[ 'file' ][ 'name' ];
					if ( is_file( $archivo ) ) {
						unlink($archivo);
					}
					move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], $archivo );
					ini_set('max_execution_time', 36000);
					ini_set('memory_limit', '12G');
					require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
					$inputFileType = PHPExcel_IOFactory::identify( $archivo );
					$objReader = PHPExcel_IOFactory::createReader( $inputFileType );
					$objPHPExcel = $objReader->load( $archivo );
					$sheet = $objPHPExcel->getSheet( 0 );
					$highestRow = $sheet->getHighestRow();
					$highestColumn = $sheet->getHighestColumn();
					for ( $row = 2; $row <= $highestRow; $row++ ) {
						$datos["rows"][]=array(
							"comprob_id"	=> $this->config->get('config_factura_comprob_id'),
							"apellido" 		=> html_entity_decode($sheet->getCell( "A" . $row )->getValue()),
							"codiva_id" 	=> (int)$sheet->getCell( "B" . $row )->getValue(),
							"cuit" 			=> $sheet->getCell( "C" . $row )->getValue(),
							"total" 		=> $sheet->getCell( "D" . $row )->getValue(),
							"motivo" 		=> $sheet->getCell( "E" . $row )->getValue(),
							"email" 		=> $sheet->getCell( "F" . $row )->getValue(),
							"fpago_id"		=> $this->config->get('config_factura_fpago_id')
						);
					}
					$datos["facs"][]=$this->model_admdirsis_contab->addXLSX($datos);
				}
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($datos));		
	}
	public function caja() {
		
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateFormCaja()) {

			$this->model_admdirsis_contab->addContabCaja($this->request->post);
			$this->session->data['success'] = "Comprobante Registrado con Exito!!";
			$url = '';
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}
			if (isset($this->request->get['filter_comprob_id'])) {
				$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
			}			
			if (isset($this->request->get['filter_saldo'])) {
				$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
			}			
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}			
			if (isset($this->request->get['filter_estado'])) {
				$url .= '&filter_estado=' . $this->request->get['filter_estado'];
			}
			if (isset($this->request->get['filter_fpago_id'])) {
				$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}
			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}				

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getFormCaja();
	}

	public function add() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');
		
		/*
		echo "add";
		print_r($this->request->post);
		die;
		*/
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$contab_id=$this->model_admdirsis_contab->addContab($this->request->post);
			
//YA REGISTRO Y VUELVE A LA PANTALLA DANDO OK
			$url=$this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . "&filter_customer_id=".$this->request->post['customer_id'], true);
			$this->session->data['success'] = $this->language->get('text_success')."|".$this->request->post['customer']."|<a href='".$url."' target='_blank'>Ver Estado de Cuenta</a>";
			
			$url = '';
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}
			if (isset($this->request->get['filter_comprob_id'])) {
				$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
			}			
			if (isset($this->request->get['filter_saldo'])) {
				$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
			}			
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}			
			if (isset($this->request->get['filter_estado'])) {
				$url .= '&filter_estado=' . $this->request->get['filter_estado'];
			}
			if (isset($this->request->get['filter_fpago_id'])) {
				$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}
			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}				
			

			$this->response->redirect($this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
		}
		

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');
		

		

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			
			$this->model_admdirsis_contab->editContab($this->request->get['contab_id'], $this->request->post);
			
				
						

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_contab_group_id'])) {
				$url .= '&filter_contab_group_id=' . $this->request->get['filter_contab_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}			
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}			
			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}				

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		if (isset($this->request->get['contab_id'])) {
			$data['contab_id'] = $this->request->get['contab_id'];
		} else {
			$data['contab_id'] = 0;
		}
		$this->getForm();
	}
	
	public function paga() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_admdirsis_contab->addContab($this->request->post);
//YA REGISTRO Y VUELVE A LA PANTALLA DANDO OK
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}
			if (isset($this->request->get['filter_comprob_id'])) {
				$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
			}			
			if (isset($this->request->get['filter_saldo'])) {
				$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
			}			
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}			
			if (isset($this->request->get['filter_estado'])) {
				$url .= '&filter_estado=' . $this->request->get['filter_estado'];
			}
			if (isset($this->request->get['filter_fpago_id'])) {
				$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
			}
			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}
			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				
			

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		

		$this->getForm();
	}	

	public function credito() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');
		
		if (isset($this->request->get['contab_id'])) {
			$contab_id=$this->model_admdirsis_contab->creditoContab($this->request->get['contab_id']);
			$this->load->model('contable/cbasiento');
			$this->model_contable_cbasiento->addContab($contab_id);
		}
		$this->getList();
	}	
	
	public function delete() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $contab_id) {
				$this->model_admdirsis_contab->deleteContab($contab_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_contab_group_id'])) {
				$url .= '&filter_contab_group_id=' . $this->request->get['filter_contab_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}			
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}			
			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				
			

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	public function unlock() {
		$this->load->language('admdirsis/contab');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/contab');

		if (isset($this->request->get['email']) && $this->validateUnlock()) {
			$this->model_admdirsis_contab->deleteLoginAttempts($this->request->get['email']);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_contab_group_id'])) {
				$url .= '&filter_contab_group_id=' . $this->request->get['filter_contab_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_desde'])) {
				$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			
			if (isset($this->request->get['filter_referencia'])) {
				$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
			}			
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}			

			if (isset($this->request->get['filter_mailing'])) {
				$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				
			

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}
		if (isset($this->request->get['filter_comprob_id'])) {
			$filter_comprob_id = $this->request->get['filter_comprob_id'];
		} else {
			$filter_comprob_id = '';
		}
		if (isset($this->request->get['filter_saldo'])) {
			$filter_saldo = $this->request->get['filter_saldo'];
		} else {
			$filter_saldo = '';
		}		
		if (isset($this->request->get['filter_customer_group_id'])) {
				$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}		
		if (isset($this->request->get['filter_cae'])) {
			$filter_cae = $this->request->get['filter_cae'];
		} else {
			$filter_cae = '';
		}		
		if (isset($this->request->get['filter_fpago_id'])) {
			$filter_fpago_id = $this->request->get['filter_fpago_id'];
		} else {
			$filter_fpago_id = '';
		}			
		if (isset($this->request->get['filter_estado'])) {
			$filter_estado = $this->request->get['filter_estado'];
		} else {
			$filter_estado = '';
		}			
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		
		
		if (isset($this->request->get['filter_referencia'])) {
			$filter_referencia = $this->request->get['filter_referencia'];
		} else {
			$filter_referencia = '';
		}
		
		if (isset($this->request->get['filter_caja_id'])) {
			$filter_caja_id = $this->request->get['filter_caja_id'];
		} else {
			$filter_caja_id = '';
		}		
		
		if (isset($this->request->get['filter_mailing'])) {
			$filter_mailing = $this->request->get['filter_mailing'];
		} else {
			$filter_mailing = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'contab_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}
		
		$url = '';

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}	
		if (isset($this->request->get['filter_saldo'])) {
			$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
		}		
		
		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}	
		
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/contab/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		
		$data['editafiscaliza_date']=date("d-m-Y");
		$data['contabs'] = array();

		$filter_data = array(
			'filter_customer'          	=> $filter_customer,
			'filter_comprob_id'        	=> $filter_comprob_id,
			'filter_saldo'        		=> $filter_saldo,
			'filter_customer_group_id'  => $filter_customer_group_id,
			'filter_cae'        		=> $filter_cae,
			'filter_fpago_id'          	=> $filter_fpago_id,
			'filter_estado'        	   	=> $filter_estado,
			'filter_date_desde'        	=> $filter_date_desde,
			'filter_date_hasta'        	=> $filter_date_hasta,
			'filter_referencia'        	=> $filter_referencia,
			'filter_caja_id'        	=> $filter_caja_id,
			'filter_mailing'        	=> $filter_mailing,
			'sort'                     	=> $sort,
			'order'                    	=> $order,
			'start'                    	=> ($page - 1) * $limit,
			'limit'                    	=> $limit
		);

	
		
		$store_codiva_id = $this->config->get('config_factura_codiva_id');
		
		$contab_total = $this->model_admdirsis_contab->getTotalContabs($filter_data);
		$resumen = $this->model_admdirsis_contab->getResumenContabs($filter_data);
		$data['resumentotalpositivas'] = $this->currency->format($resumen['positivo'], $this->config->get( 'config_currency' ) );
		$data['resumentotalnegativas'] = $this->currency->format($resumen['negativo'], $this->config->get( 'config_currency' ) );
		$data['resumentotalgenerales'] = $this->currency->format($resumen['positivo']+$resumen['negativo'], $this->config->get( 'config_currency' ) );		
		
		$results = $this->model_admdirsis_contab->getContabs($filter_data);
		
		//print_r($resumen);
		
		$negativos=$positivos=0;
		foreach ($results as $result) {
			
			$letra="X";
			
			$xd_comprob=$result['d_comprob'];
			
			if (!empty($result['cae'])){
				if ($store_codiva_id == 1){
					if ( $result['codiva_id'] == 1) $letra="A";
					if ( $result['codiva_id'] == 2) $letra="A";
					if ( $result['codiva_id'] == 3) $letra="B";
					if ( $result['codiva_id'] == 4) $letra="B";
					if ( $result['codiva_id'] == 5) $letra="B";
				}else{
					$letra="C";
				}
			}
			$codiva['name']='';
			if ($result['codiva_id']){
				$this->load->model('admdirsis/codiva');
				$codiva = $this->model_admdirsis_codiva->getCodiva($result['codiva_id']);
			}
			//print_r($codiva);
			
			$linkeo = $this->url->link('admdirsis/contab/invoice', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $result['contab_id'] . $url, true);
			
			
			if ($this->request->server['HTTPS']) {
				$linkeo =  HTTPS_CATALOG;
			} else {
				$linkeo =  HTTPS_CATALOG;
			}
			$linkeo .= "index.php?route=account/invoice&contab_id=".$result['contab_id'];
			
				
			$exento = $this->model_admdirsis_contab->getContabexento($result['contab_id']);
			
			if ($result['cae']=='' and $result['afip']!=0){
				if ($result['final']<0){
					$dcomprob="PRESUPUESTO NC";
				}else{
					$dcomprob="PRESUPUESTO";
				}
			}else{
				$dcomprob=$result['d_comprob'];
			}
			
			$data['contabs'][] = array(
				'contab_id'    	 => $result['contab_id'],
				'mailing'		 => $result['mailing'],
				'codiva_id'		 => $result['codiva_id'],
				'codiva'		 => $codiva['name'],
				'cuit'			 => $result['cuit'],
				'numero'    	 => $result['numero'],
				'serie'    	 	 => $result['serie'],
				'caja_id'      	 => $result['caja_id'],
				'customer'       => $result['customer'],
				'customer2'       => $result['customer2'],
				'linkctacte'     => $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&filter_customer_id=' . $result['customer_id'] . $url, true),
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'total'          => $this->currency->format($result['total'], $this->config->get( 'config_currency' ) ),
				'd_comprob'      => $dcomprob,
				'letra'			 => $letra,	
				'afip'      	 => $result['afip'],
				'cae'      	 	 => $result['cae'],
				'fpago'      	 => $result['fpago'],
				'comment'      	 => $result['comment'],				
				'referencia'   	 => $result['referencia'],	
				'edit'           => $this->url->link('admdirsis/contab/edit', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $result['contab_id'] . $url, true),
				'paga'           => $this->url->link('admdirsis/contab/paga', 'user_token=' . $this->session->data['user_token'] . '&paga=s&contab_id=' . $result['contab_id'] . $url, true),	
				'credito'           => $this->url->link('admdirsis/contab/credito', 'user_token=' . $this->session->data['user_token'] . '&credito=s&contab_id=' . $result['contab_id'] . $url, true),
				'invoice'           => $linkeo,
				'exento'		=> $this->currency->format($exento, $this->config->get( 'config_currency' ) )
			);
			
			if ($result['final']<0){
				$negativos=$negativos+$result['final'];
			}else{
				$positivos=$positivos+$result['final'];
			}			
		}
		$data['totalpositivas'] = $this->currency->format($negativos, $this->config->get( 'config_currency' ) );
		$data['totalnegativas'] = $this->currency->format($positivos, $this->config->get( 'config_currency' ) );
		$data['totalgenerales'] = $this->currency->format($negativos+$positivos, $this->config->get( 'config_currency' ) );
		$data['muestratotales'] = $this->config->get('config_contab_muestratotales');
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			

		if (isset($this->request->get['filter_referencia'])) {
			$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
		}		
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}		
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}	
		if (isset($this->request->get['filter_saldo'])) {
			$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
		}
		
		
		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}		
		
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}		

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				

		
			
		$data['sort_contab_id'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=contab_id' . $url, true);
		$data['sort_d_comprob'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=d_comprob' . $url, true);			
		$data['sort_customer'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
		$data['sort_total'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=total' . $url, true);		
		$data['sort_fpago'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=fpago' . $url, true);	
		$data['sort_comment'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=comment' . $url, true);	
		$data['sort_date_added'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);		
		//$data['sort_caja_id'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=caja_id' . $url, true);
		
		
			
		$data['sort_email'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_contab_group'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=contab_group' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		$data['sort_ip'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&sort=c.ip' . $url, true);
		
		
		
		
		$this->load->model('admdirsis/comprob');
		$data['comprobs'] = $this->model_admdirsis_comprob->getComprobs();

		$this->load->model('localisation/factura_status');
		$data['estados'] = $this->model_localisation_factura_status->getFacturaStatuses();
//		print_r($data['estados']);

		$this->load->model('customer/customer_group');
		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();
		
		$this->load->model('admdirsis/fpago');
		
		$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();		
		

		$url = '';

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		
		if (isset($this->request->get['filter_referencia'])) {
			$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
		}		
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}		
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}
		if (isset($this->request->get['filter_saldo'])) {
			$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
		}
		
		
		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}
		
		if (isset($this->request->get['filter_cae'])) {
			$url .= '&filter_cae=' . $this->request->get['filter_cae'];
		}		
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				

		
		$data['limit'] = $limit; 
		
		$pagination = new Pagination();
		$pagination->total = $contab_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($contab_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($contab_total - $limit)) ? $contab_total : ((($page - 1) * $limit) + $limit), $contab_total, ceil($contab_total / $limit));

		$data['filter_customer'] 	= $filter_customer;
		if ($filter_date_desde){
			$data['filter_date_desde'] 	= date("d-m-Y",strtotime($filter_date_desde));
		}
		if ($filter_date_hasta){
			$data['filter_date_hasta'] 	= date("d-m-Y",strtotime($filter_date_hasta));
		}
		$data['filter_referencia'] 	= $filter_referencia;
		$data['filter_caja_id'] 	= $filter_caja_id;
		$data['filter_mailing'] 	= $filter_mailing;
		$data['filter_comprob_id'] 	= $filter_comprob_id;
		$data['filter_saldo'] 	= $filter_saldo;
		$data['filter_customer_group_id'] 	= $filter_customer_group_id;
		$data['filter_cae'] 	= $filter_cae;
		$data['filter_fpago_id'] 	= $filter_fpago_id;
		$data['filter_estado'] 		= $filter_estado;
		
		//print_r($data);

		$data['sort'] = $sort;
		$data['order'] = $order;
		$data['page'] = $page;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/contab_list', $data));
	}

	protected function getForm() {
		
		if (!isset($this->request->get['paga'])) {
			if (isset($this->request->get['contab_id'])) {
				$data['contab_id']=$this->request->get['contab_id'];
			}
		}else{
			$data['relacion_id']=$this->request->get['contab_id'];
		}
		
		
		$data['text_form'] = !isset($data['contab_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}		

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['contab_id'])) {
			$data['error_contab_id'] = $this->error['contab_id'];
		} else {
			$data['error_contab_id'] = '';
		}		
		if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}		

		if (isset($this->error['firstname'])) {
			$data['error_firstname'] = $this->error['firstname'];
		} else {
			$data['error_firstname'] = '';
		}

		if (isset($this->error['lastname'])) {
			$data['error_lastname'] = $this->error['lastname'];
		} else {
			$data['error_lastname'] = '';
		}

		if (isset($this->error['email'])) {
			$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}

		if (isset($this->error['telephone'])) {
			$data['error_telephone'] = $this->error['telephone'];
		} else {
			$data['error_telephone'] = '';
		}
		
		if (isset($this->error['total'])) {
			$data['error_total'] = $this->error['total'];
		} else {
			$data['error_total'] = '';
		}		
		
		$url = '';
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}
		if (isset($this->request->get['filter_saldo'])) {
			$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
		}
		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}		
			if (isset($this->request->get['filter_cae'])) {
				$url .= '&filter_cae=' . $this->request->get['filter_cae'];
			}		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		
		if (isset($this->request->get['filter_referencia'])) {
			$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
		}	
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}	
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
				if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		if ($this->user->getNivel()==0){
			$data['cancel'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true);
		}
		
		if (!isset($data['contab_id'])) {
			$data['action'] = $this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
			$data['invoice']="";
		} else {
			$data['action'] = $this->url->link('admdirsis/contab/edit', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $data['contab_id'] . $url, true);
			$data['invoice'] = $this->url->link('admdirsis/contab/invoice', 'user_token=' . $this->session->data['user_token']. '&contab_id=' . $data['contab_id'] . $url, true);			
		}
		
		//$data['cancel'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($data['contab_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$contab_info = $this->model_admdirsis_contab->getContab($data['contab_id']);
		}

		$this->load->model('admdirsis/comprob');
		$data['comprobs'] = $this->model_admdirsis_comprob->getComprobsActivos();

		$this->load->model('admdirsis/fpago');
		$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();
		
		$this->load->model('localisation/factura_status');
		$data['estados'] = $this->model_localisation_factura_status->getFacturaStatuses();			

		$this->load->model('admdirsis/codiva');
		$data['codivas'] = $this->model_admdirsis_codiva->getCodivas();		

		$this->load->model('localisation/country');
		$data['countries'] = $this->model_localisation_country->getCountries();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		
		$data['margenes'][] = array( 'name' => 'Lista 0', 'valor' => '0');
		$data['margenes'][] = array( 'name' => 'Lista 1', 'valor' => '1');
		$data['margenes'][] = array( 'name' => 'Lista 2', 'valor' => '2');
		$data['margenes'][] = array( 'name' => 'Lista 3', 'valor' => '3');
		

//VER SI EXISTE
		if (isset($this->request->get['contab_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			
			$contab_info = $this->model_admdirsis_contab->getContab($this->request->get['contab_id']);
		}

		$items=0;
		if (!empty($contab_info)) {
			//NUEVO
			//$data['contab_id'] = $data['contab_id'];
			if (!isset($this->request->get['paga'])) {
				$data['date_added'] = date("d-m-Y", strtotime($contab_info['date_added']));
			}else{
				$data['date_added'] = date("d-m-Y");
			}
			$data['caja_id'] = $contab_info['caja_id'];
			
			if (isset($this->request->get['paga'])){
				$data['comprob_id']=$this->config->get('config_cobranza_comprob_id');
			}else{
				$data['comprob_id'] = $contab_info['comprob_id'];
			}
			$data['fpago_id'] = $contab_info['fpago_id'];
			
			//$data['customer'] = $contab_info['customer'];
			
			$data['customer_id'] = $contab_info['customer_id'];
			$data['firstname'] = $contab_info['firstname'];
			$data['lastname'] = $contab_info['lastname'];
			$data['email'] = $contab_info['email'];
			$data['telephone'] = $contab_info['telephone'];
			$data['codiva_id'] = $contab_info['codiva_id'];
			$data['cuit'] = $contab_info['cuit'];
			
			$this->load->model('customer/customer');
			
			$customer = $this->model_customer_customer->getCustomer($contab_info['customer_id']);
			$data['fpago_id'] = $customer['fpago_id'];
			$data['customer'] 		= $customer['firstname']." ".$customer['lastname'];	
			
			$addresses = $this->model_customer_customer->getAddresses($contab_info['customer_id']);
			
			//print_r($addresses);
			
			if ($addresses){
				foreach ($addresses as $address) {
					$data['payment_address_1'] = $address['address_1'];
					$data['payment_address_2'] = $address['address_2'];
					$data['payment_city'] = 	 $address['city'];
					$data['payment_postcode'] =  $address['postcode'];
					$data['payment_country_id'] = $address['country_id'];
					$data['payment_zone_id'] = $address['zone_id'];
					break;
				}
			}else{
				$data['payment_address_1'] = '';
				$data['payment_address_2'] = '';
				$data['payment_city'] = 	 '';
				$data['payment_postcode'] =  '';
				$data['payment_country_id'] = '';
				$data['payment_zone_id'] = '';
			}
			
			$data['contab_products'] = array();
			if (isset($data['contab_id'])){
				$products = $this->model_admdirsis_contab->getContabProducts($data['contab_id']);
				foreach ($products as $product) {
					$data['contab_products'][] = array(
						'product_id' => $product['product_id'],
						'name'       => $product['name'],
						'model'      => $product['model'],
						'quantity'   => $product['quantity'],
						'price'      => $product['price'],
						'total'      => $product['total']
					);
					$items++;
				}
			}
			
			//print_r($data['contab_products']);
			
				
			
			$data['estado'] = $contab_info['estado'];
			if (!isset($this->request->get['paga'])){
				$data['comment'] = $contab_info['comment'];
			}else{
				$data['relacion'] = $contab_info['serie']."-".$contab_info['numero'];
			}
			$data['total'] = $contab_info['total'];

			$this->response->setOutput($this->load->view('admdirsis/contab_form', $data));
		} else {
			
			//NUEVO
			
			$data['contab_id'] = 0;
			$data['caja_id'] = 0;
			$data['date_added'] = date("d-m-Y");  
			
			$this->load->model('setting/setting');
			$data['comprob_id'] = $this->config->get('config_factura_comprob_id');
			$this->load->model('admdirsis/comprob');
			$data['comprobs'] = $this->model_admdirsis_comprob->getComprobsActivos();
			
			$data['fpago_id'] = $this->config->get('config_factura_fpago_id');
			$this->load->model('admdirsis/fpago');
			$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();	
			
			$data['estado'] = $this->config->get('config_factura_status_id');
			$this->load->model('localisation/factura_status');
			$data['estados'] = $this->model_localisation_factura_status->getFacturaStatuses();			
			
//DIRSIS						
			
			$data['customer'] = '';	
			$data['customer'] = '';
			$data['customer_id'] = '';
			//$data['customer_group_id'] = $this->config->get('config_customer_group_id');
			$data['firstname'] = '';
			$data['lastname'] = '';
			$data['email'] = '';
			$data['telephone'] = '';
			$data['codiva_id'] = $this->config->get('config_codiva_default');
			$data['cuit'] = '';
			
			$data['payment_firstname'] = '';
			$data['payment_lastname'] = '';
			$data['payment_company'] = '';
			$data['payment_address_1'] = '';
			$data['payment_address_2'] = '';
			$data['payment_city'] = '';
			$data['payment_postcode'] = '';
			$data['payment_country_id'] = $this->config->get('config_country_id');
			$data['payment_zone_id'] = $this->config->get('config_zone_id');
			$data['comment'] = '';
			$data['contab_products'] = array();
			$data['total'] = 0;

			if (isset($this->request->get['filter_customer_id'])) {
				
				$this->load->model('customer/customer');
				$customer = $this->model_customer_customer->getCustomer($this->request->get['filter_customer_id']);
				$data['fpago_id'] = $customer['fpago_id'];
				$addresses = $this->model_customer_customer->getAddresses($this->request->get['filter_customer_id']);
				//print_r($addresses);
				if ($addresses){
					foreach ($addresses as $address) {
						$data['payment_address_1'] = $address['address_1'];
						$data['payment_address_2'] = $address['address_2'];
						$data['payment_city'] = 	 $address['city'];
						$data['payment_postcode'] =  $address['postcode'];
						$data['payment_country_id'] = $address['country_id'];
						$data['payment_zone_id'] = $address['zone_id'];
						break;
					}
				}
				$data['customer'] 		= $customer['firstname']." ".$customer['lastname'];	
				$data['customer_id'] 	= $customer['customer_id'];
				$data['firstname'] 		= $customer['firstname'];
				$data['lastname'] 		= $customer['lastname'];
				$data['email'] 			= $customer['email'];
				$data['telephone'] 		= $customer['telephone'];
				$data['codiva_id'] 		= $customer['codiva_id'];
				$data['cuit'] 			= $customer['cuit'];


			}

			if (isset($this->request->post['customer'])) {
				$data['customer'] = $this->request->post['customer'];	
				$data['customer'] = $this->request->post['customer'];
				$data['customer_id'] = $this->request->post['customer_id'];
				//$data['customer_group_id'] = $this->config->get('config_customer_group_id');
				$data['firstname'] = $this->request->post['firstname'];
				//$data['lastname'] = $this->request->post['lastname'];
				$data['email'] = $this->request->post['email'];
				$data['telephone'] = $this->request->post['telephone'];
				$data['codiva_id'] = $this->request->post['codiva_id'];
				$data['cuit'] = $this->request->post['cuit'];

				if (isset($this->request->post['payment_firstname'])){
					$data['payment_firstname'] = $this->request->post['payment_firstname'];
					//$data['payment_lastname'] = $this->request->post['payment_lastname'];
					$data['payment_company'] = $this->request->post['payment_company'];
					$data['payment_address_1'] = $this->request->post['payment_address_1'];
					$data['payment_address_2'] = $this->request->post['payment_address_2'];
					$data['payment_city'] = $this->request->post['payment_city'];
					$data['payment_postcode'] = $this->request->post['payment_country_id'];
					$data['payment_country_id'] = $this->request->post['payment_country_id'];
					$data['payment_zone_id'] = $this->request->post['payment_zone_id'];
				}else{
					$data['payment_firstname'] = $data['firstname'];
					//$data['payment_lastname'] = $data['lastname'];
					$data['payment_company'] = '';
					$data['payment_address_1'] = $data['payment_address_1'];
					$data['payment_address_2'] = $data['payment_address_2'];
					$data['payment_city'] = $data['payment_city'] ;
					$data['payment_postcode'] = $data['payment_postcode'];
					$data['payment_country_id'] = $data['payment_country_id'];
					$data['payment_zone_id'] = $data['payment_zone_id'];
					
				}
				$data['comment'] = $this->request->post['comment'];
				$data['relacion'] = $this->request->post['relacion'];
				//$data['contab_products'] = array();
				$data['total'] = $this->request->post['total'];
			}

			$this->response->setOutput($this->load->view('admdirsis/contab_form', $data));
		}
//FIN VER SI EXISTE		
	}
	
	protected function getFormCaja() {
		
		$data['text_form'] = $this->language->get('text_add');
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['contab_id'])) {
			$data['error_contab_id'] = $this->error['contab_id'];
		} else {
			$data['error_contab_id'] = '';
		}		
		if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}		
		if (isset($this->error['firstname'])) {
			$data['error_firstname'] = $this->error['firstname'];
		} else {
			$data['error_firstname'] = '';
		}
		if (isset($this->error['lastname'])) {
			$data['error_lastname'] = $this->error['lastname'];
		} else {
			$data['error_lastname'] = '';
		}
		if (isset($this->error['email'])) {
			$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}
		if (isset($this->error['telephone'])) {
			$data['error_telephone'] = $this->error['telephone'];
		} else {
			$data['error_telephone'] = '';
		}
		if (isset($this->error['total'])) {
			$data['error_total'] = $this->error['total'];
		} else {
			$data['error_total'] = '';
		}		
		$url = '';
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}
		if (isset($this->request->get['filter_saldo'])) {
			$url .= '&filter_saldo=' . $this->request->get['filter_saldo'];
		}		
		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}		
		if (isset($this->request->get['filter_cae'])) {
			$url .= '&filter_cae=' . $this->request->get['filter_cae'];
		}		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}			
		
		if (isset($this->request->get['filter_referencia'])) {
			$url .= '&filter_referencia=' . $this->request->get['filter_referencia'];
		}	
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}	
		if (isset($this->request->get['filter_mailing'])) {
			$url .= '&filter_mailing=' . $this->request->get['filter_mailing'];
		}		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
				if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['action'] = $this->url->link('admdirsis/contab/caja', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['cancel'] = $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$data['contab_id'] = 0;
		$data['caja_id'] = 0;
		$data['date_added'] = date("d-m-Y");  
			
		$this->load->model('admdirsis/comprob');
		$data['comprobs'] = $this->model_admdirsis_comprob->getComprobsInactivos();
		$data['fpago_id'] = $this->config->get('config_factura_fpago_id');
		$this->load->model('admdirsis/fpago');
		$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();	
		$data['estado'] = $this->config->get('config_factura_status_id');
		$this->load->model('localisation/factura_status');
		$data['estados'] = $this->model_localisation_factura_status->getFacturaStatuses();			
		$data['comment'] = '';
		$data['total'] = 0;
		$this->response->setOutput($this->load->view('admdirsis/contab_caja', $data));
//FIN VER SI EXISTE		
	}

	protected function validateForm() {

		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['customer_id']) < 1) || (utf8_strlen(trim($this->request->post['customer_id'])) > 32)) {
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		}
		
		if ((intval($this->request->post['total']) == 0)) {
			$this->error['total'] = $this->language->get('error_total');
		}		
		

/*
		if ((utf8_strlen($this->request->post['firstname']) < 1)) {
			$this->error['firstname'] = $this->language->get('error_firstname');
		}
*/		
		/*
		if ((utf8_strlen($this->request->post['lastname']) < 1) || (utf8_strlen(trim($this->request->post['lastname'])) > 32)) {
			$this->error['lastname'] = $this->language->get('error_lastname');
		}


		if ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			$this->error['email'] = $this->language->get('error_email');
		}
		if ((utf8_strlen($this->request->post['telephone']) < 3) || (utf8_strlen($this->request->post['telephone']) > 32)) {
			$this->error['telephone'] = $this->language->get('error_telephone');
		}
*/
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
	
	protected function validateFormCaja() {
		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateUnlock() {
		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function login() {
		if (isset($this->request->get['contab_id'])) {
			$contab_id = $this->request->get['contab_id'];
		} else {
			$contab_id = 0;
		}

		$this->load->model('admdirsis/contab');

		$contab_info = $this->model_admdirsis_contab->getContab($contab_id);

		if ($contab_info) {
			// Create token to login with
			$token = token(64);

			$this->model_admdirsis_contab->editToken($contab_id, $token);

			if (isset($this->request->get['store_id'])) {
				$store_id = $this->request->get['store_id'];
			} else {
				$store_id = 0;
			}

			$this->load->model('setting/store');

			$store_info = $this->model_setting_store->getStore($store_id);

			if ($store_info) {
				$this->response->redirect($store_info['url'] . 'index.php?route=account/login&token=' . $token);
			} else {
				$this->response->redirect(HTTP_CATALOG . 'index.php?route=account/login&token=' . $token);
			}
		} else {
			$this->load->language('error/not_found');

			$this->document->setTitle($this->language->get('heading_title'));

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('error/not_found', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('error/not_found', $data));
		}
	}

	public function history() {
		$this->load->language('admdirsis/contab');

		$this->load->model('admdirsis/contab');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['histories'] = array();

		$results = $this->model_admdirsis_contab->getHistories($this->request->get['contab_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['histories'][] = array(
				'comment'    => $result['comment'],
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$history_total = $this->model_admdirsis_contab->getTotalHistories($this->request->get['contab_id']);

		$pagination = new Pagination();
		$pagination->total = $history_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/contab/history', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $this->request->get['contab_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($history_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($history_total - 10)) ? $history_total : ((($page - 1) * 10) + 10), $history_total, ceil($history_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/contab_history', $data));
	}

	public function addHistory() {
		$this->load->language('admdirsis/contab');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			$this->load->model('admdirsis/contab');

			$this->model_admdirsis_contab->addHistory($this->request->get['contab_id'], $this->request->post['comment']);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function transaction() {
		$this->load->language('admdirsis/contab');

		$this->load->model('admdirsis/contab');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['transactions'] = array();

		$results = $this->model_admdirsis_contab->getTransactions($this->request->get['contab_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['transactions'][] = array(
				'amount'      => $this->currency->format($result['amount'], $this->config->get('config_currency')),
				'description' => $result['description'],
				'date_added'  => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$data['balance'] = $this->currency->format($this->model_admdirsis_contab->getTransactionTotal($this->request->get['contab_id']), $this->config->get('config_currency'));

		$transaction_total = $this->model_admdirsis_contab->getTotalTransactions($this->request->get['contab_id']);

		$pagination = new Pagination();
		$pagination->total = $transaction_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/contab/transaction', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $this->request->get['contab_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($transaction_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($transaction_total - 10)) ? $transaction_total : ((($page - 1) * 10) + 10), $transaction_total, ceil($transaction_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/contab_transaction', $data));
	}

	public function addTransaction() {
		$this->load->language('admdirsis/contab');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			$this->load->model('admdirsis/contab');

			$this->model_admdirsis_contab->addTransaction($this->request->get['contab_id'], $this->request->post['description'], $this->request->post['amount']);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function reward() {
		$this->load->language('admdirsis/contab');

		$this->load->model('admdirsis/contab');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['rewards'] = array();

		$results = $this->model_admdirsis_contab->getRewards($this->request->get['contab_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['rewards'][] = array(
				'points'      => $result['points'],
				'description' => $result['description'],
				'date_added'  => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$data['balance'] = $this->model_admdirsis_contab->getRewardTotal($this->request->get['contab_id']);

		$reward_total = $this->model_admdirsis_contab->getTotalRewards($this->request->get['contab_id']);

		$pagination = new Pagination();
		$pagination->total = $reward_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/contab/reward', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $this->request->get['contab_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($reward_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($reward_total - 10)) ? $reward_total : ((($page - 1) * 10) + 10), $reward_total, ceil($reward_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/contab_reward', $data));
	}

	public function addReward() {
		$this->load->language('admdirsis/contab');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/contab')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			$this->load->model('admdirsis/contab');

			$this->model_admdirsis_contab->addReward($this->request->get['contab_id'], $this->request->post['description'], $this->request->post['points']);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function ip() {
		$this->load->language('admdirsis/contab');

		$this->load->model('admdirsis/contab');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['ips'] = array();

		$results = $this->model_admdirsis_contab->getIps($this->request->get['contab_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['ips'][] = array(
				'ip'         => $result['ip'],
				'total'      => $this->model_admdirsis_contab->getTotalContabsByIp($result['ip']),
				'date_added' => date('d/m/y', strtotime($result['date_added'])),
				'filter_ip'  => $this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . '&filter_ip=' . $result['ip'], true)
			);
		}

		$ip_total = $this->model_admdirsis_contab->getTotalIps($this->request->get['contab_id']);

		$pagination = new Pagination();
		$pagination->total = $ip_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/contab/ip', 'user_token=' . $this->session->data['user_token'] . '&contab_id=' . $this->request->get['contab_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($ip_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($ip_total - 10)) ? $ip_total : ((($page - 1) * 10) + 10), $ip_total, ceil($ip_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/contab_ip', $data));
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_customer']) || isset($this->request->get['filter_email'])) {
			if (isset($this->request->get['filter_customer'])) {
				$filter_customer = $this->request->get['filter_customer'];
			} else {
				$filter_customer = '';
			}

			if (isset($this->request->get['filter_email'])) {
				$filter_email = $this->request->get['filter_email'];
			} else {
				$filter_email = '';
			}
			
			if (isset($this->request->get['filter_affiliate'])) {
				$filter_affiliate = $this->request->get['filter_affiliate'];
			} else {
				$filter_affiliate = '';
			}
			
			$this->load->model('admdirsis/contab');

			$filter_data = array(
				'filter_customer'      => $filter_customer,
				'filter_email'     => $filter_email,
				'filter_affiliate' => $filter_affiliate,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_contab->getContabs($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'contab_id'       	=> $result['contab_id'],
					'caja_id'       	=> $result['caja_id'],
					'contab_group_id' 	=> $result['contab_group_id'],
					'name'              => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'contab_group'    	=> $result['contab_group'],
					'firstname'         => $result['firstname'],
					'lastname'          => $result['lastname'],
					'email'             => $result['email'],
					'telephone'         => $result['telephone'],
					'codiva_id'         => $result['codiva_id'],
					'cuit'         		=> $result['cuit'],
					'custom_field'      => json_decode($result['custom_field'], true),
					'address'           => $this->model_admdirsis_contab->getAddresses($result['contab_id'])
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function customfield() {
		$json = array();

		$this->load->model('contab/custom_field');

		// Contab Group
		if (isset($this->request->get['contab_group_id'])) {
			$contab_group_id = $this->request->get['contab_group_id'];
		} else {
			$contab_group_id = $this->config->get('config_contab_group_id');
		}

		$custom_fields = $this->model_contab_custom_field->getCustomFields(array('filter_contab_group_id' => $contab_group_id));

		foreach ($custom_fields as $custom_field) {
			$json[] = array(
				'custom_field_id' => $custom_field['custom_field_id'],
				'required'        => empty($custom_field['required']) || $custom_field['required'] == 0 ? false : true
			);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function address() {
		$json = array();

		if (!empty($this->request->get['address_id'])) {
			$this->load->model('admdirsis/contab');

			$json = $this->model_admdirsis_contab->getAddress($this->request->get['address_id']);
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function invoice() {
		
		if (!empty($this->request->get['contab_id'])) {
			$contab_id=$this->request->get['contab_id'];
		}
		$this->load->language('admdirsis/contab');
		$data['title'] = $this->language->get('text_invoice');
		
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}
		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');
		
		$this->load->model('admdirsis/contab');

		$this->load->model('setting/setting');

		$contab_info = $this->model_admdirsis_contab->getContab($contab_id);	
		
		//print_r($contab_info);

		if ($contab_info) {
			
			$total_data = array();
			$store_info = $this->model_setting_setting->getSetting('config', $contab_info['store_id']);
					
			//print_r($store_info);
			
			if ($store_info) {
				$store_fantasia = $store_info['config_owner'];
				$store_name = $store_info['config_name'];
				$store_image = $store_info['config_image'];
				$store_address = $store_info['config_address'];
				$store_email = $store_info['config_email'];
				$store_telephone = $store_info['config_telephone'];
				$store_fax = $store_info['config_fax'];
			} else {
				$store_fantasia = $this->config->get('config_owner');
				$store_name = $this->config->get('config_name');
				$store_image = $this->config->get('config_image');
				$store_address = $this->config->get('config_address');
				$store_email = $this->config->get('config_email');
				$store_telephone = $this->config->get('config_telephone');
				$store_fax = $this->config->get('config_fax');
			}
			$this->load->model('admdirsis/codiva');

			$store_cuit = $this->config->get('config_factura_cuit');
			$store_iib = $this->config->get('config_factura_iib');
			$store_iniact = $this->config->get('config_factura_iniact');
			$store_codiva_id = $this->config->get('config_factura_codiva_id');
			$store_codiva = $this->model_admdirsis_codiva->getCodiva($store_codiva_id);
			//print_r($store_codiva_id);
			
			$customer_codiva_id=$contab_info['codiva_id'];
			$customer_cuit=$contab_info['cuit'];
			
			/*
			$this->load->model('customer/customer');
			$customer = $this->model_customer_customer->getCustomer($contab_info['customer_id']);
			if ($customer){
				$customer_cuit = $customer['cuit'];
				$customer_codiva_id = $customer['codiva_id'];
			}
			*/
			$codiva = $this->model_admdirsis_codiva->getCodiva($customer_codiva_id);
			

			$format = '{firstname} {lastname}'  . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			
			$format2 = '{codiva}'  . "\n" . '{cuit}'  . "\n";

			$find = array(
				'{firstname}',
				'{lastname}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{country}',
				'{cuit}',
				'{codiva}'
			);

			$replace = array(
				'firstname' => $contab_info['name'],
				'lastname'  => '',
				'address_1' => $contab_info['address_1'],
				'address_2' => $contab_info['address_2'],
				'city'      => $contab_info['city'],
				'postcode'  => $contab_info['postcode'],
				'zone'      => $contab_info['zone'],
				'country'   => $contab_info['country'],
				'cuit'      => $contab_info['cuit'],
				'codiva'    => $codiva['name']
			);

			$payment_address = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));
			
			$payment_address2 = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format2))));

			$this->load->model('tool/upload');
			
			
			
			$letra="X";
			if (!empty($contab_info['cae'])){
				if ($store_codiva_id == 1){
					if ( $customer_codiva_id == 1) $letra="A";
					if ( $customer_codiva_id == 2) $letra="A";
					if ( $customer_codiva_id == 3) $letra="B";
					if ( $customer_codiva_id == 4) $letra="B";
					if ( $customer_codiva_id == 5) $letra="B";
				}else{
					$letra="C";
				}
			}
			

			$product_data = array();
			$products = $this->model_admdirsis_contab->getContabProducts($contab_id);

			$subtotal=0;
			
			foreach ($products as $product) {
				
					$tasaiva = $product['tasaiva'];
				
					if ($letra=='A'){
						$price = round($product['price']/(1+($tasaiva/100)),2);
						$total = round($product['quantity']*$price,2);
					}else{
						$price = $product['price'];
						$total = round($product['quantity']*$product['price'],2);
					}
					
					$product_data[] = array(
						'name'     => $product['name'],
						'model'    => $product['model'],
						'quantity' => $product['quantity'],
						'price'    => $this->currency->format($price , 'ARS', 0),
						'total'    => $this->currency->format($total , 'ARS', 0),
						'tasaiva'	=> $product['tasaiva']
					);
				
					$subtotal = $subtotal + $total;
			}
			
		
			$total_data[] = array( 'title' => "SUBTOTAL",	'text'  => $this->currency->format($subtotal , 'ARS', 0));			
			if ($subtotal<>$contab_info['total'] ){
				$iva = $contab_info['total']  - $subtotal;
				$total_data[] = array( 'title' => "I.V.A.",	'text'  => $this->currency->format($iva , 'ARS', 0));			
			}
			$total_data[] = array( 'title' => "TOTAL",	'text'  => $this->currency->format($contab_info['total'] , 'ARS', 0));	
			
			$json=array("ver" => "1",
				"fecha" => date("Y-m-d"),
				"cuit" => $store_cuit,
				"iib" => $store_iib,
				"iniact" => $store_iniact,
				"ptoVta" => $this->config->get('config_factura_serie'),
				"tipoComp" => $contab_info['afip'],
				"nroCmp" => $contab_info['numero'],
				"importe" => intval($contab_info['total']*100),
				"moneda" => 'PES',
				"ctz" => '1',
				"tipoDocRec" => '99',
				"nroDocRec" => $contab_info['cuit'],
				"tipoCodAut" => "E",
				"codAut" => $contab_info['cae']);

			//$json='{"ver":1,"fecha":"2021-02-03","cuit":27221499684,"ptoVta":3,"tipoCmp":11,"nroCmp":18,"importe":2700000,"moneda":"ARS","ctz":1,"tipoDocRec":80,"nroDocRec":30627697569,"tipoCodAut":"E","codAut":71054226023404}';
			$qr='https://www.afip.gob.ar/fe/qr/?p='.base64_encode(json_encode($json,true));
			$url="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=".$qr;
			//$contents = file_get_contents($url);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, "https://chart.apis.google.com/chart");
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, "chs=200x200&cht=qr&chl=" . urlencode($qr));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			$contents = curl_exec($ch);
			curl_close($ch);
			$qr='data:image/png;base64,'.base64_encode($contents);
			
			

			
			$data['orders'][] = array(
				'd_comprob'			=> $contab_info['d_comprob'],
				'contab_id'	        => $contab_id,
				'letra' 			=> $letra,
				'ptovta'		    => str_pad($contab_info['serie'], 4, '0', STR_PAD_LEFT),
				'invoice_no'        => str_pad($contab_info['numero'], 8, '0', STR_PAD_LEFT),
				'date_added'        => date($this->language->get('date_format_short'), strtotime($contab_info['date_added'])),
				'store_fantasia'    => $store_fantasia,
				'store_name'        => $store_name,
				'store_image'       => $store_image,
				'store_address'     => nl2br($store_address),
				'store_email'       => $store_email,
				'store_telephone'   => $store_telephone,
				'store_fax'         => $store_fax,
				'store_cuit'        => $store_cuit,
				'store_iib'         => $store_iib,
				'store_iniact'      => $store_iniact,
				'store_codiva_id'   => $store_codiva_id,
				'store_codiva'   	=> $store_codiva['name'],
				'customer_id' 		=> $contab_info['customer_id'],
				'firstname' 		=> $contab_info['name'],
				'lastname'  		=> '',
				'address_1' 		=> $contab_info['address_1'],
				'address_2' 		=> $contab_info['address_2'],
				'city'      		=> $contab_info['city'],
				'postcode'  		=> $contab_info['postcode'],
				'zone'     			=> $contab_info['zone'],
				'country'   		=> $contab_info['country'],
				'cuit'     			=> $customer_cuit,
				'codiva_id'			=> $customer_codiva_id,
				'codiva'    		=> $codiva['name'],
				'email'            => $contab_info['email'],
				'telephone'        => $contab_info['telephone'],
				'payment_address'  => $payment_address,
				'payment_address2' => $payment_address2,
				'payment_method'   => $contab_info['fpago'],
				'cae'   		   => $contab_info['cae'],
				'vcae'   		   => $contab_info['vcae'],
				'product'          => $product_data,
				'total'            => $total_data,
				'qr'			   => $qr,
				'comment'          => nl2br($contab_info['comment'])
			);

			
		}
		$this->response->setOutput($this->load->view('admdirsis/contab_invoice', $data));
	}
	
	public function factura_order() {
		$json = array();
		if (isset($this->request->get['order_id'])) {
			$this->load->model('sale/order');
			$order_id = $this->request->get['order_id'];
			$order_info = $this->model_sale_order->getOrder($order_id);
			//print_r($order_info);
			if ($order_info) {
				if ($order_info['invoice_no']!=0){
					$json=array('orden' => $order_id, 'factura' => 'Ya Factura con N° '.$order_info['invoice_no']);
				}else{
					//PENDIENTE DE FACTURAR
					$this->load->model('setting/setting');
					$data['comprob_id'] = $this->config->get('config_factura_comprob_id');
					$data['fpago_id'] = $this->config->get('config_factura_fpago_id');
					$data['customer_id'] = $order_info['customer_id'];
					$status=$this->config->get('config_order_statusf_id');
					$this->load->model('customer/customer');
					$customer = $this->model_customer_customer->getCustomer($order_info['customer_id']);
					if ($customer){
						$data['firstname'] = $customer['firstname'];
						$data['lastname'] = $customer['lastname'];
						$data['cuit'] = $customer['cuit'];
						$data['codiva_id'] = $customer['codiva_id'];
					}else{
						$data['firstname'] = 'CONSUMIDOR FINAL';
						$data['lastname'] = '..';
						$data['cuit'] = '';
						$data['codiva_id'] = '0';
					}
					$data['products'] = array();
					$products = $this->model_sale_order->getOrderProducts($this->request->get['order_id']);
					foreach ($products as $product) {
						$data['products'][] = array(
							'order_product_id' => $product['order_product_id'],
							'product_id'       => $product['product_id'],
							'name'    	 	   => $product['name'],
							'model'    		   => $product['model'],
							'quantity'		   => $product['quantity'],
							'price'    		   => $product['price'],
							'total'    		   => $product['total'],
							'original'		   => $product['original']
						);
					}
					$data['total'] = $order_info['total'];
					$data['invoice_prefix'] = $order_info['invoice_prefix'];
					$data['comment'] = nl2br($order_info['comment']);
					$data['date_added'] = date("Y-m-d");  
					$data['order_id'] = $order_id;
					$this->load->model('admdirsis/contab');
					$result = $this->model_admdirsis_contab->addContab($data);
					
					//$result=0;
					
					$result2=0;
					if ($result>0){
						$result2 = $this->model_sale_order->addinvoiceOrder($order_id,$result,$status);
					}
					$json=array('orden' => $order_id, 'factura' => $result);
				}
			}
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function delfactura_order() {
		$result=0;
		if (isset($this->request->get['order_id'])) {
			$this->load->model('sale/order');
			$order_id = $this->request->get['order_id'];
			$this->load->model('setting/setting');
			$status=$this->config->get('config_order_status_id');
			$result2 = $this->model_sale_order->delinvoiceOrder($order_id,$status);
			//ELIMINAR FACTURA Y COMISIONES
			$this->load->model('admdirsis/contab');
			$result=$this->model_admdirsis_contab->deleteContabxorderid($order_id);
		}
		if ($result!=0){
			$this->session->data['success'] = "Proceso sobre Orden exitoso!";
		}
		echo $result;
	}
	
	public function agentes() {
		$results = array();
		$this->load->model('admdirsis/contab');
		if (isset($this->request->get['customer_id'])) {
			$customer_id = $this->request->get['customer_id'];
			$results = $this->model_admdirsis_contab->getAgentes($this->request->get['customer_id']);
		}
		return $results;
	}
	
	public function getPagomasivo() {
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
		
		$this->load->model('admdirsis/contab');
		//$resul = $this->model_admdirsis_contab->pagoContab(9087);
		//print_r($resul);
		//die;
	
		$html = '<table border=1>';
        $html .= '<tr>';
		$html .= '<td>ID</td>';
		$html .= '<td>Tipo</td>';
		$html .= '<td>Cliente</td>';
		$html .= '<td>Total</td>';
		$html .= '</tr>';		
		if (($this->request->server['REQUEST_METHOD'] == 'POST')){
			foreach ($this->request->post['selected'] as $contab_id) {			
				$resul = $this->model_admdirsis_contab->pagoContab($contab_id);
				if (!$resul){
					$html .= '<tr>';
					$html .= '<td>'.$contab_id.'</td>';
					$html .= '<td colspan="3">Proceso Fallado</td>';
					$html .= '</tr>';
				}else{
					$html .= '<tr>';
					$html .= '<td>' .$resul['contab_id'] . '</td>';
					$html .= '<td>' .$resul['d_comprob'] . '</td>';
					$html .= '<td>'. $resul['customer'] . '</td>';
					$html .= '<td>'. $resul['total'] . '</td>';
					$html .= '</tr>';
				}
			}
		}
		$html .= '</table>';
		$this->session->data['success'] = $html;
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($resul));		
	}	
	
}