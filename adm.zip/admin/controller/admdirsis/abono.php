<?php
class ControllerAdmdirsisAbono extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/abono');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/abono');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/abono');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/abono');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_abono->addAbono($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_abono_st'])) {
				$url .= '&filter_abono_st=' . $this->request->get['filter_abono_st'];
			}
			if (isset($this->request->get['filter_abono'])) {
				$url .= '&filter_abono=' . $this->request->get['filter_abono'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				

			$this->response->redirect($this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/abono');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/abono');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			//print_r($this->request->post);
			//die;
			$this->model_admdirsis_abono->editAbono($this->request->get['customer_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_abono'])) {
				$url .= '&filter_abono=' . $this->request->get['filter_abono'];
			}
			if (isset($this->request->get['filter_abono_st'])) {
				$url .= '&filter_abono_st=' . $this->request->get['filter_abono_st'];
			}			

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}				

			$this->response->redirect($this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function generaabono() {
		
		$this->load->language('admdirsis/abono');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/abono');
		$motivo=$this->request->post['motivo_abono'];
		$accion=$this->request->post['accion_abono'];
		$date_abono=date( "Y-m-d", strtotime($this->request->post['date_abono']));
		$this->load->model('setting/setting');
		$comprob_id = $this->config->get('config_factura_comprob_id');
		$fpago_id = $this->config->get('config_factura_fpago_id');
		$estado = $this->config->get('config_factura_status_id');
		$product_id = $this->config->get('config_factura_product_id');
		
		$acum=0;
		
		if ($accion==1){
			$filter_data = array( 'filter_abono_st' => 'S'	);
			$results = $this->model_admdirsis_abono->getAbonos($filter_data);		
			foreach ($results as $result) {
				$customer_id=$result['customer_id'];
				$this->model_admdirsis_abono->generaAbono($customer_id,$motivo,$date_abono,$comprob_id,$estado,$fpago_id,$product_id);
				$acum++;
			}
		}
		
		if ($accion==2){
			if (isset($this->request->post['selected'])) {
				$accion = $this->request->post['accion'];
				foreach ($this->request->post['selected'] as $customer_id) {
					$this->model_admdirsis_abono->generaAbono($customer_id,$motivo,$date_abono,$comprob_id,$estado,$fpago_id,$product_id);
					$acum++;
				}
			}
		}
		$acum=$accion;
		$this->session->data['success'] = "Se generaron ".$acum." abonos con exito!!";
	}
	public function activar() {
		$this->load->language('admdirsis/abono');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/abono');
		$contador=0;
		if (isset($this->request->post['selected'])) {
			$accion = $this->request->post['accion'];
			foreach ($this->request->post['selected'] as $customer_id) {
				if ($accion=='sa'){
					$this->model_admdirsis_abono->activaSistema($customer_id,'1');
					$contador++;
				}
				if ($accion=='sd'){
					$this->model_admdirsis_abono->activaSistema($customer_id,'0');
					$contador++;
				}
				if ($accion=='ha'){
					$this->model_admdirsis_abono->activaHosting($customer_id,'1');
					$contador++;
				}
				if ($accion=='hd'){
					$this->model_admdirsis_abono->activaHosting($customer_id,'0');
					$contador++;
				}				
				if ($accion=='da'){
					$this->model_admdirsis_abono->activaDominio($customer_id,'1');
					$contador++;
				}
				if ($accion=='dd'){
					$this->model_admdirsis_abono->activaDominio($customer_id,'0');
					$contador++;
				}				
			}
		}
		echo "Se actualizaron ".$contador." registros";
	}	
	public function asociarabono() {
		$contador=0;
		$this->load->language('admdirsis/abono');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/abono');
		if (isset($this->request->post['selected'])) {		
			$valor=$this->request->post['valorabono'];
			
			foreach ($this->request->post['selected'] as $customer_id) {
				$this->model_admdirsis_abono->asociarAbono($customer_id,$valor);
				$contador++;
			}		
		}
		echo "Se actualizaron ".$contador." registros";
	}	
	protected function getList() {
		
		
				error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_abono'])) {
			$filter_abono = $this->request->get['filter_abono'];
		} else {
			$filter_abono = '';
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$filter_abono_st = $this->request->get['filter_abono_st'];
		} else {
			$filter_abono_st = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['motivo_abono'])) {
			$motivo_abono = $this->request->get['motivo_abono'];
		} else {
			$motivo_abono = "";
		}
		
		if (isset($this->request->get['date_abono'])) {
			$date_abono = $this->request->get['date_abono'];
		} else {
			$date_abono = date("d-m-Y");
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.id_club';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = 500; //$this->config->get('config_limit_admin');
		}		
		
		$data['limit'] = $limit ;

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abono'])) {
			$url .= '&filter_abono=' . $this->request->get['filter_abono'];
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$url .= '&filter_abono_st=' . $this->request->get['filter_abono_st'];
		}		

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		//$data['add'] = $this->url->link('admdirsis/abono/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['activasistema'] = $this->url->link('admdirsis/abono/activasistema', 'user_token=' . $this->session->data['user_token'] . $url."&accion=1", true);
		$data['desactivasistema'] = $this->url->link('admdirsis/abono/activasistema', 'user_token=' . $this->session->data['user_token'] . $url."&accion=0", true);

		$this->load->model('setting/store');

		$stores = $this->model_setting_store->getStores();
		
		$data['abonos'] = array();
		
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'filter_abono'             => $filter_abono,
			'filter_abono_st'             => $filter_abono_st,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $data['limit'],
			'limit'                    => $data['limit']
		);

		$customer_total = $this->model_admdirsis_abono->getTotalAbonos($filter_data);

		$results = $this->model_admdirsis_abono->getAbonos($filter_data);
		
		$cadicsiro=$cabono=$tadicsiro=$tabono=0;

		foreach ($results as $result) {
			
			/*
			$login_info = $this->model_admdirsis_abono->getTotalLoginAttempts($result['email']);

			if ($login_info && $login_info['total'] >= $this->config->get('config_login_attempts')) {
				$unlock = $this->url->link('admdirsis/abono/unlock', 'user_token=' . $this->session->data['user_token'] . '&email=' . $result['email'] . $url, true);
			} else {
				$unlock = '';
			}
			*/
			$unlock = '';
			$store_data = array();

			$store_data[] = array(
				'name' => $this->config->get('config_name'),
				'href' => $this->url->link('admdirsis/abono/login', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . '&store_id=0', true)
			);

			foreach ($stores as $store) {
				$store_data[] = array(
					'name' => $store['name'],
					'href' => $this->url->link('admdirsis/abono/login', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . '&store_id=' . $result['store_id'], true)
				);
			}
			
			$data['abonos'][] = array(
				'customer_id'    => $result['customer_id'],
				'id_club'    	 => $result['id_club'],
				'name'           => $result['name'],
				'email'          => $result['email'],
				'sistema'        => ($result['sistema']=='1' ? 'Si' : 'No'),
				'colorsistema'   => ($result['sistema']=='1' ? 'green' : 'red'),
				'hosting'        => ($result['hosting']=='1' ? 'Si' : 'No'),
				'colorhosting'   => ($result['hosting']=='1' ? 'green' : 'red'),
				'dominio'        => ($result['dominio']=='1' ? 'Si' : 'No'),
				'colordominio'   => ($result['dominio']=='1' ? 'green' : 'red'),
				'abono'          => $result['abono'],
				'adicsiro'       => $result['adicsiro'],
				'customer_group' => $result['customer_group'],
				'status'         => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'ip'             => $result['ip'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'unlock'         => $unlock,
				'store'          => $store_data,
				'edit'           => $this->url->link('admdirsis/abono/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . $url, true)
			);
			
			$tabono=$tabono+$result['abono'];
			if ($result['abono']<>0){
				$cabono++;
			}
			
			$tadicsiro=$tadicsiro+($result['abono']+$result['adicsiro']);
			if (($result['abono']+$result['adicsiro'])<>0){
				$cadicsiro++;
			}
			
		}
		
		$data['tabono']=$this->currency->format($tabono, $this->config->get('config_currency'));
		$data['cabono']=$cabono;

		$data['tadicsiro']=$this->currency->format($tadicsiro, $this->config->get('config_currency'));
		$data['cadicsiro']=$cadicsiro;
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abono'])) {
			$url .= '&filter_abono=' . $this->request->get['filter_abono'];
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$url .= '&filter_abono_st=' . $this->request->get['filter_abono_st'];
		}		

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}			
		$data['sort_customer_id'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.customer_id' . $url, true);
		$data['sort_id_club'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.id_club' . $url, true);		
		$data['sort_customer_group_id'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.customer_group_id' . $url, true);		
		$data['sort_name'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_email'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		$data['sort_ip'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.ip' . $url, true);
		$data['sort_sistema'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.sistema' . $url, true);
		$data['sort_abono'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.abono' . $url, true);
		$data['sort_adicsiro'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.adicsiro' . $url, true);		
		$data['sort_hosting'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.hosting' . $url, true);
		$data['sort_dominio'] = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . '&sort=c.dominio' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abono'])) {
			$url .= '&filter_abono=' . $this->request->get['filter_abono'];
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$url .= '&filter_abono_st=' . $this->request->get['filter_abono_st'];
		}		

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		$data['limit'] = $limit; //1000; //$this->config->get('config_limit_admin');
		$pagination = new Pagination();
		
		$pagination->total = $customer_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('admdirsis/abono', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}&limit='.$limit, true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($customer_total) ? (($page - 1) * $limit ) + 1 : 0, ((($page - 1) * $limit) > ($customer_total - $limit)) ? $customer_total : ((($page - 1) * $limit) + $limit), $customer_total, ceil($customer_total / $limit));
		
		
		$this->load->model('setting/setting');
		$vto2=$this->model_setting_setting->getSettingValue2('config_dias_2vto',10);
		$vto3=$this->model_setting_setting->getSettingValue2('config_dias_3vto',20);
		
		$fvto2=$this->model_setting_setting->getSettingValue2('config_dias_2fvto',10);
		$fvto3=$this->model_setting_setting->getSettingValue2('config_dias_3fvto',20);
		
		$data['siro_fvto1'] = date("d-m-Y");
		$data['siro_fvto2'] = date("d-m-Y",strtotime($data['siro_fvto1']."+ ".$fvto2." days")); 
		$data['siro_vto2']  = $vto2;
		$data['siro_fvto3'] = date("d-m-Y",strtotime($data['siro_fvto1']."+ ".$fvto3." days")); 
		$data['siro_vto3']  = $vto3;
		
		$data['filter_name'] = $filter_name;
		$data['filter_email'] = $filter_email;
		$data['filter_customer_group_id'] = $filter_customer_group_id;
		$data['filter_status'] = $filter_status;
		$data['filter_abono'] = $filter_abono;
		$data['filter_abono_st'] = $filter_abono_st;
		$data['filter_date_added'] = $filter_date_added;
		$data['motivo_abono'] = $motivo_abono;
		$data['date_abono'] = $date_abono;

		$this->load->model('customer/customer_group');

		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/abono_list', $data));
	}
	
	
	public function generaexcel() {
		
		if (isset($this->request->get['filter_siro'])) {
			$filter_siro = $this->request->get['filter_siro'];
		} else {
			$filter_siro = '';
		}		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_abono'])) {
			$filter_abono = $this->request->get['filter_abono'];
		} else {
			$filter_abono = '';
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$filter_abono_st = $this->request->get['filter_abono_st'];
		} else {
			$filter_abono_st = '';
		}		

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['motivo_abono'])) {
			$motivo_abono = $this->request->get['motivo_abono'];
		} else {
			$motivo_abono = "";
		}
		
		if (isset($this->request->get['date_abono'])) {
			$date_abono = $this->request->get['date_abono'];
		} else {
			$date_abono = date("d-m-Y");
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data['abonos'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'filter_abono'             => $filter_abono,
			'filter_abono_st'             => $filter_abono_st,
			'filter_siro'              => $filter_siro,
			'sort'                     => $sort,
			'order'                    => $order
		);
		$this->load->model('admdirsis/abono');
		$results = $this->model_admdirsis_abono->getAbonos($filter_data);
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()
			->setCreator("dirsis.com.ar")
			->setLastModifiedBy("dirsis.com.ar")
			->setTitle("Exportar XLSX")
			->setSubject("Excel")
			->setCategory("reportes");
			/* Datos Hojas */
		$row=2;
		$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row, 'Codigo')
					->setCellValue('B'.$row, 'Cliente')
					->setCellValue('C'.$row, 'Correo')
					->setCellValue('D'.$row, 'Abono');
				
		foreach ($results as $result) {
				$row++;
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A'.$row, $result['customer_id'])
						->setCellValue('B'.$row,  $result['name'])						
						->setCellValue('C'.$row,  $result['email'])
						->setCellValue('D'.$row,  $result['abono']);						
				
		}
		$filer='dirsis/upload/excel_'.date('Ymdhis').'.xlsx';
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($filer, __FILE__);
		echo $filer;
	}
	
	public function generasiro() {
		
		$this->load->model('setting/setting');
		$siro_fvto1 = date("d-m-Y");
		$siro_vto2 = 0;
		$siro_vto3 = 0;
		$siro_fvto3 = '';
		$siro_fvto2 = '';

		if (isset($this->request->get['siro_vto2'])) {
			$siro_vto2 = $this->request->get['siro_vto2'];
			$this->model_setting_setting->editSettingValue( 'config','config_dias_2vto',$siro_vto2);
		}
		if (isset($this->request->get['siro_vto3'])) {
			$siro_vto3 = $this->request->get['siro_vto3'];
			$this->model_setting_setting->editSettingValue( 'config','config_dias_3vto',$siro_vto3);
		}
		
		if (isset($this->request->get['siro_fvto1'])) {
			$siro_fvto1 = $this->request->get['siro_fvto1'];
		}	
		
		if (isset($this->request->get['siro_fvto2'])) {
			$siro1 = new DateTime($siro_fvto1);
			$siro2 = new DateTime($this->request->get['siro_fvto2']);
			$diff = date_diff($siro1,$siro2);
			$this->model_setting_setting->editSettingValue( 'config','config_dias_2fvto',$diff->d);
			
			$siro_fvto2 = $this->request->get['siro_fvto2'];
		}
		
		if (isset($this->request->get['siro_fvto3'])) {
			$siro1 = new DateTime($siro_fvto1);
			$siro2 = new DateTime($this->request->get['siro_fvto3']);
			$diff = date_diff($siro1,$siro2);
			$this->model_setting_setting->editSettingValue( 'config','config_dias_3fvto',$diff->d);
			
			$siro_fvto3 = $this->request->get['siro_fvto3'];
		}
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_abono'])) {
			$filter_abono = $this->request->get['filter_abono'];
		} else {
			$filter_abono = '';
		}
		if (isset($this->request->get['filter_abono_st'])) {
			$filter_abono_st = $this->request->get['filter_abono_st'];
		} else {
			$filter_abono_st = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['motivo_abono'])) {
			$motivo_abono = $this->request->get['motivo_abono'];
		} else {
			$motivo_abono = "";
		}
		
		if (isset($this->request->get['date_abono'])) {
			$date_abono = $this->request->get['date_abono'];
		} else {
			$date_abono = date("d-m-Y");
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data['abonos'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'filter_siro'              => '1',
			'sort'                     => "c.id_club",
			'order'                    => 'ASC'
		);
		$this->load->model('admdirsis/abono');
		$results = $this->model_admdirsis_abono->getAbonos($filter_data);
		
		//print_r($results);
		//die;
		
		$archivo='dirsis/modelos/siro.xlsx';
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$inputFileType = PHPExcel_IOFactory::identify( $archivo );
		$objReader = PHPExcel_IOFactory::createReader( $inputFileType );
		$objPHPExcel = $objReader->load( $archivo );
		
		/*
		$objPHPExcel->getProperties()
			->setCreator("dirsis.com.ar")
			->setLastModifiedBy("dirsis.com.ar")
			->setTitle("Exportar XLSX")
			->setSubject("Excel")
			->setCategory("reportes");
		*/
		setlocale(LC_ALL,"es_ES@euro","es_ES","esp");
		$sheet = $objPHPExcel->getSheet( 0 );
		$highestRow = $sheet->getHighestRow();
		$row = 2;
		foreach ($results as $result) {
			$total = $result['abono'] +$result['adicsiro'];
			if ($total>0){
				$vto2=$total+round($total*$siro_vto2/100,2);
				$vto3=$total+round($total*$siro_vto3/100,2);
				$sheet->setCellValue('A'.$row, $result['id_club']);
				$sheet->setCellValue('B'.$row,  PHPExcel_Shared_Date::PHPToExcel( date("d/m/Y", strtotime($siro_fvto1)) )); 
				$sheet->setCellValue('C'.$row, $total);
				$sheet->setCellValue('D'.$row,  PHPExcel_Shared_Date::PHPToExcel( date("d/m/Y", strtotime($siro_fvto2)) ));
				$sheet->setCellValue('E'.$row, $vto2);
				$sheet->setCellValue('F'.$row,  PHPExcel_Shared_Date::PHPToExcel( date("d/m/Y", strtotime($siro_fvto3)) ));
				$sheet->setCellValue('G'.$row, $vto3);
				$row++;
				/*
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A'.$row, $result['id_club'])
						->setCellValue('C'.$row, $total)
						->setCellValue('E'.$row, $vto2)
						->setCellValue('G'.$row, $vto3);
				*/
			}
		}
		$sheet->rangeToArray('A'.$row.':G5000', NULL, True, True);
		$filer='dirsis/upload/siro_up_'.date('Ymdhis').'.xlsx';
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($filer, __FILE__);
		echo $filer;
/*		

				$objPHPExcel->setActiveSheetIndex(0)
						->setTitle('comprobantes')
						->setCellValue('A'.$row, 'Nro Cliente')
						->setCellValue('B'.$row, '1º Vto')
						->setCellValue('C'.$row, '1º Monto')
						->setCellValue('D'.$row, '2º Vto')
						->setCellValue('E'.$row, '2º Monto')
						->setCellValue('F'.$row, '3º Vto')
						->setCellValue('G'.$row, '3º Monto');

			//$objPHPExcel->getActiveSheet()->getStyle('A'.$row.':F'.$row)->getFill()->applyFromArray(array('type' => PHPExcel_Style_Fill::FILL_SOLID,'startcolor' => array( 'rgb' => 'F000')));
			
		
		
		//$siro_fvto12=date('d', strtotime($siro_fvto1));
		//$siro_fvto13=date('Y', strtotime($siro_fvto1));
		//$siro_fvto1=" **".$siro_fvto11."/".$siro_fvto12."/".$siro_fvto13;
		$siro_fvto2=date('Y/m/d', strtotime($siro_fvto2));
		$siro_fvto3=date('Y/m/d', strtotime($siro_fvto3));
		
		//$siro_fvto1=date_format($siro_fvto1,"m/d/Y");
		
		
			foreach ($results as $result) {
				$total = $result['abono'] +$result['adicsiro'];
				if ($total>0){
					$vto2=$total+round($total*$siro_vto2/100,2);
					$vto3=$total+round($total*$siro_vto3/100,2);
					$row++;
					$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A'.$row, $result['id_club'])
							->setCellValue('C'.$row, $total)
							->setCellValue('E'.$row, $vto2)
							->setCellValue('G'.$row, $vto3);
				}
			}
			
		$filer='dirsis/upload/siro_up_'.date('Ymdhis').'.xlsx';
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($filer, __FILE__);
		echo $filer;
*/
	}
	
	public function recibesiro() {
		if ( !isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			echo "";
			die;
		}

			$archivo = "dirsis/upload/" . $_FILES[ 'file' ][ 'name' ];
			if ( is_file( $archivo ) ) {
				unlink($archivo);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], $archivo );
			if ( is_file( $archivo ) ) {
				$this->load->model('setting/setting');
				$comprob_id = $this->config->get('config_cobranza_comprob_id');
				$fpago_id 	= $this->config->get('config_factura_fpago_id');
				ini_set('max_execution_time', 3600);
				ini_set('memory_limit', '8000M');
				require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
				$inputFileType = PHPExcel_IOFactory::identify( $archivo );
				$objReader = PHPExcel_IOFactory::createReader( $inputFileType );
				$objPHPExcel = $objReader->load( $archivo );
				$hoja1 = 0;
				$overlay = 0;
				//HOJA1
				$sheet = $objPHPExcel->getSheet( 0 );
				$highestRow = $sheet->getHighestRow();
				$highestColumn = $sheet->getHighestColumn();
			
				for ( $row = 4; $row <= $highestRow; $row++ ) {
				
					$id 	= (int)$sheet->getCell( "C" . $row )->getValue();
					$monto  = (string)$sheet->getCell( "D" . $row )->getValue();
					$fecha  = $sheet->getCell( "F" . $row )->getValue();
					$fpago	= (string)$sheet->getCell( "G" . $row )->getValue();
					$canal	= (string)$sheet->getCell( "H" . $row )->getValue();

					$Excel_date = $fecha; //here is that value 41621 or 41631
					$unix_date = ($Excel_date - 25569) * 86400;
					$Excel_date = 25569 + ($unix_date / 86400);
					$unix_date = ($Excel_date - 25569) * 86400;
					$fecha = gmdate("Y-m-d", $unix_date);

					$order_id = $id.gmdate("Ymd", $unix_date);

					$total = str_replace(",","",$monto);
					$comment = "T:".$order_id."-C:".$canal;

					$this->load->model('customer/customer');
					$customer=$this->model_customer_customer->getCustomer($id);

					if ($customer){
						$data = array( 
							"order_id" 		=> $order_id,
							"comprob_id" 	=> $comprob_id,
							"customer_id"  	=> $customer["customer_id"],
							"total"  		=> $total,
							"comment"  		=> $comment,
							"date_added"  	=> $fecha,
							"codiva_id"  	=> $customer["codiva_id"], 
							"cuit" 			=> $customer["cuit"],
							"firstname"	 	=> $customer["firstname"],
							"lastname" 		=> $customer["lastname"],
							"fpago_id" 		=> $fpago_id
						);
					
						$contab_id=1;
						//$this->load->model('admdirsis/contab');
						//$contab_id=$this->model_admdirsis_contab->addContab($data);

						if ($contab_id){
							$resula[] = array( 
								"contab_id"		=> $contab_id,
								"fecha"  	=> $fecha,
								"order" 		=> $order_id,
								"customer_id"  	=> $customer["customer_id"],
								"name"	 	=> $customer["firstname"]." ".$customer["lastname"],
								"motivo"  		=> $comment,
								"importe"  		=> $total
							);
						}
					}
				}
				//echo($resula);
				$objPHPExcelf = new PHPExcel();
				$objPHPExcelf->getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
					/* Datos Hojas */
				$row=2;
				$objPHPExcelf->setActiveSheetIndex(0)
							->setCellValue('A'.$row, 'Oper. Generada')
							->setCellValue('B'.$row, 'Fecha Pago')
							->setCellValue('C'.$row, 'Orden')
							->setCellValue('D'.$row, 'N° Cliente')
							->setCellValue('E'.$row, 'Denominacion')
							->setCellValue('F'.$row, 'Motivo')
							->setCellValue('G'.$row, 'Importe');
								

				$objPHPExcelf->getActiveSheet()->getStyle('A'.$row.':F'.$row)->getFill()->applyFromArray(array('type' => PHPExcel_Style_Fill::FILL_SOLID,'startcolor' => array( 'rgb' => 'F000')));
				foreach ($resula as $result) {
					$row++;
					$objPHPExcelf->setActiveSheetIndex(0)
							->setCellValue('A'.$row, $result['contab_id'])
							->setCellValue('B'.$row, $result['fecha'])
							->setCellValue('C'.$row, $result['order'])
							->setCellValue('D'.$row, $result['customer_id'])
							->setCellValue('E'.$row, $result['name'])
							->setCellValue('F'.$row, $result['motivo'])
							->setCellValue('G'.$row, $result['importe']);
				}
				$filer='dirsis/upload/resultado_siro_'.date('Ymdhis').'.xlsx';
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcelf, 'Excel2007');
				$objWriter->save($filer, __FILE__);
				echo $filer;
				die;
			}			
		}

	
	public function editaadicsiro() {
		$contador=0;
		if (isset($this->request->post['selected'])) {
			$this->load->model('admdirsis/abono');
			$valor = $this->request->post['valor'];
			foreach ($this->request->post['selected'] as $customer_id) {
				$this->model_admdirsis_abono->editaAdicsiro($customer_id,$valor);
				//echo $customer_id.",".$valor;
				$contador++;
			}
		}
		echo "Se actualizaron ".$contador." registros";
	}	
	
	public function editaporce() {
		$contador=0;
		if (isset($this->request->post['selected'])) {
			$this->load->model('admdirsis/abono');
			$valor = $this->request->post['valor'];
			foreach ($this->request->post['selected'] as $customer_id) {
				$this->model_admdirsis_abono->editaPorce($customer_id,$valor);
				//echo $customer_id.",".$valor;
				$contador++;
			}
		}
		echo "Se actualizaron ".$contador." registros";
	}	
	
}
				

								
																
