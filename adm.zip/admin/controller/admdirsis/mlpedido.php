<?php
class ControllerAdmdirsisMlpedido extends Controller {
	public function leerpedidos() {
		$json = ' Se revisaron: ';

		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		$this->load->model('setting/setting');	
		$store_id = $this->config->get('config_store_id');
		$store_name = $this->config->get('config_name');
		$store_url = $this->config->get('config_url');
		
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		
		foreach ($results as $result) {
			$result=array_merge($result,array('store_id' => $store_id,'store_name' => $store_name,'store_url' => $store_url));
			$this->load->model('admdirsis/mlpedido');
			$results2 = $this->model_admdirsis_mlpedido->getLeerpedidos($result);
			$json.= 'MK:'.$result['marketplace'].'->revisados='.$results2;
		}
		echo $json;
	}
}