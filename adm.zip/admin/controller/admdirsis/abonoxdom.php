<?php
class ControllerAdmdirsisAbonoxdom extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/abonoxdom');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/abonoxdom');

		$this->getList();
	}

	public function generaabonoxdom() {
		
		$this->load->language('admdirsis/abonoxdom');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/abonoxdom');
		
		$data=array();
		$data['motivo']=$this->request->post['motivo_abonoxdom'];
		$data['accion']=$this->request->post['accion_abonoxdom'];
		$data['date_abonoxdom']=date( "Y-m-d", strtotime($this->request->post['date_abonoxdom']));
		
		//$this->load->model('setting/setting');
		$data['comprob_id'] = $this->config->get('config_factura_comprob_id');
		$data['fpago_id'] = $this->config->get('config_factura_fpago_id');
		$data['estado'] = $this->config->get('config_factura_status_id');
		$data['product_id'] = $this->config->get('config_factura_product_id');
		
		$data['product_valor_id']=$this->config->get('config_planabono_valor');
		$data['product_adicional_id']=$this->config->get('config_planabono_adicional');
		if ((int)$data['product_valor_id']>0){
			$this->load->model('catalog/product');
			$results = $this->model_catalog_product->getProduct($data['product_valor_id']);
			if ($results){
				$data['product_valor']=$results['name'];
			}
		}
		if ((int)$data['product_adicional_id']>0){
			$this->load->model('catalog/product');
			$results = $this->model_catalog_product->getProduct($data['product_adicional_id']);
			if ($results){
				$data['product_adicional']=$results['name'];
			}
		}
		
		$acum=0;
		if ($data['accion']==1){
			$results = $this->model_admdirsis_abonoxdom->getAbonoxdoms();		
			foreach ($results as $result) {
				if ((float)$result['abonoxdom']<>0 or (float)$result['adicxdom']<>0){
					$data['customer_id']=$result['customer_id'];
					$recorre=$this->model_admdirsis_abonoxdom->generaAbonoxdom($data);
					$acum=$acum+$recorre;
				}
				
			}
		}
		
		if ($data['accion']==2){
			if (isset($this->request->post['selected'])) {
				//$accion = $this->request->post['accion'];
				foreach ($this->request->post['selected'] as $customer_id) {
					$data['customer_id']=$customer_id;
					$recorre=$this->model_admdirsis_abonoxdom->generaAbonoxdom($data);
					$acum=$acum+$recorre;
				}
			}
		}
		$this->session->data['success'] = "Se generaron ".$acum." abonoxdoms con exito!!";
	}
	
	protected function getList() {
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_abonoxdom'])) {
			$filter_abonoxdom = $this->request->get['filter_abonoxdom'];
		} else {
			$filter_abonoxdom = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['motivo_abonoxdom'])) {
			$motivo_abonoxdom = $this->request->get['motivo_abonoxdom'];
		} else {
			$motivo_abonoxdom = "";
		}
		
		if (isset($this->request->get['date_abonoxdom'])) {
			$date_abonoxdom = $this->request->get['date_abonoxdom'];
		} else {
			$date_abonoxdom = date("d-m-Y");
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'c.id_club';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = 500; //$this->config->get('config_limit_admin');
		}		
		
		$data['limit'] = $limit ;

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abonoxdom'])) {
			$url .= '&filter_abonoxdom=' . $this->request->get['filter_abonoxdom'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		//$data['add'] = $this->url->link('admdirsis/abonoxdom/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['activasistema'] = $this->url->link('admdirsis/abonoxdom/activasistema', 'user_token=' . $this->session->data['user_token'] . $url."&accion=1", true);
		$data['desactivasistema'] = $this->url->link('admdirsis/abonoxdom/activasistema', 'user_token=' . $this->session->data['user_token'] . $url."&accion=0", true);

		$this->load->model('setting/store');

		$stores = $this->model_setting_store->getStores();
		
		$data['abonoxdoms'] = array();
		
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'filter_abonoxdom'         => $filter_abonoxdom,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $data['limit'],
			'limit'                    => $data['limit']
		);

		$customer_total = $this->model_admdirsis_abonoxdom->getTotalAbonoxdoms($filter_data);

		$results = $this->model_admdirsis_abonoxdom->getAbonoxdoms($filter_data);
		
		$cadicsiro=$cabonoxdom=$tadicsiro=$tabonoxdom=0;

		foreach ($results as $result) {
			$unlock = '';
			$store_data = array();

			$store_data[] = array(
				'name' => $this->config->get('config_name'),
				'href' => $this->url->link('admdirsis/abonoxdom/login', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . '&store_id=0', true)
			);

			foreach ($stores as $store) {
				$store_data[] = array(
					'name' => $store['name'],
					'href' => $this->url->link('admdirsis/abonoxdom/login', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . '&store_id=' . $result['store_id'], true)
				);
			}
			if ((float)$result['abonoxdom']<>0 or (float)$result['adicxdom']<>0){
				$data['abonoxdoms'][] = array(
					'customer_id'    => $result['customer_id'],
					'id_club'    	 => $result['id_club'],
					'name'           => $result['name'],
					'email'          => $result['email'],
					'abonoxdom'      => $this->currency->format($result['abonoxdom'], $this->config->get( 'config_currency' ) ),
					'adicxdom'       => $this->currency->format($result['adicxdom'], $this->config->get( 'config_currency' ) ),
					'customer_group' => $result['customer_group'],
					'status'         => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
					'ip'             => $result['ip'],
					'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
					'unlock'         => $unlock,
					'store'          => $store_data,
					'edit'           => $this->url->link('admdirsis/abonoxdom/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . $url, true)
				);
				$tabonoxdom=$tabonoxdom+(float)$result['abonoxdom']+(float)$result['adicxdom'];
				$cabonoxdom++;
			}
		}
		
		$data['tabonoxdom']=$this->currency->format($tabonoxdom, $this->config->get('config_currency'));
		$data['cabonoxdom']=$cabonoxdom;

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abonoxdom'])) {
			$url .= '&filter_abonoxdom=' . $this->request->get['filter_abonoxdom'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		if (isset($this->request->get['limit'])) {
			$url .= '&limit=' . $this->request->get['limit'];
		}			
		$data['sort_customer_id'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.customer_id' . $url, true);
		$data['sort_id_club'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.id_club' . $url, true);		
		$data['sort_customer_group_id'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.customer_group_id' . $url, true);		
		$data['sort_name'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, true);
		$data['sort_email'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		$data['sort_ip'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.ip' . $url, true);
		$data['sort_sistema'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.sistema' . $url, true);
		$data['sort_abonoxdom'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.abonoxdom' . $url, true);
		$data['sort_adicsiro'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.adicsiro' . $url, true);		
		$data['sort_hosting'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.hosting' . $url, true);
		$data['sort_dominio'] = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . '&sort=c.dominio' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_abonoxdom'])) {
			$url .= '&filter_abonoxdom=' . $this->request->get['filter_abonoxdom'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		$data['limit'] = $limit; //1000; //$this->config->get('config_limit_admin');
		$pagination = new Pagination();
		
		$pagination->total = $customer_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('admdirsis/abonoxdom', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}&limit='.$limit, true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($customer_total) ? (($page - 1) * $limit ) + 1 : 0, ((($page - 1) * $limit) > ($customer_total - $limit)) ? $customer_total : ((($page - 1) * $limit) + $limit), $customer_total, ceil($customer_total / $limit));
		
		
		$this->load->model('setting/setting');
		$vto2=$this->model_setting_setting->getSettingValue2('config_dias_2vto',10);
		$vto3=$this->model_setting_setting->getSettingValue2('config_dias_3vto',20);
		
		$fvto2=$this->model_setting_setting->getSettingValue2('config_dias_2fvto',10);
		$fvto3=$this->model_setting_setting->getSettingValue2('config_dias_3fvto',20);
		
		$data['siro_fvto1'] = date("d-m-Y");
		$data['siro_fvto2'] = date("d-m-Y",strtotime($data['siro_fvto1']."+ ".$fvto2." days")); 
		$data['siro_vto2']  = $vto2;
		$data['siro_fvto3'] = date("d-m-Y",strtotime($data['siro_fvto1']."+ ".$fvto3." days")); 
		$data['siro_vto3']  = $vto3;
		
		$data['filter_name'] = $filter_name;
		$data['filter_email'] = $filter_email;
		$data['filter_customer_group_id'] = $filter_customer_group_id;
		$data['filter_status'] = $filter_status;
		$data['filter_abonoxdom'] = $filter_abonoxdom;
		$data['filter_date_added'] = $filter_date_added;
		$data['motivo_abonoxdom'] = $motivo_abonoxdom;
		$data['date_abonoxdom'] = $date_abonoxdom;

		$this->load->model('customer/customer_group');

		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/abonoxdom_list', $data));
	}
	
	
	public function generaexcel() {
		
		if (isset($this->request->get['filter_siro'])) {
			$filter_siro = $this->request->get['filter_siro'];
		} else {
			$filter_siro = '';
		}		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = '';
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = '';
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}

		if (isset($this->request->get['filter_abonoxdom'])) {
			$filter_abonoxdom = $this->request->get['filter_abonoxdom'];
		} else {
			$filter_abonoxdom = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['motivo_abonoxdom'])) {
			$motivo_abonoxdom = $this->request->get['motivo_abonoxdom'];
		} else {
			$motivo_abonoxdom = "";
		}
		
		if (isset($this->request->get['date_abonoxdom'])) {
			$date_abonoxdom = $this->request->get['date_abonoxdom'];
		} else {
			$date_abonoxdom = date("d-m-Y");
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$data['abonoxdoms'] = array();
		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_date_added'        => $filter_date_added,
			'filter_abonoxdom'             => $filter_abonoxdom,
			'filter_siro'              => $filter_siro,
			'sort'                     => $sort,
			'order'                    => $order
		);
		$this->load->model('admdirsis/abonoxdom');
		$results = $this->model_admdirsis_abonoxdom->getAbonoxdoms($filter_data);
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()
			->setCreator("dirsis.com.ar")
			->setLastModifiedBy("dirsis.com.ar")
			->setTitle("Exportar XLSX")
			->setSubject("Excel")
			->setCategory("reportes");
			/* Datos Hojas */
		$row=2;
		$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row, 'Codigo')
					->setCellValue('B'.$row, 'Cliente')
					->setCellValue('C'.$row, 'Correo')
					->setCellValue('D'.$row, 'Abono')
					->setCellValue('E'.$row, 'Adicional');
				
		foreach ($results as $result) {
				if ((float)$result['abonoxdom']<>0 or (float)$result['adicxdom']<>0){
				$row++;
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A'.$row, $result['customer_id'])
						->setCellValue('B'.$row,  $result['name'])						
						->setCellValue('C'.$row,  $result['email'])
						->setCellValue('D'.$row,  $result['abonoxdom'])						
						->setCellValue('E'.$row,  $result['adicxdom']);						
				}
				
		}
		$filer='dirsis/upload/excel_'.date('Ymdhis').'.xlsx';
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($filer, __FILE__);
		echo $filer;
	}
	
}
				

								
																
