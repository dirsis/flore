<?php
class ControllerAdmdirsisEstado extends Controller {
	private $error = array();
	public function index() {
		
		$this->load->language('admdirsis/estado');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/estado');
		
		$this->getList();
		
	}
	
	protected function getList() {
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}		
		if (isset($this->request->get['filter_date_begin'])) {
			$filter_date_begin = $this->request->get['filter_date_begin'];
		} else {
			$filter_date_begin = date('01-m-Y');
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = $this->request->get['filter_date_end'];
		} else {
			$filter_date_end = date('d-m-Y');
		}				
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_added';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}		
		

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . urlencode(html_entity_decode($this->request->get['filter_customer_id'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_begin'])) {
			$url .= '&filter_date_begin=' . $this->request->get['filter_date_begin'];
		}
		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['estados'] = array();
		
		$this->load->model('customer/customer');
		if ($filter_customer_id>0){
			$customer = $this->model_customer_customer->getCustomer($filter_customer_id);
			$filter_customer=$customer['name'];
		}
		$subs=array();
		$subs[] = array(
			'customer_id'   	=> $filter_customer_id
		);
		$subagentes = $this->model_customer_customer->getSubagentes($filter_customer_id);
		foreach ($subagentes as $subagente) {	
			$subs[] = array(
				'customer_id'   	=> $subagente['customer_id']
			);
			$subagentes2 = $this->model_customer_customer->getSubagentes($subagente['customer_id']);
			foreach ($subagentes2 as $subagente2) {	
				$subs[] = array(
					'customer_id'   	=> $subagente2['customer_id']
				);
				$subagentes3 = $this->model_customer_customer->getSubagentes($subagente2['customer_id']);
				foreach ($subagentes3 as $subagente3) {	
					$subs[] = array(
						'customer_id'   	=> $subagente3['customer_id']
					);
				}
			}
		}
		
		$filter_data = array(
			'filter_customer_id'	 => $filter_customer_id,
			'filter_saldo'			 => '1',
			'filter_subs'	 		 => $subs,
			'filter_customer'	     => $filter_customer,
			'filter_date_begin'      => date("Y-m-d",strtotime($filter_date_begin)),
			'filter_date_end'      	 => date("Y-m-d",strtotime($filter_date_end)),
			'filter_status'			 => $filter_status,
			'sort'                   => $sort,
			'order'                  => $order,
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);
	
		//print_r($filter_data);
		
		$estado_total=0;
		$data['estados']=array();
		if ($filter_customer_id){
			$this->load->model('admdirsis/saldo');
			$saldos = $this->model_admdirsis_saldo->getSaldo($filter_data);
			if ($saldos){
				foreach ($saldos as $saldo) {
					$data['mailing_estado']=date("d-m-Y",strtotime($saldo['mailing_estado']));
					$data['customer']=$saldo['customer'];
					break;
				}
			}
			$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
			$inicial = $this->model_admdirsis_estado->getEstadosaldoinicial($filter_data);
			$acum=$inicial;
			$orden=0;
			
			$data['estados0'][] = array(
						'orden'			=> $orden,
						'contab_id'   	=> 0,
						'order_id'   	=> 0,
						'd_comprob' 	=> "Saldo Inicial",
						'letra' => '',
						'afip'      	 => '',
						'customer_id'   => 0,
						'relacion_id'   => -1,
						'numero'    	 => 0,
						'serie'    	 	 => 0,
						'customer'      => '',
						'comment'      	=> '',
						'invoice_prefix' 	=> '',
						'date_added'    => date("d/m/Y",strtotime($filter_date_begin)),
						'total'         => number_format($inicial, '2'),
						'final'         => number_format($inicial, '2'),
						'final2'         => $inicial,
						'acum'         	=> number_format($inicial, '2'),
						'tcolor'		=> $inicial>0 ? "red" : "green",
						'accion'		=> '',
						'pdf'		=> '',
			);			
			$results = $this->model_admdirsis_estado->getEstado($filter_data);
			

			
			$store_codiva_id = $this->config->get('config_factura_codiva_id');
			foreach ($results as $result) {
				$orden++;
				$acum=$acum+$result['final'];
				if ($result['final']<0){ 
					$color="red";
					$relacion_id=-1;
				}else{	
					$color="green";	
					$relacion_id=$result['relacion_id'];
				}
				$verurl="&contab_id=".$result['contab_id']."&filter_customer_id=".$result['customer_id']."&filter_customer=".$result['customer'];
				$editar=$this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $verurl, true);
				
				$letra="";
				if (!empty($result['cae'])){
					if ($store_codiva_id == 1){
						if ( $result['codiva_id'] == 1) $letra="A";
						if ( $result['codiva_id'] == 2) $letra="A";
						if ( $result['codiva_id'] == 3) $letra="B";
						if ( $result['codiva_id'] == 4) $letra="B";
						if ( $result['codiva_id'] == 5) $letra="B";
					}else{
						$letra="C";
					}
				}				
				
				if ($this->request->server['HTTPS']) {
					$linkeo =  HTTPS_CATALOG;
				} else {
					$linkeo =  HTTPS_CATALOG;
				}
				$linkeo .= "index.php?route=account/invoice&contab_id=".$result['contab_id'];
				
				$data['estados0'][] = array(
					'orden' => $orden,
					'date_added'    	=> date("d/m/Y", strtotime($result['date_added'])),
					'contab_id'   		=> $result['contab_id'],
					'order_id'   	=> $result['order_id'],
					'd_comprob' 		=> $result['d_comprob'],
					'letra'    	 		=> $letra,
					'afip'      	 	=> $result['afip'],
					'numero'    	 	=> $result['numero'],
					'serie'    	 	 	=> $result['serie'],					
					'customer_id'   	=> $result['customer_id'],
					'relacion_id'   	=> $relacion_id,
					'customer'      	=> $result['customer'],
					'comment'      		=> $result['comment'],
					'invoice_prefix' 	=> $result['invoice_prefix'],
					'total'         => number_format($result['total'], '2'),
					'final'         => number_format($result['final'], '2'),
					'final2'         => $result['final'],
					'acum'         	=> number_format($acum, '2'),
					'tcolor'		=> $color,
					'accion'		=> $editar,
					'pdf'			=> $linkeo
				);
			}
			//$data['inicial']	=	number_format($inicial, '2');		
			//$data['inicialf']	=	number_format($inicial, '2');		
			$periodo = $acum - $inicial;
			$data['periodo']	=	number_format($periodo, '2');	;
			$data['saldo']		=	number_format($acum, '2');	
			if ($acum<0){	$color="red"; }else{	$color="green";	}
			$data['tsaldo']		=	$color;
			if ($inicial<0){	$color="red"; }else{	$color="green";	}
			$data['tinicial']	=	$color;
			if ($periodo<0){	$color="red"; }else{	$color="green";	}
			$data['tperiodo']	=	$color;
		/*	
			echo "<pre>";
			print_r($data['estados0']);
			echo "</pre>";
*/
			//echo $order;
			if ($sort=='date_added'){
				arsort($data['estados0']);
			}
/*			
			echo "<pre>";
			print_r($data['estados0']);
			echo "</pre>";
		*/	
			foreach ($data['estados0'] as $result) {
				$data['estados'][] = array(
					'orden'			=> $result['orden'],
					'contab_id'   	=> $result['contab_id'],
					'order_id'   	=> $result['order_id'],
					'letra' =>  $result['letra'],
					'afip'      	 => $result['afip'],
					'd_comprob' 	=> $result['d_comprob'],
					'numero'    	 => $result['numero'],
					'serie'    	 	 => $result['serie'],					
					'customer_id'   => $result['customer_id'],
					'relacion_id'   => $result['relacion_id'],
					'customer'      => $result['customer'],
					'comment'      	=> $result['comment'],
					'invoice_prefix' 	=> $result['invoice_prefix'],
					'date_added'    => $result['date_added'],
					'total'         => $result['total'],
					'final'         => $result['final'],
					'acum'         	=> $result['acum'],
					'tcolor'		=> $result['tcolor'],
					'accion'		=> $result['accion'],
					'pdf'		=> $result['pdf']
				);
			}			
			
		}
		
		
		
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . $this->request->get['filter_customer_id'];
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_date_begin'])) {
			$url .= '&filter_date_begin=' . $this->request->get['filter_date_begin'];
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$data['sort_date_added'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);
		$data['sort_contab_id'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=contab_id' . $url, true);
		$data['sort_d_comprob'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=d_comprob' . $url, true);
		$data['sort_customer_id'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=customer_id' . $url, true);
		//$data['sort_customer'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
		$data['sort_comment'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=comment' . $url, true);
		$data['sort_final'] = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&sort=final' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . urlencode(html_entity_decode($this->request->get['filter_customer_id'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}		
		if (isset($this->request->get['filter_date_begin'])) {
			$url .= '&filter_date_begin=' . $this->request->get['filter_date_begin'];
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $estado_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($estado_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($estado_total - $this->config->get('config_limit_admin'))) ? $estado_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $estado_total, ceil($estado_total / $this->config->get('config_limit_admin')));

		$data['filter_customer_id'] = $filter_customer_id;
		$data['filter_customer'] = $filter_customer;
		$data['filter_date_begin'] = $filter_date_begin;
		$data['filter_date_end'] = $filter_date_end;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		
		$data['config_invoice_prefix'] = $this->config->get('config_invoice_prefix');
		
//FIN LISTAR		
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->load->model('user/api');
		
		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));
		if ($api_info && $this->user->hasPermission('modify', 'admdirsis/estado')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);
			$session->start();
			$this->model_user_api->deleteApiSessionBySessonId($session->getId());
			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
			$session->data['api_id'] = $api_info['api_id'];
			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}
		
		$data['pagar'] = $this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/estado/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
/*DIRSIS*/		
		$this->load->model('user/user');
		
		$user_info = $this->model_user_user->getUser($this->user->getId());
		if ($user_info) {
			
			$data['firstname'] = $user_info['firstname'];
			$data['lastname'] = $user_info['lastname'];
			$data['username']  = $user_info['username'];
			$data['user_group'] = $user_info['user_group'];		
			$data['user_group_id'] = $user_info['user_group_id'];	
			$data['user_group_nivel'] = $user_info['user_group_nivel'];
			//$data['nivel'] = $user_info['nivel'];		
		}
		
		$data['mask'] = $this->config->get('config_valor_pp');
		$data['mask2'] = $this->config->get('config_valor_adm');
		$data['mask3'] = $this->config->get('config_valor_fecha');	
		
		
		if (empty($filter_date_end)){
			$data['filter_date_end']=date("d-m-Y");
		}
		if (empty($filter_date_begin)){
			$data['filter_date_begin']=$this->_data_first_month_day();
		}
		
		
		
/*DIRSIS*/		
		$this->response->setOutput($this->load->view('admdirsis/estado_list', $data));
	}
	
	public function getCiti() {
		$resul="";
		
		$archivo2o = "dirsis/modelo/citi_ventas_ALIC.txt";
		$archivo1o = "dirsis/modelo/citi_ventas_COMP.txt";
		$archivo2  = "citi_ventas_ALIC.txt";
		$archivo1  = "citi_ventas_COMP.txt";		
		copy($archivo1o, $archivo1);
		copy($archivo2o, $archivo2);
		
		$salto=PHP_EOL;
		
		$outputBuffer2 = fopen($archivo2, 'w+');
		$outputBuffer1 = fopen($archivo1, 'w+');
		$this->load->model('admdirsis/contab');
		if (isset($_REQUEST['selected'])){
			foreach ($_REQUEST['selected'] as &$valor) {
				$result = $this->model_admdirsis_contab->getContab($valor);

				if ($result){
				$xfecha=date("Ymd",strtotime($result['date_added'])); //YYYYMMDD
				if ($result['letra']=='1'){
					$xtipo=substr("000".trim($result['afip']),-3);
				}else{
					if (trim($result['afip'])=='1'){
						$xafip='6';
					}
					if (trim($result['afip'])=='2'){
						$xafip='7';
					}
					if (trim($result['afip'])=='3'){
						$xafip='8';
					}
					$xtipo=substr("000".trim($xafip),-3);
				}
				//$xtipo=$xtipo."-".$result['letra']."-".$result['afip'].$result['codiva_id'].")";
				$xserie =substr(str_repeat('0',5).$result['serie'],-5); //XSERIE=Tran(IIF(serie>0,serie,serie*-1),"@L #####") &&5
				$xnumero=substr(str_repeat('0',20).$result['numero'],-20); //XNUMERO=Tran(numero,"@L ### ### ### ### ### ### ##") &&20
				$xultimo=substr(str_repeat('0',20).$result['numero'],-20); //XULTIMO=Tran(numero,"@L ####################") &&20
				$xapelli=trim(mb_strtoupper($result['customer'], 'UTF-8'));
				$xapelli=str_replace("Ó","O",$xapelli);
				$xapelli=str_replace("Á","A",$xapelli);
				$xapelli=str_replace("É","E",$xapelli);
				$xapelli=str_replace("Í","I",$xapelli);
				$xapelli=str_replace("Ú","U",$xapelli);
				$xapelli=str_replace("Ñ","N",$xapelli);
				$xapelli=substr($xapelli.str_repeat(' ',30),0,30);					

				$xdoc="96";
				$xdni=str_replace(chr(10),"",htmlspecialchars($result['cuit']));
				$xdni=str_replace(chr(255),"",$xdni);
				$xdni=str_replace(chr(32),"",$xdni);
				$xdni=trim(str_replace("-","",trim(nl2br($xdni))));
				if ($result['letra']=='A'){
					$xdoc="80";
				}else{
					if (strlen($xdni)>9){
						$xdoc="80";
					}else{
						if (empty($xdni)){
							$xdoc="99";
						}
					}
				}
				//XDOC=Iif(CODIVA="I" Or CODIVA="M","80",Iif(Empty(ALLTRIM(CUIT)),"99","96")) &&2
				
				$xdni  =substr(str_repeat('0',20).$xdni,-20); //Strtran(CUIT,"-","")),"@L ####################") &&20
				if ($result['total']>0){
					$xtotal0=$result['total']; //"@L ###############") &&15
				}else{
					$xtotal0=($result['total']*-1);
				}
				$xtotal=substr(str_repeat('0',15).($xtotal0*100),-15);
				$xnogra    =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xnocat    =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xexent    =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xperciva  =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xpercotros=str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xperciib  =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xpercmuni =str_repeat('0',15); //Tran(0,"@L ###############") &&15
				$xinter    =str_repeat('0',15); //Tran(0,"@L ###############") &&15

				$xmoneda="PES";
				$xcambio="0001000000"; //XCAMBIO="0001000000" &&TRAN(1000,"@L ### #######")
				$xotros=str_repeat('0',15); //Tran(0,"@L ### ### ### ######")
				$xecuit=str_repeat('0',11); //"000 000 000 00"
				$xenom   =str_repeat('0',30); //Space(30)
				$xcomi   =str_repeat('0',15); //Tran(0,"@L ###############")
				$ximpiva =str_repeat('0',15); //Tran(0,"@L ###############")

				
					
				$resultivas = $this->model_admdirsis_contab->getContabTasaiva($valor);
				if ($resultivas){
					$totaiva=$xalic=0;
					foreach ($resultivas as $resultiva) {
						//print_r($resultiva);
						$xcode="0";
						$xalic++;
						$xiva="0005";
						if ($resultiva['tasaiva']==10.5){
							$xiva="0004";
						}
						if ($resultiva['tasaiva']==27){
							$xiva="0006";
						}
						if ($resultiva['tasaiva']==0){
							$xiva="0003";
							$xcode="E";
						}
						//XIVA=Iif(TASA=21,"0005",Iif(TASA=10.5,"0004",Iif(TASA=27,"0006","0003")))
						$xneto0	=round($resultiva['total']/(1+($resultiva['tasaiva']/100)),2);	//XNETO=ROUND(IIF(TOTAL<0,TOTAL*-1,TOTAL)/(1+(TASA/100)),2)
						$xiva0	=round($xtotal0-$xneto0,2);
						$xneto =substr(str_repeat('0',15).($xneto0*100),-15); //XNETO1=Tran((XNETO*100)*Iif(XNETO<0,-1,1),"@L ###############")
						$xliqiva  =substr(str_repeat('0',15).($xiva0*100),-15);
						
						$B1=$xtipo.$xserie.$xnumero.$xneto.$xiva.$xliqiva; //$B1=XTIPO+XSERIE+XNUMERO+XNETO1+XIVA+XLIQIVA

						//$totaliva=$totaliva+$xliqiva;
						$linea=preg_replace("/\r\n|\r|\n/","\r\n",$B1 . $salto);
						fwrite($outputBuffer2, $linea);
					}
				}else{
					$xcode="A";
				}
						
				$A1=$xfecha.$xtipo.$xserie.$xnumero.$xultimo.$xdoc.$xdni.$xapelli.$xtotal.$xnogra.$xperciva.$xexent.$xpercotros.$xperciib.$xpercmuni.$xinter.$xmoneda.$xcambio.$xalic.$xcode.$xotros."00000000";
				$linea=preg_replace("/\r\n|\r|\n/","\r\n",$A1 . $salto);
				fwrite($outputBuffer1,$linea);
				
				//fputcsv($outputBuffer1, $A1 . $salto);
				}
			}
			fclose($outputBuffer1);
			fclose($outputBuffer2);
			$this->response->setOutput($archivo1);	
			$this->response->setOutput($archivo2);	
			
		}
		/*
		}
		*/
		echo "";
	}
	

	
	public function generar_csv() {
		
		if (isset($this->request->get['accion'])) {
			$accion = $this->request->get['accion'];
		} else {
			$accion = '1';
		}		
		
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}		
		if (isset($this->request->get['filter_date_begin'])) {
			$filter_date_begin = $this->request->get['filter_date_begin'];
		} else {
			$filter_date_begin = date('01-m-Y');
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = $this->request->get['filter_date_end'];
		} else {
			$filter_date_end = date('d-m-Y');
		}				
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_added';
		}
		$order = 'ASC';

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);		

		if (isset($this->request->get['filter_customer_id'])) {
			$url .= '&filter_customer_id=' . urlencode(html_entity_decode($this->request->get['filter_customer_id'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		if (isset($this->request->get['filter_date_begin'])) {
			$url .= '&filter_date_begin=' . $this->request->get['filter_date_begin'];
		}
		if (isset($this->request->get['filter_date_end'])) {
			$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=ASC';
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=contab_id';
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['estados'] = array();
		
		$this->load->model('customer/customer');
		if ($filter_customer_id>0){
			$customer = $this->model_customer_customer->getCustomer($filter_customer_id);
			$filter_customer=$customer['name'];
		}
		$subs=array();
		$subs[] = array(
			'customer_id'   	=> $filter_customer_id
		);
		$subagentes = $this->model_customer_customer->getSubagentes($filter_customer_id);
		foreach ($subagentes as $subagente) {	
			$subs[] = array(
				'customer_id'   	=> $subagente['customer_id']
			);
			$subagentes2 = $this->model_customer_customer->getSubagentes($subagente['customer_id']);
			foreach ($subagentes2 as $subagente2) {	
				$subs[] = array(
					'customer_id'   	=> $subagente2['customer_id']
				);
				$subagentes3 = $this->model_customer_customer->getSubagentes($subagente2['customer_id']);
				foreach ($subagentes3 as $subagente3) {	
					$subs[] = array(
						'customer_id'   	=> $subagente3['customer_id']
					);
				}
			}
		}
		
		$filter_data = array(
			'filter_customer_id'	 => $filter_customer_id,
			'filter_saldo'			 => '1',
			'filter_subs'	 		 => $subs,
			'filter_customer'	     => $filter_customer,
			'filter_date_begin'      => date("Y-m-d",strtotime($filter_date_begin)),
			'filter_date_end'      	 => date("Y-m-d",strtotime($filter_date_end)),
			'filter_status'			 => $filter_status,
			'sort'                   => "contab_id",
			'order'                  => " ASC",
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);
/*	
		echo "<pre>";
		print_r($filter_data);
		echo "</pre>";
*/		
		$this->load->model('admdirsis/estado');
		$estado_total=0;
		$data['estados']=array();
		if ($filter_customer_id){
			$this->load->model('admdirsis/saldo');
			$saldos = $this->model_admdirsis_saldo->getSaldo($filter_data);
			if ($saldos){
				foreach ($saldos as $saldo) {
					$data['mailing_estado']=$saldo['mailing_estado'];
					$data['customer']=$saldo['customer'];
					break;
				}
			}
			$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
			$inicial = $this->model_admdirsis_estado->getEstadosaldoinicial($filter_data);
			$acum=$inicial;
			$orden=0;
			
			$data['estados0'][] = array(
						'order_id'			=> 0,
						'contab_id'   	=> 0,
						'd_comprob' 	=> "Saldo Inicial",
						'invoice_prefix' => '',
						'letra' => '',
						'afip'      	 => '',
						'customer_id'   => 0,
						'relacion_id'   => 0,
						'numero'    	 => 0,
						'serie'    	 	 => 0,
						'customer'      => '',
						'comment'      	=> '',
						'date_added'    => date("d/m/Y",strtotime($filter_date_begin)),
						'total'         => number_format($inicial, '2'),
						'final'         => number_format($inicial, '2'),
						'final2'         => $inicial,
						'acum'         	=> number_format($inicial, '2'),
						'tcolor'		=> $inicial>0 ? "red" : "green",
						'accion'		=> '',
						'pdf'		=> '',
			);			
			$results = $this->model_admdirsis_estado->getEstado($filter_data);
			

			
			$store_codiva_id = $this->config->get('config_factura_codiva_id');
			foreach ($results as $result) {
				$orden++;
				$acum=$acum+$result['final'];
				if ($result['final']<0){ $color="red";	}else{	$color="green";	}
				$verurl="&contab_id=".$result['contab_id']."&filter_customer_id=".$result['customer_id']."&filter_customer=".$result['customer'];
				$editar=$this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $verurl, true);
				
				$letra="";
				if (!empty($result['cae'])){
					if ($store_codiva_id == 1){
						if ( $result['codiva_id'] == 1) $letra="A";
						if ( $result['codiva_id'] == 2) $letra="A";
						if ( $result['codiva_id'] == 3) $letra="B";
						if ( $result['codiva_id'] == 4) $letra="B";
						if ( $result['codiva_id'] == 5) $letra="B";
					}else{
						$letra="C";
					}
				}				
				
				if ($this->request->server['HTTPS']) {
					$linkeo =  HTTPS_CATALOG;
				} else {
					$linkeo =  HTTPS_CATALOG;
				}
				$linkeo .= "index.php?route=account/invoice&contab_id=".$result['contab_id'];
				
				$data['estados0'][] = array(
					'order_id'			=> $result['order_id'],
					'date_added'    => date("d/m/Y", strtotime($result['date_added'])),
					'invoice_prefix' => $result['invoice_prefix'],
					'contab_id'   	=> $result['contab_id'],
					'd_comprob' 	=> $result['d_comprob'],
					'letra'    	 => $letra,
					'afip'      	 => $result['afip'],
					'numero'    	 => $result['numero'],
					'serie'    	 	 => $result['serie'],					
					'customer_id'   => $result['customer_id'],
					'relacion_id'   => $result['relacion_id'],
					'customer'      => $result['customer'],
					'comment'      	=> $result['comment'],
					'total'         => number_format($result['total'], '2'),
					'final'         => number_format($result['final'], '2'),
					'final2'         => $result['final'],
					'acum'         	=> number_format($acum, '2'),
					'tcolor'		=> $color,
					'accion'		=> $editar,
					'pdf'			=> $linkeo
				);
			}
			//$data['inicial']	=	number_format($inicial, '2');		
			//$data['inicialf']	=	number_format($inicial, '2');		
			$periodo = $acum - $inicial;
			$data['periodo']	=	number_format($periodo, '2');	;
			$data['saldo']		=	number_format($acum, '2');	
			if ($acum<0){	$color="red"; }else{	$color="green";	}
			$data['tsaldo']		=	$color;
			if ($inicial<0){	$color="red"; }else{	$color="green";	}
			$data['tinicial']	=	$color;
			if ($periodo<0){	$color="red"; }else{	$color="green";	}
			$data['tperiodo']	=	$color;
		/*	
			echo "<pre>";
			print_r($data['estados0']);
			echo "</pre>";
*/
			//echo $order;
			//if ($sort=='date_added'){
			//	arsort($data['estados0']);
			//}
/*			
			echo "<pre>";
			print_r($data['estados0']);
			echo "</pre>";
		*/	
			foreach ($data['estados0'] as $result) {
				$data['estados'][] = array(
					'order_id'			=> $result['order_id'],
					'invoice_prefix' => $result['invoice_prefix'],
					'contab_id'   	=> $result['contab_id'],
					'letra' 		=>  $result['letra'],
					'afip'      	 => $result['afip'],
					'd_comprob' 	=> $result['d_comprob'],
					'numero'    	 => $result['numero'],
					'serie'    	 	 => $result['serie'],					
					'customer_id'   => $result['customer_id'],
					'relacion_id'   => $result['relacion_id'],
					'customer'      => $result['customer'],
					'comment'      	=> $result['comment'],
					'date_added'    => $result['date_added'],
					'total'         => $result['total'],
					'final'         => $result['final'],
					'acum'         	=> $result['acum'],
					'tcolor'		=> $result['tcolor'],
					'accion'		=> $result['accion'],
					'pdf'		=> $result['pdf']
				);
			}			
			
		}
		
		if ($accion =='1'){
			//PDF
			$archivo = "estado_cuenta.pdf";
			require('dirsis/fpdf.php');
			$pdf = new FPDF();
			$pdf->SetTitle("ESTADO DE CUENTA", true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			$pdf->Ln(5);
			$pdf->SetFont('Arial','',12);
			$pdf->Cell(2);
			$pdf->Cell(80,7,"Cuenta:".$filter_customer_id."-".$filter_customer,0,0,'L');
			$pdf->SetFont('Arial','',8);
			$pdf->Ln(8);
			$pdf->Cell(2);
			$pdf->Cell(17,7,"Fecha",0,0,'L');
			$pdf->Cell(20,7,"ID",0,0,'L');
			$pdf->Cell(20,7,"Operacion",0,0,'L');
			$pdf->Cell(10,7,"Id Vend",0,0,'L');
			$pdf->Cell(40,7,"Vendedor",0,0,'L');
			$pdf->Cell(20,7,"Origen",0,0,'L');
			$pdf->Cell(20,7,"Total",0,0,'R');
			$pdf->Cell(20,7,"Acum",0,0,'R');
			$pdf->Rect(10,10, 190, 20);
			$pdf->Ln();
			foreach ($data['estados'] as $result) {
				//$order=$result['order_id'];
				$pdf->Cell(2);
				$pdf->Cell(17,7,date("d/m/Y", strtotime($result['date_added'])),0,0,'L');
				$pdf->Cell(20,7,$result['contab_id']."(".$result['order_id'].")",0,0,'L');
				$pdf->Cell(20,7,$result['d_comprob'],0,0,'L');
				$pdf->Cell(10,7,$result['customer_id'],0,0,'L');
				$pdf->Cell(40,7,strip_tags(html_entity_decode($result['customer'], ENT_QUOTES, 'UTF-8')),0,0,'L');
				$pdf->Cell(20,7,$result['invoice_prefix'],0,0,'L');
				$pdf->Cell(20,7,$result['final'],0,0,'R');
				$pdf->Cell(20,7,$result['acum'],0,0,'R');
				$pdf->Ln();
			}
			//$pdf->Output($archivo,'F');
			$pdf->Output($archivo,'F');
			echo "estado_cuenta.pdf";
			//FIN PDF
		}else{
			//XLSX
			$archivo = "estado_".uniqid().".xlsx";
			require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
			$objPHPExcel = new PHPExcel();
			$objPHPExcel->
			getProperties()
						->setCreator("dirsis.com.ar")
						->setLastModifiedBy("dirsis.com.ar")
						->setTitle("Exportar XLSX")
						->setSubject("Excel")
						->setCategory("reportes");
			/* Datos Hojas */
			$row=2;
			/*
			ME MUESTRA FECHA, CAMPAÑA, NRO DE FACTURA, DESCRIPCION DEL MOVIMIENTO (SI ES PAGO, DEVOLUCION, FACTURA, ETC), EL ID DEL VENDEDOR, EL NOMBRE DEL VENDEDOR, ESPECIFICA SI ES FACTURA DE NUVE, MARTINA O VITNIK Y MUESTRA AMBOS SALDOS, EL DE LA FACTURA Y YA CON LA COMISION DE LA LIDER DESCONTADA
			*/	
			$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A'.$row, 'Fecha')
							->setCellValue('B'.$row, 'Campaña')
							->setCellValue('C'.$row, 'ID')
							->setCellValue('D'.$row, 'Operacion')
							->setCellValue('E'.$row, 'ID Vend')
							->setCellValue('F'.$row, 'Vendedor')
							->setCellValue('G'.$row, 'Origen')
							->setCellValue('H'.$row, 'Total')
							->setCellValue('I'.$row, 'Acumulado');
			$row++;
			foreach ($data['estados'] as $result) {
				$objPHPExcel->setActiveSheetIndex(0)
						->setCellValue('A'.$row,  date("d/m/Y", strtotime($result['date_added'])))
						->setCellValue('B'.$row,  $result['invoice_prefix'])
						->setCellValue('C'.$row,  $result['contab_id'])
						->setCellValue('D'.$row,  $result['d_comprob'])
						->setCellValue('E'.$row,  $result['customer_id'])
						->setCellValue('F'.$row,  strip_tags(html_entity_decode($result['customer'], ENT_QUOTES, 'UTF-8')))
						->setCellValue('G'.$row,  $result['comment'])
						->setCellValue('H'.$row,  $result['final'])	
						->setCellValue('I'.$row,  $result['acum']);	

				$row++;
			}

			foreach(range('A','F') as $columnID) {
				$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
			}

			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			$objWriter->save($archivo, __FILE__);
			//$this->response->setOutput($archivo);
			echo $archivo;	
		}
		
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'admdirsis/estado')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	public function delete() {
		$this->load->language('admdirsis/estado');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/estado');
		

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			
			foreach ($this->request->post['selected'] as $contab_id) {
				$this->model_admdirsis_estado->deleteEstado($contab_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['filter_customer_id'])) {
				$url .= '&filter_customer_id=' . urlencode(html_entity_decode($this->request->get['filter_customer_id'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}	
			if (isset($this->request->get['filter_date_end'])) {
				$url .= '&filter_date_end=' . $this->request->get['filter_date_end'];
			}			
			if (isset($this->request->get['filter_date_begin'])) {
				$url .= '&filter_date_begin=' . $this->request->get['filter_date_begin'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}			

			$this->response->redirect($this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	public function invoice() {
		$this->load->language('admdirsis/estado');
		$data['title'] = $this->language->get('text_estado');
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}
		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');
		$this->load->model('setting/setting');
		$store_info = $this->model_setting_setting->getSetting('config', '0');
		if ($store_info) {
			$store_name = $store_info['config_meta_title'];
			$store_image = $store_info['config_image'];
			$store_address = $store_info['config_address'];
			$store_email = $store_info['config_email'];
			$store_telephone = $store_info['config_telephone'];
			$store_fax = $store_info['config_fax'];
		} else {
			$store_name = $store_info['config_meta_title'];
			$store_image = $store_info['config_image'];
			$store_address = $this->config->get('config_address');
			$store_email = $this->config->get('config_email');
			$store_telephone = $this->config->get('config_telephone');
			$store_fax = $this->config->get('config_fax');
		}
		
		$data['store_name']       = $store_name;
		$data['store_image']      = $store_image;
		$data['store_address']    = nl2br($store_address);
		$data['store_email']      = $store_email;
		$data['store_telephone']  = $store_telephone;
		$data['store_fax']        = $store_fax;
	
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}		
		if (isset($this->request->get['filter_date_begin'])) {
			$filter_date_begin = date("Y-m-d", strtotime($this->request->get['filter_date_begin']));
		} else {
			$filter_date_begin = '';
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = date("Y-m-d", strtotime($this->request->get['filter_date_end']));
		} else {
			$filter_date_end = date('Y-m-d');
		}				
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$data['date_begin']  = date("d/m/Y", strtotime($filter_date_begin));
		$data['date_end']    = date("d/m/Y", strtotime($filter_date_end));
		$url = '';
		$data['estados'] = array();
		$filter_data = array(
			'filter_customer_id'	 => $filter_customer_id,
			'filter_date_begin'      => $filter_date_begin,
			'filter_date_end'      	 => $filter_date_end,
			'filter_status'			 => $filter_status,
			'sort'                   => $sort,
			'order'                  => 'ASC',
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);
		
		$this->load->model('admdirsis/estado');
		//$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
		
		
		$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
		$inicial = $this->model_admdirsis_estado->getEstadosaldoinicial($filter_data);
		

		//$results = $this->model_admdirsis_estado->getEstado($filter_data);
		
		$this->load->model('customer/customer');
		$customer = $this->model_customer_customer->getCustomer($filter_customer_id);
		
		//print_r($customer);
		//die;
		
		if ($customer) {
			$data['customer_id']=$customer['customer_id'];
			$data['customer_firstname']=$customer['firstname'];
			$data['customer_lastname']=$customer['lastname'];
			$data['customer_email']=$customer['email'];  
			$data['customer_telephone']=$customer['telephone']; 
			if ($customer['sistema']=='1'){
				$data['customer_sistema']='Activo'; 
			}else{
				$data['customer_sistema']='No'; 
			}
			$data['customer_abono']=$customer['abono'];  
			$data['customer_hosting']=$customer['hosting'];  
			$data['customer_dominio']=$customer['dominio'];  
			$results = $this->model_admdirsis_estado->getEstado($filter_data);
			$acum=$inicial;
			foreach ($results as $result) {
			$acum=$acum+$result['final'];
			if ($result['final']<0){ $color="red";	}else{	$color="green";	}
			$verurl="&contab_id".$result['contab_id']."&filter_customer_id=".$result['customer_id']."&filter_customer=".$result['customer'];
			
			$ok=0;
			if (empty($filter_date_begin)){
				$ok=1;
			}else{
				
				$fecha=date("Y/m/d", strtotime($result['date_added']));
				$filter=date("Y/m/d", strtotime($filter_date_begin));
					
				if ($fecha>=$filter) {
					$ok=1;
				}
			}
			/*
			echo $filter;
			echo "<hr>";
			echo $fecha;
			echo "<hr>";
			*/	
			
			if ($ok==1){
				//if ($result['d_comprob']=='COBRANZA'){
					$verurl="&contab_id=".$result['contab_id'];
					$accion=$this->url->link('admdirsis/debcre', 'user_token=' . $this->session->data['user_token'] . $verurl, true);
				//}else{
				//	$accion="";
				//}
				$link='';
				if ($result['numero']!=0){
					$link=HTTPS_CATALOG."index.php?route=account/invoice&contab_id=".$result['contab_id'];
				}
				$data['estados'][] = array(
					'contab_id'   	=> $result['contab_id'],
					'link'			=> $link,
					'd_comprob' 	=> $result['d_comprob'],
					'customer_id'   => $result['customer_id'],
					'customer'      => $result['customer'],
					'comment'      	=> $result['comment'],
					'date_added'    => date("d/m/Y", strtotime($result['date_added'])),
					'total'         => number_format($result['total'], '2'),
					'final'         => number_format($result['final'], '2'),
					'acum'         	=> number_format($acum, '2'),
					'tcolor'		=> $color,
					'accion'		=> $accion,
				);
			}else{
				//$inicial=$inicial+$result['final'];
			}
			
		}
			$data['inicial']	=	$inicial;
			$data['inicialf']	=	number_format($inicial, '2');		
			$periodo = $acum;
			$data['periodo']	=	$periodo;
			$data['saldo']		=	$acum;
			if ($acum<0){	$color="red"; }else{	$color="green";	}
			$data['tsaldo']		=	$color;
			if ($inicial<0){	$color="red"; }else{	$color="green";	}
			$data['tinicial']	=	$color;
			if ($periodo<0){	$color="red"; }else{	$color="green";	}
			$data['tperiodo']	=	$color;
			$data['user_token'] = $this->session->data['user_token'];
			$url = '';
			$this->load->model('user/user');
			$user_info = $this->model_user_user->getUser($this->user->getId());
			if ($user_info) {
				$data['firstname'] = $user_info['firstname'];
				$data['lastname'] = $user_info['lastname'];
				$data['username']  = $user_info['username'];
				$data['user_group'] = $user_info['user_group'];		
				$data['user_group_id'] = $user_info['user_group_id'];	
				$data['user_group_nivel'] = $user_info['user_group_nivel'];
			}
			
			if ($this->config->get( 'payment_mp_standard_client_id' )){
				if ($acum>0){
					$data['mercadopago']=HTTPS_CATALOG.'index.php?route=extension/payment/dirsismp&order_id=9&total='.$acum;
				}
			}
			//print_r($this->load->view('admdirsis/estado_invoice', $data));
			//die;
			//$result=$this->load->view('admdirsis/estado_invoice', $data);

			$data['config_mail_pie1'] = html_entity_decode($this->config->get('config_mail_pie1'));
			$data['config_mail_pie2'] = html_entity_decode($this->config->get('config_mail_pie2'));
			if ($this->request->get['filter_enviarcorreo']=='1') {
				$correo=$data['customer_email'];
				$porciones = explode(",", $correo);

				$text_subject="Resumen de Cuenta";
				require("../class.phpmailer.php");
				require("../class.smtp.php");

				$mail1 = new PHPMailer();
				$mail1->IsSMTP();
				$mail1->SMTPAuth = true;
				$mail1->Port = $this->config->get('config_mail_smtp_port'); 
				if ($this->config->get('config_mail_smtp_port')!='25'){
					$mail1->SMTPSecure = 'ssl';
				}
				$mail1->IsHTML(true); 
				$mail1->CharSet = "utf-8";
				$mail1->Host = $this->config->get('config_mail_smtp_hostname');
				$mail1->Username = $this->config->get('config_mail_smtp_username'); 
				$mail1->Password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
				$mail1->From = $this->config->get('config_email');
				$mail1->FromName = html_entity_decode($this->config->get('config_meta_title'), ENT_QUOTES, 'UTF-8');
				$envios=0;
				foreach ($porciones as $mail){
					if (!empty($mail)){
						$mail1->AddAddress($mail); 	
						$envios++;
					}
				}		
				
				if ($this->config->get('config_mail_seguridad')){
					$mail1->AddAddress($this->config->get('config_mail_seguridad'));
				}				

				$mail1->Subject = sprintf($text_subject, html_entity_decode($this->config->get('config_meta_title'), ENT_QUOTES, 'UTF-8'));
				$mensajeHtml = $this->load->view('admdirsis/estado_invoice', $data);
				$mail1->Body = "{$mensajeHtml} <br />"; 
				//$mail->AltBody = "{$mensaje} \n\n"; // Texto sin formato HTML
				if ($envios>0){
					$estadoEnvio = $mail1->Send();			
					if ($estadoEnvio){
						
						$this->model_customer_customer->editMailingestado($customer['customer_id']);
						
						echo "Envio Exito! (".$correo.")";
					}else{
						echo "ERROR Envio! (".$correo.")";
					}
				}else{
					echo "ERROR Sin Correo! (".$data['customer_firstname'].",".$data['customer_lastname'].")<br>";	
				}
			}else{
				$this->response->setOutput($this->load->view('admdirsis/estado_invoice', $data));
			}
		}
		
	}
	
	public function wsp() {
		$this->load->language('admdirsis/estado');
		$data['title'] = $this->language->get('text_estado');
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}
		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');
		$this->load->model('setting/setting');
		$store_info = $this->model_setting_setting->getSetting('config', '0');
		if ($store_info) {
			$store_name = $store_info['config_meta_title'];
			$store_image = $store_info['config_image'];
			$store_address = $store_info['config_address'];
			$store_email = $store_info['config_email'];
			$store_telephone = $store_info['config_telephone'];
			$store_fax = $store_info['config_fax'];
		} else {
			$store_name = $store_info['config_meta_title'];
			$store_image = $store_info['config_image'];
			$store_address = $this->config->get('config_address');
			$store_email = $this->config->get('config_email');
			$store_telephone = $this->config->get('config_telephone');
			$store_fax = $this->config->get('config_fax');
		}
		
		$data['store_name']       = $store_name;
		$data['store_image']      = $store_image;
		$data['store_address']    = nl2br($store_address);
		$data['store_email']      = $store_email;
		$data['store_telephone']  = $store_telephone;
		$data['store_fax']        = $store_fax;
	
		if (isset($this->request->get['filter_customer_id'])) {
			$filter_customer_id = $this->request->get['filter_customer_id'];
		} else {
			$filter_customer_id = '';
		}
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '';
		}		
		if (isset($this->request->get['filter_date_begin'])) {
			$filter_date_begin = date("Y-m-d", strtotime($this->request->get['filter_date_begin']));
		} else {
			$filter_date_begin = '';
		}		
		if (isset($this->request->get['filter_date_end'])) {
			$filter_date_end = date("Y-m-d", strtotime($this->request->get['filter_date_end']));
		} else {
			$filter_date_end = date('Y-m-d');
		}				
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'date_added';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$data['date_begin']  = date("d/m/Y", strtotime($filter_date_begin));
		$data['date_end']    = date("d/m/Y", strtotime($filter_date_end));
		$url = '';
		$data['estados'] = array();
		$filter_data = array(
			'filter_customer_id'	 => $filter_customer_id,
			'filter_date_begin'      => $filter_date_begin,
			'filter_date_end'      	 => $filter_date_end,
			'filter_status'			 => $filter_status,
			'sort'                   => $sort,
			'order'                  => 'ASC',
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);
		
		$this->load->model('admdirsis/estado');
		//$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
		
		
		$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
		$inicial = $this->model_admdirsis_estado->getEstadosaldoinicial($filter_data);
		

		//$results = $this->model_admdirsis_estado->getEstado($filter_data);
		
		$this->load->model('customer/customer');
		$customer = $this->model_customer_customer->getCustomer($filter_customer_id);
		
		//print_r($customer);
		//die;
		
		if ($customer) {
			$results = $this->model_admdirsis_estado->getEstado($filter_data);
			$acum=$inicial;
			foreach ($results as $result) {
				$acum=$acum+$result['final'];
			}
			if ($acum>0){
				$filter_data = array(
					'id' => $customer['customer_id'],
					'name' => $customer['firstname']." ".$customer['lastname'],
					'email' => $customer['email'],
					'tele' => $customer['telephone'],
					'saldo' => $acum
				); 
				$envios = $this->model_admdirsis_estado->getWSP($filter_data);
				if ($envios==true){
					echo "Envio WSP Exitoso (".$customer['telephone'].")";
				}else{
					echo "Fallo Envio WSP (".$customer['telephone'].")";
				}
			}
		}
	}
	
	public function _data_first_month_day() {
      $month = date('m');
      $year = date('Y');
      return date('d-m-Y', mktime(0,0,0, $month, 1, $year));
	}

	public function invoicefact() {
		$envios=0;
		if (isset($this->request->get['filter_contab_id'])) {
			$data = array();
			$filter_contab_id = $this->request->get['filter_contab_id'];
			$this->load->language('admdirsis/estado');
			$data['title'] = $this->language->get('text_estado');
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER;
			} else {
				$data['base'] = HTTP_SERVER;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');
			$this->load->model('setting/setting');
			$store_info = $this->model_setting_setting->getSetting('config', '0');
			if ($store_info) {
				$store_name = $store_info['config_name'];
				$store_image = $store_info['config_image'];
				$store_address = $store_info['config_address'];
				$store_email = $store_info['config_email'];
				$store_telephone = $store_info['config_telephone'];
				$store_fax = $store_info['config_fax'];
			} else {
				$store_name = $store_info['config_name'];
				$store_image = $store_info['config_image'];
				$store_address = $this->config->get('config_address');
				$store_email = $this->config->get('config_email');
				$store_telephone = $this->config->get('config_telephone');
				$store_fax = $this->config->get('config_fax');
			}
		
			$data['store_name']       = $store_name;
			$data['store_image']      = $store_image;
			$data['store_address']    = nl2br($store_address);
			$data['store_email']      = $store_email;
			$data['store_telephone']  = $store_telephone;
			$data['store_fax']        = $store_fax;
	
			$this->load->model('admdirsis/contab');
			$result = $this->model_admdirsis_contab->getContab($filter_contab_id);

			$link="";
			if ($result['numero']!=0){
				$link=HTTPS_CATALOG."index.php?route=account/invoice&contab_id=".$result['contab_id'];
			}
			$data['link']			=$link;
			$data['d_comprob']		=$result['d_comprob'];
			$data['serie']			=$result['serie'];
			$data['numero'] 		=$result['numero'];
			$data['customer_email']	=$result['email'];
			$data['customer']      	=$result['firstname'].",".$result['lastname'];
			$data['comment']       	=$result['comment'];
			$data['date_added']    	=date("d/m/Y", strtotime($result['date_added']));
			$data['total']         	=number_format($result['total'], '2');
			
 
			
			$result=$this->load->view('admdirsis/estado_invoicefact', $data);

			if (isset($this->request->get['filter_enviarcorreo'])) {
				$text_subject="Su Factura ya esta disponible";
				$correo=$data['customer_email'];
				$porciones = explode(",", $correo);
				
				
				require("../class.phpmailer.php");
				require("../class.smtp.php");
				
				$mail1 = new PHPMailer();
				$mail1->IsSMTP();
				$mail1->SMTPAuth = true;
				$mail1->Port = $this->config->get('config_mail_smtp_port'); 
				if ($this->config->get('config_mail_smtp_port')!='25'){
					$mail1->SMTPSecure = 'ssl';
				}
				$mail1->IsHTML(true); 
				$mail1->CharSet = "utf-8";
				$mail1->Host = $this->config->get('config_mail_smtp_hostname');
				$mail1->Username = $this->config->get('config_mail_smtp_username'); 
				$mail1->Password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
				$mail1->From = $this->config->get('config_email');
				$mail1->FromName = html_entity_decode($this->config->get('config_meta_title'), ENT_QUOTES, 'UTF-8');
				//html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');
				
				foreach ($porciones as $mail){
					if (!empty($mail)){
						$mail1->AddAddress($mail); 	
						$envios++;
					}
				}	

				if ($this->config->get('config_mail_seguridad')){
					$mail1->AddAddress($this->config->get('config_mail_seguridad'));
				}				

				
				$mail1->Subject = sprintf($text_subject, html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'));
				$mensajeHtml = nl2br($this->load->view('admdirsis/estado_invoicefact', $data));
				$mensajeHtml = $this->load->view('admdirsis/estado_invoicefact', $data);
				$mail1->Body = "{$mensajeHtml} <br />"; 
				//$mail->AltBody = "{$mensaje} \n\n"; // Texto sin formato HTML
				$estadoEnvio = $mail1->Send();	
								
				$this->model_admdirsis_contab->editMailing($filter_contab_id);
			}
		}
		echo $envios;
	}
	
	
	
	public function pdf() {
		$archivo="";
		if ($this->request->get['filter_customer_id']!=0){

			$i=$A2=1;
			$this->load->model('admdirsis/estado');

			if (isset($this->request->get['filter_customer_id'])) {
				$filter_customer_id = $this->request->get['filter_customer_id'];
			} else {
				$filter_customer_id = '';
			}
			if (isset($this->request->get['filter_customer'])) {
				$filter_customer = $this->request->get['filter_customer'];
			} else {
				$filter_customer = '';
			}		
			if (isset($this->request->get['filter_status'])) {
				$filter_status = $this->request->get['filter_status'];
			} else {
				$filter_status = '';
			}		
			if (isset($this->request->get['filter_date_begin'])) {
				$filter_date_begin = $this->request->get['filter_date_begin'];
			} else {
				$filter_date_begin = date('01-m-Y');
			}		
			if (isset($this->request->get['filter_date_end'])) {
				$filter_date_end = $this->request->get['filter_date_end'];
			} else {
				$filter_date_end = date('d-m-Y');
			}				
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'date_added';
			}
			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'ASC';
			}		
		

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}


			$data['estados'] = array();

			$this->load->model('customer/customer');
				$customer = $this->model_customer_customer->getCustomer($filter_customer_id);
			$filter_customer=$customer['name'];
			$subs=array();
			$subs[] = array(
				'customer_id'   	=> $filter_customer_id
			);
			$subagentes = $this->model_customer_customer->getSubagentes($filter_customer_id);
			foreach ($subagentes as $subagente) {	
				$subs[] = array(
					'customer_id'   	=> $subagente['customer_id']
				);
				$subagentes2 = $this->model_customer_customer->getSubagentes($subagente['customer_id']);
				foreach ($subagentes2 as $subagente2) {	
					$subs[] = array(
						'customer_id'   	=> $subagente2['customer_id']
					);
					$subagentes3 = $this->model_customer_customer->getSubagentes($subagente2['customer_id']);
					foreach ($subagentes3 as $subagente3) {	
						$subs[] = array(
							'customer_id'   	=> $subagente3['customer_id']
						);
					}
				}
			}
		
			$filter_data = array(
				'filter_customer_id'	 => $filter_customer_id,
				'filter_saldo'			 => '1',
				'filter_subs'	 		 => $subs,
				'filter_customer'	     => $filter_customer,
				'filter_date_begin'      => date("Y-m-d",strtotime($filter_date_begin)),
				'filter_date_end'      	 => date("Y-m-d",strtotime($filter_date_end)),
				'filter_status'			 => $filter_status,
				'sort'                   => $sort,
				'order'                  => $order,
				'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
				'limit'                  => $this->config->get('config_limit_admin')
			);
			$estado_total=0;
			$data['estados']=array();
		
			$this->load->model('admdirsis/saldo');
			$saldos = $this->model_admdirsis_saldo->getSaldo($filter_data);
			if ($saldos){
				foreach ($saldos as $saldo) {
					$data['mailing_estado']=date("d-m-Y",strtotime($saldo['mailing_estado']));
					$data['customer']=$saldo['customer'];
					break;
				}
			}
			$estado_total = $this->model_admdirsis_estado->getTotalEstado($filter_data);
			$inicial = $this->model_admdirsis_estado->getEstadosaldoinicial($filter_data);
			$acum=$inicial;
			$orden=0;
			
			$results = $this->model_admdirsis_estado->getEstado($filter_data);
			$store_codiva_id = $this->config->get('config_factura_codiva_id');
			foreach ($results as $result) {
				$orden++;
				$acum=$acum+$result['final'];
				if ($result['final']<0){ 
					$color="red";
					$relacion_id=-1;
				}else{	
					$color="green";	
					$relacion_id=$result['relacion_id'];
				}
				$verurl="&contab_id=".$result['contab_id']."&filter_customer_id=".$result['customer_id']."&filter_customer=".$result['customer'];
				$editar=$this->url->link('admdirsis/contab/add', 'user_token=' . $this->session->data['user_token'] . $verurl, true);
				
				$letra="";
				if (!empty($result['cae'])){
					if ($store_codiva_id == 1){
						if ( $result['codiva_id'] == 1) $letra="A";
						if ( $result['codiva_id'] == 2) $letra="A";
						if ( $result['codiva_id'] == 3) $letra="B";
						if ( $result['codiva_id'] == 4) $letra="B";
						if ( $result['codiva_id'] == 5) $letra="B";
					}else{
						$letra="C";
					}
				}				
				
				$data['estados0'][] = array(
					'orden' => $orden,
					'date_added'    	=> date("d/m/Y", strtotime($result['date_added'])),
					'contab_id'   		=> $result['contab_id'],
					'order_id'   	=> $result['order_id'],
					'd_comprob' 		=> $result['d_comprob'],
					'letra'    	 		=> $letra,
					'afip'      	 	=> $result['afip'],
					'numero'    	 	=> $result['numero'],
					'serie'    	 	 	=> $result['serie'],					
					'customer_id'   	=> $result['customer_id'],
					'relacion_id'   	=> $relacion_id,
					'customer'      	=> $result['customer'],
					'comment'      		=> $result['comment'],
					'invoice_prefix' 	=> $result['invoice_prefix'],
					'total'         => number_format($result['total'], '2'),
					'debe'         => $result['final']>0?number_format($result['final'], '2'):'',
					'haber'         => $result['final']>0?'':number_format($result['final']*-1, '2'),
					'acum'         	=> number_format($acum, '2')
				);
			}
			//$data['inicial']	=	number_format($inicial, '2');		
			//$data['inicialf']	=	number_format($inicial, '2');		
			$periodo = $acum - $inicial;
			$periodo	=	number_format($periodo, '2');	;
			$saldo		=	number_format($acum, '2');	
			$idebe=$ihaber="";
			if ($inicial>0){
				$ihaber=number_format($inicial, '2');	
			}else{
				$idebe=number_format($inicial*-1, '2');	
			}
			
			$ftitulo="CUENTA SIN DEUDA";
			$fdebe=$fhaber="";
			if ($acum>0){
				$ftitulo="SALDO A PENDIENTE DE PAGO";
				$fhaber=number_format($acum, '2');	
			}else{
				if ($acum<0){
					$ftitulo="SALDO A FAVOR";
					$fdebe=number_format($acum*-1, '2');	
				}
			}			
			/*
			if ($sort=='date_added'){
				arsort($data['estados0']);
			}

			foreach ($data['estados0'] as $result) {
				$data['estados'][] = array(
					'orden'			=> $result['orden'],
					'contab_id'   	=> $result['contab_id'],
					'order_id'   	=> $result['order_id'],
					'letra' =>  $result['letra'],
					'afip'      	 => $result['afip'],
					'd_comprob' 	=> $result['d_comprob'],
					'numero'    	 => $result['numero'],
					'serie'    	 	 => $result['serie'],					
					'customer_id'   => $result['customer_id'],
					'relacion_id'   => $result['relacion_id'],
					'customer'      => $result['customer'],
					'comment'      	=> $result['comment'],
					'invoice_prefix' 	=> $result['invoice_prefix'],
					'date_added'    => $result['date_added'],
					'total'         => $result['total'],
					'final'         => $result['final'],
					'acum'         	=> $result['acum'],
					'tcolor'		=> $result['tcolor'],
					'accion'		=> $result['accion'],
					'pdf'		=> $result['pdf']
				);
			}			
			*/
			$membrete = array(
					"p1" => 10,
					"p2" => 60,
					"p3" => 120,
					"p4" => 140,
					"p5" => 170,
					"titulo" => 'RESUMEN DE CUENTA',
					"norma" => 'FO-7.5-034',
					"version" => '01',
					"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
					"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
					"image" => $this->config->get('config_image'),
					"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
					"email" => $this->config->get('config_email'),
					"telephone" => $this->config->get('config_telephone'),
					"fax" => $this->config->get('config_fax'),
					"cuit" => $this->config->get('config_factura_cuit'),
					"iib" => $this->config->get('config_factura_iib'),
					"iniact" => $this->config->get('config_factura_iniact')
			);
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			require('dirsis/ean13.php');
			$pdf=new PDF_EAN13();
			$pdf->SetAutoPageBreak(true,2);			
			$pdf->SetTitle("Resumen de Cuenta", true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1'],13,50);
			$pdf->Rect($A2+$membrete['p1']-1,12,190,20);
			$pdf->Rect($A2+$membrete['p1']-1+53,12,83,20);
			$pdf->Rect($A2+$membrete['p5']+10,12,19,20);
//MEMBRETE
			//IZQ
			$yy=17;
			$pdf->SetY($yy);
			$pdf->SetFont('Arial','',10);
			$pdf->Cell($A2+$membrete['p2']-5);
			$pdf->Cell(100,0,$membrete['titulo'],0,0,'L');
			$pdf->Ln(4);
			$pdf->Cell($A2+$membrete['p2']-5);
			$pdf->Cell(100,0,"Desde ".$filter_date_begin,0,0,'L');
			//MEDIO
			$pdf->SetY($yy);
			$pdf->SetFont('Arial','',12);
			$pdf->Cell($A2+$membrete['p4']);
			$pdf->Cell(130,0,$membrete['norma'],0,0,'L');
			$pdf->Ln(7);
			$pdf->Cell($A2+$membrete['p4']);
			$pdf->Cell(130,0,"VERSION:".$membrete['version'],0,0,'L');
			//DERECHO
			$pdf->SetY($yy);
			$pdf->SetFont('Arial','',12);
			$pdf->Cell($A2+$membrete['p5']);
			$pdf->Cell(110,0,'Hoja N:'.$i,0,0,'L');
			$yy=$yy+20;
			$pdf->SetY($yy);
			//DATOS CODIGO		
			$pdf->SetFont('Arial','',9);
			$datoscab = array();
			$datoscab[] = array("xt" => 40,"titulo" => "Codigo:");
			$datoscab[] = array("xt" => 40,"titulo" => $customer['customer_id']);
			$datoscab[] = array("xt" => 40,"titulo" => "Designacion");
			$datoscab[] = array("xt" => 190-(40*3),"titulo" => $customer['firstname'].",".$customer['lastname']);
			$pdf->Cell($A2);
			foreach ($datoscab as $dato) {
				$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
			}	
			$pdf->Ln();
			$pdf->Ln();
			$pdf->SetFont('Arial','',9);
			//TITULOS GRILLA
			$datoscab = array();
			$datoscab[] = array("xt" => 25,"titulo" => "Fecha");
			$datoscab[] = array("xt" => 40,"titulo" => "Numero");
			$datoscab[] = array("xt" => 190-(30+30+40+25),"titulo" => "Descripcion");
			$datoscab[] = array("xt" => 30,"titulo" => "Debe");
			$datoscab[] = array("xt" => 30,"titulo" => "Haber");
			$pdf->Cell($A2);
			foreach ($datoscab as $dato) {
				$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
			}		
			$pdf->Ln();
			
			//SALDO ANTERIORI
				$datoscab = array();
				$datoscab[] = array("xt" => 25,"titulo" => '');
				$datoscab[] = array("xt" => 40,"titulo" => '');
				$datoscab[] = array("xt" => 190-(30+30+40+25),"titulo" => 'SALDO ANTERIOR');
				$datoscab[] = array("xt" => 30,"titulo" => $idebe);
				$datoscab[] = array("xt" => 30,"titulo" => $ihaber);
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				$pdf->Ln();
			//RESUMEN
			foreach ($data['estados0'] as $result) {
				$datoscab = array();
				$datoscab[] = array("xt" => 25,"titulo" => $result['date_added']);
				$datoscab[] = array("xt" => 40,"titulo" => $result['d_comprob'].$result['contab_id']);
				$datoscab[] = array("xt" => 190-(30+30+40+25),"titulo" => $result['comment']);
				$datoscab[] = array("xt" => 30,"titulo" => $result['debe']);
				$datoscab[] = array("xt" => 30,"titulo" => $result['haber']);
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				$pdf->Ln();
			}
			$pdf->Ln();
			$pdf->SetFont('Arial','',10);
			//SALDO FINAL
				$datoscab = array();
				$datoscab[] = array("xt" => 25,"titulo" => '');
				$datoscab[] = array("xt" => 35,"titulo" => '');
				$datoscab[] = array("xt" => 190-(30*4),"titulo" => $ftitulo);
				$datoscab[] = array("xt" => 30,"titulo" => $fdebe);
				$datoscab[] = array("xt" => 30,"titulo" => $fhaber);
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				$pdf->Ln();			
			//PIE
			$archivo="LT".uniqid().".pdf";
			if (file_exists($archivo)){
				unlink($archivo);
			}
			//$pdf->Output($archivo,'F');
			$pdf->Output($archivo,'F');	
		}
		echo $archivo;
	}

}
