<?php
class ControllerAdmdirsisFactura extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/factura');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/factura');

		
		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/factura');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/factura');

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/factura');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/factura');

		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('admdirsis/factura');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->session->data['success'] = $this->language->get('text_success');

		$url = '';

		if (isset($this->request->get['filter_factura_id'])) {
			$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
		}		
		
		if (isset($this->request->get['filter_invoice_prefix'])) {
			$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
		}
	
		if (isset($this->request->get['filter_factura_status_id'])) {
			$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$this->response->redirect($this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
			
	protected function getList() {
		if (isset($this->request->get['filter_factura_id'])) {
			$filter_factura_id = $this->request->get['filter_factura_id'];
		} else {
			$filter_factura_id = '';
		}
		
		if (isset($this->request->get['filter_invoice_prefix'])) {
			$filter_invoice_prefix = $this->request->get['filter_invoice_prefix'];
		} else {
			$filter_invoice_prefix = '';
		}
		
		
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = '';
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$filter_factura_status = $this->request->get['filter_factura_status'];
		} else {
			$filter_factura_status = '';
		}
		
		if (isset($this->request->get['filter_factura_status_id'])) {
			$filter_factura_status_id = $this->request->get['filter_factura_status_id'];
		} else {
			$filter_factura_status_id = '';
		}
		
		if (isset($this->request->get['filter_total'])) {
			$filter_total = $this->request->get['filter_total'];
		} else {
			$filter_total = '';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$filter_date_modified = $this->request->get['filter_date_modified'];
		} else {
			$filter_date_modified = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.factura_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_factura_id'])) {
			$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
		}
		
		if (isset($this->request->get['filter_invoice_prefix'])) {
			$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
		}		

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
		}
	
		if (isset($this->request->get['filter_factura_status_id'])) {
			$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['invoice'] = $this->url->link('admdirsis/factura/invoice', 'user_token=' . $this->session->data['user_token'], true);
		$data['shipping'] = $this->url->link('admdirsis/factura/shipping', 'user_token=' . $this->session->data['user_token'], true);
		$data['add'] = $this->url->link('admdirsis/factura/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = str_replace('&amp;', '&', $this->url->link('admdirsis/factura/delete', 'user_token=' . $this->session->data['user_token'] . $url, true));

		$data['facturas'] = array();

		$filter_data = array(
			'filter_factura_id'        => $filter_factura_id,
			'filter_invoice_prefix'  => $filter_invoice_prefix,
			'filter_customer'	     => $filter_customer,
			'filter_factura_status'    => $filter_factura_status,
			'filter_factura_status_id' => $filter_factura_status_id,
			'filter_total'           => $filter_total,
			'filter_date_added'      => $filter_date_added,
			'filter_date_modified'   => $filter_date_modified,
			'sort'                   => $sort,
			'order'                  => $order,
			'start'                  => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                  => $this->config->get('config_limit_admin')
		);

		$factura_total = $this->model_admdirsis_factura->getTotalFacturas($filter_data);

		$results = $this->model_admdirsis_factura->getFacturas($filter_data);

		foreach ($results as $result) {
			
			
			$color='#fff';
			$tcolor='#000';			
			if (strpos($result['invoice_prefix'], 'ML') !== false) {
				$color='#FFE600';
				$tcolor='#000';
			}
			if (strpos($result['invoice_prefix'], 'MG') !== false) {
				$color='#ffa400';
				$tcolor='#000';
			}
			if (strpos($result['invoice_prefix'], 'OC') !== false) {
				$color='#0080c3';
				$tcolor='#fff';
			}			
			if (strpos($result['invoice_prefix'], 'PS') !== false) {
				$color='#ff0076';
				$tcolor='#fff';
			}			
			
			$itemsvendidos = "";
			$results2 = $this->model_admdirsis_factura->getFacturaProducts($result['factura_id']);
			foreach ($results2 as $result2) {
				$itemsvendidos.=$result2['model']."|".$result2['quantity']."<br>";
			}
			
			
			$data['facturas'][] = array(
				'itemsvendidos' => $itemsvendidos,
				'factura_id'      => $result['factura_id'],
				'color'			=> $color,
				'tcolor'		=> $tcolor,
				'invoice_prefix'  => $result['invoice_prefix'],
				'customer'      => $result['customer'],
				'factura_status'  => $result['factura_status'] ? $result['factura_status'] : $this->language->get('text_missing'),
				'total'         => $this->currency->format($result['total'], $result['currency_code'], $result['currency_value']),
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'date_modified' => date($this->language->get('date_format_short'), strtotime($result['date_modified'])),
				'shipping_code' => $result['shipping_code'],
				'view'          => $this->url->link('admdirsis/factura/info', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . $result['factura_id'] . $url, true),
				'edit'          => $this->url->link('admdirsis/factura/edit', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . $result['factura_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_factura_id'])) {
			$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
		}		

		if (isset($this->request->get['filter_invoice_prefix'])) {
			$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
		}
		
		if (isset($this->request->get['filter_factura_status_id'])) {
			$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];

		$data['sort_order'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=o.factura_id' . $url, true);
		
		$data['sort_invoice_prefix'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=o.invoice_prefix' . $url, true);
		
		$data['sort_customer'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=customer' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=factura_status' . $url, true);
		$data['sort_total'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=o.total' . $url, true);
		$data['sort_date_added'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		$data['sort_date_modified'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_modified' . $url, true);
		}
	
		$url = '';

		if (isset($this->request->get['filter_factura_id'])) {
			$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
		}
		
		if (isset($this->request->get['filter_invoice_prefix'])) {
			$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
		}

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
		}
		
		if (isset($this->request->get['filter_factura_status_id'])) {
			$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $factura_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($factura_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($factura_total - $this->config->get('config_limit_admin'))) ? $factura_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $factura_total, ceil($factura_total / $this->config->get('config_limit_admin')));

		$data['filter_factura_id'] = $filter_factura_id;
		$data['filter_invoice_prefix'] = $filter_invoice_prefix;
		$data['filter_customer'] = $filter_customer;
		
		$data['filter_factura_status'] = $filter_factura_status;
		$data['filter_factura_status_id'] = $filter_factura_status_id;
		$data['filter_total'] = $filter_total;
		$data['filter_date_added'] = $filter_date_added;
		$data['filter_date_modified'] = $filter_date_modified;

		$data['sort'] = $sort;
		$data['order'] = $order;

		$this->load->model('localisation/factura_status');

		$data['factura_statuses'] = $this->model_localisation_factura_status->getFacturaStatuses();

		// API login
		$data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
		
		// API login
		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info && $this->user->hasPermission('modify', 'admdirsis/factura')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);
			
			$session->start();
					
			$this->model_user_api->deleteApiSessionBySessonId($session->getId());
			
			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
			
			$session->data['api_id'] = $api_info['api_id'];

			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/factura_list', $data));
	}
		
	public function getForm() {
		$data['text_form'] = !isset($this->request->get['factura_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$url = '';

		if (isset($this->request->get['filter_factura_id'])) {
			$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
		}
		if (isset($this->request->get['filter_invoice_prefix'])) {
			$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
		}		

		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_factura_status'])) {
			$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
		}
		
		if (isset($this->request->get['filter_factura_status_id'])) {
			$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
		}
			
		if (isset($this->request->get['filter_total'])) {
			$url .= '&filter_total=' . $this->request->get['filter_total'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['cancel'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['factura_id'])) {
			$factura_info = $this->model_admdirsis_factura->getFactura($this->request->get['factura_id']);
		}

		if (!empty($factura_info)) {
			$data['factura_id'] = $this->request->get['factura_id'];
			$data['store_id'] = $factura_info['store_id'];
			$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
			
//DIRSIS		
			$data['comprob_id'] = $factura_info['comprob_id'];
			$this->load->model('admdirsis/comprob');
			$data['comprobs'] = $this->model_admdirsis_comprob->getComprobs();

			$data['fpago_id'] = $factura_info['fpago_id'];
			$this->load->model('admdirsis/fpago');
			$data['fpagos'] = $this->model_admdirsis_fpago->getfpagos();
			
//DIRSIS						
			
			$data['customer'] = $factura_info['customer'];
			$data['customer_id'] = $factura_info['customer_id'];
			$data['customer_group_id'] = $factura_info['customer_group_id'];
			$data['firstname'] = $factura_info['firstname'];
			$data['lastname'] = $factura_info['lastname'];
			$data['email'] = $factura_info['email'];
			$data['telephone'] = $factura_info['telephone'];
			$data['account_custom_field'] = $factura_info['custom_field'];

			$this->load->model('customer/customer');

			$data['addresses'] = $this->model_customer_customer->getAddresses($factura_info['customer_id']);

			$data['payment_firstname'] = $factura_info['payment_firstname'];
			$data['payment_lastname'] = $factura_info['payment_lastname'];
			$data['payment_company'] = $factura_info['payment_company'];
			$data['payment_address_1'] = $factura_info['payment_address_1'];
			$data['payment_address_2'] = $factura_info['payment_address_2'];
			$data['payment_city'] = $factura_info['payment_city'];
			$data['payment_postcode'] = $factura_info['payment_postcode'];
			$data['payment_country_id'] = $factura_info['payment_country_id'];
			$data['payment_zone_id'] = $factura_info['payment_zone_id'];
			$data['payment_custom_field'] = $factura_info['payment_custom_field'];
			$data['payment_method'] = $factura_info['payment_method'];
			$data['payment_code'] = $factura_info['payment_code'];

			$data['shipping_firstname'] = $factura_info['shipping_firstname'];
			$data['shipping_lastname'] = $factura_info['shipping_lastname'];
			$data['shipping_company'] = $factura_info['shipping_company'];
			$data['shipping_address_1'] = $factura_info['shipping_address_1'];
			$data['shipping_address_2'] = $factura_info['shipping_address_2'];
			$data['shipping_city'] = $factura_info['shipping_city'];
			$data['shipping_postcode'] = $factura_info['shipping_postcode'];
			$data['shipping_country_id'] = $factura_info['shipping_country_id'];
			$data['shipping_zone_id'] = $factura_info['shipping_zone_id'];
			$data['shipping_custom_field'] = $factura_info['shipping_custom_field'];
			$data['shipping_method'] = $factura_info['shipping_method'];
			$data['shipping_code'] = $factura_info['shipping_code'];

			// Products
			$data['factura_products'] = array();

			$products = $this->model_admdirsis_factura->getFacturaProducts($this->request->get['factura_id']);

			foreach ($products as $product) {
				$data['factura_products'][] = array(
					'product_id' => $product['product_id'],
					'name'       => $product['name'],
					'model'      => $product['model'],
					'option'     => $this->model_admdirsis_factura->getFacturaOptions($this->request->get['factura_id'], $product['factura_product_id']),
					'quantity'   => $product['quantity'],
					'price'      => $product['price'],
					'total'      => $product['total'],
					'reward'     => $product['reward']
				);
			}

			// Vouchers
			$data['factura_vouchers'] = $this->model_admdirsis_factura->getFacturaVouchers($this->request->get['factura_id']);

			$data['coupon'] = '';
			$data['voucher'] = '';
			$data['reward'] = '';

			$data['factura_totals'] = array();

			$factura_totals = $this->model_admdirsis_factura->getFacturaTotals($this->request->get['factura_id']);

			foreach ($factura_totals as $factura_total) {
				// If coupon, voucher or reward points
				$start = strpos($factura_total['title'], '(') + 1;
				$end = strrpos($factura_total['title'], ')');

				if ($start && $end) {
					$data[$factura_total['code']] = substr($factura_total['title'], $start, $end - $start);
				}
			}

			$data['factura_status_id'] = $factura_info['factura_status_id'];
			$data['comment'] = $factura_info['comment'];
			$data['affiliate_id'] = $factura_info['affiliate_id'];
			$data['affiliate'] = $factura_info['affiliate_firstname'] . ' ' . $factura_info['affiliate_lastname'];
			$data['currency_code'] = $factura_info['currency_code'];
		} else {
			$data['factura_id'] = 0;
			$data['store_id'] = 0;
			$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
			
//DIRSIS		
			$this->load->model('setting/setting');
			$data['comprob_id'] = $this->config->get('config_factura_comprob_id');
			$this->load->model('admdirsis/comprob');
			$data['comprobs'] = $this->model_admdirsis_comprob->getComprobs();
			
			$data['fpago_id'] = $this->config->get('config_factura_fpago_id');
			$this->load->model('admdirsis/fpago');
			$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();			
			
//DIRSIS						
			
			$data['customer'] = '';
			$data['customer_id'] = '';
			$data['customer_group_id'] = $this->config->get('config_customer_group_id');
			$data['firstname'] = '';
			$data['lastname'] = '';
			$data['email'] = '';
			$data['telephone'] = '';
			$data['customer_custom_field'] = array();

			$data['addresses'] = array();

			$data['payment_firstname'] = '';
			$data['payment_lastname'] = '';
			$data['payment_company'] = '';
			$data['payment_address_1'] = '';
			$data['payment_address_2'] = '';
			$data['payment_city'] = '';
			$data['payment_postcode'] = '';
			$data['payment_country_id'] = '';
			$data['payment_zone_id'] = '';
			$data['payment_custom_field'] = array();
			$data['payment_method'] = '';
			$data['payment_code'] = '';

			$data['shipping_firstname'] = '';
			$data['shipping_lastname'] = '';
			$data['shipping_company'] = '';
			$data['shipping_address_1'] = '';
			$data['shipping_address_2'] = '';
			$data['shipping_city'] = '';
			$data['shipping_postcode'] = '';
			$data['shipping_country_id'] = '';
			$data['shipping_zone_id'] = '';
			$data['shipping_custom_field'] = array();
			$data['shipping_method'] = '';
			$data['shipping_code'] = '';

			$data['factura_products'] = array();
			$data['factura_vouchers'] = array();
			$data['factura_totals'] = array();

			$data['factura_status_id'] = $this->config->get('config_factura_status_id');
			$data['comment'] = '';
			$data['affiliate_id'] = '';
			$data['affiliate'] = '';
			$data['currency_code'] = $this->config->get('config_currency');

			$data['coupon'] = '';
			$data['voucher'] = '';
			$data['reward'] = '';
		}

		// Stores
		$this->load->model('setting/store');

		$data['stores'] = array();

		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default')
		);

		$results = $this->model_setting_store->getStores();

		foreach ($results as $result) {
			$data['stores'][] = array(
				'store_id' => $result['store_id'],
				'name'     => $result['name']
			);
		}

		// Customer Groups
		$this->load->model('customer/customer_group');

		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		// Custom Fields
		$this->load->model('customer/custom_field');

		$data['custom_fields'] = array();

		$filter_data = array(
			'sort'  => 'cf.sort_order',
			'order' => 'ASC'
		);

		$custom_fields = $this->model_customer_custom_field->getCustomFields($filter_data);

		foreach ($custom_fields as $custom_field) {
			$data['custom_fields'][] = array(
				'custom_field_id'    => $custom_field['custom_field_id'],
				'custom_field_value' => $this->model_customer_custom_field->getCustomFieldValues($custom_field['custom_field_id']),
				'name'               => $custom_field['name'],
				'value'              => $custom_field['value'],
				'type'               => $custom_field['type'],
				'location'           => $custom_field['location'],
				'sort_order'         => $custom_field['sort_order']
			);
		}

		$this->load->model('localisation/factura_status');

		$data['factura_statuses'] = $this->model_localisation_factura_status->getFacturaStatuses();

		$this->load->model('localisation/country');

		$data['countries'] = $this->model_localisation_country->getCountries();

		$this->load->model('localisation/currency');

		$data['currencies'] = $this->model_localisation_currency->getCurrencies();

		$data['voucher_min'] = $this->config->get('config_voucher_min');

		$this->load->model('sale/voucher_theme');

		$data['voucher_themes'] = $this->model_sale_voucher_theme->getVoucherThemes();

		// API login
		$data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
		
		// API login
		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info && $this->user->hasPermission('modify', 'admdirsis/factura')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);
			
			$session->start();
					
			$this->model_user_api->deleteApiSessionBySessonId($session->getId());
			
			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
			
			$session->data['api_id'] = $api_info['api_id'];

			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/factura_form', $data));
	}

	public function info() {
		$this->load->model('admdirsis/factura');

		if (isset($this->request->get['factura_id'])) {
			$factura_id = $this->request->get['factura_id'];
		} else {
			$factura_id = 0;
		}

		$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

		if ($factura_info) {
			$this->load->language('admdirsis/factura');

			$this->document->setTitle($this->language->get('heading_title'));

			$data['text_ip_add'] = sprintf($this->language->get('text_ip_add'), $this->request->server['REMOTE_ADDR']);
			$data['text_factura'] = sprintf($this->language->get('text_factura'), $this->request->get['factura_id']);

			$url = '';

			if (isset($this->request->get['filter_factura_id'])) {
				$url .= '&filter_factura_id=' . $this->request->get['filter_factura_id'];
			}
			
			if (isset($this->request->get['filter_invoice_prefix'])) {
				$url .= '&filter_invoice_prefix=' . $this->request->get['filter_invoice_prefix'];
			}			

			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_factura_status'])) {
				$url .= '&filter_factura_status=' . $this->request->get['filter_factura_status'];
			}
			
			if (isset($this->request->get['filter_factura_status_id'])) {
				$url .= '&filter_factura_status_id=' . $this->request->get['filter_factura_status_id'];
			}
			
			if (isset($this->request->get['filter_total'])) {
				$url .= '&filter_total=' . $this->request->get['filter_total'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['filter_date_modified'])) {
				$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);

			$data['shipping'] = $this->url->link('admdirsis/factura/shipping', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . (int)$this->request->get['factura_id'], true);
			$data['invoice'] = $this->url->link('admdirsis/factura/invoice', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . (int)$this->request->get['factura_id'], true);
			$data['edit'] = $this->url->link('admdirsis/factura/edit', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . (int)$this->request->get['factura_id'], true);
			$data['cancel'] = $this->url->link('admdirsis/factura', 'user_token=' . $this->session->data['user_token'] . $url, true);

			$data['user_token'] = $this->session->data['user_token'];

			$data['factura_id'] = $this->request->get['factura_id'];

			$data['store_id'] = $factura_info['store_id'];
			$data['store_name'] = $factura_info['store_name'];
			
//DIRSIS
			$data['comprob_id'] = $factura_info['comprob_id'];
			$data['fpago_id'] = $factura_info['fpago_id'];
			
//DIRSIS			
			
			if ($factura_info['store_id'] == 0) {
				$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
			} else {
				$data['store_url'] = $factura_info['store_url'];
			}

			if ($factura_info['invoice_no']) {
				$data['invoice_no'] = $factura_info['invoice_prefix'] . $factura_info['invoice_no'];
			} else {
				$data['invoice_no'] = '';
			}

			$data['date_added'] = date($this->language->get('date_format_short'), strtotime($factura_info['date_added']));

			$data['firstname'] = $factura_info['firstname'];
			$data['lastname'] = $factura_info['lastname'];

			if ($factura_info['customer_id']) {
				$data['customer'] = $this->url->link('customer/customer/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $factura_info['customer_id'], true);
			} else {
				$data['customer'] = '';
			}

			$this->load->model('customer/customer_group');

			$customer_group_info = $this->model_customer_customer_group->getCustomerGroup($factura_info['customer_group_id']);

			if ($customer_group_info) {
				$data['customer_group'] = $customer_group_info['name'];
			} else {
				$data['customer_group'] = '';
			}

			$data['email'] = $factura_info['email'];
			$data['telephone'] = $factura_info['telephone'];

			$data['shipping_method'] = $factura_info['shipping_method'];
			$data['payment_method'] = $factura_info['payment_method'];

			// Payment Address
			if ($factura_info['payment_address_format']) {
				$format = $factura_info['payment_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $factura_info['payment_firstname'],
				'lastname'  => $factura_info['payment_lastname'],
				'company'   => $factura_info['payment_company'],
				'address_1' => $factura_info['payment_address_1'],
				'address_2' => $factura_info['payment_address_2'],
				'city'      => $factura_info['payment_city'],
				'postcode'  => $factura_info['payment_postcode'],
				'zone'      => $factura_info['payment_zone'],
				'zone_code' => $factura_info['payment_zone_code'],
				'country'   => $factura_info['payment_country']
			);

			$data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			// Shipping Address
			if ($factura_info['shipping_address_format']) {
				$format = $factura_info['shipping_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $factura_info['shipping_firstname'],
				'lastname'  => $factura_info['shipping_lastname'],
				'company'   => $factura_info['shipping_company'],
				'address_1' => $factura_info['shipping_address_1'],
				'address_2' => $factura_info['shipping_address_2'],
				'city'      => $factura_info['shipping_city'],
				'postcode'  => $factura_info['shipping_postcode'],
				'zone'      => $factura_info['shipping_zone'],
				'zone_code' => $factura_info['shipping_zone_code'],
				'country'   => $factura_info['shipping_country']
			);

			$data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			// Uploaded files
			$this->load->model('tool/upload');

			$data['products'] = array();

			$products = $this->model_admdirsis_factura->getFacturaProducts($this->request->get['factura_id']);

			foreach ($products as $product) {
				$option_data = array();

				$options = $this->model_admdirsis_factura->getFacturaOptions($this->request->get['factura_id'], $product['factura_product_id']);

				foreach ($options as $option) {
					if ($option['type'] != 'file') {
						$option_data[] = array(
							'name'  => $option['name'],
							'value' => $option['value'],
							'type'  => $option['type']
						);
					} else {
						$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

						if ($upload_info) {
							$option_data[] = array(
								'name'  => $option['name'],
								'value' => $upload_info['name'],
								'type'  => $option['type'],
								'href'  => $this->url->link('tool/upload/download', 'user_token=' . $this->session->data['user_token'] . '&code=' . $upload_info['code'], true)
							);
						}
					}
				}

				$data['products'][] = array(
					'factura_product_id' => $product['factura_product_id'],
					'product_id'       => $product['product_id'],
					'name'    	 	   => $product['name'],
					'model'    		   => $product['model'],
					'option'   		   => $option_data,
					'quantity'		   => $product['quantity'],
					'price'    		   => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $factura_info['currency_code'], $factura_info['currency_value']),
					'total'    		   => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $factura_info['currency_code'], $factura_info['currency_value']),
					'href'     		   => $this->url->link('catalog/product/edit', 'user_token=' . $this->session->data['user_token'] . '&product_id=' . $product['product_id'], true)
				);
			}

			$data['vouchers'] = array();

			$vouchers = $this->model_admdirsis_factura->getFacturaVouchers($this->request->get['factura_id']);

			foreach ($vouchers as $voucher) {
				$data['vouchers'][] = array(
					'description' => $voucher['description'],
					'amount'      => $this->currency->format($voucher['amount'], $factura_info['currency_code'], $factura_info['currency_value']),
					'href'        => $this->url->link('sale/voucher/edit', 'user_token=' . $this->session->data['user_token'] . '&voucher_id=' . $voucher['voucher_id'], true)
				);
			}

			$data['totals'] = array();

			$totals = $this->model_admdirsis_factura->getFacturaTotals($this->request->get['factura_id']);

			foreach ($totals as $total) {
				$data['totals'][] = array(
					'title' => $total['title'],
					'text'  => $this->currency->format($total['value'], $factura_info['currency_code'], $factura_info['currency_value'])
				);
			}

			$data['comment'] = nl2br($factura_info['comment']);
/*
			$this->load->model('customer/customer');

			$data['reward'] = $factura_info['reward'];

			$data['reward_total'] = $this->model_customer_customer->getTotalCustomerRewardsByFacturaId($this->request->get['factura_id']);

			$data['affiliate_firstname'] = $factura_info['affiliate_firstname'];
			$data['affiliate_lastname'] = $factura_info['affiliate_lastname'];

			if ($factura_info['affiliate_id']) {
				$data['affiliate'] = $this->url->link('customer/customer/edit', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $factura_info['affiliate_id'], true);
			} else {
				$data['affiliate'] = '';
			}

			$data['commission'] = $this->currency->format($factura_info['commission'], $factura_info['currency_code'], $factura_info['currency_value']);

			$this->load->model('customer/customer');

			$data['commission_total'] = $this->model_customer_customer->getTotalTransactionsByFacturaId($this->request->get['factura_id']);
*/
			$this->load->model('localisation/factura_status');

			$factura_status_info = $this->model_localisation_factura_status->getFacturaStatus($factura_info['factura_status_id']);

			if ($factura_status_info) {
				$data['factura_status'] = $factura_status_info['name'];
			} else {
				$data['factura_status'] = '';
			}

			$data['factura_statuses'] = $this->model_localisation_factura_status->getFacturaStatuses();

			$data['factura_status_id'] = $factura_info['factura_status_id'];

			$data['account_custom_field'] = $factura_info['custom_field'];

			// Custom Fields
			$this->load->model('customer/custom_field');

			$data['account_custom_fields'] = array();

			$filter_data = array(
				'sort'  => 'cf.sort_order',
				'order' => 'ASC'
			);

			$custom_fields = $this->model_customer_custom_field->getCustomFields($filter_data);

			foreach ($custom_fields as $custom_field) {
				if ($custom_field['location'] == 'account' && isset($factura_info['custom_field'][$custom_field['custom_field_id']])) {
					if ($custom_field['type'] == 'select' || $custom_field['type'] == 'radio') {
						$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($factura_info['custom_field'][$custom_field['custom_field_id']]);

						if ($custom_field_value_info) {
							$data['account_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $custom_field_value_info['name']
							);
						}
					}

					if ($custom_field['type'] == 'checkbox' && is_array($factura_info['custom_field'][$custom_field['custom_field_id']])) {
						foreach ($factura_info['custom_field'][$custom_field['custom_field_id']] as $custom_field_value_id) {
							$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($custom_field_value_id);

							if ($custom_field_value_info) {
								$data['account_custom_fields'][] = array(
									'name'  => $custom_field['name'],
									'value' => $custom_field_value_info['name']
								);
							}
						}
					}

					if ($custom_field['type'] == 'text' || $custom_field['type'] == 'textarea' || $custom_field['type'] == 'file' || $custom_field['type'] == 'date' || $custom_field['type'] == 'datetime' || $custom_field['type'] == 'time') {
						$data['account_custom_fields'][] = array(
							'name'  => $custom_field['name'],
							'value' => $factura_info['custom_field'][$custom_field['custom_field_id']]
						);
					}

					if ($custom_field['type'] == 'file') {
						$upload_info = $this->model_tool_upload->getUploadByCode($factura_info['custom_field'][$custom_field['custom_field_id']]);

						if ($upload_info) {
							$data['account_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $upload_info['name']
							);
						}
					}
				}
			}

			// Custom fields
			$data['payment_custom_fields'] = array();

			foreach ($custom_fields as $custom_field) {
				if ($custom_field['location'] == 'address' && isset($factura_info['payment_custom_field'][$custom_field['custom_field_id']])) {
					if ($custom_field['type'] == 'select' || $custom_field['type'] == 'radio') {
						$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($factura_info['payment_custom_field'][$custom_field['custom_field_id']]);

						if ($custom_field_value_info) {
							$data['payment_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $custom_field_value_info['name'],
								'sort_order' => $custom_field['sort_order']
							);
						}
					}

					if ($custom_field['type'] == 'checkbox' && is_array($factura_info['payment_custom_field'][$custom_field['custom_field_id']])) {
						foreach ($factura_info['payment_custom_field'][$custom_field['custom_field_id']] as $custom_field_value_id) {
							$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($custom_field_value_id);

							if ($custom_field_value_info) {
								$data['payment_custom_fields'][] = array(
									'name'  => $custom_field['name'],
									'value' => $custom_field_value_info['name'],
									'sort_order' => $custom_field['sort_order']
								);
							}
						}
					}

					if ($custom_field['type'] == 'text' || $custom_field['type'] == 'textarea' || $custom_field['type'] == 'file' || $custom_field['type'] == 'date' || $custom_field['type'] == 'datetime' || $custom_field['type'] == 'time') {
						$data['payment_custom_fields'][] = array(
							'name'  => $custom_field['name'],
							'value' => $factura_info['payment_custom_field'][$custom_field['custom_field_id']],
							'sort_order' => $custom_field['sort_order']
						);
					}

					if ($custom_field['type'] == 'file') {
						$upload_info = $this->model_tool_upload->getUploadByCode($factura_info['payment_custom_field'][$custom_field['custom_field_id']]);

						if ($upload_info) {
							$data['payment_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $upload_info['name'],
								'sort_order' => $custom_field['sort_order']
							);
						}
					}
				}
			}

			// Shipping
			$data['shipping_custom_fields'] = array();

			foreach ($custom_fields as $custom_field) {
				if ($custom_field['location'] == 'address' && isset($factura_info['shipping_custom_field'][$custom_field['custom_field_id']])) {
					if ($custom_field['type'] == 'select' || $custom_field['type'] == 'radio') {
						$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($factura_info['shipping_custom_field'][$custom_field['custom_field_id']]);

						if ($custom_field_value_info) {
							$data['shipping_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $custom_field_value_info['name'],
								'sort_order' => $custom_field['sort_order']
							);
						}
					}

					if ($custom_field['type'] == 'checkbox' && is_array($factura_info['shipping_custom_field'][$custom_field['custom_field_id']])) {
						foreach ($factura_info['shipping_custom_field'][$custom_field['custom_field_id']] as $custom_field_value_id) {
							$custom_field_value_info = $this->model_customer_custom_field->getCustomFieldValue($custom_field_value_id);

							if ($custom_field_value_info) {
								$data['shipping_custom_fields'][] = array(
									'name'  => $custom_field['name'],
									'value' => $custom_field_value_info['name'],
									'sort_order' => $custom_field['sort_order']
								);
							}
						}
					}

					if ($custom_field['type'] == 'text' || $custom_field['type'] == 'textarea' || $custom_field['type'] == 'file' || $custom_field['type'] == 'date' || $custom_field['type'] == 'datetime' || $custom_field['type'] == 'time') {
						$data['shipping_custom_fields'][] = array(
							'name'  => $custom_field['name'],
							'value' => $factura_info['shipping_custom_field'][$custom_field['custom_field_id']],
							'sort_order' => $custom_field['sort_order']
						);
					}

					if ($custom_field['type'] == 'file') {
						$upload_info = $this->model_tool_upload->getUploadByCode($factura_info['shipping_custom_field'][$custom_field['custom_field_id']]);

						if ($upload_info) {
							$data['shipping_custom_fields'][] = array(
								'name'  => $custom_field['name'],
								'value' => $upload_info['name'],
								'sort_order' => $custom_field['sort_order']
							);
						}
					}
				}
			}

			$data['ip'] = $factura_info['ip'];
			$data['forwarded_ip'] = $factura_info['forwarded_ip'];
			$data['user_agent'] = $factura_info['user_agent'];
			$data['accept_language'] = $factura_info['accept_language'];

			// Additional Tabs
			$data['tabs'] = array();

			if ($this->user->hasPermission('access', 'extension/payment/' . $factura_info['payment_code'])) {
				if (is_file(DIR_CATALOG . 'controller/extension/payment/' . $factura_info['payment_code'] . '.php')) {
					$content = $this->load->controller('extension/payment/' . $factura_info['payment_code'] . '/order');
				} else {
					$content = '';
				}

				if ($content) {
					$this->load->language('extension/payment/' . $factura_info['payment_code']);

					$data['tabs'][] = array(
						'code'    => $factura_info['payment_code'],
						'title'   => $this->language->get('heading_title'),
						'content' => $content
					);
				}
			}

			$this->load->model('setting/extension');

			$extensions = $this->model_setting_extension->getInstalled('fraud');

			foreach ($extensions as $extension) {
				if ($this->config->get('fraud_' . $extension . '_status')) {
					$this->load->language('extension/fraud/' . $extension, 'extension');

					$content = $this->load->controller('extension/fraud/' . $extension . '/order');

					if ($content) {
						$data['tabs'][] = array(
							'code'    => $extension,
							'title'   => $this->language->get('extension')->get('heading_title'),
							'content' => $content
						);
					}
				}
			}
			
			// The URL we send API requests to
			$data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
			
			// API login
			$this->load->model('user/api');

			$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

			if ($api_info && $this->user->hasPermission('modify', 'admdirsis/factura')) {
				$session = new Session($this->config->get('session_engine'), $this->registry);
				
				$session->start();
				
				$this->model_user_api->deleteApiSessionBySessonId($session->getId());
				
				$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);
				
				$session->data['api_id'] = $api_info['api_id'];

				$data['api_token'] = $session->getId();
			} else {
				$data['api_token'] = '';
			}

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('admdirsis/factura_info', $data));
		} else {
			return new Action('error/not_found');
		}
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	public function createInvoiceNo() {
		$this->load->language('admdirsis/factura');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$json['error'] = $this->language->get('error_permission');
		} elseif (isset($this->request->get['factura_id'])) {
			if (isset($this->request->get['factura_id'])) {
				$factura_id = $this->request->get['factura_id'];
			} else {
				$factura_id = 0;
			}

			$this->load->model('admdirsis/factura');

			$invoice_no = $this->model_admdirsis_factura->createInvoiceNo($factura_id);

			if ($invoice_no) {
				$json['invoice_no'] = $invoice_no;
			} else {
				$json['error'] = $this->language->get('error_action');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function addReward() {
		$this->load->language('admdirsis/factura');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->get['factura_id'])) {
				$factura_id = $this->request->get['factura_id'];
			} else {
				$factura_id = 0;
			}

			$this->load->model('admdirsis/factura');

			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			if ($factura_info && $factura_info['customer_id'] && ($factura_info['reward'] > 0)) {
				$this->load->model('customer/customer');

				$reward_total = $this->model_customer_customer->getTotalCustomerRewardsByFacturaId($factura_id);

				if (!$reward_total) {
					$this->model_customer_customer->addReward($factura_info['customer_id'], $this->language->get('text_factura_id') . ' #' . $factura_id, $factura_info['reward'], $factura_id);
				}
			}

			$json['success'] = $this->language->get('text_reward_added');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function removeReward() {
		$this->load->language('admdirsis/factura');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->get['factura_id'])) {
				$factura_id = $this->request->get['factura_id'];
			} else {
				$factura_id = 0;
			}

			$this->load->model('admdirsis/factura');

			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			if ($factura_info) {
				$this->load->model('customer/customer');

				$this->model_customer_customer->deleteReward($factura_id);
			}

			$json['success'] = $this->language->get('text_reward_removed');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function addCommission() {
		$this->load->language('admdirsis/factura');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->get['factura_id'])) {
				$factura_id = $this->request->get['factura_id'];
			} else {
				$factura_id = 0;
			}

			$this->load->model('admdirsis/factura');

			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			if ($factura_info) {
				$this->load->model('customer/customer');

				$affiliate_total = $this->model_customer_customer->getTotalTransactionsByFacturaId($factura_id);

				if (!$affiliate_total) {
					$this->model_customer_customer->addTransaction($factura_info['affiliate_id'], $this->language->get('text_factura_id') . ' #' . $factura_id, $factura_info['commission'], $factura_id);
				}
			}

			$json['success'] = $this->language->get('text_commission_added');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function removeCommission() {
		$this->load->language('admdirsis/factura');

		$json = array();

		if (!$this->user->hasPermission('modify', 'admdirsis/factura')) {
			$json['error'] = $this->language->get('error_permission');
		} else {
			if (isset($this->request->get['factura_id'])) {
				$factura_id = $this->request->get['factura_id'];
			} else {
				$factura_id = 0;
			}

			$this->load->model('admdirsis/factura');

			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			if ($factura_info) {
				$this->load->model('customer/customer');

				$this->model_customer_customer->deleteTransactionByFacturaId($factura_id);
			}

			$json['success'] = $this->language->get('text_commission_removed');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function history() {
		$this->load->language('admdirsis/factura');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['histories'] = array();

		$this->load->model('admdirsis/factura');

		$results = $this->model_admdirsis_factura->getFacturaHistories($this->request->get['factura_id'], ($page - 1) * 10, 10);

		foreach ($results as $result) {
			$data['histories'][] = array(
				'notify'     => $result['notify'] ? $this->language->get('text_yes') : $this->language->get('text_no'),
				'status'     => $result['status'],
				'comment'    => nl2br($result['comment']),
				'date_added' => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$history_total = $this->model_admdirsis_factura->getTotalFacturaHistories($this->request->get['factura_id']);

		$pagination = new Pagination();
		$pagination->total = $history_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('admdirsis/factura/history', 'user_token=' . $this->session->data['user_token'] . '&factura_id=' . $this->request->get['factura_id'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($history_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($history_total - 10)) ? $history_total : ((($page - 1) * 10) + 10), $history_total, ceil($history_total / 10));

		$this->response->setOutput($this->load->view('admdirsis/factura_history', $data));
	}

	public function invoice() {
		$this->load->language('admdirsis/factura');

		$data['title'] = $this->language->get('text_invoice');

		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}

		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');

		$this->load->model('admdirsis/factura');

		$this->load->model('setting/setting');

		$data['facturas'] = array();

		$facturas = array();

		if (isset($this->request->post['selected'])) {
			$facturas = $this->request->post['selected'];
		} elseif (isset($this->request->get['factura_id'])) {
			$facturas[] = $this->request->get['factura_id'];
		}

		foreach ($facturas as $factura_id) {
			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			if ($factura_info) {
				$store_info = $this->model_setting_setting->getSetting('config', $factura_info['store_id']);

				if ($store_info) {
					$store_address = $store_info['config_address'];
					$store_email = $store_info['config_email'];
					$store_telephone = $store_info['config_telephone'];
					$store_fax = $store_info['config_fax'];
				} else {
					$store_address = $this->config->get('config_address');
					$store_email = $this->config->get('config_email');
					$store_telephone = $this->config->get('config_telephone');
					$store_fax = $this->config->get('config_fax');
				}

				if ($factura_info['invoice_no']) {
					$invoice_no = $factura_info['invoice_prefix'] . $factura_info['invoice_no'];
				} else {
					$invoice_no = '';
				}

				if ($factura_info['payment_address_format']) {
					$format = $factura_info['payment_address_format'];
				} else {
					$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
				}

				$find = array(
					'{firstname}',
					'{lastname}',
					'{company}',
					'{address_1}',
					'{address_2}',
					'{city}',
					'{postcode}',
					'{zone}',
					'{zone_code}',
					'{country}'
				);

				$replace = array(
					'firstname' => $factura_info['payment_firstname'],
					'lastname'  => $factura_info['payment_lastname'],
					'company'   => $factura_info['payment_company'],
					'address_1' => $factura_info['payment_address_1'],
					'address_2' => $factura_info['payment_address_2'],
					'city'      => $factura_info['payment_city'],
					'postcode'  => $factura_info['payment_postcode'],
					'zone'      => $factura_info['payment_zone'],
					'zone_code' => $factura_info['payment_zone_code'],
					'country'   => $factura_info['payment_country']
				);

				$payment_address = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

				if ($factura_info['shipping_address_format']) {
					$format = $factura_info['shipping_address_format'];
				} else {
					$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
				}

				$find = array(
					'{firstname}',
					'{lastname}',
					'{company}',
					'{address_1}',
					'{address_2}',
					'{city}',
					'{postcode}',
					'{zone}',
					'{zone_code}',
					'{country}'
				);

				$replace = array(
					'firstname' => $factura_info['shipping_firstname'],
					'lastname'  => $factura_info['shipping_lastname'],
					'company'   => $factura_info['shipping_company'],
					'address_1' => $factura_info['shipping_address_1'],
					'address_2' => $factura_info['shipping_address_2'],
					'city'      => $factura_info['shipping_city'],
					'postcode'  => $factura_info['shipping_postcode'],
					'zone'      => $factura_info['shipping_zone'],
					'zone_code' => $factura_info['shipping_zone_code'],
					'country'   => $factura_info['shipping_country']
				);

				$shipping_address = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

				$this->load->model('tool/upload');

				$product_data = array();

				$products = $this->model_admdirsis_factura->getFacturaProducts($factura_id);

				foreach ($products as $product) {
					$option_data = array();

					$options = $this->model_admdirsis_factura->getFacturaOptions($factura_id, $product['factura_product_id']);

					foreach ($options as $option) {
						if ($option['type'] != 'file') {
							$value = $option['value'];
						} else {
							$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

							if ($upload_info) {
								$value = $upload_info['name'];
							} else {
								$value = '';
							}
						}

						$option_data[] = array(
							'name'  => $option['name'],
							'value' => $value
						);
					}

					$product_data[] = array(
						'name'     => $product['name'],
						'model'    => $product['model'],
						'option'   => $option_data,
						'quantity' => $product['quantity'],
						'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $factura_info['currency_code'], $factura_info['currency_value']),
						'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $factura_info['currency_code'], $factura_info['currency_value'])
					);
				}

				$voucher_data = array();

				$vouchers = $this->model_admdirsis_factura->getFacturaVouchers($factura_id);

				foreach ($vouchers as $voucher) {
					$voucher_data[] = array(
						'description' => $voucher['description'],
						'amount'      => $this->currency->format($voucher['amount'], $factura_info['currency_code'], $factura_info['currency_value'])
					);
				}

				$total_data = array();

				$totals = $this->model_admdirsis_factura->getFacturaTotals($factura_id);

				foreach ($totals as $total) {
					$total_data[] = array(
						'title' => $total['title'],
						'text'  => $this->currency->format($total['value'], $factura_info['currency_code'], $factura_info['currency_value'])
					);
				}

				$data['facturas'][] = array(
					'factura_id'	       => $factura_id,
					'invoice_no'       => $invoice_no,
					'date_added'       => date($this->language->get('date_format_short'), strtotime($factura_info['date_added'])),
					'store_name'       => $factura_info['store_name'],
					'store_url'        => rtrim($factura_info['store_url'], '/'),
					'store_address'    => nl2br($store_address),
					'store_email'      => $store_email,
					'store_telephone'  => $store_telephone,
					'store_fax'        => $store_fax,
					'email'            => $factura_info['email'],
					'telephone'        => $factura_info['telephone'],
					'shipping_address' => $shipping_address,
					'shipping_method'  => $factura_info['shipping_method'],
					'payment_address'  => $payment_address,
					'payment_method'   => $factura_info['payment_method'],
					'product'          => $product_data,
					'voucher'          => $voucher_data,
					'total'            => $total_data,
					'comment'          => nl2br($factura_info['comment'])
				);
			}
		}

		$this->response->setOutput($this->load->view('admdirsis/factura_invoice', $data));
	}

	public function shipping() {
		$this->load->language('admdirsis/factura');

		$data['title'] = $this->language->get('text_shipping');

		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}

		$data['direction'] = $this->language->get('direction');
		$data['lang'] = $this->language->get('code');

		$this->load->model('admdirsis/factura');

		$this->load->model('catalog/product');

		$this->load->model('setting/setting');

		$data['facturas'] = array();

		$facturas = array();

		if (isset($this->request->post['selected'])) {
			$facturas = $this->request->post['selected'];
		} elseif (isset($this->request->get['factura_id'])) {
			$facturas[] = $this->request->get['factura_id'];
		}

		foreach ($facturas as $factura_id) {
			$factura_info = $this->model_admdirsis_factura->getFactura($factura_id);

			// Make sure there is a shipping method
			if ($factura_info && $factura_info['shipping_code']) {
				$store_info = $this->model_setting_setting->getSetting('config', $factura_info['store_id']);

				if ($store_info) {
					$store_address = $store_info['config_address'];
					$store_email = $store_info['config_email'];
					$store_telephone = $store_info['config_telephone'];
				} else {
					$store_address = $this->config->get('config_address');
					$store_email = $this->config->get('config_email');
					$store_telephone = $this->config->get('config_telephone');
				}

				if ($factura_info['invoice_no']) {
					$invoice_no = $factura_info['invoice_prefix'] . $factura_info['invoice_no'];
				} else {
					$invoice_no = '';
				}

				if ($factura_info['shipping_address_format']) {
					$format = $factura_info['shipping_address_format'];
				} else {
					$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
				}

				$find = array(
					'{firstname}',
					'{lastname}',
					'{company}',
					'{address_1}',
					'{address_2}',
					'{city}',
					'{postcode}',
					'{zone}',
					'{zone_code}',
					'{country}'
				);

				$replace = array(
					'firstname' => $factura_info['shipping_firstname'],
					'lastname'  => $factura_info['shipping_lastname'],
					'company'   => $factura_info['shipping_company'],
					'address_1' => $factura_info['shipping_address_1'],
					'address_2' => $factura_info['shipping_address_2'],
					'city'      => $factura_info['shipping_city'],
					'postcode'  => $factura_info['shipping_postcode'],
					'zone'      => $factura_info['shipping_zone'],
					'zone_code' => $factura_info['shipping_zone_code'],
					'country'   => $factura_info['shipping_country']
				);

				$shipping_address = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

				$this->load->model('tool/upload');

				$product_data = array();

				$products = $this->model_admdirsis_factura->getFacturaProducts($factura_id);

				foreach ($products as $product) {
					$option_weight = '';

					$product_info = $this->model_catalog_product->getProduct($product['product_id']);

					if ($product_info) {
						$option_data = array();

						$options = $this->model_admdirsis_factura->getFacturaOptions($factura_id, $product['factura_product_id']);

						foreach ($options as $option) {
							if ($option['type'] != 'file') {
								$value = $option['value'];
							} else {
								$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

								if ($upload_info) {
									$value = $upload_info['name'];
								} else {
									$value = '';
								}
							}

							$option_data[] = array(
								'name'  => $option['name'],
								'value' => $value
							);

							$product_option_value_info = $this->model_catalog_product->getProductOptionValue($product['product_id'], $option['product_option_value_id']);

							if ($product_option_value_info) {
								if ($product_option_value_info['weight_prefix'] == '+') {
									$option_weight += $product_option_value_info['weight'];
								} elseif ($product_option_value_info['weight_prefix'] == '-') {
									$option_weight -= $product_option_value_info['weight'];
								}
							}
						}

						$product_data[] = array(
							'name'     => $product_info['name'],
							'model'    => $product_info['model'],
							'option'   => $option_data,
							'quantity' => $product['quantity'],
							'location' => $product_info['location'],
							'sku'      => $product_info['sku'],
							'upc'      => $product_info['upc'],
							'ean'      => $product_info['ean'],
							'jan'      => $product_info['jan'],
							'isbn'     => $product_info['isbn'],
							'mpn'      => $product_info['mpn'],
							'weight'   => $this->weight->format(($product_info['weight'] + (float)$option_weight) * $product['quantity'], $product_info['weight_class_id'], $this->language->get('decimal_point'), $this->language->get('thousand_point'))
						);
					}
				}

				$data['facturas'][] = array(
					'factura_id'	       => $factura_id,
					'invoice_no'       => $invoice_no,
					'date_added'       => date($this->language->get('date_format_short'), strtotime($factura_info['date_added'])),
					'store_name'       => $factura_info['store_name'],
					'store_url'        => rtrim($factura_info['store_url'], '/'),
					'store_address'    => nl2br($store_address),
					'store_email'      => $store_email,
					'store_telephone'  => $store_telephone,
					'email'            => $factura_info['email'],
					'telephone'        => $factura_info['telephone'],
					'shipping_address' => $shipping_address,
					'shipping_method'  => $factura_info['shipping_method'],
					'product'          => $product_data,
					'comment'          => nl2br($factura_info['comment'])
				);
			}
		}

		$this->response->setOutput($this->load->view('admdirsis/factura_shipping', $data));
	}
}
