<?php
class ControllerAdmdirsisConsolaencuesta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/consolaencuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'tema';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		$url = '';
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$data['user_token'] = $this->session->data['user_token'];
		$data['breadcrumbs'] = array();
		$data['consolas'] = array();
		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);
		
		
		$result = $this->model_admdirsis_encuesta->getConsolaencuesta();
		//print_r($result);
		//foreach ($results as $result) {		
				$data['banners'] = array(
					'encuesta_id' => $result['encuesta_id'],
					'tema' => $result['tema'],
					'codigo' => html_entity_decode($result['codigo'], ENT_QUOTES, 'UTF-8'),
				);
		
		$this->document->addStyle('../catalog/view/javascript/jquery/swiper/css/swiper.min.css');
		$this->document->addStyle('../catalog/view/javascript/jquery/swiper/css/opencart.css');
		$this->document->addScript('../catalog/view/javascript/jquery/swiper/js/swiper.jquery.js');
		
		$this->load->model('dirsisturno/banner');
		$this->load->model('tool/image');
		$banner_images = $this->model_dirsisturno_banner->getBannerImages(7);
		$data['banners'] = array();
		foreach ($banner_images as $key => $value) {
			foreach ($value as $banner_image) {
				if (is_file(DIR_IMAGE . $banner_image['image'])) {
					$data['banners'][] = array(
						'title' => $banner_image['title'],
						'link'  => $banner_image['link'],
						'image' => $this->model_tool_image->resize($banner_image['image'], 1920, 300)
					);				
				}
			}
		}
		$data['module'] = 1;		
		//print_r($data['turneros']);
		
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}


		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/consolaencuesta_list', $data));
	}

}


class ControllerExtensionModuleEncuesta extends Controller {
	public function index($setting) {
		static $module = 0;		

		$this->load->model('design/banner');
		$this->load->model('tool/image');

		$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/swiper.min.css');
		$this->document->addStyle('catalog/view/javascript/jquery/swiper/css/opencart.css');
		$this->document->addScript('catalog/view/javascript/jquery/swiper/js/swiper.jquery.js');
		
		$data['banners'] = array();

		/*
		$results = $this->model_design_banner->getBanner($setting['banner_id']);

		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$data['banners'][] = array(
					'title' => $result['title'],
					'link'  => $result['link'],
					'image' => $this->model_tool_image->resize($result['image'], $setting['width'], $setting['height'])
				);
			}
		}
		*/
		
		//$this->load->model('admdirsis/encuesta');
		$result = $this->model_design_banner->getEncuesta();
		//print_r($result);
		
		//foreach ($results as $result) {		
				$data['banners'] = array(
					'encuesta_id' => $result['encuesta_id'],
					'tema' => $result['tema'],
					'codigo' => html_entity_decode($result['codigo'], ENT_QUOTES, 'UTF-8'),
				);
		//}
		
		
		$data['module'] = $module++;

		return $this->load->view('extension/module/encuesta', $data);
	}
}