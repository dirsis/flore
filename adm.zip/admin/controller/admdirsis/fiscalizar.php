<?php
class ControllerAdmdirsisFiscalizar extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('admdirsis/fiscalizar');
		$this->load->model('admdirsis/fiscalizar');
		//$this->getList();
	}
	
	public function getPruebaafip() {
		
		$this->load->model('setting/setting');
		$this->load->model('admdirsis/comprob');
		$this->load->model('admdirsis/fiscalizar');
		
		$cuit=$this->config->get('config_factura_cuit');
		$serie=$this->config->get('config_factura_serie');
		$codiva_id=$this->config->get('config_factura_codiva_id');		
		$recorrecobs = array();
		if ($codiva_id==1){	
			$recorrecobs[] = array( 'afip' => 1, 'name' => 'FACTURA A' );
			$recorrecobs[] = array( 'afip' => 2, 'name' => 'DEBITO A' );
			$recorrecobs[] = array( 'afip' => 3, 'name' => 'CREDITO A' );
			$recorrecobs[] = array( 'afip' => 6, 'name' => 'FACTURA B' );
			$recorrecobs[] = array( 'afip' => 7, 'name' => 'DEBITO B' );
			$recorrecobs[] = array( 'afip' => 8, 'name' => 'CREDITO B' );
		}else{
			$recorrecobs[] = array( 'afip' => 11, 'name' => 'FACTURA C' );
			$recorrecobs[] = array( 'afip' => 12, 'name' => 'DEBITO C' );
			$recorrecobs[] = array( 'afip' => 13, 'name' => 'CREDITO C' );
			$recorrecobs[] = array( 'afip' => 15, 'name' => 'RECIBO C' );
		}
		//print_r($recorrecobs);
		//$recorrecobs = $this->model_admdirsis_comprob->getComprobs();	
		$resultado = array();
		foreach ($recorrecobs as $recorrecob) {
			if ((int)$recorrecob['afip']!=0){
				$tipo=$recorrecob['afip'];
				//print_r("<br>".$serie."-".$cuit);
				//die;
				$ultimonumero = $this->model_admdirsis_fiscalizar->ultimocomprobante($cuit,$tipo,$serie);
				$resultado[] = array(
					'afip' => $tipo,
					'cuit' => $cuit,
					'name' => $recorrecob['name'],
					'serie' => $serie,
					'numero' => $ultimonumero
				);

			}
			
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($resultado));
	}
	
	public function getUltimonumero() {
		if (isset($this->request->get['comprob_id'])) {
			$comprob_id = $this->request->get['comprob_id'];
		} else {
			$comprob_id = '';
		}
		if (isset($this->request->get['customer_codiva_id'])) {
			$customer_codiva_id = $this->request->get['customer_codiva_id'];
		} else {
			$customer_codiva_id = '';
		}			
		
		$this->load->model('admdirsis/comprob');
		$comprob = $this->model_admdirsis_comprob->getComprob($comprob_id );		
		$afip = $comprob['afip'];
		
		$this->load->model('setting/setting');
		$serie 		= $this->config->get('config_factura_serie');
		$cuit 		= $this->config->get('config_factura_cuit');
		$codiva_id 	= $this->config->get('config_factura_codiva_id');
		
		$data = array(
			'comprob_id'	     	=> $comprob_id,
			'customer_codiva_id'    => $customer_codiva_id,
			'cuit'    => $cuit,
			'codiva_id'    => $codiva_id,
			'serie'		=> $serie,
			'afip'		=> $afip
		);
		//print_r($data);
		
		$this->load->model('admdirsis/fiscalizar');
		//die;
		$ultimonumero = $this->model_admdirsis_fiscalizar->getUltimonumero($data);
		echo $ultimonumero;
	}
	
	public function getFacturarmasivo() {
		$html = '<table border=1>';
        $html .= '<tr>';
		$html .= '<td>ID</td>';
		$html .= '<td>Tipo</td>';
		$html .= '<td>Serie</td>';
		$html .= '<td>Numero</td>';
		$html .= '<td>Cae</td>';
		$html .= '<td>Total</td>';
		$html .= '<td>Resul</td>';
		$html .= '</tr>';		
		if (($this->request->server['REQUEST_METHOD'] == 'POST')){
			foreach ($this->request->post['selected'] as $contab_id) {			
				$resul=$this->emitirFactura($contab_id);
				if (!isset($resul['cae'])){
					$html .= '<tr>';
					$html .= '<td>'.$contab_id.'</td>';
					$html .= '<td colspan="5">'.$resul['resul'].'</td>';
					$html .= '</tr>';
				}else{
					$html .= '<tr>';
					$html .= '<td>' .$contab_id . '</td>';
					$html .= '<td>' .$resul['tipo'] . '</td>';
					$html .= '<td>'. $resul['serie'] . '</td>';
					$html .= '<td>'. $resul['numero'] . '</td>';
					$html .= '<td>'. $resul['cae'] . '</td>';
					$html .= '<td>'. $resul['total'] . '</td>';
					$html .= '<td>'. $resul['resul'] . '</td>';
					$html .= '</tr>';
				}
			}
		}
		

		$html .= '</table>';
		
		$this->session->data['success'] = $html;
		/*
			$url = '';
			if (isset($this->request->get['filter_customer'])) {
				$url .= '&filter_customer=' . urlencode(html_entity_decode($this->request->get['filter_customer'], ENT_QUOTES, 'UTF-8'));
			}
			if (isset($this->request->get['filter_comprob_id'])) {
				$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
			}
			if (isset($this->request->get['filter_estado'])) {
				$url .= '&filter_estado=' . $this->request->get['filter_estado'];
			}
			if (isset($this->request->get['filter_fpago_id'])) {
				$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
			}
			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}
			if (isset($this->request->get['filter_date_hasta'])) {
				$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
			}			
			if (isset($this->request->get['filter_caja_id'])) {
				$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
			}
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/contab', 'user_token=' . $this->session->data['user_token'] . $url, true));
		*/
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($resul));		
	}
	
	
	public function getSimplemasivo() {
		$this->load->model('admdirsis/fiscalizar');
		$json=array();
		if (($this->request->server['REQUEST_METHOD'] == 'POST')){
			foreach ($this->request->post['selected'] as $recibo_id) {	
				$json=$this->model_admdirsis_fiscalizar->getFiscalizarecibo($recibo_id);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
	}
	
	
	public function getFacturar() {
		$resul=array();
		if (isset($this->request->get['contab_id'])) {
			$contab_id=$this->request->get['contab_id'];
			$resul=$this->emitirFactura($contab_id);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($resul));
	}
	public function emitirFactura($contab_id) {
		
			ini_set('display_errors', 1);
			error_reporting(E_ALL);
		
			$cae = array();
			$this->load->model('admdirsis/contab');
			$contab_info = $this->model_admdirsis_contab->getContab($contab_id);	
			if ($contab_info) {
				
				//print_r($contab_info);
				//die;
				
				if (empty($contab_info['cae'])){
					$customer_cuit=$contab_info['cuit'];
					$comprob_id=$contab_info['comprob_id'];
					$customer_codiva_id=$contab_info['codiva_id'];
					//if ($contab_info['customer_id']!=0){
						//$this->load->model('customer/customer');
						//$customer_info = $this->model_customer_customer->getCustomer($contab_info['customer_id']);			
						//if ($customer_info){
						//	$customer_cuit=$customer_info['cuit'];
						//	$customer_codiva_id=$customer_info['codiva_id'];
						//}
					//}
					$this->load->model('admdirsis/comprob');
					$comprob = $this->model_admdirsis_comprob->getComprob($comprob_id );		
					$afip = $comprob['afip'];

					$this->load->model('setting/setting');
					$serie 		= $this->config->get('config_factura_serie');
					$cuit 		= $this->config->get('config_factura_cuit');
					$codiva_id 	= $this->config->get('config_factura_codiva_id');

					$this->load->model('localisation/tax_class');

					$product_data = array();
					$products = $this->model_admdirsis_contab->getContabTasaiva($contab_id);
					$total_exento=0;
					$total_gravado=0;
					$total_iva=0;
					foreach ($products as $product) {
						$gravado=round($product['total']/(($product['tasaiva']/100)+1),2);
						$product_data[] = array(
							'total'     => $product['total'],
							'tasaiva'    => $product['tasaiva'],
							'gravado'    => $gravado
						);
						if ($product['tasaiva']<>0){
							$total_gravado=$total_gravado+$product['total'];
						}else{
							$total_exento=$total_exento+$product['total'];
						}
						$total_iva=$total_iva+($product['total']-$gravado);
					}

					$data = array(
						'contab_id'				=> $contab_id,
						'relacion'				=> $contab_info['relacion'],
						'comprob_id'	     	=> $contab_info['comprob_id'],
						'customer_codiva_id'    => $contab_info['codiva_id'],
						'customer_cuit'    		=> $customer_cuit,
						'cuit'    				=> $this->config->get('config_factura_cuit'),
						'codiva_id'    			=> $this->config->get('config_factura_codiva_id'),
						'serie'					=> $this->config->get('config_factura_serie'),
						'afip'					=> $comprob['afip'],
						'd_tipo'				=> $comprob['name'],
						'total'					=> $contab_info['total'],
						'total_exento'			=> $total_exento,
						'total_nogravado'		=> 0,
						'total_gravado'			=> $total_gravado,
						'total_iva'				=> $total_iva,
						'tasas'   			=> $product_data
					);
					$this->load->model('admdirsis/fiscalizar');
					$cae = $this->model_admdirsis_fiscalizar->getFacturar($data);
					
					if ((int)$cae['cae']!=0){
						$this->model_admdirsis_contab->editcaeContab($contab_id,$cae);
					}
				}
			}
			return $cae;
	}
	
	
	public function editCae() {

		$data = array (	
			date_added => $this->request->get['date_added'],
			serie 	=> $this->request->get['serie'],
			numero 	=> $this->request->get['numero'],
			cae 	=> $this->request->get['cae'],
			vto 	=> $this->request->get['vto']);
		
		$this->load->model('admdirsis/contab');
		echo $this->model_admdirsis_contab->editcaeContab($this->request->get['contab_id'],$data);		
	}
	
	public function getSimple() {
		$this->load->model('admdirsis/fiscalizar');
		//NC &afip=13&cuit=20221499108&total=10&relacion=4
		//RC &afip=15&cuit=20221499108&total=10&relacion=0
		
		$cae=array();
		
		if (isset($this->request->get['total']) and 
			isset($this->request->get['afip']) and 
			isset($this->request->get['cuit']) and 
			isset($this->request->get['relacion']) 
		   ){
			$total=$this->request->get['total'];
			$gravado=$total;
			$iva=$total-$gravado;
			$cuit=$this->request->get['cuit'];
			$relacion=$this->request->get['relacion'];
			$afip = $this->request->get['afip'];
			$cae=$this->model_admdirsis_fiscalizar->emitesimple($total,$afip,$cuit,-1);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($cae));
		
	}
	
	
	
}
