<?php
class ControllerAdmdirsisMlconsulta extends Controller {
	private $error = array();
	

	public function index() {
	
		$this->load->language('admdirsis/mlconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlconsulta');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/mlconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlconsulta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_mlconsulta->addMlconsulta($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/mlconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlconsulta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_mlconsulta->editMlconsulta($this->request->get['mlconsulta_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('admdirsis/mlconsulta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/mlconsulta');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $mlconsulta_id) {
				$this->model_admdirsis_mlconsulta->deleteMlconsulta($mlconsulta_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->request->get['filter_id'])) {
			$filter_id = $this->request->get['filter_id'];
		} else {
			$filter_id = '';
		}
		if (isset($this->request->get['filter_marketplace'])) {
			$filter_marketplace = $this->request->get['filter_marketplace'];
		} else {
			$filter_marketplace = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = 'UNANSWERED';
		}		
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = '';
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'id';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . urlencode(html_entity_decode($this->request->get['filter_status'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		
		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . $this->request->get['filter_id'];
		}
		if (isset($this->request->get['filter_marketplace'])) {
			$url .= '&filter_marketplace=' . $this->request->get['filter_marketplace'];
		}
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/mlconsulta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/mlconsulta/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['mlconsultas'] = array();

		$filter_data = array(
			'filter_id'            => $filter_id,
			'filter_marketplace'   => $filter_marketplace,
			'filter_status'        => $filter_status,
			'filter_date_added'    => $filter_date_added,			
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$mlconsulta_total = $this->model_admdirsis_mlconsulta->getTotalMlconsultas();

		$results = $this->model_admdirsis_mlconsulta->getMlconsultas($filter_data);
		foreach ($results as $result) {
			$data['mlconsultas'][] = array(
				'mlconsulta_id' => $result['mlconsulta_id'],
				'id'            => $result['id'],
				'fecha'         => date("d/m/Y",strtotime($result['fecha'])),	
				'hora'          => $result['hora'],
				'item_id'       => $result['item_id'],
				'seller_id'     => $result['seller_id'],
				'status'        => $result['status'],
				'd_status'      => $result['d_status'],
				'product_status' => $result['product_status'],
				'text'         	=> $result['text'],
				'marketplace'  	=> $result['marketplace'],
				'clien_id'      => $result['clien_id'],
				'clien_nick'    => $result['clien_nick'],
				'clien_link'    => $result['clien_link'],
				'arti_foto'     => $result['arti_foto'],
				'arti_link'     => $result['arti_link'],
				'arti_titulo'   => $result['arti_titulo'],
				'respuesta'   => $result['respuesta'],
				'edit'          => $this->url->link('admdirsis/mlconsulta/edit', 'user_token=' . $this->session->data['user_token'] . '&mlconsulta_id=' . $result['mlconsulta_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . urlencode(html_entity_decode($this->request->get['filter_status'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		
		if (isset($this->request->get['filter_id'])) {
			$url .= '&filter_id=' . $this->request->get['filter_id'];
		}	
		
		if (isset($this->request->get['filter_marketplace'])) {
			$url .= '&filter_marketplace=' . $this->request->get['filter_marketplace'];
		}			

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_id'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=id' . $url, true);
		$data['sort_fecha'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=fecha' . $url, true);
		$data['sort_clien_nick'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=clien_nick' . $url, true);
		$data['sort_arti_titulo'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=arti_titulo' . $url, true);
		$data['sort_text'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=text' . $url, true);
		$data['sort_marketplace'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=marketplace' . $url, true);
		$data['sort_status'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=status' . $url, true);
		$data['sort_arti_foto'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . '&sort=arti_foto' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $mlconsulta_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($mlconsulta_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($mlconsulta_total - $this->config->get('config_limit_admin'))) ? $mlconsulta_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $mlconsulta_total, ceil($mlconsulta_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->load->model('admdirsis/preyfirma');
		$filter_premensaje = array(	'filter_aplica' => '2', 'filter_estado' => '1');
		$bienvenidaactivo =$this->model_admdirsis_preyfirma->getPreyfirmas($filter_premensaje);		
		if ($bienvenidaactivo){
			$data['bienvenidaactivo'] = $bienvenidaactivo[0]['name'];
		}

		$filter_premensaje = array(	'filter_aplica' => '2');
		$data['bienvenidas'] = $this->model_admdirsis_preyfirma->getPreyfirmas($filter_premensaje);		
		$filter_premensaje = array(	'filter_aplica' => '1');
		$data['premensajes'] = $this->model_admdirsis_preyfirma->getPreyfirmas($filter_premensaje);
		
		$filter_premensaje = array(	'filter_aplica' => '0', 'filter_estado' => '1');
		$prefirmas=$this->model_admdirsis_preyfirma->getPreyfirmas($filter_premensaje);
		if ($prefirmas){
			$data['firmaactivo'] = $prefirmas[0]['name'];
		}
		$filter_premensaje = array(	'filter_aplica' => '0');
		$data['prefirmas'] = $this->model_admdirsis_preyfirma->getPreyfirmas($filter_premensaje);
		
		
		
		
		$data['filter_id']=$filter_id;
		$data['filter_marketplace']=$filter_marketplace;
		$data['filter_status']=$filter_status;
		$data['filter_date_added']=$filter_date_added;
		
		
		
		$this->response->setOutput($this->load->view('admdirsis/mlconsulta_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['mlconsulta_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['id'])) {
			$data['error_id'] = $this->error['id'];
		} else {
			$data['error_id'] = '';
		}
		
		if (isset($this->error['estado'])) {
			$data['error_estado'] = $this->error['estado'];
		} else {
			$data['error_estado'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['mlconsulta_id'])) {
			$data['action'] = $this->url->link('admdirsis/mlconsulta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/mlconsulta/edit', 'user_token=' . $this->session->data['user_token'] . '&mlconsulta_id=' . $this->request->get['mlconsulta_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/mlconsulta', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['mlconsulta_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$mlconsulta_info = $this->model_admdirsis_mlconsulta->getMlconsulta($this->request->get['mlconsulta_id']);
		}

		if (isset($this->request->post['id'])) {
			$data['id'] = $this->request->post['id'];
		} elseif (!empty($mlconsulta_info)) {
			$data['id'] = $mlconsulta_info['id'];
		} else {
			$data['id'] = '';
		}
		
		if (isset($this->request->post['fecha'])) {
			$data['fecha'] = $this->request->post['fecha'];
		} elseif (!empty($mlconsulta_info)) {
			$data['fecha'] = $mlconsulta_info['fecha'];
		} else {
			$data['fecha'] = '';
		}			

		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($mlconsulta_info['permission']['access'])) {
			$data['access'] = $mlconsulta_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($mlconsulta_info['permission']['modify'])) {
			$data['modify'] = $mlconsulta_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/mlconsulta_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/mlconsulta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['id']) < 3) || (utf8_strlen($this->request->post['id']) > 64)) {
			$this->error['id'] = $this->language->get('error_id');
		}
		
		return !$this->error;
	}	

	public function autocomplete() {	
		$json = array();

		if (isset($this->request->get['filter_id'])) {
			if (isset($this->request->get['filter_id'])) {
				$filter_id = $this->request->get['filter_id'];
			} else {
				$filter_id = '';
			}

			$this->load->model('admdirsis/mlconsulta');

			$filter_data = array(
				'filter_id'      => $filter_id,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_mlconsulta->getMlconsultas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'mlconsulta_id' => $result['mlconsulta_id'],
					'id'     => strip_tags(html_entity_decode($result['id'], ENT_QUOTES, 'UTF-8')),
					'fecha'    => $result['fecha']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['id'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function historico_preguntador() {
		$json = array();
		if (isset($this->request->get['clien_id'])) {
			$clien_id=$this->request->get['clien_id'];
		}else{
			$clien_id='';
		}
		if (isset($this->request->get['item_id'])) {
			$item_id=$this->request->get['item_id'];
		}else{
			$item_id='';
		}
		if (isset($this->request->get['esteno'])) {
			$esteno=$this->request->get['esteno'];
		}else{
			$esteno='';
		}		
		$this->load->model('admdirsis/mlconsulta');
		$filter_data = array(
			'filter_clien_id'      => $clien_id,
			'filter_item_id'      => $item_id,
			'esteno'		=> $esteno,
			'order_campo' => ' FECHA DESC, id',
			'order' => 'DESC'
		);
		$results = $this->model_admdirsis_mlconsulta->getMlconsultas($filter_data);
/*			foreach ($results as $result) {
			$json[] = array(
				'mlconsulta_id' => $result['mlconsulta_id'],
				'id'     => strip_tags(html_entity_decode($result['id'], ENT_QUOTES, 'UTF-8')),
				'fecha'    => $result['fecha'],

			);
		}*/
		$json=$results;
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function responderconsulta() {
		$resultado='0';
		if (isset($this->request->get['id'])) {
			$id=$this->request->get['id'];
			$mlconsulta_id=$this->request->get['mlconsulta_id'];
			$respuesta=$this->request->get['respuesta'];
			
			$this->load->model('admdirsis/mlconsulta');
			$results = $this->model_admdirsis_mlconsulta->getMlconsulta($mlconsulta_id);
			if ($results){
				$this->load->model('admdirsis/plataforma');
				$plataforma = $this->model_admdirsis_plataforma->getPlataforma($results['plataforma_id']);
				$data = array(
					'id' => $id,
					'respuesta' => $respuesta,
					'marketplace' => $plataforma['marketplace'],
					'client_id' => $plataforma['client_id'],
					'token_id' => $plataforma['token_id'],
					'secret_id' => $plataforma['secret_id']
				);
				$resultado = $this->model_admdirsis_mlconsulta->getResponderConsulta($data);
			}
		}
		echo $resultado;
	}
	
	public function leermensajes() {
		$json = ' Se revisaron: ';
		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		//print_r($results);
		foreach ($results as $result) {
			if ($result['estado'] == '1'){
				$this->load->model('admdirsis/mlconsulta');
				$results2 = $this->model_admdirsis_mlconsulta->getLeermensajes($result);
				$json.= 'MK:'.$result['marketplace'].'->revisados='.$results2;
			}else{
				$json.= 'MK:'.$result['marketplace'].'->desactivada';
			}
		}
		echo $json;
	}
	public function buscarmetricas() {
		$filter_data = array(
			'filter_code'  => 'MELI'
		);		
		$json=array();
		$this->load->model('admdirsis/plataforma');
		$results = $this->model_admdirsis_plataforma->getPlataformas($filter_data);
		foreach ($results as $result) {
			$this->load->model('admdirsis/mlconsulta');
			$results2 = $this->model_admdirsis_mlconsulta->getBuscarMetricas($result);
			
			if (isset($results2['thumbnail']['picture_url'])){
				$foto=$results2['thumbnail']['picture_url'];
			}else{
				$foto="";
			}
			
			$json[] = array(
			'marketplace' => $result['marketplace'],
		    'experiencia' => $results2['seller_experience'],
			'nivelcolor' => $results2['seller_reputation']['level_id'],
			'power' 	 => $results2['seller_reputation']['power_seller_status'],
			'oper_canc' => $results2['seller_reputation']['transactions']['canceled'],
			'oper_comp' => $results2['seller_reputation']['transactions']['completed'],
			'rati_nega' => $results2['seller_reputation']['transactions']['ratings']['negative'],
			'rati_neut' => $results2['seller_reputation']['transactions']['ratings']['neutral'],
			'rati_posi' => $results2['seller_reputation']['transactions']['ratings']['positive'],
			'ventas' => $results2['seller_reputation']['metrics']['sales']['period']."/".$results2['seller_reputation']['metrics']['sales']['completed'],
			'reclamo' => $results2['seller_reputation']['metrics']['claims']['period']."/".$results2['seller_reputation']['metrics']['claims']['rate']."/".$results2['seller_reputation']['metrics']['claims']['value'],
			'retraso' => $results2['seller_reputation']['metrics']['delayed_handling_time']['period']."/".$results2['seller_reputation']['metrics']['delayed_handling_time']['rate']."/".$results2['seller_reputation']['metrics']['delayed_handling_time']['value'],
			'cancelo' => $results2['seller_reputation']['metrics']['cancellations']['period']."/".$results2['seller_reputation']['metrics']['cancellations']['rate']."/".$results2['seller_reputation']['metrics']['cancellations']['value'],
			'foto' => $foto);
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	

}