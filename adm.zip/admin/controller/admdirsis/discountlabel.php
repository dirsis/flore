<?php
class ControllerAdmdirsisDiscountlabel extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/discountlabel');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('admdirsis/discountlabel');
		$this->getForm();
	}

	public function edit() {
		$this->load->model('admdirsis/discountlabel');
		if ($this->request->server['REQUEST_METHOD'] == 'POST') {
			
			$this->model_admdirsis_discountlabel->editDiscountlabel($this->request->post);
			$this->load->language('admdirsis/discountlabel');
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('admdirsis/discountlabel', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getForm();
	}
	protected function getForm() {
		$data['text_form'] = $this->language->get('text_edit');
		$url = '';
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/discountlabel', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		$data['action'] = $this->url->link('admdirsis/discountlabel/edit', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['user_token'] = $this->session->data['user_token'];
		
		$this->load->model('admdirsis/discountlabel');
		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$discountlabel=$this->model_admdirsis_discountlabel->getDiscountlabel();
			//die;
			//print_r($discountlabel);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($discountlabel)) {
			$data['image'] = $discountlabel['image'];
		} else {
			$data['image'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($discountlabel) && $discountlabel['image'] && is_file(DIR_IMAGE . $discountlabel['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($discountlabel['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['oferta'])) {
			$data['oferta'] = $this->request->post['oferta'];
		} elseif (!empty($discountlabel)) {
			$data['oferta'] = $discountlabel['oferta'];
		} else {
			$data['oferta'] = 0;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($discountlabel)) {
			$data['status'] = $discountlabel['status'];
		} else {
			$data['status'] = 1;
		}		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/discountlabel_form', $data));
	}
}