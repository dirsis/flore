<?php
class ControllerAdmdirsisEncuesta extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		$this->getList();
	}

	public function add() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_admdirsis_encuesta->addEncuesta($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_admdirsis_encuesta->editEncuesta($this->request->get['encuesta_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function clear() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		$this->model_admdirsis_encuesta->clearEncuesta();

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$this->response->redirect($this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		
		$this->getList();
	}
	
	public function delete() {
		$this->load->language('admdirsis/encuesta');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('admdirsis/encuesta');

		if (isset($this->request->post['selected'])) {
			foreach ($this->request->post['selected'] as $encuesta_id) {
				$this->model_admdirsis_encuesta->deleteEncuesta($encuesta_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'tema';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('admdirsis/encuesta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['clear'] = $this->url->link('admdirsis/encuesta/clear', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('admdirsis/encuesta/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['encuestas'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$encuesta_total = $this->model_admdirsis_encuesta->getTotalEncuestas();

		$results = $this->model_admdirsis_encuesta->getEncuestas($filter_data);

		foreach ($results as $result) {
			$data['encuestas'][] = array(
				'encuesta_id' => $result['encuesta_id'],
				'tema'          => $result['tema'],
				'referencia'    => $result['referencia'],
				'recorrido'    => $result['recorrido'],
				'respuesta'     => $this->model_admdirsis_encuesta->getTotalEncuestahistorial($result['encuesta_id']),
				'estado'          => $result['estado'],
				'edit'          => $this->url->link('admdirsis/encuesta/edit', 'user_token=' . $this->session->data['user_token'] . '&encuesta_id=' . $result['encuesta_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_tema'] = $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . '&sort=tema' . $url, true);
		$data['sort_respuesta'] = $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . '&sort=respuesta' . $url, true);
		$data['sort_estado'] = $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $encuesta_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($encuesta_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($encuesta_total - $this->config->get('config_limit_admin'))) ? $encuesta_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $encuesta_total, ceil($encuesta_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/encuesta_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['encuesta_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['tema'])) {
			$data['error_tema'] = $this->error['tema'];
		} else {
			$data['error_tema'] = '';
		}
		
		if (isset($this->error['codigo'])) {
			$data['error_codigo'] = $this->error['codigo'];
		} else {
			$data['error_codigo'] = '';
		}		
		
		if (isset($this->error['respuesta'])) {
			$data['error_respuesta'] = $this->error['respuesta'];
		} else {
			$data['error_respuesta'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['encuesta_id'])) {
			$data['action'] = $this->url->link('admdirsis/encuesta/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('admdirsis/encuesta/edit', 'user_token=' . $this->session->data['user_token'] . '&encuesta_id=' . $this->request->get['encuesta_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('admdirsis/encuesta', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['encuesta_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$encuesta_info = $this->model_admdirsis_encuesta->getEncuesta($this->request->get['encuesta_id']);
		}

		if (isset($this->request->post['tema'])) {
			$data['tema'] = $this->request->post['tema'];
		} elseif (!empty($encuesta_info)) {
			$data['tema'] = $encuesta_info['tema'];
		} else {
			$data['tema'] = '';
		}
		
		if (isset($this->request->post['codigo'])) {
			$data['codigo'] = $this->request->post['codigo'];
		} elseif (!empty($encuesta_info)) {
			$data['codigo'] = $encuesta_info['codigo'];
		} else {
			$data['codigo'] = '';
		}		
		
		if (isset($this->request->post['respuesta'])) {
			$data['respuesta'] = $this->request->post['respuesta'];
		} elseif (!empty($encuesta_info)) {
			$data['respuesta'] = $encuesta_info['respuesta'];
		} else {
			$data['respuesta'] = '';
		}		
		
		if (isset($this->request->post['referencia'])) {
			$data['referencia'] = $this->request->post['referencia'];
		} elseif (!empty($encuesta_info)) {
			$data['referencia'] = $encuesta_info['referencia'];
		} else {
			$data['referencia'] = '';
		}		
		
		if (isset($this->request->post['estado'])) {
			$data['estado'] = $this->request->post['estado'];
		} elseif (!empty($encuesta_info)) {
			$data['estado'] = $encuesta_info['estado'];
		} else {
			$data['estado'] = '';
		}		

		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($encuesta_info['permission']['access'])) {
			$data['access'] = $encuesta_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($encuesta_info['permission']['modify'])) {
			$data['modify'] = $encuesta_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('admdirsis/encuesta_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'admdirsis/encuesta')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['tema']) < 3) || (utf8_strlen($this->request->post['tema']) > 64)) {
			$this->error['tema'] = $this->language->get('error_tema');
		}
				
/*
		if ((utf8_strlen($this->request->post['estado']) < 3) || (utf8_strlen($this->request->post['estado']) > 64)) {
			$this->error['estado'] = $this->language->get('error_estado');
		}		
*/		

		return !$this->error;
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_tema'])) {
			if (isset($this->request->get['filter_tema'])) {
				$filter_tema = $this->request->get['filter_tema'];
			} else {
				$filter_tema = '';
			}

			$this->load->model('admdirsis/encuesta');

			$filter_data = array(
				'filter_tema'      => $filter_tema,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_admdirsis_encuesta->getEncuestas($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'encuesta_id' => $result['encuesta_id'],
					'tema'     => strip_tags(html_entity_decode($result['tema'], ENT_QUOTES, 'UTF-8')),
					'respuesta'    => $result['respuesta'],
					'estado'    => $result['estado']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['tema'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}