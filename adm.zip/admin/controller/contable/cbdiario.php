<?php
class ControllerContableCbdiario extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('contable/cbdiario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('contable/cbasiento');

		$this->getList();
	}

	public function add() {
		$this->load->language('contable/cbdiario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('contable/cbasiento');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_contable_cbasiento->addCbasiento($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}				

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('contable/cbdiario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('contable/cbasiento');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_contable_cbasiento->editCbasiento($this->request->get['cbasiento_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . $this->request->get['filter_name'];
			}			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('contable/cbdiario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('contable/cbasiento');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $cbasiento_id) {
				$this->model_contable_cbasiento->deleteCbasiento($cbasiento_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	public function repair() {
		$this->load->language('contable/cbdiario');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('contable/cbasiento');

		if ($this->validateRepair()) {
			$this->model_contable_cbasiento->repairCbasientos();

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = '';
		}		
		if (isset($this->request->get['filter_cbplan_id'])) {
			$filter_cbplan_id = $this->request->get['filter_cbplan_id'];
		} else {
			$filter_cbplan_id = '';
		}		
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'code';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}	
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}	
		if (isset($this->request->get['filter_cbplan_id'])) {
			$url .= '&filter_cbplan_id=' . $this->request->get['filter_cbplan_id'];
		}
			
		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('contable/cbdiario/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('contable/cbdiario/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['repair'] = $this->url->link('contable/cbdiario/repair', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['cbasientos'] = array();
		
		$filter_data = array(
			'filter_name'	  => $filter_name,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$cbasiento_total = $this->model_contable_cbasiento->getTotalCbasientos();

		$results = $this->model_contable_cbasiento->getCbasientos($filter_data);

		
		foreach ($results as $result) {
			$data['cbasientos'][] = array(
				'cbasiento_id' => $result['cbasiento_id'],
				'name'        => $result['name'],
				'date_added'        => date("d-m-Y",strtotime($result['date_added'])),
				'total'        => $result['total'],
				'sort_order'  => $result['sort_order'],
				'edit'        => $this->url->link('contable/cbdiario/edit', 'user_token=' . $this->session->data['user_token'] . '&cbasiento_id=' . $result['cbasiento_id'] . $url, true),
				'delete'      => $this->url->link('contable/cbdiario/delete', 'user_token=' . $this->session->data['user_token'] . '&cbasiento_id=' . $result['cbasiento_id'] . $url, true)
			);
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		$data['sort_id'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . '&sort=cbasiento_id' . $url, true);
		
		$data['sort_code'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . '&sort=c.code' . $url, true);		
		
		$data['sort_name'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . '&sort=c.name' . $url, true);
		$data['sort_parent_id'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . '&sort=c.parent_id' . $url, true);		
		$data['sort_sort_order'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . '&sort=sort_order' . $url, true);
		
		$url = '';

		if (isset($filter_name)) {
			$url .= '&filter_name=' . $filter_name;
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $cbasiento_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($cbasiento_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($cbasiento_total - $this->config->get('config_limit_admin'))) ? $cbasiento_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $cbasiento_total, ceil($cbasiento_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('contable/cbasiento_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['cbasiento_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}

		if (isset($this->error['parent'])) {
			$data['error_parent'] = $this->error['parent'];
		} else {
			$data['error_parent'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['cbasiento_id'])) {
			$data['action'] = $this->url->link('contable/cbdiario/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('contable/cbdiario/edit', 'user_token=' . $this->session->data['user_token'] . '&cbasiento_id=' . $this->request->get['cbasiento_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('contable/cbdiario', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['cbasiento_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$cbasiento_info = $this->model_contable_cbasiento->getCbasiento($this->request->get['cbasiento_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($cbasiento_info)) {
			$data['name'] = $cbasiento_info['name'];
		} else {
			$data['name'] = '';
		}	
		
		if (isset($this->request->post['code'])) {
			$data['code'] = $this->request->post['code'];
		} elseif (!empty($cbasiento_info)) {
			$data['code'] = $cbasiento_info['code'];
		} else {
			$data['code'] = '';
		}			
			

		if (isset($this->request->post['parent_id'])) {
			$data['parent_id'] = $this->request->post['parent_id'];
		} elseif (!empty($cbasiento_info)) {
			$data['parent_id'] = $cbasiento_info['parent_id'];
		} else {
			$data['parent_id'] = 0;
		}
		

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (!empty($cbasiento_info)) {
			$data['sort_order'] = $cbasiento_info['sort_order'];
		} else {
			$data['sort_order'] = 0;
		}
		
		if (isset($this->request->post['type'])) {
			$data['type'] = $this->request->post['type'];
		} elseif (!empty($cbasiento_info)) {
			$data['type'] = $cbasiento_info['type'];
		} else {
			$data['type'] = 0;
		}		

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($cbasiento_info)) {
			$data['status'] = $cbasiento_info['status'];
		} else {
			$data['status'] = true;
		}
		


		$this->load->model('design/layout');

		$data['layouts'] = $this->model_design_layout->getLayouts();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
			
		$this->response->setOutput($this->load->view('contable/cbasiento_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'contable/cbasiento')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

/*		
		if (empty($this->request->post['name'])) {
			$this->error['name'] = $this->language->get('error_name');
		}
*/
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'contable/cbasiento')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateRepair() {
		if (!$this->user->hasPermission('modify', 'contable/cbasiento')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('contable/cbplan');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'filter_type' => $this->request->get['filter_type'],
				'sort'        => 'name',
				'order'       => 'ASC',
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_contable_cbplan->getCbplans($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'cbplan_id' => $result['cbplan_id'],
					'name'		=> html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	

	
	

}
