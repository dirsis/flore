<?php
class ControllerContableCbbalance extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('contable/cbbalance');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('contable/cbbalance');
		$this->getList();
	}
	protected function getList() {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		if (isset($this->request->get['filter_date_desde'])) {
			$filter_date_desde = $this->request->get['filter_date_desde'];
		} else {
			$filter_date_desde = '';
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$filter_date_hasta = $this->request->get['filter_date_hasta'];
		} else {
			$filter_date_hasta = '';
		}		
		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}	
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('contable/cbbalance', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['cbbalances'] = array();
		
		
		$this->load->model('contable/cbplan');
		$filter_data = array(
			'sort'  => "c.cbplan_id",
			'order' => "ASCE"
		);
		$results = $this->model_contable_cbplan->getCbplans($filter_data);		
		foreach ($results as $result) {
			$filter_data = array(
				'filter_cbplan_id'   => $result['cbplan_id'],
				'filter_date_desde'	  => $filter_date_desde,
				'filter_date_hasta'	  => $filter_date_hasta
			);
			$resulto=$this->model_contable_cbbalance->getCbplanTotal($filter_data);
			$data['cbbalances'][] = array(
				'cbplan_id' 	=> $result['cbplan_id'],
				'code' 			=> $result['code'],
				'name'        	=> $result['name'],
				'debe'        	=> $resulto['debe'],
				'haber'        	=> $resulto['haber']
			);
		}
		$data['user_token'] = $this->session->data['user_token'];
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		$url = '';
		if (isset($this->request->get['filter_date_desde'])) {
			$url .= '&filter_date_desde=' . $this->request->get['filter_date_desde'];
		}
		if (isset($this->request->get['filter_date_hasta'])) {
			$url .= '&filter_date_hasta=' . $this->request->get['filter_date_hasta'];
		}	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('contable/cbbalance_list', $data));
	}

}
