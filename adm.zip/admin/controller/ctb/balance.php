<?php
class ControllerCtbBalance extends Controller {
	private $error = array();

	public function index() {

		$this->load->language('ctb/balance');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ctb/balance');
		$this->getList();
	}
	
	public function filtrar($get){
		$url = '';
		
		if (isset($get['filter_cuenta_id'])) {
			$url .= '&filter_cuenta_id=' . urlencode(html_entity_decode($get['filter_cuenta_id'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($get['filter_modulo_id'])) {
			$url .= '&filter_modulo_id=' . urlencode(html_entity_decode($get['filter_modulo_id'], ENT_QUOTES, 'UTF-8'));
		}
		if (isset($get['filter_asiento_id'])) {
			$url .= '&filter_asiento_id=' . urlencode(html_entity_decode($get['filter_asiento_id'], ENT_QUOTES, 'UTF-8'));
		}		

		if (isset($get['filter_descrip'])) {
			$url .= '&filter_descrip=' . urlencode(html_entity_decode($get['filter_descrip'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}

		if (isset($get['filter_date_ini'])) {
			$url .= '&filter_date_ini=' . $get['filter_date_ini'];
		}
		if (isset($get['filter_date_fin'])) {
			$url .= '&filter_date_fin=' . $get['filter_date_fin'];
		}

		if (isset($get['sort'])) {
			$url .= '&sort=' . $get['sort'];
		}

		if (isset($get['order'])) {
			$url .= '&order=' . $get['order'];
		}

		if (isset($get['page'])) {
			$url .= '&page=' . $get['page'];
		}
		
		if (isset($get['limit'])) {
			$url .= '&limit=' . $get['limit'];
		}else{
			$url .= '&limit=' . $this->config->get('config_limit_admin');
		}		
		
		return $url;
	}


	protected function getList() {
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		

		if (isset($this->request->get['filter_asiento_id'])) {
			$filter_asiento_id = $this->request->get['filter_asiento_id'];
		} else {
			$filter_asiento_id = '';
		}
		if (isset($this->request->get['filter_modulo_id'])) {
			$filter_modulo_id = $this->request->get['filter_modulo_id'];
		} else {
			$filter_modulo_id = '';
		}		
		if (isset($this->request->get['filter_cuenta_id'])) {
			$filter_cuenta_id = $this->request->get['filter_cuenta_id'];
		} else {
			$filter_cuenta_id = '';
		}		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}
		if (isset($this->request->get['filter_date_ini'])) {
			$filter_date_ini = date("d-m-Y",strtotime($this->request->get['filter_date_ini']));
		} else {
			$filter_date_ini = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'fecha';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get);

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ctb/balance', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		

		$data['asientos'] = array();
		
		$filter_cuentas = array();
		$this->load->model('ctb/cuenta');
		if ($filter_cuenta_id){
			$arbols=$this->model_ctb_cuenta->getArbol($filter_cuenta_id);
			foreach ($arbols as $arbol) {
				$filter_cuentas[]=$arbol['cuenta_id'];
			}
		}
		

		$filter_data = array(
			'filter_cuenta_id'          => $filter_cuenta_id,
			'filter_modulo_id'          => $filter_modulo_id,
			'filter_date_ini'        	=> $filter_date_ini,
			'filter_date_fin'        	=> $filter_date_fin,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		
	
		
		$results = $this->model_ctb_balance->getBalances2($filter_data);
		$acum=0;
		foreach ($results as $result) {
			
			$filter_datasa = array(
				'filter_cuenta_id'          => $result['cuenta_id'],
				'filter_modulo_id'          => $filter_modulo_id,
				'filter_date_ini'        	=> $filter_date_ini,
				'filter_date_fin'        	=> $filter_date_fin,
				'sort'                     => $sort,
				'order'                    => $order,
				'start'                    => ($page - 1) * $limit,
				'limit'                    => $limit
			);			
			$sa=$this->model_ctb_balance->getBalances2sa($filter_datasa);
				
			$acum=$acum+($sa['debe']+$result['debe'])-($sa['haber']+$result['haber']);
			$data['asientos'][] = array(
				'codigo'           	=> $result['codigo'],
				'cuenta_id'    		=> $result['cuenta_id'],
				'cuenta'          	=> $result['cuenta'],
				'sadebe'       		=> $sa['debe'],
				'sahaber'          	=> $sa['haber'],
				'debe'       		=> $result['debe'],
				'haber'          	=> $result['haber'],
				"deudor" 			=> $result['debe']-$result['haber']<0?0:$result['haber']-$result['debe'],
				"acreedor" 			=> $result['debe']-$result['haber']<0?0:$result['debe']-$result['haber'],
				'saldo'          	=> ($sa['debe']+$result['debe'])-($sa['haber']+$result['haber']),
				'acum'          	=> $acum,
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$data['filter_cuenta_id'] = $filter_cuenta_id;
		$data['filter_modulo_id'] = $filter_modulo_id;
		$data['filter_descrip'] = $filter_descrip;
		$data['filter_status'] = $filter_status;
		$data['filter_date_ini'] = $filter_date_ini;
		$data['filter_date_fin'] = $filter_date_fin;

		$this->load->model('ctb/modulo');
		$data['modulos'] = $this->model_ctb_modulo->getModulos(array());

		$this->load->model('ctb/cuenta');
		$data['cuentas'] = $this->model_ctb_cuenta->getCuentas(array());
		
		
		$this->load->model('ctb/ejercicio');
		$data['eactivo']=$this->model_ctb_ejercicio->getEjercicio_activo();
		$data['eactivo_text']="Ejercicio ACTIVO (".date("d-m-Y",strtotime($data['eactivo']['date_desde']))." al ".date("d-m-Y",strtotime($data['eactivo']['date_hasta'])).")";
		
		
		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ctb/balance_list', $data));
	}
		
	public function download_xlsx() {
		
		

		
	
		if (isset($this->request->get['filter_asiento_id'])) {
			$filter_asiento_id = $this->request->get['filter_asiento_id'];
		} else {
			$filter_asiento_id = '';
		}

		if (isset($this->request->get['filter_cuenta_id'])) {
			$filter_cuenta_id = $this->request->get['filter_cuenta_id'];
		} else {
			$filter_cuenta_id = '';
		}
		if (isset($this->request->get['filter_modulo_id'])) {
			$filter_modulo_id = $this->request->get['filter_modulo_id'];
		} else {
			$filter_modulo_id = '';
		}
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		
		if (isset($this->request->get['filter_date_ini'])) {
			$filter_date_ini = date("d-m-Y",strtotime($this->request->get['filter_date_ini']));
		} else {
			$filter_date_ini = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}
		
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'cuenta_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['asientos'] = array();
		
		$filter_data = array(
			'filter_asiento_id'           => $filter_asiento_id,
			'filter_cuenta_id'           => $filter_cuenta_id,
			'filter_modulo_id'           => $filter_modulo_id,
			'filter_descrip'           => $filter_descrip,
			'filter_status'            => $filter_status,
			'filter_date_ini'        	=> $filter_date_ini,
			'filter_date_fin'        	=> $filter_date_fin,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		
		$this->load->model('ctb/balance');
		$results = $this->model_ctb_balance->getBalances2($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/balance_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "Cuenta")
					->setCellValue('B'.$row,  "Descripcion")
					->setCellValue('C'.$row,  "Debe")
					->setCellValue('D'.$row,  "Haber")
					->setCellValue('E'.$row,  "Deudor")
					->setCellValue('F'.$row,  "Acreedor")
					->setCellValue('G'.$row,  "Saldo")
					->setCellValue('H'.$row,  "Acumulado");
		$row++;	
		$xacum=0;
		$xid=0;
		foreach ($results as $result) {
			$xacum=$xacum+$result['debe']-$result['haber'];
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['codigo'])
					->setCellValue('B'.$row,  $result['cuenta'])
					->setCellValue('C'.$row,  $result['debe']) 
					->setCellValue('D'.$row,  $result['haber'])
					->setCellValue('E'.$row,  $result['debe']-$result['haber']<0?0:$result['haber']-$result['debe'])
					->setCellValue('F'.$row,  $result['debe']-$result['haber']<0?0:$result['debe']-$result['haber'])
					->setCellValue('G'.$row,  $result['debe']-$result['haber'])
					->setCellValue('H'.$row,  $xacum);

			$row++;

		}
		foreach(range('A','H') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function download_pdf() {
		
		
		error_reporting(E_ALL);
		ini_set('display_errors', '1');	
		
	
		if (isset($this->request->get['filter_asiento_id'])) {
			$filter_asiento_id = $this->request->get['filter_asiento_id'];
		} else {
			$filter_asiento_id = '';
		}

		if (isset($this->request->get['filter_cuenta_id'])) {
			$filter_cuenta_id = $this->request->get['filter_cuenta_id'];
		} else {
			$filter_cuenta_id = '';
		}
		if (isset($this->request->get['filter_modulo_id'])) {
			$filter_modulo_id = $this->request->get['filter_modulo_id'];
		} else {
			$filter_modulo_id = '';
		}
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		
		if (isset($this->request->get['filter_date_ini'])) {
			$filter_date_ini = date("d-m-Y",strtotime($this->request->get['filter_date_ini']));
		} else {
			$filter_date_ini = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}
		
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'cuenta_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['asientos'] = array();
		
		$filter_data = array(
			'filter_asiento_id'           => $filter_asiento_id,
			'filter_cuenta_id'           => $filter_cuenta_id,
			'filter_modulo_id'           => $filter_modulo_id,
			'filter_descrip'           => $filter_descrip,
			'filter_status'            => $filter_status,
			'filter_date_ini'        	=> $filter_date_ini,
			'filter_date_fin'        	=> $filter_date_fin,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		
		$this->load->model('ctb/balance');
		$results = $this->model_ctb_balance->getBalances2($filter_data);
		
		$archivo = "dirsis/download/balance_".uniqid().".pdf";
		
		if (file_exists($archivo)){
			unlink($archivo);
		}
		
		
		$this->load->model('setting/setting');
		$store_fantasia = $this->config->get('config_owner');
		$store_name = $this->config->get('config_name');
		$store_image = $this->config->get('config_image');
		$store_address = html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8');
		$store_email = $this->config->get('config_email');
		$store_telephone = $this->config->get('config_telephone');
		$store_fax = $this->config->get('config_fax');
			
		require('dirsis/fpdf.php');
		$pdf = new FPDF();
		$pdf->SetTitle("BALANCE", true);
		$pdf->AliasNbPages();
		$pdf->AddPage('L');
		
			$pdf->Image("../image/".$store_image,15,8,50);
			$pdf->SetFont('Arial','B',12);
			$pdf->Cell(90);
			$pdf->Cell(90,15,"BALANCE DE SUMA Y SALDO",1,0,'C');
			$pdf->Ln(16);
		
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(20,7,"Cuenta",0,0,'L');
		$pdf->Cell(100,7,"Descripcion",0,0,'L');
		$pdf->Cell(25,7,"Debe",0,0,'R');
		$pdf->Cell(25,7,"Haber",0,0,'R');
		$pdf->Cell(25,7,"Deudor",0,0,'R');
		$pdf->Cell(25,7,"Acreedor",0,0,'R');
		$pdf->Cell(25,7,"Saldo",0,0,'R');
		$pdf->Cell(25,7,"Acumulado",0,0,'R');
		$pdf->Ln();

		$xacum=$xid=0;
		
		foreach ($results as $result) {
			$xacum=$xacum+$result['debe']-$result['haber'];
			$pdf->SetFont('Arial','',9);
			$pdf->Cell(20,7,$result['codigo'],0,0,'L');
			$pdf->Cell(100,7,$result['cuenta'],0,0,'L');
			$pdf->Cell(25,7,number_format($result['debe'],2,",","."),0,0,'R');
			$pdf->Cell(25,7,number_format($result['haber'],2,",","."),0,0,'R');
			$pdf->Cell(25,7,number_format($result['debe']-$result['haber']<0?0:$result['haber']-$result['debe'],2,",","."),0,0,'R');
			$pdf->Cell(25,7,number_format($result['debe']-$result['haber']<0?0:$result['debe']-$result['haber'],2,",","."),0,0,'R');
			$pdf->Cell(25,7,number_format($result['debe']-$result['haber'],2,",","."),0,0,'R');
			$pdf->Cell(25,7,number_format($xacum,2,",","."),0,0,'R');
			$pdf->Ln();
		}
		$pdf->Output($archivo,'I');
		//echo $archivo;
		//FIN PDF
		
	}		
	
}