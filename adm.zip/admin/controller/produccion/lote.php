<?php
class ControllerProduccionLote extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/lote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/lote');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_produccion_lote->bajaLote();
		$this->model_produccion_lote->creaLote();
		//			
		$this->getList();
	}
	public function reinicia(){
		$this->load->language('produccion/lote');
		$this->load->model('produccion/lote');
		$this->model_produccion_lote->bajaLote();
		$this->model_produccion_lote->creaLote();
		//$this->model_produccion_lote->traeLote();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_lote_id'])) {
			$url .= '&filter_lote_id=' . $get['filter_lote_id'];
		}
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		if (isset($get['filter_lotecode'])) {
			$url .= '&filter_lotecode=' . $get['filter_lotecode'];
		}		
		
		if (isset($get['filter_proceso_id'])) {
			$url .= '&filter_proceso_id=' . $get['filter_proceso_id'];
		}		
		
		if (isset($get['filter_proceso'])) {
			$url .= '&filter_proceso=' . get['filter_proceso'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/lote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/lote');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_produccion_lote->addLote($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('produccion/lote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/lote');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->model_produccion_lote->editLote($this->request->get['lote_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/lote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/lote');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $lote_id) {
				$this->model_produccion_lote->deleteLote($lote_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	
	public function copy() {
		$this->load->language('produccion/lote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/lote');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $lote_id) {
				$this->model_produccion_lote->copyLote($lote_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_lote_id'])) {
			$filter_lote_id = $this->request->get['filter_lote_id'];
		} else {
			$filter_lote_id = '';
		}
		
		if (isset($this->request->get['filter_date_ini'])) {
			$filter_date_ini = date("d-m-Y",strtotime($this->request->get['filter_date_ini']));
		} else {
			$filter_date_ini = '';
		}		

		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}		
		
		if (isset($this->request->get['filter_lotecode'])) {
			$filter_lotecode = $this->request->get['filter_lotecode'];
		} else {
			$filter_lotecode = '';
		}		
		
		if (isset($this->request->get['filter_proceso_id'])) {
			$filter_proceso_id = $this->request->get['filter_proceso_id'];
		} else {
			$filter_proceso_id = '';
		}		
		
		if (isset($this->request->get['filter_proceso'])) {
			$filter_proceso = $this->request->get['filter_proceso'];
		} else {
			$filter_proceso = '';
		}				
		

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/lote/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/lote/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/lote/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['lotes'] = array();
		$filter_data = array(
			'filter_lote_id'           => $filter_lote_id,
			'filter_status'            => $filter_status,
			'filter_lotecode'            => $filter_lotecode,
			'filter_proceso_id'            => $filter_proceso_id,
			'filter_proceso'            => $filter_proceso,
			'filter_date_ini'         => $filter_date_ini,
			'filter_date_fin'          => $filter_date_fin,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$lote_total = $this->model_produccion_lote->getTotalLotes($filter_data);

		$this->load->model('user/user');
		$results = $this->model_produccion_lote->getLotes($filter_data);
		$calculo=0;
		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['lotes'][] = array(
				'lote_id'    		=> $result['lote_id'],
				'accion_id'    		=> $result['accion_id'],
				'accion'    		=> $result['accion_id']==1?"IN":"OUT",
				'otpr_item_id'    	=> $result['otpr_item_id'],
				'ot_id'    		=> $result['ot_id'],
				'otpr_id'    		=> $result['otpr_id'],
				'product_id'    	=> $result['product_id'],
				'codigo'    		=> $result['codigo'],
				'product'    		=> $result['product'],
				'proceso_id'    	=> $result['proceso_id'],
				'proceso'    		=> $result['proceso'],
				'cantidad'    		=> number_format($result['cantidad'],2,",","."),
				'calculo'    		=> number_format($result['cantidad']*($result['accion_id']==1?1:-1),2,",","."),
				'lotecode'    		=> $result['lotecode'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('produccion/lote/edit', 'user_token=' . $this->session->data['user_token'] . '&lote_id=' . $result['lote_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/lote/clonar', 'user_token=' . $this->session->data['user_token'] . '&lote_id=' . $result['lote_id'] . $url, true)				
			);
			$calculo=$calculo+($result['cantidad']*($result['accion_id']==1?1:-1));
		}
		$data['calculo']=number_format($calculo,2,",",".");
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_lote_id'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=lote_id' . $url, true);
		
		$data['sort_codigo'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=codigo' . $url, true);
		
		$data['sort_accion_id'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.accion_id' . $url, true);		
		$data['sort_otpr_id'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.otpr_id' . $url, true);
		$data['sort_product_id'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.product_id' . $url, true);
		$data['sort_proceso_id'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.proceso_id' . $url, true);
		$data['sort_cantidad'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=cantidad' . $url, true);
		$data['sort_lotecode'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.lotecode' . $url, true);
		$data['sort_date_added'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $lote_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($lote_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($lote_total -  $limit)) ? $lote_total : ((($page - 1) *  $limit) +  $limit), $lote_total, ceil($lote_total /  $limit));

		$data['filter_lote_id'] = $filter_lote_id;
		$data['filter_date_ini'] = $filter_date_ini;
		$data['filter_date_fin'] = $filter_date_fin;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/lote_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['lote_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['lote_id'])) {
			$data['action'] = $this->url->link('produccion/lote/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('produccion/lote/edit', 'user_token=' . $this->session->data['user_token'] . '&lote_id=' . $this->request->get['lote_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('produccion/lote', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['lote_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_produccion_lote->getLote($this->request->get['lote_id']);
		}

		if (isset($this->request->get['lote_id'])) {
			$data['lote_id'] = $this->request->get['lote_id'];
		} elseif (!empty($info)) {
			$data['lote_id'] = $info['lote_id'];			
		} else {
			$data['lote_id'] = 0;
		}
		
		if (isset($this->request->get['accion_id'])) {
			$data['accion_id'] = $this->request->get['accion_id'];
		} elseif (!empty($info)) {
			$data['accion_id'] = $info['accion_id'];			
		} else {
			$data['accion_id'] = 1;
		}
		
		if (isset($this->request->get['otpr_item_id'])) {
			$data['otpr_item_id'] = $this->request->get['otpr_item_id'];
		} elseif (!empty($info)) {
			$data['otpr_item_id'] = $info['otpr_item_id'];			
		} else {
			$data['otpr_item_id'] = '';
		}
		
		if (isset($this->request->get['otpr_id'])) {
			$data['otpr_id'] = $this->request->get['otpr_id'];
		} elseif (!empty($info)) {
			$data['otpr_id'] = $info['otpr_id'];			
		} else {
			$data['otpr_id'] = '';
		}
		
		if (isset($this->request->get['product_id'])) {
			$data['product_id'] = $this->request->get['product_id'];
		} elseif (!empty($info)) {
			$data['product_id'] = $info['product_id'];			
		} else {
			$data['product_id'] = '';
		}
		
		if (isset($this->request->get['proceso_id'])) {
			$data['proceso_id'] = $this->request->get['proceso_id'];
		} elseif (!empty($info)) {
			$data['proceso_id'] = $info['proceso_id'];			
		} else {
			$data['proceso_id'] = '';
		}
		
		if (isset($this->request->get['cantidad'])) {
			$data['cantidad'] = $this->request->get['cantidad'];
		} elseif (!empty($info)) {
			$data['cantidad'] = $info['cantidad'];			
		} else {
			$data['cantidad'] = 0;
		}
		
		if (isset($this->request->get['lotecode'])) {
			$data['lotecode'] = $this->request->get['lotecode'];
		} elseif (!empty($info)) {
			$data['lotecode'] = $info['lotecode'];			
		} else {
			$data['lotecode'] = '';
		}
		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($info)) {
			$data['date_added'] = date("d-m-Y",strtotime($info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($info)) {
			$data['date_modified'] = $info['date_modified']==""?"":date("d-m-Y",strtotime($info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($info)) {
			$data['date_delete'] = $info['date_delete']==""?"":date("d-m-Y",strtotime($info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($info)) {
			$data['user_id_added'] = $info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($info)) {
			$data['user_id_modified'] = $info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($info)) {
			$data['user_id_delete'] = $info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
		
		$data['accions'][] = array("accion_id" => 1, "descrip" => "ENTRADA");
		$data['accions'][] = array("accion_id" => 2, "descrip" => "SALIDA");	
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/lote_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'produccion/lote')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/lote')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'produccion/lote')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_lote_id'])) {
			$filter_lote_id = $this->request->get['filter_lote_id'];
		} else {
			$filter_lote_id = '';
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['lotes'] = array();
		$filter_data = array(
			'filter_lote_id'        => $filter_lote_id,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('produccion/lote');
		$results = $this->model_produccion_lote->getLotes($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "Accion")
					->setCellValue('B'.$row,  "Item")
					->setCellValue('C'.$row,  "Id")
					->setCellValue('D'.$row,  "Product")
					->setCellValue('E'.$row,  "Proceso")
					->setCellValue('F'.$row,  "Cantidad")
					->setCellValue('G'.$row,  "Lote");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['accion_id'])
					->setCellValue('B'.$row,  $result['otpr_item_id'])
					->setCellValue('C'.$row,  $result['otpr_id'])
					->setCellValue('D'.$row,  $result['product_id'])
					->setCellValue('E'.$row,  $result['proceso_id'])
					->setCellValue('F'.$row,  $result['cantidad'])
					->setCellValue('G'.$row,  $result['lotecode']);
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('produccion/product');
		$this->load->model('produccion/proceso');
		$this->load->model('produccion/lote');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[0])){
				
				$codigo=$in_ar[0];
				$lote=$in_ar[1];
				$proceso=$in_ar[2];
				$cantidad=$in_ar[3];
				
				$result=$this->model_produccion_product->getProductxcodigo($codigo);
				if (isset($result['product_id'])){
					$product_id=$result['product_id'];
					$result=$this->model_produccion_proceso->getProcesoxdescrip2($proceso);
					
					if (isset($result['proceso_id'])){
						$proceso_id=$result['proceso_id'];
						$dato=array(
							"accion_id" => '1',
							"otpr_item_id" => '0',
							"otpr_id" => '0',
							"product_id" => $product_id,
							"proceso_id" => $proceso_id,
							"cantidad" => $cantidad,
							"lotecode" => $lote,
						);
						$this->model_produccion_lote->addLote($dato);			
						$new++;
					}else{
						print_r($proceso);
						print_r($result);
					}
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	
	public function autocomplete() {
		$json = array();
		if (isset($this->request->get['filter_descrip'])) {
			$this->load->model('produccion/lote');
			$filter_data = array(
				'filter_descrip'  => $this->request->get['filter_descrip'],
				'filter_status' => '1'
			);
			$results = $this->model_produccion_lote->getLotes($filter_data);
			foreach ($results as $result) {
				$json[] = array(
					'lote_id' => $result['lote_id'],
					'descrip'       => strip_tags(html_entity_decode($result['descrip'], ENT_QUOTES, 'UTF-8')),
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function getlote() {
		$json = array();
		if (isset($this->request->get['descrip'])) {
			$this->load->model('produccion/lote');
			$result = $this->model_produccion_lote->getLotexdescrip($this->request->get['descrip'],$this->request->get['product_id']);
			if (isset($result['lote_id'])) {
				$json = array(
					'lote_id' => $result['lote_id'],
					'descrip'    => strip_tags(html_entity_decode($result['descrip'], ENT_QUOTES, 'UTF-8')),
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function getlotexproductyot() {
		$json = array();
		if (isset($this->request->get['product_id'])) {
			$this->load->model('produccion/lote');
			$result = $this->model_produccion_lote->getLotexProductyOt($this->request->get['product_id'],$this->request->get['ot_id']);
			if ($result) {
				$json = array(
					'lote_id' => $result['lote_id'],
					'lotecode'    => $result['lotecode'],
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
		
}