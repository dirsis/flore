<?php
class ControllerProduccionOt extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/ot');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_produccion_ot->bajaOt();
		//$this->model_produccion_ot->creaOt();
		
		//			
		$this->getList();
	}
	public function reinicia(){
		$this->load->language('produccion/ot');
		$this->load->model('produccion/ot');
		$this->model_produccion_ot->bajaOt();
		$this->model_produccion_ot->creaOt();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	public function sincro(){
		$this->load->language('produccion/ot');
		$this->load->model('produccion/ot');
		$this->model_produccion_ot->traeOt();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}
		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_ot_id'])) {
			$url .= '&filter_ot_id=' . $get['filter_ot_id'];
		}
		if (isset($get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $get['filter_descrip'];
		}
		if (isset($get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $get['filter_date_init'];
		}
		if (isset($get['filter_date_fin'])) {
			$url .= '&filter_date_fin=' . $get['filter_date_fin'];
		}
		if (isset($get['filter_estado_id'])) {
			$url .= '&filter_estado_id=' . $get['filter_estado_id'];
		}	
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/ot');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			
			$this->model_produccion_ot->addOt($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('produccion/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/ot');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";			
			*/
			
			$this->model_produccion_ot->editOt($this->request->get['ot_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/ot');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $ot_id) {
				$this->model_produccion_ot->deleteOt($ot_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	
	public function copy() {
		$this->load->language('produccion/ot');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/ot');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $ot_id) {
				$this->model_produccion_ot->copyOt($ot_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_ot_id'])) {
			$filter_ot_id = $this->request->get['filter_ot_id'];
		} else {
			$filter_ot_id = '';
		}
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		if (isset($this->request->get['filter_estado_id'])) {
			$filter_estado_id = $this->request->get['filter_estado_id'];
		} else {
			$filter_estado_id = '';
		}
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = date("d-m-Y",strtotime($this->request->get['filter_date_init']));
		} else {
			$filter_date_init = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/ot/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/ot/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/ot/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['ots'] = array();
		$filter_data = array(
			'filter_ot_id'      => $filter_ot_id,
			'filter_descrip'   	=> $filter_descrip,
			'filter_date_init' 	=> $filter_date_init,
			'filter_date_fin' 	=> $filter_date_fin,
			'filter_estado_id' 	=> $filter_estado_id,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$ot_total = $this->model_produccion_ot->getTotalOts($filter_data);

		$this->load->model('user/user');
		$results = $this->model_produccion_ot->getOts($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}
			
			if ($result['proveedor_id']=='2136'){
				$print=$this->url->link('produccion/ot/printpdfinterna', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true);
			}else{
				$print=$this->url->link('produccion/ot/printpdfexterna', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true);
			}
			
			$data['ots'][] = array(
				'ot_id'    	=> $result['ot_id'],
				'descrip'    		=> $result['descrip'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'date_compr'        => $result['date_compr']?date('d-m-Y', strtotime($result['date_compr'])):"",
				'product'    		=> $result['product'],
				'estado'    		=> $result['estado'],
				'estadocolor'    		=> $result['estadocolor'],
				'cantidad'    		=> $result['cantidad'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('produccion/ot/edit', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/ot/clonar', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true),
				'print'           	=> $print,
				'printho'	=> $this->url->link('produccion/ot/printpdfho', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $result['ot_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_ot_id'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.ot_id' . $url, true);
		
		$data['sort_estado_id'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.estado_id' . $url, true);		
		
		$data['sort_descrip'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.descrip' . $url, true);
		
		$data['sort_cantidad'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.cantidad' . $url, true);
		$data['sort_product'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=product' . $url, true);
		$data['sort_date_added'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		$data['sort_date_compr'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_compr' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $ot_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($ot_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($ot_total -  $limit)) ? $ot_total : ((($page - 1) *  $limit) +  $limit), $ot_total, ceil($ot_total /  $limit));

		$data['filter_ot_id'] = $filter_ot_id;
		$data['filter_descrip'] = $filter_descrip;
		$data['filter_date_init'] = $filter_date_init;
		$data['filter_date_fin'] = $filter_date_fin;
		$data['filter_estado_id'] = $filter_estado_id;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->load->model('produccion/proveedor');
		$data['proveedors'] = $this->model_produccion_proveedor->getProveedors(array());	
		
		$this->load->model('user/user');
		$data['users'] = $this->model_user_user->getUsers(array());	
	
		$this->load->model('produccion/sector');
		$data['sectors'] = $this->model_produccion_sector->getSectors(array());	
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());	
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/ot_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['ot_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['ot_id'])) {
			$data['action'] = $this->url->link('produccion/ot/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('produccion/ot/edit', 'user_token=' . $this->session->data['user_token'] . '&ot_id=' . $this->request->get['ot_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('produccion/ot', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['ot_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_produccion_ot->getOt($this->request->get['ot_id']);
		}

		if (isset($this->request->get['ot_id'])) {
			$data['ot_id'] = $this->request->get['ot_id'];
		} else {
			$data['ot_id'] = 0;
		}

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($info)) {
			$data['date_added'] = date("d-m-Y",strtotime($info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}

		if (isset($this->request->post['date_compr'])) {
			$data['date_compr'] = $this->request->post['date_compr'];
		} elseif (!empty($info)) {
			$data['date_compr'] = date("d-m-Y",strtotime($info['date_compr']));
		} else {
			$data['date_compr'] = date('d-m-Y');
		}
		
		if (isset($this->request->post['proveedor_id'])) {
			$data['proveedor_id'] = $this->request->post['proveedor_id'];
		} elseif (!empty($info)) {
			$data['proveedor_id'] = $info['proveedor_id'];
		} else {
			$data['proveedor_id'] = $this->config->get('config_proveedor_default');
		}		
		if (isset($this->request->post['material'])) {
			$data['material'] = $this->request->post['material'];
		} elseif (!empty($info)) {
			$data['material'] = $info['material'];
		} else {
			$data['material'] = '';
		}		
		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($info)) {
			$data['descrip'] = $info['descrip'];
		} else {
			$data['descrip'] = '';
		}	
		
		if (isset($this->request->post['obs'])) {
			$data['obs'] = $this->request->post['obs'];
		} elseif (!empty($info)) {
			$data['obs'] = $info['obs'];
		} else {
			$data['obs'] = '';
		}			
		
		if (isset($this->request->post['sector_id'])) {
			$data['sector_id'] = $this->request->post['sector_id'];
		} elseif (!empty($info)) {
			$data['sector_id'] = $info['sector_id'];
		} else {
			$data['sector_id'] = '';
		}	
		
		
		if (isset($this->request->post['retrabajo'])) {
			$data['retrabajo'] = $this->request->post['retrabajo'];
		} elseif (!empty($info)) {
			$data['retrabajo'] = $info['retrabajo'];
		} else {
			$data['retrabajo'] = '';
		}
		if (isset($this->request->post['tiemporetrabajo'])) {
			$data['tiemporetrabajo'] = $this->request->post['tiemporetrabajo'];
		} elseif (!empty($info)) {
			$data['tiemporetrabajo'] = $info['tiemporetrabajo'];
		} else {
			$data['tiemporetrabajo'] = '';
		}
		if (isset($this->request->post['pap'])) {
			$data['pap'] = $this->request->post['pap'];
		} elseif (!empty($info)) {
			$data['pap'] = $info['pap'];
		} else {
			$data['pap'] = '';
		}
		if (isset($this->request->post['tiempopap'])) {
			$data['tiempopap'] = $this->request->post['tiempopap'];
		} elseif (!empty($info)) {
			$data['tiempopap'] = $info['tiempopap'];
		} else {
			$data['tiempopap'] = '';
		}		
		

		if (isset($this->request->post['user_id_resp'])) {
			$data['user_id_resp'] = $this->request->post['user_id_resp'];
		} elseif (!empty($info)) {
			$data['user_id_resp'] = $info['user_id_resp'];
		} else {
			$data['user_id_resp'] = '';
		}
		if (isset($this->request->post['user_id_auto'])) {
			$data['user_id_auto'] = $this->request->post['user_id_auto'];
		} elseif (!empty($info)) {
			$data['user_id_auto'] = $info['user_id_auto'];
		} else {
			$data['user_id_auto'] = '';
		}
		if (isset($this->request->post['user_id_aten'])) {
			$data['user_id_aten'] = $this->request->post['user_id_aten'];
		} elseif (!empty($info)) {
			$data['user_id_aten'] = $info['user_id_aten'];
		} else {
			$data['user_id_aten'] = '';
		}		
			
		
		if (isset($this->request->post['product_id'])) {
			$data['product_id'] = $this->request->post['product_id'];
		} elseif (!empty($info)) {
			$data['product_id'] = $info['product_id'];
		} else {
			$data['product_id'] = '';
		}	
		
		if (isset($this->request->post['lote'])) {
			$data['lote'] = $this->request->post['lote'];
		} elseif (!empty($info)) {
			$data['lote'] = $info['lote'];
		} else {
			$data['lote'] = '';
		}
		
		if (isset($this->request->post['cantidad'])) {
			$data['cantidad'] = $this->request->post['cantidad'];
		} elseif (!empty($info)) {
			$data['cantidad'] = $info['cantidad'];
		} else {
			$data['cantidad'] = '1';
		}
		
		
		if (isset($this->request->post['estado_id'])) {
			$data['estado_id'] = $this->request->post['estado_id'];
		} elseif (!empty($info)) {
			$data['estado_id'] = $info['estado_id'];
		} else {
			$data['estado_id'] = '';
		}		
		
	
		
		
		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($info)) {
			$data['date_modified'] = $info['date_modified']==""?"":date("d-m-Y",strtotime($info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($info)) {
			$data['date_delete'] = $info['date_delete']==""?"":date("d-m-Y",strtotime($info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($info)) {
			$data['user_id_added'] = $info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($info)) {
			$data['user_id_modified'] = $info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($info)) {
			$data['user_id_delete'] = $info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
		
		$this->load->model('produccion/proveedor');
		$data['proveedors'] = $this->model_produccion_proveedor->getProveedors(array());	
		
		$this->load->model('user/user');
		$data['users'] = $this->model_user_user->getUsers(array());	
	
		$this->load->model('produccion/sector');
		$data['sectors'] = $this->model_produccion_sector->getSectors(array());	
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());			
		
		$data['procesos']= array();
		
		
		if ($data['product_id']!=0){
			
			$this->load->model('produccion/product');
			$producto = $this->model_produccion_product->getProduct($data['product_id']);
			
			$data['product'] = $producto['descrip'];
			
			$results = $this->model_produccion_product->getProcesoxProduct($data['product_id']);
			foreach ($results as $result) {
				
				$data['procesos'][]  = array(
					'proceso_id' => $result['proceso_id'],
					'proceso'       => strip_tags(html_entity_decode($result['proceso']."(".$result['tarea'].")", ENT_QUOTES, 'UTF-8')),
					'ok' => strpos($info['procesos'], $result['proceso_id']."|") === false?0:1

				);
			}
		}else{
			//$data['procesos'] = $this->model_produccion_proceso->getProcesos(array());			
		}
		//print_r($data['procesos']);
			
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/ot_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'produccion/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*		
		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 200)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
*/		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'produccion/ot')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_ot_id'])) {
			$filter_ot_id = $this->request->get['filter_ot_id'];
		} else {
			$filter_ot_id = '';
		}
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}

		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['ots'] = array();
		$filter_data = array(
			'filter_ot_id'        => $filter_ot_id,
			'filter_descrip'           => $filter_descrip,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('produccion/ot');
		$results = $this->model_produccion_ot->getOts($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setOt("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['ot_id'])
					->setCellValue('B'.$row,  $result['descrip'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('produccion/ot');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					
					
					"descrip" => $in_ar[1],
					"domicilio" => $in_ar[2],
					"ciudad" => $in_ar[3],
					"telefono" => $in_ar[4],
					"email" => $in_ar[5],
					"status" => 1
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_produccion_ot->editOt($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_produccion_ot->addOt($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}
	
	
	public function Code128($x, $y, $code, $w, $h) {
		$Aguid = "";                                                                      // Création des guides de choix ABC
		$Bguid = "";
		$Cguid = "";
		for ($i=0; $i < strlen($code); $i++) {
			$needle = substr($code,$i,1);
			$Aguid .= ((strpos($this->Aset,$needle)===false) ? "N" : "O"); 
			$Bguid .= ((strpos($this->Bset,$needle)===false) ? "N" : "O"); 
			$Cguid .= ((strpos($this->Cset,$needle)===false) ? "N" : "O");
		}

		$SminiC = "OOOO";
		$IminiC = 4;

		$crypt = "";
		while ($code > "") {
																						// BOUCLE PRINCIPALE DE CODAGE
			$i = strpos($Cguid,$SminiC);                                                // forçage du jeu C, si possible
			if ($i!==false) {
				$Aguid [$i] = "N";
				$Bguid [$i] = "N";
			}

			if (substr($Cguid,0,$IminiC) == $SminiC) {                                  // jeu C
				$crypt .= chr(($crypt > "") ? $this->JSwap["C"] : $this->JStart["C"]);  // début Cstart, sinon Cswap
				$made = strpos($Cguid,"N");                                             // étendu du set C
				if ($made === false) {
					$made = strlen($Cguid);
				}
				if (fmod($made,2)==1) {
					$made--;                                                            // seulement un nombre pair
				}
				for ($i=0; $i < $made; $i += 2) {
					$crypt .= chr(strval(substr($code,$i,2)));                          // conversion 2 par 2
				}
				$jeu = "C";
			} else {
				$madeA = strpos($Aguid,"N");                                            // étendu du set A
				if ($madeA === false) {
					$madeA = strlen($Aguid);
				}
				$madeB = strpos($Bguid,"N");                                            // étendu du set B
				if ($madeB === false) {
					$madeB = strlen($Bguid);
				}
				$made = (($madeA < $madeB) ? $madeB : $madeA );                         // étendu traitée
				$jeu = (($madeA < $madeB) ? "B" : "A" );                                // Jeu en cours

				$crypt .= chr(($crypt > "") ? $this->JSwap[$jeu] : $this->JStart[$jeu]); // début start, sinon swap

				$crypt .= strtr(substr($code, 0,$made), $this->SetFrom[$jeu], $this->SetTo[$jeu]); // conversion selon jeu

			}
			$code = substr($code,$made);                                           // raccourcir légende et guides de la zone traitée
			$Aguid = substr($Aguid,$made);
			$Bguid = substr($Bguid,$made);
			$Cguid = substr($Cguid,$made);
		}                                                                          // FIN BOUCLE PRINCIPALE

		$check = ord($crypt[0]);                                                   // calcul de la somme de contrôle
		for ($i=0; $i<strlen($crypt); $i++) {
			$check += (ord($crypt[$i]) * $i);
		}
		$check %= 103;

		$crypt .= chr($check) . chr(106) . chr(107);                               // Chaine cryptée complète

		$i = (strlen($crypt) * 11) - 8;                                            // calcul de la largeur du module
		$modul = $w/$i;

		for ($i=0; $i<strlen($crypt); $i++) {                                      // BOUCLE D'IMPRESSION
			$c = $this->T128[ord($crypt[$i])];
			for ($j=0; $j<count($c); $j++) {
				$this->Rect($x,$y,$c[$j]*$modul,$h,"F");
				$x += ($c[$j++]+$c[$j])*$modul;
			}
		}
	}
	
	public function printpdfinterna(){
		if (isset($this->request->get['ot_id'])) {
			
			$this->load->model('admdirsis/codiva');
			
			$ot_id = $this->request->get['ot_id'];
			$this->load->model('produccion/ot');
			$cabeza = $this->model_produccion_ot->getOt($ot_id);
			
			//print_r($cabeza);
			//die;
			
			$this->load->model('produccion/product');
			$items = $this->model_produccion_product->getFormulaxProduct($cabeza['product_id']);
			//$procesos = $this->model_produccion_ot->getProcesoxProduct($cabeza['product_id']);
			
			$results = $this->model_produccion_product->getProcesoxProduct($cabeza['product_id']);
			foreach ($results as $result) {
				if (strpos($cabeza['procesos'], $result['proceso_id']."|") !== false){
					$procesos[]  = array(
						'proceso_id'  => $result['proceso_id'],
						'proceso'     => $result['proceso'],
						'tarea'       => $result['tarea'],
						'dispo'       => $result['dispo'],
						'segundo' 		=> $result['segundo'],
						'tpp' => $result['tpp']
					);
				}
			}
 			/*			
			print_r($items);
			die;
			*/
 
			$membrete = array(
				"p1" => 10,
				"p2" => 60,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'ORDEN DE TRABAJO',
				"norma" => 'FO-7.4-001',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact'),
				"codiva_id" => $this->config->get('config_factura_codiva_id'),
				"codiva" => $this->model_admdirsis_codiva->getCodiva($this->config->get('config_factura_codiva_id'))
			);
			

			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			//require('dirsis/fpdf.php');
			//$pdf = new FPDF('L','mm','A4');
			//$pdf = new FPDF();
			
			//require('dirsis/ean13.php');
			//$pdf=new PDF_EAN13();
			
			//require('dirsis/code39.php');
			//$pdf = new PDF_Code39();
			
			require('dirsis/codabar.php');
			$pdf=new PDF_Codabar();
			
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			
			//TITULO Y APERTURA
			$pdf->SetTitle("OT N°:".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			$A2=1;
			for ($i = 1; $i <= 2; $i++) {
	//LOGO	
				$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1'],13,50);
				$pdf->Rect($A2+$membrete['p1']-1,12,190,20);
				$pdf->Rect($A2+$membrete['p1']-1+53,12,83,20);
				$pdf->Rect($A2+$membrete['p5']+10,12,19,20);
				/*
				
				$pdf->Rect($A2+$membrete['p1'],5+7, $A2+140,37);
				$pdf->Rect($A2+$membrete['p1'],5+7+37, $A2+140,37);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37, $A2+140,7);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37+7, $A2+140,80);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37+80, $A2+140,7);
				*/
				
	//CENTRO	
				$retra="";
				if ($cabeza['retrabajo']!=0){
					$retra="RETRABAJO";
				}
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,$membrete['titulo'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,"Numero:".$cabeza['ot_id']." ".$retra,0,0,'L');
				$pdf->SetFont('Arial','',10);
				
				//EAN13
				//$pdf->EAN13(120,16,$cabeza['ot_id'],10,.25);
				//code39
				//$pdf->Code39(120,14, $cabeza['ot_id'],false,false,0.5,12,false);
				$pdf->Codabar(120,14,$cabeza['ot_id'], 'A', 'A', 0.35, 10);
				
	//CENTRO2	
				/*		
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p3']);
				$pdf->Cell(130,0,"Numero:".$cabeza['ot_id'],0,0,'L');
				*/
	//DERECHA	
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,$membrete['norma'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,"VERSION:".$membrete['version'],0,0,'L');
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(110,0,'Hoja N:'.$i,0,0,'L');
				$datos = array();
				
				$datos[] = array("xt" => 25,"xd" => 30,"titulo" => "Fecha de Pedido","dato" => date("d-m-Y",strtotime($cabeza['date_added'])));
				$datos[] = array("xt" => 20,"xd" => 65,"titulo" => "Proveedor","dato" => $cabeza['razonsocial']);
				$datos[] = array("xt" => 20,"xd" => 30,"titulo" => "Asignado: ","dato" => $cabeza['user_aten']);				

					
				$pdf->SetY(32);
				$pdf->SetFont('Arial','',9);
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'L');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'L');
				}
				$datos = array();
				$datos[] = array("xt" => 40,"xd" => 40,"titulo" => "Codigo","dato" => $cabeza['codigo']);
				$datos[] = array("xt" => 40,"xd" => 70,"titulo" => "Designacion","dato" => $cabeza['descrip']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}
				$datos = array();
				$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Lote","dato" => $cabeza['lote']);
				$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Hoja de Ruta","dato" => $cabeza['lote']);
				$datos[] = array("xt" => 40,"xd" => 30,"titulo" => "Cantidad a Producir","dato" => $cabeza['cantidad']);
				
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}	

				$datos = array();
				$datos[] = array("xt" => 60,"xd" => 25,"titulo" => "Fecha Estimada de Entrega","dato" => $cabeza['date_compr']);
				$datos[] = array("xt" => 30,"xd" => 25,"titulo" => "Fecha Real","dato" => '');
				$datos[] = array("xt" => 30,"xd" => 20,"titulo" => "Cantidad Real","dato" => '');
				
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}	

				$datos = array();
				$datos[] = array("xt" => 30,"xd" => 130,"titulo" => "Observaciones","dato" => $cabeza['obs']);
				$datos[] = array("xt" => 0,"xd" => 30,"titulo" => "","dato" => $cabeza['sector']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					if ($dato['xt']!=0){
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
					}
					$pdf->Cell($dato['xd'],10,$dato['dato'],1,0,'C');
				}	
				
				$pdf->SetFont('Arial','',7);
				$datoscab = array();
				$datoscab[] = array("xt" => 30,"titulo" => "Codigo");
				$datoscab[] = array("xt" => 100,"titulo" => "Designacion");
				$datoscab[] = array("xt" => 20,"titulo" => "Cantidad");
				$datoscab[] = array("xt" => 40,"titulo" => "No. de Lote");
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
				}	
				$pdf->ln();
				/*
				Array ( [0] => Array ( [productformula_id] => 1 [parent_id] => 12 [product_id] => 626 [quantity] => 1 [hruta] => [plano] => [product] => Sub. Rotor EVO Quartz FG ) )
				*/
				$pdf->SetFont('Arial','',7);
				$largo=6;
				foreach ($items as $item) {
					$datos = array();
					$datos[] = array("xt" => 30,"titulo" => $item['codigo']);
					$datos[] = array("xt" => 100,"titulo" => $item['product']);
					$datos[] = array("xt" => 20,"titulo" => $item['quantity']);
					$datos[] = array("xt" => 40,"titulo" => '');
					//$yy=$yy+10;
					//$pdf->SetY($yy);
					
					$pdf->Cell($A2);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],6,$dato['titulo'],1,0,'L');
					}
					$largo--;
					$pdf->ln();
				}	
				/*
				for ($i = 1; $i <= $largo; $i++) {
					$yy=$yy+10;
					$pdf->SetY($yy);					
					$pdf->Cell($A2);
					foreach ($datoscab as $dato) {
						$pdf->Cell($dato['xt'],10,"",1,0,'C');
					}
				}
				*/
				$datos = array();
				$datos[] = array("xt" => 40,"titulo" => "Planifica:".trim($cabeza['user_auto']));
				$datos[] = array("xt" => 50,"titulo" => "Responsable:".trim($cabeza['user_resp']));
				$datos[] = array("xt" => 50,"titulo" => "Recibe(Proveedor)");
				$datos[] = array("xt" => 50,"titulo" => "Recibe(Gacela S.R.L.)");
			
				//$yy=$yy+10;
				//$pdf->SetY($yy);
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],10,'',1,0,'C');
				}			
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],6,$dato['titulo'],1,0,'C');
				}
				
				
				$pdf->SetFont('Arial','',8);
				$datos = array();
				$datos[] = array("xt" => 10,"titulo" => "Prc");
				$datos[] = array("xt" => 10,"titulo" => "No");
				$datos[] = array("xt" => 60,"titulo" => "Operacion");
				$datos[] = array("xt" => 20,"titulo" => "Disp");
				$datos[] = array("xt" => 15,"titulo" => "TPO STD");
				$datos[] = array("xt" => 15,"titulo" => "Tipo");
				$datos[] = array("xt" => 20,"titulo" => "Fecha");
				$datos[] = array("xt" => 10,"titulo" => "OK");
				$datos[] = array("xt" => 10,"titulo" => "Scrap");
				$datos[] = array("xt" => 20,"titulo" => "Firma");
				$pdf->ln();
				
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				foreach ($procesos as $proceso) {
					$datos = array();
					$datos[] = array("xt" => 10,"titulo" => $proceso['proceso_id']);
					$datos[] = array("xt" => 10,"titulo" => $proceso['proceso']);
					$datos[] = array("xt" => 60,"titulo" => $proceso['tarea']);
					$datos[] = array("xt" => 20,"titulo" => $proceso['dispo']);
					$datos[] = array("xt" => 15,"titulo" => $proceso['segundo']);
					$datos[] = array("xt" => 15,"titulo" => $proceso['tpp']);
					$datos[] = array("xt" => 20,"titulo" => "");
					$datos[] = array("xt" => 10,"titulo" => "");
					$datos[] = array("xt" => 10,"titulo" => "");
					$datos[] = array("xt" => 20,"titulo" => "");
					$pdf->ln();
					
					$pdf->Cell($A2);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],6,$dato['titulo'],1,0,'L');
					}
				}				
				//PIE
				$archivo="OT".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT).".pdf";
				//$pdf->Output($archivo,'F');
				$pdf->Output($archivo,'I');			

			}
		}
	}	
	
	public function printpdfexterna(){
		if (isset($this->request->get['ot_id'])) {
			
			$this->load->model('admdirsis/codiva');
			
			$ot_id = $this->request->get['ot_id'];
			$this->load->model('produccion/ot');
			$cabeza = $this->model_produccion_ot->getOt($ot_id);
			
			//print_r($cabeza);
			//die;
			
			$this->load->model('produccion/product');
			$items = $this->model_produccion_product->getFormulaxProduct($cabeza['product_id']);
			$procesos = $this->model_produccion_product->getProcesoxProduct($cabeza['product_id']);
 			/*			
			print_r($items);
			die;
			*/
 
			$membrete = array(
				"p1" => 10,
				"p2" => 60,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'ORDEN DE TRABAJO',
				"norma" => 'FO-7.4-001',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact'),
				"codiva_id" => $this->config->get('config_factura_codiva_id'),
				"codiva" => $this->model_admdirsis_codiva->getCodiva($this->config->get('config_factura_codiva_id'))
			);
			

			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			//require('dirsis/fpdf.php');
			//$pdf = new FPDF('L','mm','A4');
			//$pdf = new FPDF();
			
			//require('dirsis/ean13.php');
			//$pdf=new PDF_EAN13();
			
			//require('dirsis/code39.php');
			//$pdf = new PDF_Code39();
			
			require('dirsis/codabar.php');
			$pdf=new PDF_Codabar();
			
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			
			//TITULO Y APERTURA
			$pdf->SetTitle("OT N°:".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			$A2=1;
			$Y2=15;
			for ($i = 1; $i <= 2; $i++) {
	//LOGO	
				$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1']+1,$Y2-2,50);
				$pdf->Rect($A2+$membrete['p1'],$Y2-3,190,20);
				$pdf->Rect($A2+$membrete['p1']+53,$Y2-3,83,20);
				$pdf->Rect($A2+$membrete['p5']+10,$Y2-3,20,20);
	//CENTRO	
				$retra="";
				if ($cabeza['retrabajo']!=0){
					$retra="RETRABAJO";
				}
				$pdf->SetY($Y2);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,$membrete['titulo'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,"Numero:".$cabeza['ot_id']." ".$retra,0,0,'L');
				$pdf->SetFont('Arial','',10);
				$pdf->Codabar(120,14,$cabeza['ot_id'], 'A', 'A', 0.35, 10);
	//DERECHA	
				$pdf->SetY($Y2);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,$membrete['norma'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,"VERSION:".$membrete['version'],0,0,'L');
				$pdf->SetY($Y2);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(110,0,'Hoja N:'.$i,0,0,'L');
				$datos = array();
				$Y2=$Y2+30;
				$pdf->Ln(17);
				$datos[] = array("xt" => 25,"xd" => 30,"titulo" => "Fecha de Pedido","dato" => date("d-m-Y",strtotime($cabeza['date_added'])));
				$datos[] = array("xt" => 20,"xd" => 65,"titulo" => "Proveedor","dato" => $cabeza['razonsocial']);
				$datos[] = array("xt" => 20,"xd" => 30,"titulo" => "Att.Sr: ","dato" => $cabeza['user_aten']);				

				$pdf->SetFont('Arial','',9);
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'L');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'L');
				}
				
				$datos = array();
				$datos[] = array("xt" => 40,"xd" => 25,"titulo" => "Corresponde OP N:","dato" => "");
				$datos[] = array("xt" => 40,"xd" => 25,"titulo" => "Fecha de Emision de O.P.","dato" => "");
				$datos[] = array("xt" => 35,"xd" => 25,"titulo" => "Remitida VIA:","dato" => "");
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}
				
				$pdf->SetFont('Arial','',11);
				$datos = array();
				$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Codigo","dato" => $cabeza['codigo']);
				$datos[] = array("xt" => 30,"xd" => 100,"titulo" => "Designacion","dato" => $cabeza['descrip']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}
				$pdf->SetFont('Arial','B',12);
				$datos = array();
				$datos[] = array("xt" => 60,"xd" => 30,"titulo" => "Cantidad a Producir","dato" => $cabeza['cantidad']);
				$datos[] = array("xt" => 60,"xd" => 40,"titulo" => "Fecha Estimada de Entrega","dato" => date("d-m-Y",strtotime($cabeza['date_compr'])));
				
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
					$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'C');
				}	
	
				$pdf->SetFont('Arial','',10);
				$datos = array();
				$datos[] = array("xt" => 40,"xd" => 150,"titulo" => "Material Entregado","dato" => $cabeza['material']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					if ($dato['xt']!=0){
					$pdf->Cell($dato['xt'],20,$dato['titulo'],1,0,'C');
					}
					$pdf->Cell($dato['xd'],20,$dato['dato'],1,0,'C');
				}				
				$datos = array();
				$datos[] = array("xt" => 40,"xd" => 150,"titulo" => "Descripcion de Tarea","dato" => $cabeza['descripot']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					if ($dato['xt']!=0){
					$pdf->Cell($dato['xt'],20,$dato['titulo'],1,0,'C');
					}
					$pdf->Cell($dato['xd'],20,$dato['dato'],1,0,'C');
				}	
				$datos = array();
				$datos[] = array("xt" => 40,"xd" => 150,"titulo" => "Observaciones","dato" => $cabeza['obs']);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					if ($dato['xt']!=0){
					$pdf->Cell($dato['xt'],20,$dato['titulo'],1,0,'C');
					}
					$pdf->Cell($dato['xd'],20,$dato['dato'],1,0,'C');
				}	
				
	

				$datos = array();
				$datos[] = array("xt" => 95,"titulo" => "Responsable:".trim($cabeza['user_resp']));
				$datos[] = array("xt" => 95,"titulo" => "Recibe(Proveedor)");
			
				//$yy=$yy+10;
				//$pdf->SetY($yy);
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],10,'',1,0,'C');
				}			
				$pdf->ln();
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],6,$dato['titulo'],1,0,'C');
				}
				
				$Y2=$Y2+120;
				
			}
				
				
			//PIE
			$archivo="OT".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT).".pdf";
			//$pdf->Output($archivo,'F');
			$pdf->Output($archivo,'I');			

		}
	}	
	
	public function printpdfho(){
		if (isset($this->request->get['ot_id'])) {
			
			
			$membrete = array(
				"p1" => 5,
				"p2" => 40,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'ORDEN DE TRABAJO',
				"norma" => 'FO-7.4-001',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact')
			);			
			
			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');


			
			$this->load->model('admdirsis/codiva');
			$ot_id = $this->request->get['ot_id'];
			$this->load->model('produccion/ot');
			$cabeza = $this->model_produccion_ot->getOt($ot_id);
			$this->load->model('produccion/product');
			$items = $this->model_produccion_product->getFormulaxProduct($cabeza['product_id']);
			
			$results = $this->model_produccion_product->getProcesoxProduct($cabeza['product_id']);
			

			
			
			
			require('dirsis/fpdf.php');
			$pdf = new FPDF('L','mm','A4');
			$pdf->SetAutoPageBreak(true,2);			
			$pdf->SetTitle("HR de OT N°:".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();

			
			foreach ($results as $proceso) {
				if (strpos($cabeza['procesos'], $proceso['proceso_id']."|") !== false){
					
					
			$this->load->model('produccion/proceso');
			$herras = $this->model_produccion_proceso->getProcesos_herra($cabeza['product_id'],$proceso['proceso_id']);
			//print_r($herras);
					//die;
			$caracs = $this->model_produccion_proceso->getProcesos_carac($cabeza['product_id'],$proceso['proceso_id']);
			$tiemps = $this->model_produccion_proceso->getProcesos_tiemp($cabeza['product_id'],$proceso['proceso_id']);					
					
					//print_r($proceso);
					$hoja=1;
					$pdf->AddPage("L","A4");
					$A2=1;
					$pdf->SetFillColor(174, 182, 191 );
					$pdf->Rect($A2+$membrete['p1'],10,285,13,'DF');
					
					//LOGO	
					$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1']+2,13-2,36);
					

					$pdf->SetFont('Arial','',12);
					$pdf->Cell($A2+$membrete['p2']);
					$pdf->Cell(60,13,$membrete['titulo'],1,0,'C');
					$pdf->Cell(120,13,"Designacion:".$proceso['tarea'],1,0,'L');
					$pdf->Cell(30,13,$membrete['norma'],1,0,'C');
					$pdf->Cell(30,13,"OP N:".$proceso['proceso_id']."-".$proceso['proceso'],1,0,'C');
					$pdf->SetFont('Arial','',8);		
					$datos = array();
					$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Codigo de Pieza:","dato" => $cabeza['codigo']);
					$datos[] = array("xt" => 30,"xd" => 90,"titulo" => "Designacion:","dato" => $cabeza['descrip']);
					$datos[] = array("xt" => 30,"xd" => 75,"titulo" => "Dispositibo:","dato" => $proceso['dispo']);
					$pdf->ln();
					$pdf->Cell($A2-5);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],9,$dato['titulo'],1,0,'C');
						$pdf->Cell($dato['xd'],9,$dato['dato'],1,0,'C');
					}
					

					
					
					$datos = array();
					$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Material:","dato" => $cabeza['material']);
					$datos[] = array("xt" => 30,"xd" => 90,"titulo" => "Designacion:","dato" => $cabeza['descripot']);
					$pdf->ln();
					$pdf->Cell($A2-5);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],9,$dato['titulo'],1,0,'C');
						$pdf->Cell($dato['xd'],9,$dato['dato'],1,0,'C');
					}	
					
					$Y=$pdf->GetY();
					$pdf->Image($data['url']."image/".$membrete['image'],190,$Y+2,100,150);					

					
					$datos = array();
					$datos[] = array("xt" => 30,"xd" => 150,"titulo" => "Maquina:","dato" => $proceso['maquina']);
					$pdf->ln();
					$pdf->Cell($A2-5);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],9,$dato['titulo'],1,0,'C');
						$pdf->Cell($dato['xd'],9,$dato['dato'],1,0,'C');
					}
					
					$datos = array();
					$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Plano:","dato" => $proceso['plano']);
					$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Revision:","dato" => $proceso['replano']);
					$datos[] = array("xt" => 30,"xd" => 30,"titulo" => "Codigo H.Ruta:","dato" => '');
					$pdf->ln();
					$pdf->Cell($A2-5);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],9,$dato['titulo'],1,0,'C');
						$pdf->Cell($dato['xd'],9,$dato['dato'],1,0,'C');
					}	
					
					$pdf->ln();
					$pdf->Cell($A2-5);
					$pdf->Cell(60,9,"Herramienta",1,0,'C',true);
					$pdf->Cell(30,9,"Codigo",1,0,'C',true);
					$pdf->Cell(15,9,"Vc (mm)",1,0,'C',true);
					$pdf->Cell(15,9,"RPM",1,0,'C',true);
					$pdf->Cell(15,9,"a (mm/rev)",1,0,'C',true);
					$pdf->Cell(15,9,"p (mm)",1,0,'C',true);
					$pdf->Cell(30,9,"Refrigeracion",1,0,'C',true);
					foreach ($herras as $dato) {
						$pdf->ln();
						$pdf->Cell($A2-5);
						$pdf->Cell(60,9,$dato['descrip'],1,0,'C');
						$pdf->Cell(30,9,$dato['code'],1,0,'C');
						$pdf->Cell(15,9,$dato['vc'],1,0,'C');
						$pdf->Cell(15,9,$dato['rpm'],1,0,'C');
						$pdf->Cell(15,9,$dato['av'],1,0,'C');
						$pdf->Cell(15,9,$dato['prof'],1,0,'C');
						$pdf->Cell(30,9,$dato['refrig'],1,0,'C');				
					}
					$datos = array();
					$datos[] = array("xt" => 50,"xd" => 130,"titulo" => "Analisis de Riesgo:","dato" => '');
					$pdf->ln();
					$pdf->Cell($A2-5);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],9,$dato['titulo'],1,0,'C');
						$pdf->Cell($dato['xd'],9,$dato['dato'],1,0,'C');
					}
					
					$pdf->ln();
					$pdf->Cell($A2-5);
					$pdf->Cell(40,9,"Caracteristica a medir",1,0,'C',true);
					$pdf->Cell(20,9,"Cota",1,0,'C',true);
					$pdf->Cell(10,9,"Max.",1,0,'C',true);
					$pdf->Cell(10,9,"Min.",1,0,'C',true);
					$pdf->Cell(15,9,"Codigo",1,0,'C',true);
					$pdf->Cell(25,9,"Designacion",1,0,'C',true);
					$pdf->Cell(20,9,"Ctrl.",1,0,'C',true);					
					$pdf->Cell(10,9,"Rep.",1,0,'C',true);					
					$pdf->Cell(30,9,"Reg",1,0,'C',true);	
					
					foreach ($caracs as $dato) {
						$pdf->ln();
						$pdf->Cell($A2-5);
						$pdf->Cell(40,9,$dato['descrip'],1,0,'C');
						$pdf->Cell(20,9,$dato['cota'],1,0,'C');
						$pdf->Cell(10,9,$dato['totemin'],1,0,'C');
						$pdf->Cell(10,9,$dato['totemax'],1,0,'C');
						$pdf->Cell(15,9,$dato['inscode'],1,0,'C');
						$pdf->Cell(25,9,$dato['insdes'],1,0,'C');
						$pdf->Cell(20,9,$dato['frectrl'],1,0,'C');				
						$pdf->Cell(10,9,$dato['frereg'],1,0,'C');				
						$pdf->Cell(30,9,$dato['reg'],1,0,'C');				
					}					
					
					
					
					$pdf->SetY(-22);
					$pdf->Cell($A2-5);
					$pdf->Cell(45,9,"Tiempo Ciclo",1,0,'C',true);
					$pdf->Cell(45,9,"Total",1,0,'C',true);
					$pdf->Cell(45,9,"Produccion x Hora",1,0,'C',true);
					$pdf->Cell(45,9,"Produccion x Dia",1,0,'C',true);	
					$pdf->Cell(30,9,"Confesiono",1,0,'C',true);	
					$pdf->Cell(31,9,"Vo.Bo",1,0,'C',true);	
					$pdf->ln();
					$pdf->Cell($A2-5);
					$pdf->Cell(45,11,$proceso['obs'],1,0,'C');
					$pdf->Cell(45,11,"",1,0,'C');
					$pdf->Cell(45,11,"",1,0,'C');
					$pdf->Cell(45,11,"",1,0,'C');			
					$pdf->Cell(30,11,"",1,0,'C');			
					$pdf->Cell(31,11,"",1,0,'C');
					
					
					$text=str_repeat($proceso['nota'],20);
					$nb=$this->WordWrap($pdf,$text,120);
					
					$pdf->SetY(-70);
					$pdf->SetX(-190);
					$pdf->Cell(0,50,$nb,0,0,'C');
					$pdf->SetY(-22);
					$pdf->SetX(-50);
					$pdf->Cell(25,5,"Fecha",1,0,'C');
					$pdf->Cell(20,5,date("d-m-Y",strtotime($cabeza['date_added'])),1,0,'C');
					$pdf->ln();
					$pdf->SetX(-50);
					$pdf->Cell(25,5,"Fum",1,0,'C');
					$pdf->Cell(20,5,date("d-m-Y",strtotime($proceso['fum'])),1,0,'C');
					$pdf->ln();
					$pdf->SetX(-50);
					$pdf->Cell(25,5,"Revision",1,0,'C');
					$pdf->Cell(20,5,"01",1,0,'C');
					$pdf->ln();
					$pdf->SetX(-50);
					$pdf->Cell(25,5,"Hoja N:",1,0,'C');			
					$pdf->Cell(20,5,$hoja,1,0,'C');			
					/*

					$datos = array();
					$datos[] = array("xt" => 25,"xd" => 30,"titulo" => "Fecha de Pedido","dato" => date("d-m-Y",strtotime($cabeza['date_added'])));
					$datos[] = array("xt" => 20,"xd" => 65,"titulo" => "Proveedor","dato" => $cabeza['razonsocial']);
					$datos[] = array("xt" => 20,"xd" => 30,"titulo" => "Asignado: ","dato" => $cabeza['user_aten']);				

					$pdf->SetFont('Arial','',9);
					$pdf->Cell($A2);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'L');
						$pdf->Cell($dato['xd'],8,$dato['dato'],1,0,'L');
					}
*/					
				}
				
			}
			
			//PIE
			$archivo="OT".str_pad($cabeza['ot_id'], 8, "0", STR_PAD_LEFT).".pdf";
			$pdf->Output($archivo,'I');			
//FIN PDF					
		}
	}	
	
	public function getot(){
		$json=array();
		if (isset($this->request->get['ot_id'])) {
			$ot_id = $this->request->get['ot_id'];
			$this->load->model('produccion/ot');
			$json = $this->model_produccion_ot->getOt($ot_id);		
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
		
	}
	
public function  WordWrap($pdf,&$text, $maxwidth)
{
    $text = trim($text);
    if ($text==='')
        return 0;
    $space = $pdf->GetStringWidth(' ');
    $lines = explode("\n", $text);
    $text = '';
    $count = 0;

    foreach ($lines as $line)
    {
        $words = preg_split('/ +/', $line);
        $width = 0;

        foreach ($words as $word)
        {
            $wordwidth = $pdf->GetStringWidth($word);
            if ($wordwidth > $maxwidth)
            {
                // Word is too long, we cut it
                for($i=0; $i<strlen($word); $i++)
                {
                    $wordwidth = $pdf->GetStringWidth(substr($word, $i, 1));
                    if($width + $wordwidth <= $maxwidth)
                    {
                        $width += $wordwidth;
                        $text .= substr($word, $i, 1);
                    }
                    else
                    {
                        $width = $wordwidth;
                        $text = rtrim($text)."\n".substr($word, $i, 1);
                        $count++;
                    }
                }
            }
            elseif($width + $wordwidth <= $maxwidth)
            {
                $width += $wordwidth + $space;
                $text .= $word.' ';
            }
            else
            {
                $width = $wordwidth + $space;
                $text = rtrim($text)."\n".$word.' ';
                $count++;
            }
        }
        $text = rtrim($text)."\n";
        $count++;
    }
    $text = rtrim($text);
    return $count;
}	
		
}