<?php
class ControllerProduccionOtpr extends Controller {
	private $error = array();
	
	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/otpr');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/otpr');
		$this->getList();
	}
	public function reinicia(){
		$this->load->model('produccion/otpr');
		$this->model_produccion_otpr->bajaOtpr();
		$this->model_produccion_otpr->creaOtpr();
	}	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}
		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_otpr_id'])) {
			$url .= '&filter_otpr_id=' . $get['filter_otpr_id'];
		}
		if (isset($get['filter_ot_id'])) {
			$url .= '&filter_ot_id=' . $get['filter_ot_id'];
		}
		if (isset($get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $get['filter_date_init'];
		}
		if (isset($get['filter_date_fin'])) {
			$url .= '&filter_date_fin=' . $get['filter_date_fin'];
		}
		if (isset($get['filter_estado_id'])) {
			$url .= '&filter_estado_id=' . $get['filter_estado_id'];
		}	
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	
	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/otpr');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/otpr');
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$this->model_produccion_otpr->addOtpr($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/otpr');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/otpr');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $otpr_id) {
				$this->model_produccion_otpr->deleteOtpr($otpr_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_otpr_id'])) {
			$filter_otpr_id = $this->request->get['filter_otpr_id'];
		} else {
			$filter_otpr_id = '';
		}
		if (isset($this->request->get['filter_ot_id'])) {
			$filter_ot_id = $this->request->get['filter_ot_id'];
		} else {
			$filter_ot_id = '';
		}		
		if (isset($this->request->get['filter_estado_id'])) {
			$filter_estado_id = $this->request->get['filter_estado_id'];
		} else {
			$filter_estado_id = '';
		}
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = date("d-m-Y",strtotime($this->request->get['filter_date_init']));
		} else {
			$filter_date_init = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/otpr/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/otpr/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/otpr/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['otprs'] = array();
		$filter_data = array(
			'filter_otpr_id'	=> $filter_otpr_id,
			'filter_ot_id'      => $filter_ot_id,
			'filter_date_init' 	=> $filter_date_init,
			'filter_date_fin' 	=> $filter_date_fin,
			'filter_estado_id' 	=> $filter_estado_id,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		
		//print_r($filter_data);
 
		$ot_total = $this->model_produccion_otpr->getTotalOtprs($filter_data);
		$results = $this->model_produccion_otpr->getOtprs($filter_data);
		foreach ($results as $result) {
			$data['otprs'][] = array(
				'otpr_id'    		=> $result['otpr_id'],
				'ot_id'    			=> $result['ot_id'],
				'operador_id'    	=> $result['operador_id'],
				'operador'    		=> $result['operador'],
				'user_id'    		=> $result['user_id'],
				'user'    			=> $result['user'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'estado_id'    			=> $result['estado_id'],
				'edit'           	=> $this->url->link('produccion/otpr/edit', 'user_token=' . $this->session->data['user_token'] . '&otpr_id=' . $result['otpr_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/otpr/clonar', 'user_token=' . $this->session->data['user_token'] . '&otpr_id=' . $result['otpr_id'] . $url, true),
				'print'           	=> $this->url->link('produccion/otpr/printpdf', 'user_token=' . $this->session->data['user_token'] . '&otpr_id=' . $result['otpr_id'] . $url, true)	
			);
		}
		 
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_otpr_id'] = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.ot_id' . $url, true);
		$data['sort_ot_id'] = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.ot_id' . $url, true);
		$data['sort_date_added'] = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		$data['sort_estado_id'] = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . '&sort=o.estado_id' . $url, true);		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $ot_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($ot_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($ot_total -  $limit)) ? $ot_total : ((($page - 1) *  $limit) +  $limit), $ot_total, ceil($ot_total /  $limit));

		$data['filter_otpr_id'] 	= $filter_otpr_id;
		$data['filter_ot_id'] 		= $filter_ot_id;
		$data['filter_date_init'] 	= $filter_date_init;
		$data['filter_date_fin'] 	= $filter_date_fin;
		$data['filter_estado_id'] 	= $filter_estado_id;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['accions'][] = array("accion_id" => 1, "descrip" => "ENTRADA");
		$data['accions'][] = array("accion_id" => 2, "descrip" => "SALIDA");
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());	
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/otpr_list', $data));
	}	
	protected function getForm() {
		$data['text_form'] = $this->language->get('text_add');
		$data['user_token'] = $this->session->data['user_token'];
		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		$url = "";
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['action'] = $this->url->link('produccion/otpr/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['cancel'] = $this->url->link('produccion/otpr', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['ot_id'] = '';
		$data['date_added'] = date('d-m-Y');
		$data['otoc'] = '1';
		
		$data['accions'][] = array("accion_id" => 1, "descrip" => "ENTRADA");
		$data['accions'][] = array("accion_id" => 2, "descrip" => "SALIDA");

		$data['otocs'][] = array("otoc" => 1, "descrip" => "OT");
		$data['otocs'][] = array("otoc" => 2, "descrip" => "OC");
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());			
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/otpr_form', $data));
	}
	
	public function verifyadd() {
		$json = array();
		$this->load->model('produccion/ot');
		$this->load->model('user/user');
		if ($this->request->server['REQUEST_METHOD'] == 'POST'){
			if ($this->request->post['otoc']=='1'){
				$ot_id=$this->model_produccion_ot->getOt($this->request->post['ot_id']);
			}else{
				$this->load->model('produccion/oc');
				$ot_id=$this->model_produccion_oc->getOc($this->request->post['ot_id']);
			}
			$operador=$this->model_user_user->getUserxlastname($this->request->post['operador']);
			$user=$this->model_user_user->getUserxlastname($this->request->post['user']);
			$json = array (
				"ot_id" => $ot_id,
				"postoperador" => $this->request->post['operador'],
				"operador" => $operador?$operador['username']:"",
				"operador_id" => $operador?$operador['user_id']:"",
				"postuser" => $this->request->post['user'],
				"user" => $user?$user['username']:"",
				"user_id" => $user?$user['user_id']:"");
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/otpr')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
	
	public function getLoteoproduct() {
		$json = array();
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		if (isset($this->request->get['codigo'])){
			$codigo=$this->request->get['codigo'];
			$ot_id=$this->request->get['ot_id'];
			$otoc=$this->request->get['otoc'];
			$this->load->model('produccion/lote');
			$lote=$this->model_produccion_lote->getLotexlotecode($codigo);
			if ($lote){
				//LOTE ENCONTRADO
				$json= array(
					'codigo' => $lote['codigo'],
					'product_id' => $lote['product_id'],
					'descrip' => $lote['descrip'],
					'proceso_id' => $lote['proceso_id'],
					'proceso' => $lote['proceso'],
					'otpr_lote_id' => $lote['lote_id'],
					'lotecode' => $lote['lotecode'],
				);
			}else{
				//BUSCA LOTE ASOCIADO A OT/OC
				$lote=$this->model_produccion_lote->getLotexProductyOt($codigo,$otoc,$ot_id);
				if ($lote){
					//LOTE ENCONTRADO
					$json= array(
						'codigo' => $lote['codigo'],
						'product_id' => $lote['product_id'],
						'descrip' => $lote['descrip'],
						'proceso_id' => $lote['proceso_id'],
						'proceso' => $lote['proceso'],
						'otpr_lote_id' => $lote['lote_id'],
						'lotecode' => $lote['lotecode'],
					);
				}else{
					//BUSCA X CODIGO O EAN13
					$codigo=$this->request->get['codigo'];
					$this->load->model('produccion/product');
					$lote=$this->model_produccion_product->getProductxcodigo($codigo);
					if ($lote){
						$json = array (
							'codigo' => $lote['codigo'],
							"product_id" => $lote['product_id'],
							"descrip" => $lote['descrip'],
							"proceso_id" => "0",
							"proceso" => "",
							"otpr_item_id" => "0",
							"otpr_lote_id" => "0",
							"lote_id" => "0",
							"lotecode" => ""
						);
					}else{
						$json = array (
							'codigo' => "",
							"product_id" => 0,
							"descrip" => "Producto no Identificado",
							"proceso_id" => "0",
							"proceso" => "",
							"otpr_item_id" => "0",
							"otpr_lote_id" => "0",
							"lote_id" => "0",
							"lotecode" => $codigo
						);						
					}	
				}
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function getProceso() {
		$json = array();
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		if (isset($this->request->get['proceso'])){
			$this->load->model('produccion/proceso');
			$proceso=$this->model_produccion_proceso->getProcesoxdescrip($this->request->get['proceso']);
			if ($proceso){
				//PROCESO ENCONTRADO
				$json= array(
					'proceso_id' => $proceso['proceso_id'],
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	public function getCodigoproduct() {
		$json = array();
		if (isset($this->request->get['codigo'])){
			$codigo=$this->request->get['codigo'];
			$this->load->model('produccion/product');
			$lote=$this->model_produccion_product->getProductxcodigo($codigo);
			//print_r($lote);
			if (isset($lote['product_id'])){
				$json = array (
					"product_id" => $lote['product_id'],
					"descrip" => $lote['descrip'],
					"proceso_id" => "0",
					"proceso" => "",
					"otpr_item_id" => "0",
					"otpr_lote_id" => "0",
					"lote_id" => "0",
					"lotecode" => ""
				);
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
}