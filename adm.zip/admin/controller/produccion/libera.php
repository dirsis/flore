<?php
class ControllerProduccionLibera extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/libera');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/libera');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_produccion_libera->bajaLibera();
		$this->model_produccion_libera->creaLibera();
		
		//			
		$this->getList();
	}
	public function reinicia(){
		$this->load->language('produccion/libera');
		$this->load->model('produccion/libera');
		$this->model_produccion_libera->bajaLibera();
		$this->model_produccion_libera->creaLibera();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	public function sincro(){
		$this->load->language('produccion/libera');
		$this->load->model('produccion/libera');
		$this->model_produccion_libera->traeLibera();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}
		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_libera_id'])) {
			$url .= '&filter_libera_id=' . $get['filter_libera_id'];
		}
		if (isset($get['filter_ot_id'])) {
			$url .= '&filter_ot_id=' . $get['filter_ot_id'];
		}		
		if (isset($get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $get['filter_descrip'];
		}
		if (isset($get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $get['filter_date_init'];
		}
		if (isset($get['filter_date_fin'])) {
			$url .= '&filter_date_fin=' . $get['filter_date_fin'];
		}
		if (isset($get['filter_estado_id'])) {
			$url .= '&filter_estado_id=' . $get['filter_estado_id'];
		}	
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/libera');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/libera');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_produccion_libera->addLibera($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('produccion/libera');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/libera');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			$this->model_produccion_libera->editLibera($this->request->get['libera_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/libera');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/libera');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $libera_id) {
				$this->model_produccion_libera->deleteLibera($libera_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	
	public function copy() {
		$this->load->language('produccion/libera');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/libera');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $libera_id) {
				$this->model_produccion_libera->copyLibera($libera_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_libera_id'])) {
			$filter_libera_id = $this->request->get['filter_libera_id'];
		} else {
			$filter_libera_id = '';
		}
		if (isset($this->request->get['filter_ot_id'])) {
			$filter_ot_id = $this->request->get['filter_ot_id'];
		} else {
			$filter_ot_id = '';
		}		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		if (isset($this->request->get['filter_estado_id'])) {
			$filter_estado_id = $this->request->get['filter_estado_id'];
		} else {
			$filter_estado_id = '';
		}
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = date("d-m-Y",strtotime($this->request->get['filter_date_init']));
		} else {
			$filter_date_init = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/libera/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/libera/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/libera/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['liberas'] = array();
		$filter_data = array(
			'filter_libera_id'      => $filter_libera_id,
			'filter_ot_id'      => $filter_ot_id,
			'filter_descrip'   	=> $filter_descrip,
			'filter_date_init' 	=> $filter_date_init,
			'filter_date_fin' 	=> $filter_date_fin,
			'filter_estado_id' 	=> $filter_estado_id,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$libera_total = $this->model_produccion_libera->getTotalLiberas($filter_data);

		$this->load->model('user/user');
		$results = $this->model_produccion_libera->getLiberas($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}

			$data['liberas'][] = array(
				'libera_id'    	=> $result['libera_id'],
				'ot_id'    		=> $result['ot_id'],
				'descrip'    		=> $result['descrip'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('produccion/libera/edit', 'user_token=' . $this->session->data['user_token'] . '&libera_id=' . $result['libera_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/libera/clonar', 'user_token=' . $this->session->data['user_token'] . '&libera_id=' . $result['libera_id'] . $url, true),
				'print'           	=> $this->url->link('produccion/libera/printpdf', 'user_token=' . $this->session->data['user_token'] . '&libera_id=' . $result['libera_id'] . $url, true),
				'garantia'           	=> $this->url->link('produccion/libera/garantiapdf', 'user_token=' . $this->session->data['user_token'] . '&libera_id=' . $result['libera_id'] . $url, true)				
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_libera_id'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=libera_id' . $url, true);
		
		$data['sort_ot_id'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=ot_id' . $url, true);		
		
		$data['sort_estado_id'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=estado_id' . $url, true);		
		
		$data['sort_descrip'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=descrip' . $url, true);
		
		$data['sort_product'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=product' . $url, true);
		$data['sort_date_added'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $libera_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($libera_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($libera_total -  $limit)) ? $libera_total : ((($page - 1) *  $limit) +  $limit), $libera_total, ceil($libera_total /  $limit));

		$data['filter_libera_id'] = $filter_libera_id;
		$data['filter_ot_id'] = $filter_ot_id;
		$data['filter_descrip'] = $filter_descrip;
		$data['filter_date_init'] = $filter_date_init;
		$data['filter_date_fin'] = $filter_date_fin;
		$data['filter_estado_id'] = $filter_estado_id;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->load->model('produccion/proveedor');
		$data['proveedors'] = $this->model_produccion_proveedor->getProveedors(array());	
		
		$this->load->model('user/user');
		$data['users'] = $this->model_user_user->getUsers(array());	
	
		$this->load->model('produccion/sector');
		$data['sectors'] = $this->model_produccion_sector->getSectors(array());	
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());	
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/libera_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['libera_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['libera_id'])) {
			$data['action'] = $this->url->link('produccion/libera/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('produccion/libera/edit', 'user_token=' . $this->session->data['user_token'] . '&libera_id=' . $this->request->get['libera_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('produccion/libera', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['libera_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_produccion_libera->getLibera($this->request->get['libera_id']);
		}

		if (isset($this->request->get['libera_id'])) {
			$data['libera_id'] = $this->request->get['libera_id'];
		} else {
			$data['libera_id'] = 0;
		}
		
		

		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($info)) {
			$data['date_added'] = date("d-m-Y",strtotime($info['date_added']));
		} else {
			$data['date_added'] = date('d-m-Y');
		}

		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($info)) {
			$data['descrip'] = $info['descrip'];
		} else {
			$data['descrip'] = '';
		}	
		
		if (isset($this->request->post['ot_id'])) {
			$data['ot_id'] = $this->request->post['ot_id'];
		} elseif (!empty($info)) {
			$data['ot_id'] = $info['ot_id'];
		} else {
			$data['ot_id'] = '';
		}		
		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($info)) {
			$data['date_modified'] = $info['date_modified']==""?"":date("d-m-Y",strtotime($info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($info)) {
			$data['date_delete'] = $info['date_delete']==""?"":date("d-m-Y",strtotime($info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($info)) {
			$data['user_id_added'] = $info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($info)) {
			$data['user_id_modified'] = $info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($info)) {
			$data['user_id_delete'] = $info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
		
		$data['liberas'] = $this->model_produccion_libera->getLibera_products($data['libera_id']);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/libera_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'produccion/libera')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*		
		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 200)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
*/		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/libera')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'produccion/libera')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_libera_id'])) {
			$filter_libera_id = $this->request->get['filter_libera_id'];
		} else {
			$filter_libera_id = '';
		}
		if (isset($this->request->get['filter_ot_id'])) {
			$filter_ot_id = $this->request->get['filter_ot_id'];
		} else {
			$filter_ot_id = '';
		}		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}

		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['ots'] = array();
		$filter_data = array(
			'filter_libera_id'        => $filter_libera_id,
			'filter_ot_id'        => $filter_ot_id,
			'filter_descrip'           => $filter_descrip,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('produccion/libera');
		$results = $this->model_produccion_libera->getLiberas($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setLibera("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['libera_id'])
					->setCellValue('B'.$row,  $result['descrip'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('produccion/libera');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					
					
					"descrip" => $in_ar[1],
					"domicilio" => $in_ar[2],
					"ciudad" => $in_ar[3],
					"telefono" => $in_ar[4],
					"email" => $in_ar[5],
					"status" => 1
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_produccion_libera->editLibera($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_produccion_libera->addLibera($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}
	
	
	public function Code128($x, $y, $code, $w, $h) {
		$Aguid = "";                                                                      // Création des guides de choix ABC
		$Bguid = "";
		$Cguid = "";
		for ($i=0; $i < strlen($code); $i++) {
			$needle = substr($code,$i,1);
			$Aguid .= ((strpos($this->Aset,$needle)===false) ? "N" : "O"); 
			$Bguid .= ((strpos($this->Bset,$needle)===false) ? "N" : "O"); 
			$Cguid .= ((strpos($this->Cset,$needle)===false) ? "N" : "O");
		}

		$SminiC = "OOOO";
		$IminiC = 4;

		$crypt = "";
		while ($code > "") {
																						// BOUCLE PRINCIPALE DE CODAGE
			$i = strpos($Cguid,$SminiC);                                                // forçage du jeu C, si possible
			if ($i!==false) {
				$Aguid [$i] = "N";
				$Bguid [$i] = "N";
			}

			if (substr($Cguid,0,$IminiC) == $SminiC) {                                  // jeu C
				$crypt .= chr(($crypt > "") ? $this->JSwap["C"] : $this->JStart["C"]);  // début Cstart, sinon Cswap
				$made = strpos($Cguid,"N");                                             // étendu du set C
				if ($made === false) {
					$made = strlen($Cguid);
				}
				if (fmod($made,2)==1) {
					$made--;                                                            // seulement un nombre pair
				}
				for ($i=0; $i < $made; $i += 2) {
					$crypt .= chr(strval(substr($code,$i,2)));                          // conversion 2 par 2
				}
				$jeu = "C";
			} else {
				$madeA = strpos($Aguid,"N");                                            // étendu du set A
				if ($madeA === false) {
					$madeA = strlen($Aguid);
				}
				$madeB = strpos($Bguid,"N");                                            // étendu du set B
				if ($madeB === false) {
					$madeB = strlen($Bguid);
				}
				$made = (($madeA < $madeB) ? $madeB : $madeA );                         // étendu traitée
				$jeu = (($madeA < $madeB) ? "B" : "A" );                                // Jeu en cours

				$crypt .= chr(($crypt > "") ? $this->JSwap[$jeu] : $this->JStart[$jeu]); // début start, sinon swap

				$crypt .= strtr(substr($code, 0,$made), $this->SetFrom[$jeu], $this->SetTo[$jeu]); // conversion selon jeu

			}
			$code = substr($code,$made);                                           // raccourcir légende et guides de la zone traitée
			$Aguid = substr($Aguid,$made);
			$Bguid = substr($Bguid,$made);
			$Cguid = substr($Cguid,$made);
		}                                                                          // FIN BOUCLE PRINCIPALE

		$check = ord($crypt[0]);                                                   // calcul de la somme de contrôle
		for ($i=0; $i<strlen($crypt); $i++) {
			$check += (ord($crypt[$i]) * $i);
		}
		$check %= 103;

		$crypt .= chr($check) . chr(106) . chr(107);                               // Chaine cryptée complète

		$i = (strlen($crypt) * 11) - 8;                                            // calcul de la largeur du module
		$modul = $w/$i;

		for ($i=0; $i<strlen($crypt); $i++) {                                      // BOUCLE D'IMPRESSION
			$c = $this->T128[ord($crypt[$i])];
			for ($j=0; $j<count($c); $j++) {
				$this->Rect($x,$y,$c[$j]*$modul,$h,"F");
				$x += ($c[$j++]+$c[$j])*$modul;
			}
		}
	}
	
	public function printpdf(){
		if (isset($this->request->get['libera_id'])) {

			$libera_id = $this->request->get['libera_id'];
			$this->load->model('produccion/libera');
			$cabeza = $this->model_produccion_libera->getLibera($libera_id);
			$items = $this->model_produccion_libera->getLibera_products($libera_id);
 			 		
	 
			 
 
			$membrete = array(
				"p1" => 10,
				"p2" => 60,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'LIBERACION del PRODUCTO',
				"norma" => 'FO-7.5-034',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact')
			);
			

			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			//require('dirsis/fpdf.php');
			//$pdf = new FPDF('L','mm','A4');
			//$pdf = new FPDF();
			require('dirsis/ean13.php');
			$pdf=new PDF_EAN13();
			
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			
			//TITULO Y APERTURA
			$pdf->SetTitle("N°:".str_pad($cabeza['libera_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			$A2=1;
			for ($i = 1; $i <= 2; $i++) {
	//LOGO	
				$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1'],13,50);
				$pdf->Rect($A2+$membrete['p1']-1,12,190,20);
				$pdf->Rect($A2+$membrete['p1']-1+53,12,83,20);
				$pdf->Rect($A2+$membrete['p5']+10,12,19,20);
	//CENTRO	
				$yy=17;
				$pdf->SetY($yy);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,$membrete['titulo'],0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,$cabeza['product'],0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell($A2+$membrete['p2']-5);
				$pdf->Cell(100,0,"Numero:".$cabeza['libera_id'],0,0,'L');
				//$pdf->SetFont('Arial','',10);
				//$pdf->EAN13(120,16,$cabeza['libera_id'],10,.25);
				 
				
	//CENTRO2	
				/*		
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p3']);
				$pdf->Cell(130,0,"Numero:".$cabeza['libera_id'],0,0,'L');
				*/
	//DERECHA	
				$pdf->SetY($yy);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,$membrete['norma'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,"VERSION:".$membrete['version'],0,0,'L');
				
				$pdf->SetY($yy);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(110,0,'Hoja N:'.$i,0,0,'L');
//DATOS CODIGO			
				$yy=$yy+10;
				$pdf->SetY($yy);
				$datoscab = array();
				$datoscab[] = array("xt" => 40,"titulo" => "Codigo");
				$datoscab[] = array("xt" => 40,"titulo" => $cabeza['codigo']);
				$datoscab[] = array("xt" => 40,"titulo" => "Designacion");
				$datoscab[] = array("xt" => 70,"titulo" => $cabeza['product']);
				$yy=$yy+10;
				$pdf->SetY($yy);
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				$pdf->Ln(7);
				$datoscab = array();
				$datoscab[] = array("xt" => 40,"titulo" => "Cantidad");
				$datoscab[] = array("xt" => 40,"titulo" => $cabeza['cantidad']);
				$datoscab[] = array("xt" => 40,"titulo" => "Lote");
				$datoscab[] = array("xt" => 70,"titulo" => "");
				$yy=$yy+10;
				$pdf->SetY($yy);
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}
				$pdf->Ln(10);
//FIRMAS
				$pdf->SetFont('Arial','',8);
				$datos = array();
				$datos[] = array("xt" => 64,"titulo" => "CONTROL (Firma y Fecha)");
				$datos[] = array("xt" => 63,"titulo" => "EMBALAJE (Firma y Fecha)");
				$datos[] = array("xt" => 63,"titulo" => "LIBERA (Firma y Fecha)");
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],28,'',1,0,'C');
				}	
				$pdf->Ln(20);
				$pdf->Cell($A2);
				foreach ($datos as $dato) {
					$pdf->Cell($dato['xt'],8,$dato['titulo'],1,0,'C');
				}
				$pdf->Ln(10);
//SERIES
				$datoscab = array();
				$datoscab[] = array("xt" => 10,"titulo" => "N°");
				$datoscab[] = array("xt" => 36,"titulo" => "SERIE");
				$datoscab[] = array("xt" => 36,"titulo" => "PRESION");
				$datoscab[] = array("xt" => 36,"titulo" => "ESTANQUEDAD");
				$datoscab[] = array("xt" => 36,"titulo" => "ESTETICA");
				$datoscab[] = array("xt" => 36,"titulo" => "CORRECION");
				$pdf->Cell($A2);
				foreach ($datoscab as $dato) {
					$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
				}	
				$pdf->Ln(10);
				$largo=1;
				foreach ($items as $item) {
					$datos = array();
					$datos[] = array("xt" => 10,"titulo" => $largo);
					$datos[] = array("xt" => 36,"titulo" => $item['serie']);
					$datos[] = array("xt" => 36,"titulo" => '');
					$datos[] = array("xt" => 36,"titulo" => '');
					$datos[] = array("xt" => 36,"titulo" => '');
					$datos[] = array("xt" => 36,"titulo" => '');
					$pdf->Cell($A2);
					foreach ($datos as $dato) {
						$pdf->Cell($dato['xt'],10,$dato['titulo'],1,0,'C');
					}
					$pdf->Ln(10);
					$largo++;
				}			
				//PIE
				$archivo="LT".str_pad($cabeza['libera_id'], 8, "0", STR_PAD_LEFT).".pdf";
				//$pdf->Output($archivo,'F');
				$pdf->Output($archivo,'I');			

			}
		}
	}
	
	public function garantiapdf(){
		if (isset($this->request->get['libera_id'])) {

			$libera_id = $this->request->get['libera_id'];
			$this->load->model('produccion/libera');
			$cabeza = $this->model_produccion_libera->getLibera($libera_id);
			$items = $this->model_produccion_libera->getLibera_products($libera_id);
 			 		
	 
			 
 
			$membrete = array(
				"p1" => 10,
				"p2" => 60,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'LIBERACION del PRODUCTO',
				"norma" => 'FO-7.5-034',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact')
			);
			

			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			//require('dirsis/fpdf.php');
			//$pdf = new FPDF('L','mm','A4');
			//$pdf = new FPDF();
			require('dirsis/ean13.php');
			$pdf=new PDF_EAN13();
			
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			
			//TITULO Y APERTURA
			$pdf->SetTitle("N°:".str_pad($cabeza['libera_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			foreach ($items as $item) {
				$pdf->AddPage();
				$A2=100;
				$yy=100;
				$pdf->SetY($yy);
				$pdf->SetFont('Arial','',10);
				$largo=1;
				$datos = array();
				$datos[] = array("xt" => 40,"titulo" => 'T'.$item['serie']);
				$datos[] = array("xt" => 40,"titulo" => 'M'.$item['serie']);
				$datos[] = array("xt" => 40,"titulo" => 'C'.$item['serie']);
				$datos[] = array("xt" => 40,"titulo" => 'P'.$item['serie']);
				$datos[] = array("xt" => 40,"titulo" => 'C'.$item['serie']);
				
				foreach ($datos as $dato) {
					$pdf->Cell($A2);
					$pdf->Cell($dato['xt'],14,$dato['titulo'],0,0,'C');
					$pdf->Ln();
				}
			}			
			$archivo="LT".str_pad($cabeza['libera_id'], 8, "0", STR_PAD_LEFT).".pdf";
			$pdf->Output($archivo,'I');			
		}
	}	
	
	public function emiteetiq(){
		if (isset($this->request->get['libera_id'])) {
			$libera_id = $this->request->get['libera_id'];
			$this->load->model('produccion/libera');
			$procesos=$this->model_produccion_libera->getLibera_products($libera_id);
			
			$this->load->model('produccion/etiq');
			$datos = array();
			foreach ($procesos as $proceso) {
				if ($proceso['serie']){
				$data= array ( 	"report" => '3',
						  	"sector" => '2',
						  	"ot" => $libera_id,
							"dato1" => $proceso['serie'],
							"dato2" => '',
							"dato3" => '',
							"dato4" => '',
							"dato5" => '',
							"dato6" => '',
							"dato7" => '',
							"dato8" => '',
							"dato9" => '',
							"status" => '1');
				print_r($data);
				//$this->model_produccion_etiq->addEtiq($data);
				}
			}				
		}
	}
	
		
}