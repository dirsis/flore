<?php
class ControllerProduccionEtiq extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/etiq');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/etiq');
		$this->getList();
	}
	
	public function filtrar($get,$accion="gral"){
	
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'sector';
		}
		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_etiq_id'])) {
			$url .= '&filter_etiq_id=' . $get['filter_etiq_id'];
		}
		if (isset($get['filter_report'])) {
			$url .= '&filter_report=' . $get['filter_report'];
		}		
		if (isset($get['filter_sector'])) {
			$url .= '&filter_sector=' . $get['filter_sector'];
		}
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/etiq');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/etiq');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_produccion_etiq->addEtiq($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('produccion/etiq');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/etiq');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			$this->model_produccion_etiq->editEtiq($this->request->get['etiq_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/etiq');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/etiq');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $etiq_id) {
				$this->model_produccion_etiq->deleteEtiq($etiq_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_etiq_id'])) {
			$filter_etiq_id = $this->request->get['filter_etiq_id'];
		} else {
			$filter_etiq_id = '';
		}
		if (isset($this->request->get['filter_report'])) {
			$filter_report = $this->request->get['filter_report'];
		} else {
			$filter_report = '';
		}		
		if (isset($this->request->get['filter_sector'])) {
			$filter_sector = $this->request->get['filter_sector'];
		} else {
			$filter_sector = '';
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '0';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'sector';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/etiq/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/etiq/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['etiqs'] = array();
		$filter_data = array(
			'filter_etiq_id'      => $filter_etiq_id,
			'filter_report'      => $filter_report,
			'filter_sector'   	=> $filter_sector,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$etiq_total = $this->model_produccion_etiq->getTotalEtiqs($filter_data);

		$this->load->model('user/user');
		$results = $this->model_produccion_etiq->getEtiqs($filter_data);

		foreach ($results as $result) {
			
			$data['etiqs'][] = array(
				'etiq_id'    	=> $result['etiq_id'],
				'sector'    		=> $result['sector'],
				'report'    		=> $result['report'],
				'dato1'    		=> $result['dato1'],
				'dato2'    		=> $result['dato2'],
				'dato3'    		=> $result['dato3'],
				'dato4'    		=> $result['dato4'],
				'dato5'    		=> $result['dato5'],
				'dato6'    		=> $result['dato6'],
				'dato7'    		=> $result['dato7'],
				'dato8'    		=> $result['dato8'],
				'dato9'    		=> $result['dato9'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'edit'           	=> $this->url->link('produccion/etiq/edit', 'user_token=' . $this->session->data['user_token'] . '&etiq_id=' . $result['etiq_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/etiq/clonar', 'user_token=' . $this->session->data['user_token'] . '&etiq_id=' . $result['etiq_id'] . $url, true)
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_etiq_id'] = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . '&sort=etiq_id' . $url, true);
		
		$data['sort_report'] = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . '&sort=report' . $url, true);		
		
		$data['sort_sector'] = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . '&sort=sector' . $url, true);
		
		$data['sort_date_added'] = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $etiq_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($etiq_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($etiq_total -  $limit)) ? $etiq_total : ((($page - 1) *  $limit) +  $limit), $etiq_total, ceil($etiq_total /  $limit));

		$data['filter_etiq_id'] = $filter_etiq_id;
		$data['filter_report'] = $filter_report;
		$data['filter_sector'] = $filter_sector;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/etiq_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['etiq_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['etiq_id'])) {
			$data['action'] = $this->url->link('produccion/etiq/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('produccion/etiq/edit', 'user_token=' . $this->session->data['user_token'] . '&etiq_id=' . $this->request->get['etiq_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('produccion/etiq', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['etiq_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_produccion_etiq->getEtiq($this->request->get['etiq_id']);
		}

		if (isset($this->request->get['etiq_id'])) {
			$data['etiq_id'] = $this->request->get['etiq_id'];
		} else {
			$data['etiq_id'] = 0;
		}
		
		if (isset($this->request->post['sector'])) {
			$data['sector'] = $this->request->post['sector'];
		} elseif (!empty($info)) {
			$data['sector'] = $info['sector'];
		} else {
			$data['sector'] = '';
		}	
		
		if (isset($this->request->post['report'])) {
			$data['report'] = $this->request->post['report'];
		} elseif (!empty($info)) {
			$data['report'] = $info['report'];
		} else {
			$data['report'] = '';
		}
		
		if (isset($this->request->post['dato1'])) {
			$data['dato1'] = $this->request->post['dato1'];
		} elseif (!empty($info)) {
			$data['dato1'] = $info['dato1'];
		} else {
			$data['dato1'] = '';
		}
		
		if (isset($this->request->post['dato2'])) {
			$data['dato2'] = $this->request->post['dato2'];
		} elseif (!empty($info)) {
			$data['dato2'] = $info['dato2'];
		} else {
			$data['dato2'] = '';
		}
		
		if (isset($this->request->post['dato3'])) {
			$data['dato3'] = $this->request->post['dato3'];
		} elseif (!empty($info)) {
			$data['dato3'] = $info['dato3'];
		} else {
			$data['dato3'] = '';
		}
		
		if (isset($this->request->post['dato4'])) {
			$data['dato4'] = $this->request->post['dato4'];
		} elseif (!empty($info)) {
			$data['dato4'] = $info['dato4'];
		} else {
			$data['dato4'] = '';
		}
		
		if (isset($this->request->post['dato5'])) {
			$data['dato5'] = $this->request->post['dato5'];
		} elseif (!empty($info)) {
			$data['dato5'] = $info['dato5'];
		} else {
			$data['dato5'] = '';
		}
		
		if (isset($this->request->post['dato6'])) {
			$data['dato6'] = $this->request->post['dato6'];
		} elseif (!empty($info)) {
			$data['dato6'] = $info['dato6'];
		} else {
			$data['dato6'] = '';
		}
		
		if (isset($this->request->post['dato7'])) {
			$data['dato7'] = $this->request->post['dato7'];
		} elseif (!empty($info)) {
			$data['dato7'] = $info['dato7'];
		} else {
			$data['dato7'] = '';
		}
		
		if (isset($this->request->post['dato8'])) {
			$data['dato8'] = $this->request->post['dato8'];
		} elseif (!empty($info)) {
			$data['dato8'] = $info['dato8'];
		} else {
			$data['dato8'] = '';
		}
		
		if (isset($this->request->post['dato9'])) {
			$data['dato9'] = $this->request->post['dato9'];
		} elseif (!empty($info)) {
			$data['dato9'] = $info['dato9'];
		} else {
			$data['dato9'] = '';
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/etiq_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'produccion/etiq')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*		
		if ((utf8_strlen($this->request->post['sector']) < 1) || (utf8_strlen(trim($this->request->post['sector'])) > 200)) {
			$this->error['sector'] = $this->language->get('error_sector');
		}
*/		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/etiq')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
		
}