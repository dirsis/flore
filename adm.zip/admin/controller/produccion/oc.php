<?php
class ControllerProduccionOc extends Controller {
	private $error = array();

	public function normalize($word){
			$word = str_replace("@","%40",$word);
			$word = str_replace("`","%60",$word);
			$word = str_replace("¢","%A2",$word);
			$word = str_replace("£","%A3",$word);
			$word = str_replace("¥","%A5",$word);
			$word = str_replace("|","%A6",$word);
			$word = str_replace("«","%AB",$word);
			$word = str_replace("¬","%AC",$word);
			$word = str_replace("¯","%AD",$word);
			$word = str_replace("º","%B0",$word);
			$word = str_replace("±","%B1",$word);
			$word = str_replace("ª","%B2",$word);
			$word = str_replace("µ","%B5",$word);
			$word = str_replace("»","%BB",$word);
			$word = str_replace("¼","%BC",$word);
			$word = str_replace("½","%BD",$word);
			$word = str_replace("¿","%BF",$word);
			$word = str_replace("À","%C0",$word);
			$word = str_replace("Á","%C1",$word);
			$word = str_replace("Â","%C2",$word);
			$word = str_replace("Ã","%C3",$word);
			$word = str_replace("Ä","%C4",$word);
			$word = str_replace("Å","%C5",$word);
			$word = str_replace("Æ","%C6",$word);
			$word = str_replace("Ç","%C7",$word);
			$word = str_replace("È","%C8",$word);
			$word = str_replace("É","%C9",$word);
			$word = str_replace("Ê","%CA",$word);
			$word = str_replace("Ë","%CB",$word);
			$word = str_replace("Ì","%CC",$word);
			$word = str_replace("Í","%CD",$word);
			$word = str_replace("Î","%CE",$word);
			$word = str_replace("Ï","%CF",$word);
			$word = str_replace("Ð","%D0",$word);
			$word = str_replace("Ñ","%D1",$word);
			$word = str_replace("Ò","%D2",$word);
			$word = str_replace("Ó","%D3",$word);
			$word = str_replace("Ô","%D4",$word);
			$word = str_replace("Õ","%D5",$word);
			$word = str_replace("Ö","%D6",$word);
			$word = str_replace("Ø","%D8",$word);
			$word = str_replace("Ù","%D9",$word);
			$word = str_replace("Ú","%DA",$word);
			$word = str_replace("Û","%DB",$word);
			$word = str_replace("Ü","%DC",$word);
			$word = str_replace("Ý","%DD",$word);
			$word = str_replace("Þ","%DE",$word);
			$word = str_replace("ß","%DF",$word);
			$word = str_replace("à","%E0",$word);
			$word = str_replace("á","%E1",$word);
			$word = str_replace("â","%E2",$word);
			$word = str_replace("ã","%E3",$word);
			$word = str_replace("ä","%E4",$word);
			$word = str_replace("å","%E5",$word);
			$word = str_replace("æ","%E6",$word);
			$word = str_replace("ç","%E7",$word);
			$word = str_replace("è","%E8",$word);
			$word = str_replace("é","%E9",$word);
			$word = str_replace("ê","%EA",$word);
			$word = str_replace("ë","%EB",$word);
			$word = str_replace("ì","%EC",$word);
			$word = str_replace("í","%ED",$word);
			$word = str_replace("î","%EE",$word);
			$word = str_replace("ï","%EF",$word);
			$word = str_replace("ð","%F0",$word);
			$word = str_replace("ñ","%F1",$word);
			$word = str_replace("ò","%F2",$word);
			$word = str_replace("ó","%F3",$word);
			$word = str_replace("ô","%F4",$word);
			$word = str_replace("õ","%F5",$word);
			$word = str_replace("ö","%F6",$word);
			$word = str_replace("÷","%F7",$word);
			$word = str_replace("ø","%F8",$word);
			$word = str_replace("ù","%F9",$word);
			$word = str_replace("ú","%FA",$word);
			$word = str_replace("û","%FB",$word);
			$word = str_replace("ü","%FC",$word);
			$word = str_replace("ý","%FD",$word);
			$word = str_replace("þ","%FE",$word);
			$word = str_replace("ÿ","%FF",$word);
			return $word;
		//urldecode($word);
		}

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/oc');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/oc');
		//CREA LA TABLA SI NO EXISTE
		//$this->model_produccion_oc->bajaOc();
		$this->model_produccion_oc->creaOc();
		
		//			
		$this->getList();
	}
	public function reinicia(){
		$this->load->model('produccion/oc');
		$this->model_produccion_oc->bajaOc();
		$this->model_produccion_oc->creaOc();
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}	
	public function sincro(){
		$this->load->language('produccion/oc');
		$this->load->model('produccion/oc');
		$this->model_produccion_oc->traeOc();
		$this->session->data['success'] = $this->language->get('text_success');
		$url = $this->filtrar($this->request->get,"gral");
		$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
	}
	
	public function filtrar($get,$accion="gral"){
	
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}
		

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_oc_id'])) {
			$url .= '&filter_oc_id=' . $get['filter_oc_id'];
		}
		if (isset($get['filter_descrip'])) {
			$url .= '&filter_descrip=' . $get['filter_descrip'];
		}
		if (isset($get['filter_date_init'])) {
			$url .= '&filter_date_init=' . $get['filter_date_init'];
		}
		if (isset($get['filter_date_fin'])) {
			$url .= '&filter_date_fin=' . $get['filter_date_fin'];
		}
		if (isset($get['filter_estado_id'])) {
			$url .= '&filter_estado_id=' . $get['filter_estado_id'];
		}	
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

	public function add() {
		
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//		
		$this->load->language('produccion/oc');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/oc');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_produccion_oc->addOc($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function edit() {
		$this->load->language('produccion/oc');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/oc');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			/*
			echo "<pre>";
			print_r($this->request->post);
			echo "</pre>";
			die;
			*/
			$this->model_produccion_oc->editOc($this->request->get['oc_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get);
			$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getForm();
	}
	
	public function delete() {
		$this->load->language('produccion/oc');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/oc');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $oc_id) {
				$this->model_produccion_oc->deleteOc($oc_id);
			}
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}
		$this->getList();
	}
	
	
	public function copy() {
		$this->load->language('produccion/oc');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/oc');

		if (isset($this->request->post['selected']) && $this->validateCopy()) {
			foreach ($this->request->post['selected'] as $oc_id) {
				$this->model_produccion_oc->copyOc($oc_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');
			$url = $this->filtrar($this->request->get,"gral");
			$this->response->redirect($this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}
	
	protected function getList() {

		if (isset($this->request->get['filter_oc_id'])) {
			$filter_oc_id = $this->request->get['filter_oc_id'];
		} else {
			$filter_oc_id = '';
		}
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		if (isset($this->request->get['filter_estado_id'])) {
			$filter_estado_id = $this->request->get['filter_estado_id'];
		} else {
			$filter_estado_id = '';
		}
		if (isset($this->request->get['filter_date_init'])) {
			$filter_date_init = date("d-m-Y",strtotime($this->request->get['filter_date_init']));
		} else {
			$filter_date_init = '';
		}
		if (isset($this->request->get['filter_date_fin'])) {
			$filter_date_fin = date("d-m-Y",strtotime($this->request->get['filter_date_fin']));
		} else {
			$filter_date_fin = '';
		}		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}


		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/oc/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/oc/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/oc/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['ocs'] = array();
		$filter_data = array(
			'filter_oc_id'      => $filter_oc_id,
			'filter_descrip'   	=> $filter_descrip,
			'filter_date_init' 	=> $filter_date_init,
			'filter_date_fin' 	=> $filter_date_fin,
			'filter_estado_id' 	=> $filter_estado_id,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$oc_total = $this->model_produccion_oc->getTotalOcs($filter_data);

		$this->load->model('user/user');
		$results = $this->model_produccion_oc->getOcs($filter_data);

		foreach ($results as $result) {
			
			
			$user_id_added=$this->model_user_user->getUser($result['user_id_added']);
			
			$user_id_added=$user_id_added['username'];
			if ($result['user_id_modified']!=0){
				$user_id_modified=$this->model_user_user->getUser($result['user_id_modified']);
				$user_id_modified=$user_id_modified['username'];
			}else{
				$user_id_modified="";
			}
			if ($result['user_id_delete']!=0){
				$user_id_delete=$this->model_user_user->getUser($result['user_id_delete']);
				$user_id_delete=$user_id_delete['username'];
			}else{
				$user_id_delete="";
			}
			
			

			$data['ocs'][] = array(
				'oc_id'    			=> $result['oc_id'],
				'proveedor'    		=> $result['proveedor'],
				'contacto'    		=> $result['contacto'],
				'descrip'    		=> $result['descrip'],
				'obs'    			=> $result['obs'],
				'nota'    			=> $result['nota'],
				'estado_id'    		=> $result['estado_id'],
				'estado'    		=> $result['estado'],
				'estadocolor'    	=> $result['estadocolor'],
				'date_added'        => $result['date_added']?date('d-m-Y', strtotime($result['date_added'])):"",
				'date_compr'        => $result['date_compr']?date('d-m-Y', strtotime($result['date_compr'])):"",
				'pagado'    		=> $result['pagado'],
				'status'         	=> ($result['status']=='1' ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'date_modified'     => $result['date_modified']==""?"":date('d-m-Y', strtotime($result['date_modified'])),
				'date_delete'     	=> $result['date_delete']==""?"":date('d-m-Y', strtotime($result['date_delete'])),
				'user_id_added'		=> $user_id_added,
				'user_id_modified'	=> $user_id_modified,
				'user_id_delete'	=> $user_id_delete,
				'edit'           	=> $this->url->link('produccion/oc/edit', 'user_token=' . $this->session->data['user_token'] . '&oc_id=' . $result['oc_id'] . $url, true),
				'clonar'           	=> $this->url->link('produccion/oc/clonar', 'user_token=' . $this->session->data['user_token'] . '&oc_id=' . $result['oc_id'] . $url, true),
				'print'           	=> $this->url->link('produccion/oc/printpdf', 'user_token=' . $this->session->data['user_token'] . '&oc_id=' . $result['oc_id'] . $url, true)	
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}
//proveedor_id,contacto,descrip,obs,nota,estado_id,date_added,date_compr,pagado
		$url = $this->filtrar($this->request->get,"column");
		$data['sort_oc_id'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.oc_id' . $url, true);
		
		$data['sort_proveedor'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=proveedor' . $url, true);
		$data['sort_contacto'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.contacto' . $url, true);
		$data['sort_descrip'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.descrip' . $url, true);
		$data['sort_estado_id'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.estado_id' . $url, true);		
		$data['sort_date_added'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		$data['sort_date_compr'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_compr' . $url, true);
		$data['sort_pagado'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . '&sort=o.pagado' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $oc_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($oc_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($oc_total -  $limit)) ? $oc_total : ((($page - 1) *  $limit) +  $limit), $oc_total, ceil($oc_total /  $limit));

		$data['filter_oc_id'] = $filter_oc_id;
		$data['filter_descrip'] = $filter_descrip;
		$data['filter_date_init'] = $filter_date_init;
		$data['filter_date_fin'] = $filter_date_fin;
		$data['filter_estado_id'] = $filter_estado_id;
		$data['filter_status'] = $filter_status;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$this->load->model('produccion/proveedor');
		$data['proveedors'] = $this->model_produccion_proveedor->getProveedors(array());	

		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());	
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/oc_list', $data));
	}

	protected function getForm() {
		
				//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		
		$data['text_form'] = !isset($this->request->get['oc_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		$data['user_token'] = $this->session->data['user_token'];

		//ERRORES
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = $this->filtrar($this->request->get,"gral");
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['oc_id'])) {
			$data['action'] = $this->url->link('produccion/oc/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('produccion/oc/edit', 'user_token=' . $this->session->data['user_token'] . '&oc_id=' . $this->request->get['oc_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('produccion/oc', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['oc_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$info = $this->model_produccion_oc->getOc($this->request->get['oc_id']);
		}

		
		
		
		if (isset($this->request->get['oc_id'])) {
			$data['oc_id'] = $this->request->get['oc_id'];
		} else {			$data['oc_id'] = 0;		}

		
		//proveedor_id,contacto,descrip,obs,nota,estado_id,date_added,date_compr,pagado
		if (isset($this->request->post['proveedor_id'])) {
			$data['proveedor_id'] = $this->request->post['proveedor_id'];
		} elseif (!empty($info)) {
			$data['proveedor_id'] = $info['proveedor_id'];
		} else {			$data['proveedor_id'] = '';		}
		if (isset($this->request->post['contacto'])) {
			$data['contacto'] = $this->request->post['contacto'];
		} elseif (!empty($info)) {
			$data['contacto'] = $info['contacto'];
		} else {			$data['contacto'] = '';		}	
		if (isset($this->request->post['descrip'])) {
			$data['descrip'] = $this->request->post['descrip'];
		} elseif (!empty($info)) {
			$data['descrip'] = $info['descrip'];
		} else {			$data['descrip'] = '';		}
		if (isset($this->request->post['obs'])) {
			$data['obs'] = $this->request->post['obs'];
		} elseif (!empty($info)) {
			$data['obs'] = $info['obs'];
		} else {			$data['obs'] = '';		}
		if (isset($this->request->post['nota'])) {
			$data['nota'] = $this->request->post['nota'];
		} elseif (!empty($info)) {
			$data['nota'] = $info['nota'];
		} else {			$data['nota'] = '';		}	
		if (isset($this->request->post['estado_id'])) {
			$data['estado_id'] = $this->request->post['estado_id'];
		} elseif (!empty($info)) {
			$data['estado_id'] = $info['estado_id'];
		} else {			$data['estado_id'] = '';		}		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($info)) {
			$data['date_added'] = date("d-m-Y",strtotime($info['date_added']));
		} else {			$data['date_added'] = date('d-m-Y');		}
		if (isset($this->request->post['date_compr'])) {
			$data['date_compr'] = $this->request->post['date_compr'];
		} elseif (!empty($info)) {
			$data['date_compr'] = date("d-m-Y",strtotime($info['date_compr']));
		} else {			$data['date_compr'] = date('d-m-Y');		}
		if (isset($this->request->post['pagado'])) {
			$data['pagado'] = $this->request->post['pagado'];
		} elseif (!empty($info)) {
			$data['pagado'] = $info['pagado'];
		} else {			$data['pagado'] = '';		}	
		
		if (isset($this->request->post['date_modified'])) {
			$data['date_modified'] = $this->request->post['date_modified'];
		} elseif (!empty($info)) {
			$data['date_modified'] = $info['date_modified']==""?"":date("d-m-Y",strtotime($info['date_modified']));
		} else {
			$data['date_modified'] = "";
		}
		if (isset($this->request->post['date_delete'])) {
			$data['date_delete'] = $this->request->post['date_delete'];
		} elseif (!empty($info)) {
			$data['date_delete'] = $info['date_delete']==""?"":date("d-m-Y",strtotime($info['date_delete']));
		} else {
			$data['date_delete'] = "";
		}	
		
		if (isset($this->request->post['user_id_added'])) {
			$data['user_id_added'] = $this->request->post['user_id_added'];
		} elseif (!empty($info)) {
			$data['user_id_added'] = $info['user_id_added'];
		} else {
			$data['user_id_added'] = $this->user->getId();
		}		
		if (isset($this->request->post['user_id_modified'])) {
			$data['user_id_modified'] = $this->request->post['user_id_modified'];
		} elseif (!empty($info)) {
			$data['user_id_modified'] = $info['user_id_modified'];
		} else {
			$data['user_id_modified'] = "";
		}
		if (isset($this->request->post['user_id_delete'])) {
			$data['user_id_delete'] = $this->request->post['user_id_delete'];
		} elseif (!empty($info)) {
			$data['user_id_delete'] = $info['user_id_delete'];
		} else {
			$data['user_id_delete'] = "";
		}
		
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($info)) {
			$data['status'] = $info['status'];
		} else {
			$data['status'] = true;
		}
		
		$data['items']=array();
		if (isset($this->request->get['oc_id'])){
			$data['items']= $this->model_produccion_oc->getItemsxOc($this->request->get['oc_id']);
		}
		
		$data['iditems'] = $this->load->view('produccion/oc_item', $data);
		
		$this->load->model('produccion/proveedor');
		$data['proveedors'] = $this->model_produccion_proveedor->getProveedors(array());	
		
		$this->load->model('produccion/estado');
		$data['estados'] = $this->model_produccion_estado->getEstados(array());			
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('produccion/oc_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'produccion/oc')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
/*		
		if ((utf8_strlen($this->request->post['descrip']) < 1) || (utf8_strlen(trim($this->request->post['descrip'])) > 200)) {
			$this->error['descrip'] = $this->language->get('error_descrip');
		}
*/		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'produccion/oc')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
	
	protected function validateCopy() {
		if (!$this->user->hasPermission('modify', 'produccion/oc')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	
		
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_oc_id'])) {
			$filter_oc_id = $this->request->get['filter_oc_id'];
		} else {
			$filter_oc_id = '';
		}
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}

		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = '1';
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = date("Y-m-d",strtotime($this->request->get['filter_date_added']));
		} else {
			$filter_date_added = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'descrip';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		if (isset($get['limit'])) {
			$limit = $get['limit'];
		}else{
			$limit = $this->config->get('config_limit_admin');
		}
		$data['ocs'] = array();
		$filter_data = array(
			'filter_oc_id'        => $filter_oc_id,
			'filter_descrip'           => $filter_descrip,
			'filter_status'            => $filter_status,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
		$this->load->model('produccion/oc');
		$results = $this->model_produccion_oc->getOcs($filter_data);
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setOt("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "id")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Estado")
					->setCellValue('D'.$row,  "Fecha Alta");
		$row++;	
		foreach ($results as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['oc_id'])
					->setCellValue('B'.$row,  $result['descrip'])
					->setCellValue('C'.$row,  $result['status'])
					->setCellValue('D'.$row,  date('d-m-Y', strtotime($result['date_added'])));
			$row++;
		}
		foreach(range('A','D') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
	public function upload_xlsx() {
		$json=array();
		if ( isset( $_FILES[ 'file' ][ 'name' ] ) ) {
			$code = sha1(uniqid(mt_rand(), true)).".xlsx";
			if (is_file(DIR_UPLOAD . $code)) {
				unlink(DIR_UPLOAD . $code);
			}
			move_uploaded_file( $_FILES[ "file" ][ "tmp_name" ], DIR_UPLOAD . $code );
			$json[]=array("Archivo" => DIR_UPLOAD . $code);
			
			$json=$this->leer_archivo(DIR_UPLOAD . $code,0,1);
			
			$this->session->data['success'] = "Se Editaron:".$json['edit']."/ Se Crearon:".$json['new']." con exito!";
		}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}	
	public function leer_archivo( $archivo,$hoja = 0,$linea = 1 ) {
		ini_set('max_execution_time', 36000);
		ini_set('memory_limit', '12G');
		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$inputFileName = $archivo;
		$reader = PHPExcel_IOFactory::createReaderForFile($inputFileName);
		$reader->setReadDataOnly(true);
		$excel = $reader->load($inputFileName);
		$sheet = $excel->getActiveSheet();
		$data = $sheet->toArray();
		$this->load->model('produccion/oc');
		$edit=$new=$linea=0;
		foreach ($data as $in_ar){
			if (!empty($in_ar[1]) and $linea>0){
				$dato=array(
					
					
					"descrip" => $in_ar[1],
					"domicilio" => $in_ar[2],
					"ciudad" => $in_ar[3],
					"telefono" => $in_ar[4],
					"email" => $in_ar[5],
					"status" => 1
				);
				if ((int)$in_ar[0]>0){
					//EDITAR
					$this->model_produccion_oc->editOc($in_ar[0],$dato);
					$edit++;
				}else{
					//NUEVO
					$this->model_produccion_oc->addOc($dato);			
					$new++;
				}
			}
			$linea++;
		}
		return array("archivo" => $archivo, "edit" => $edit,"new" => $new);
	}	
	
	
	public function printpdf(){
		if (isset($this->request->get['oc_id'])) {
			
			$this->load->model('admdirsis/codiva');
			
			$oc_id = $this->request->get['oc_id'];
			$this->load->model('produccion/oc');
			$cabeza = $this->model_produccion_oc->getOc($oc_id);
			$detalle = $this->model_produccion_oc->getItemsxOc($oc_id);
/*						
						print_r($cabeza);
						print_r($detalle);
						die;
*/
			$membrete = array(
				"p1" => 10,
				"p2" => 60,
				"p3" => 120,
				"p4" => 140,
				"p5" => 170,
				"titulo" => 'ORDEN DE COMPRA',
				"norma" => 'FO-7.4-001',
				"version" => '01',
				"fantasia" => html_entity_decode($this->config->get('config_owner'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"name" => html_entity_decode($this->config->get('config_name'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"image" => $this->config->get('config_image'),
				"address" => html_entity_decode($this->config->get('config_address'), ENT_QUOTES | ENT_XML1, 'UTF-8'),
				"email" => $this->config->get('config_email'),
				"telephone" => $this->config->get('config_telephone'),
				"fax" => $this->config->get('config_fax'),
				"cuit" => $this->config->get('config_factura_cuit'),
				"iib" => $this->config->get('config_factura_iib'),
				"iniact" => $this->config->get('config_factura_iniact'),
				"codiva_id" => $this->config->get('config_factura_codiva_id'),
				"codiva" => $this->model_admdirsis_codiva->getCodiva($this->config->get('config_factura_codiva_id'))
			);
			

			
			if ($this->request->server['HTTPS']) {
				$data['base'] = HTTPS_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			} else {
				$data['base'] = HTTP_SERVER."catalog/";
				$data['url'] = HTTPS_CATALOG;
			}
			$data['direction'] = $this->language->get('direction');
			$data['lang'] = $this->language->get('code');

			//require('dirsis/fpdf.php');
			//$pdf = new FPDF('L','mm','A4');
			//$pdf = new FPDF();
			
			require('dirsis/codabar.php');
			$pdf=new PDF_Codabar();			
			
			//$pdf->SetMargins(3, 2 , 3);
			#Establecemos el margen inferior:
			$pdf->SetAutoPageBreak(true,2);			
			//TITULO Y APERTURA
			$pdf->SetTitle("OC N°:".str_pad($cabeza['oc_id'], 8, "0", STR_PAD_LEFT), true);
			$pdf->AliasNbPages();
			$pdf->AddPage();
			header("Content-type: application/pdf; charset=utf-8");
			$A2=1;
			for ($i = 1; $i <= 2; $i++) {
	//LOGO	
				$pdf->Image($data['url']."image/".$membrete['image'],$A2+$membrete['p1'],13,50);
				$pdf->Rect($A2+$membrete['p1']-1,12,190,20);
				$pdf->Rect($A2+$membrete['p1']-1+53,12,80,20);
				$pdf->Rect($A2+$membrete['p5']+10,12,19,20);
				/*
				
				$pdf->Rect($A2+$membrete['p1'],5+7, $A2+140,37);
				$pdf->Rect($A2+$membrete['p1'],5+7+37, $A2+140,37);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37, $A2+140,7);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37+7, $A2+140,80);
				$pdf->Rect($A2+$membrete['p1'],5+7+37+37+80, $A2+140,7);
				*/
				
	//CENTRO	
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p2']);
				$pdf->Cell(130,0,$membrete['titulo'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p2']);
				$pdf->Cell(130,0,"No:".$cabeza['oc_id'],0,0,'L');
	/*/CENTRO2			
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p3']);
				$pdf->Cell(130,0,$cabeza['oc_id'],0,0,'L');
	*/
	//DERECHA	
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',12);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,$membrete['norma'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,"VERSION:".$membrete['version'],0,0,'L');
				
				$pdf->SetY(20);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(110,0,'Hoja N:'.$i,0,0,'L');
	//CENTRO			
				$pdf->SetY(40);
				$pdf->Cell($A2+$membrete['p2']);
				$pdf->Cell(110,0,"DATOS PROVEEDOR",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,35,190,10);
				
				$pdf->Codabar(120,14,$cabeza['oc_id'], 'A', 'A', 0.35, 10);
				
	//CENTRO	
				$yy=55;
				$pdf->SetY($yy);
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,30,8+8+8+8);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2);
				$pdf->Cell(130,0,"Razon Social",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,190,8);
				$pdf->Ln(7);
				$pdf->Cell($A2);
				$pdf->Cell(130,0,"Domicilio",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5+8,190,8);
				$pdf->Ln(7);
				$pdf->Cell($A2);
				$pdf->Cell(130,0,"Tel/Fax",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5+8+8,190,8);
				$pdf->Ln(7);
				$pdf->Cell($A2);
				$pdf->Cell(130,0,"Contacto",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5+8+8+8,190,8);
				
				$pdf->SetY($yy);
				$pdf->Cell($A2+$membrete['p1']+20);
				$pdf->Cell(130,0,$cabeza['razonsocial'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p1']+20);
				$pdf->Cell(130,0,$cabeza['domicilio'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p1']+20);
				$pdf->Cell(130,0,$cabeza['telefono'],0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p1']+20);
				$pdf->Cell(130,0,$cabeza['contacto'],0,0,'L');
				/*
				
 Array ( [oc_id] => 2 [proveedor_id] => 51 [contacto] => [descrip] => B [obs] => C [nota] => [estado_id] => 1 [date_added] => 2024-03-09 21:28:47 [date_compr] => 2024-04-03 [pagado] => 1 [status] => 1 [date_modified] => [date_delete] => [user_id_added] => 1 [user_id_modified] => 0 [user_id_delete] => 0 [razonsocial] => Abrasivos - Kling [domicilio] => [barrio] => [ciudad] => [cp] => [provincia_id] => 0 [email] => gabriel.medina@klingspor.com.ar [telefono] => 156-136906 [codiva_id] => 1 [cuit] => [autogestion_id] => 0 ) 
	 			*/
				$yy=$yy+8+7;
				$pdf->SetY($yy);
				$pdf->Rect($A2+$membrete['p3']-13,$yy-4,40,8+8);
				$pdf->Cell($A2+$membrete['p3']-20);
				$pdf->Cell(130,0,"Fecha de Pedido",0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p3']-20);
				$pdf->Cell(130,0,"Fecha de Entrega",0,0,'L');
				$pdf->SetY($yy);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,date("d-m-Y",strtotime($cabeza['date_added'])),0,0,'L');
				$pdf->Ln(7);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(130,0,date("d-m-Y",strtotime($cabeza['date_compr'])),0,0,'L');	
				
	//CENTRO			
				$yy=$yy+20;
				$pdf->SetY($yy);
				$pdf->Cell($A2+$membrete['p2']);
				$pdf->Cell(110,0,"DATOS DE PEDIDO",0,0,'L');
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,190,10);				
	//ITEM
				$yy=$yy+16;
				$pdf->SetY($yy);
				$pdf->SetFont('Arial','',8);
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,190,10);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(30,0,"CODIGO",0,0,'L');
				$pdf->Cell(50,0,"DESIGNACION",0,0,'L');
				$pdf->Cell(30,0,"CANTIDAD",0,0,'R');
				$pdf->Cell(20,0,"KGS",0,0,'L');
				$pdf->Cell(25,0,"PRECIO.UNIT",0,0,'R');
				$pdf->Cell(25,0,"TOTAL",0,0,'R');
				$pdf->Ln(8);
				/*
				Array ( [0] => Array ( [ocitem_id] => 8 [oc_id] => 2 [product_id] => 1 [cantidad] => 222 [product] => Reparación ) )
				*/	
				$total=0;
				foreach ($detalle as $result) {
					$pdf->SetFont('Arial','',10);
					$pdf->Cell($A2+$membrete['p1']);
					$pdf->Cell(30,0,$result['codigo'],0,0,'L');
					$pdf->Cell(50,0,$result['product'],0,0,'L');
					$pdf->Cell(30,0,$result['cantidad'],0,0,'R');
					$pdf->Cell(20,0,"",0,0,'L');
					$pdf->Cell(25,0,$result['costo'],0,0,'R');
					$pdf->Cell(25,0,$result['total'],0,0,'R');					
					$pdf->Ln(6);
					$total=$total+$result['total'];
				}	
				
				$pdf->SetY(-60);
				$yy=$pdf->GetY();
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,130,15);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(130,0, "RECIBIO (Firma y Fecha)",0,0,'C');
				$pdf->Ln(13);
				$pdf->Rect($A2+$membrete['p1']-1,$yy+10,130,10);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(70,0, "Condiciones",0,0,'L');
				$pdf->Ln(6);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(140,0, $cabeza['nota'],0,0,'L');
				$pdf->Ln(4);
				$pdf->Rect($A2+$membrete['p1']-1,$yy+10+10,130,15);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(70,0, "Observaciones",0,0,'L');
				$pdf->Ln(6);
				$pdf->Cell($A2+$membrete['p1']);
				$pdf->Cell(140,0, $cabeza['obs'],0,0,'L');
				
				$pdf->SetY(-60);
				//$pdf->Rect($A2+$membrete['p4']-1,$yy-5,65,30);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(20,0, "Sub.Total",0,0,'R');
				$pdf->Ln(8);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(20,0, "I.V.A.",0,0,'R');
				$pdf->Ln(8);
				$pdf->Cell($A2+$membrete['p4']);
				$pdf->Cell(20,0, "TOTAL",0,0,'R');				

				$pdf->SetY(-60);
				$pdf->SetFont('Arial','',10);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(20,0, number_format($total,2,",","."),0,0,'R');
				$pdf->Ln(8);
				$iva=round($total*21/100);
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(20,0, number_format($iva,2,",","."),0,0,'R');
				$pdf->Ln(8);
				$total=$total+$iva;
				$pdf->Cell($A2+$membrete['p5']);
				$pdf->Cell(20,0, number_format($total,2,",","."),0,0,'R');
				
				
				$pdf->SetY(-20);
				$yy=$pdf->GetY();
				$pdf->SetFont('Arial','',8);
				$pdf->Rect($A2+$membrete['p1']-1,$yy-5,190,20);
				$pdf->Rect($A2+$membrete['p1']+52,$yy-5,48,20);
				$pdf->Rect($A2+$membrete['p1']+52+48,$yy-5,48,20);
				$pdf->Cell($A2);
				$pdf->Cell(50,0,"SOLICITA (Firma y Fecha)",0,0,'C');
				$pdf->Cell(50,0,"APRUEBA (Firma y Fecha)",0,0,'C');
				$pdf->Cell(47,0,"AUTORIZA (Firma y Fecha)",0,0,'C');
				$pdf->Cell(48,0,"EJECUTA (Firma y Fecha)",0,0,'C');
				$pdf->Ln(6);
				$pdf->Cell($A2);
				$pdf->Cell(50,0,"",0,0,'L');
				$pdf->Cell(48,0,"(G.Produccion s/Aplica)",0,0,'C');
				$pdf->Cell(48,0,"(G.Comercial)",0,0,'C');
				
				
	//PIE
				$archivo="OC".str_pad($cabeza['oc_id'], 8, "0", STR_PAD_LEFT).".pdf";
				//$pdf->Output($archivo,'F');
				$pdf->Output($archivo,'I');			

			}
		}
	}
}