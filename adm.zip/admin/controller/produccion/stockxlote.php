<?php
class ControllerProduccionStockxlote extends Controller {
	private $error = array();

	public function index() {
		//VISUALIZAR ERRORES
		error_reporting(E_ALL);
		ini_set('display_errors', '1');
		//
		$this->load->language('produccion/stockxlote');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('produccion/stockxlote');
		$this->getList();
	}
	public function filtrar($get,$accion="gral"){
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}	
		
		$url='';

		//generico
		if (isset($get['filter_lote_id'])) {
			$url .= '&filter_lote_id=' . $get['filter_lote_id'];
		}
		if (isset($get['filter_status'])) {
			$url .= '&filter_status=' . $get['filter_status'];
		}
		//fin generico
		
		if ($accion=="gral"){
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
			
			
		}
		if ($accion=="column"){
			if ($order == 'ASC') {
				$url .= '&order=DESC';
			} else {
				$url .= '&order=ASC';
			}
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}
		}
		if ($accion=="nopage"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}			
		}
		
		if ($accion=="form"){
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
		}
		return $url;
	}	

 
	protected function getList() {

		if (isset($this->request->get['filter_codigo'])) {
			$filter_codigo = $this->request->get['filter_codigo'];
		} else {
			$filter_codigo = '';
		}
		
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}		

		if (isset($this->request->get['filter_proceso'])) {
			$filter_proceso = $this->request->get['filter_proceso'];
		} else {
			$filter_proceso = '';
		}	

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		if (isset($this->request->get['limit'])) {
			$limit = $this->request->get['limit'];
		} else {
			$limit = $this->config->get('config_limit_admin');
		}		
		$data['limit']=$limit;
		
		$url = $this->filtrar($this->request->get,"gral");

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('produccion/stockxlote/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['delete'] = $this->url->link('produccion/stockxlote/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		$data['copy'] = $this->url->link('produccion/stockxlote/copy', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['stockxlotes'] = array();
		$filter_data = array(
			'filter_codigo'           => $filter_codigo,
			'filter_descrip'           => $filter_descrip,
			'filter_proceso'           => $filter_proceso,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 
		$stockxlote_total = $this->model_produccion_stockxlote->getTotalStockxlotes($filter_data);
		$results = $this->model_produccion_stockxlote->getStockxlotes($filter_data);
		

		foreach ($results as $result) {
			
			$dife=$result['minimo']-$result['stock'];

			$revisas=$this->model_produccion_stockxlote->getxproceso($result['product_id']);
			$proceso=array();
			foreach ($revisas as $revisa) {
				$proceso[] = array(	
					'product_id' 	=> $revisa['product_id'],
					'proceso_id' 	=> $revisa['proceso_id'],
					'descrip' 		=> $revisa['descrip'],
					'cantidad' 		=> $revisa['cantidad'],
					'color' 		=> $revisa['cantidad']-$result['minimo']>0?"success":"danger"
				);
			}
			
			$data['stockxlotes'][] = array(
				'product_id'    	=> $result['product_id'],
				'codigo'    		=> $result['codigo'],
				'product'    		=> $result['descrip'],
				'proceso'    		=> $proceso,
				'stock'    			=> number_format($result['stock'],2,",","."),
				'minimo'    			=> number_format($result['minimo'],2,",","."),
				'dife'				=> number_format($dife,2,",",".")
			);
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = $this->filtrar($this->request->get,"column");
		$data['sort_stockxlote_id'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=stockxlote_id' . $url, true);
		$data['sort_accion_id'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.accion_id' . $url, true);		
		$data['sort_otpr_id'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.otpr_id' . $url, true);
		$data['sort_product_id'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.product_id' . $url, true);
		$data['sort_proceso_id'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.proceso_id' . $url, true);
		$data['sort_cantidad'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=cantidad' . $url, true);
		$data['sort_stockxlotecode'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.stockxlotecode' . $url, true);
		$data['sort_date_added'] = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date_added' . $url, true);
		
		$url = $this->filtrar($this->request->get,"nopage");
		
		$pagination = new Pagination();
		$pagination->total = $stockxlote_total;
		$pagination->page = $page;
		$pagination->limit = $limit;
		$pagination->url = $this->url->link('produccion/stockxlote', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($stockxlote_total) ? (($page - 1) *  $limit) + 1 : 0, ((($page - 1) *  $limit) > ($stockxlote_total -  $limit)) ? $stockxlote_total : ((($page - 1) *  $limit) +  $limit), $stockxlote_total, ceil($stockxlote_total /  $limit));

		$data['filter_codigo'] = $filter_codigo;
		$data['filter_descrip'] = $filter_descrip;
		$data['filter_proceso'] = $filter_proceso;

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('produccion/stockxlote_list', $data));
	}

 	
	public function download_xlsx() {
	
		if (isset($this->request->get['filter_codigo'])) {
			$filter_codigo = $this->request->get['filter_codigo'];
		} else {
			$filter_codigo = '';
		}
		if (isset($this->request->get['filter_descrip'])) {
			$filter_descrip = $this->request->get['filter_descrip'];
		} else {
			$filter_descrip = '';
		}
		if (isset($this->request->get['filter_proceso'])) {
			$filter_proceso = $this->request->get['filter_proceso'];
		} else {
			$filter_proceso = '';
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'orden';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($get['page'])) {
			$page = $get['page'];
		}else{
			$page = 1;
		}
		
		$limit = 10000000000;
		
		$stockxlotes = array();
		$filter_data = array(
			'filter_codigo'           => $filter_codigo,
			'filter_descrip'           => $filter_descrip,
			'filter_proceso'           => $filter_proceso,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $limit,
			'limit'                    => $limit
		);
 		$this->load->model('produccion/stockxlote');
		$stockxlote_total = $this->model_produccion_stockxlote->getTotalStockxlotes($filter_data);
		$results = $this->model_produccion_stockxlote->getStockxlotes($filter_data);
		

		foreach ($results as $result) {
			
			$dife=$result['minimo']-$result['stock'];

			$stockxlotes[] = array(
				'product_id'    	=> $result['product_id'],
				'codigo'    		=> $result['codigo'],
				'product'    		=> $result['descrip'],
				'stock'    			=> $result['stock'],
				'minimo'    		=> $result['minimo'],
				'dife'				=> $dife
			);
		}		
	
	
		//XLSX
		$archivo = "dirsis/download/xlsx_".uniqid().".xlsx";

		require_once 'dirsis/phpexcel/Classes/PHPExcel.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->
		getProperties()
					->setCreator("dirsis.com.ar")
					->setLastModifiedBy("dirsis.com.ar")
					->setTitle("Exportar XLSX")
					->setSubject("Excel")
					->setCategory("reportes");
		/* Datos Hojas */
		$row=1;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  "Codigo")
					->setCellValue('B'.$row,  "Denominacion")
					->setCellValue('C'.$row,  "Stock")
					->setCellValue('D'.$row,  "Minimo")
					->setCellValue('E'.$row,  "Alerta");
		$row++;	
		foreach ($stockxlotes as $result) {
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$row,  $result['codigo'])
					->setCellValue('B'.$row,  $result['product'])
					->setCellValue('C'.$row,  $result['stock'])
					->setCellValue('D'.$row,  $result['minimo'])
					->setCellValue('E'.$row,  $result['dife']);
			$row++;
		}
		foreach(range('A','E') as $columnID) {
    		$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setAutoSize(true);
		}
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($archivo, __FILE__);
		$this->response->setOutput(HTTPS_SERVER.$archivo);	
		
	}		
 
 	
}