<?php
class ControllerDirsisturnoConsola extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsisturno/consola');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		$this->getList(0);
	}

	public function add() {
		$this->load->language('dirsisturno/consola');
		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('dirsisturno/turnero');
		//$result=$this->request->get['filter_turnero_id']; //
		$refe=$this->model_dirsisturno_turnero->getTurnero($this->request->get['filter_turnero_id']);
		//print_r($refe);
		if (isset($refe['recorrido'])){
			$result=$this->model_dirsisturno_turnero->addConsola($refe['recorrido'],$this->request->get['filter_turnero_id']);
			$this->getList($this->request->get['filter_turnero_id']."-".$result);
		}
	}

	protected function getList($turnotomado) {
		$data['turnotomado'] = $turnotomado;
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'tema';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['user_token'] = $this->session->data['user_token'];
		
		$data['breadcrumbs'] = array();

		$data['consolas'] = array();
		
		

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$results = $this->model_dirsisturno_turnero->getTurneros($filter_data);

		foreach ($results as $result) {
			$data['turneros'][] = array(
				'turnero_id' => $result['turnero_id'],
				'tema'          => $result['tema'],
				'referencia'    => $result['referencia'],
				'recorrido'    => $result['recorrido'],
				'respuesta'     => $result['respuesta'],
				'estado'          => $result['estado']
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		$this->document->addStyle('../catalog/view/javascript/jquery/swiper/css/swiper.min.css');
		$this->document->addStyle('../catalog/view/javascript/jquery/swiper/css/opencart.css');
		$this->document->addScript('../catalog/view/javascript/jquery/swiper/js/swiper.jquery.js');
		
		$this->load->model('dirsisturno/banner');
		$this->load->model('tool/image');
		$banner_images = $this->model_dirsisturno_banner->getBannerImages(7);
		$data['banners'] = array();
		foreach ($banner_images as $key => $value) {
			foreach ($value as $banner_image) {
				if (is_file(DIR_IMAGE . $banner_image['image'])) {
					$data['banners'][] = array(
						'title' => $banner_image['title'],
						'link'  => $banner_image['link'],
						'image' => $this->model_tool_image->resize($banner_image['image'], 1920, 100)
					);				
				}
			}
		}
		$data['module'] = 1;


		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsisturno/consola_list', $data));
	}

}