<?php
class ControllerDirsisturnoHistoria extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		$this->getList();
	}
/*
	public function add() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			$this->model_dirsisturno_turnero->addTurnero($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsisturno/turnero', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsisturno_turnero->editTurnero($this->request->get['turnero_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsisturno/turnero', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}
*/	
	
	public function llamar() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		if (isset($this->request->get['turnerohistorial_id'])) {
			//$logged = $this->isLogged();
			
			$username=$this->user->getLastname();

			$this->model_dirsisturno_turnero->llamarTurnerohistorial($this->request->get['turnerohistorial_id'],$username);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$url=$this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true);
			
			$this->response->redirect($url);			
		}
		$this->getList();
	}	

	public function atender() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		if (isset($this->request->get['turnerohistorial_id'])) {
			//$logged = $this->isLogged();
			
			$username=$this->user->getLastname();

			$this->model_dirsisturno_turnero->atenderTurnerohistorial($this->request->get['turnerohistorial_id'],$username);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$url=$this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true);
			
			$this->response->redirect($url);			
		}
		$this->getList();
	}	

	public function cancel() {
		$this->load->language('dirsisturno/historia');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsisturno/turnero');

		if (isset($this->request->get['turnerohistorial_id'])) {
			$this->model_dirsisturno_turnero->cancelTurnerohistorial($this->request->get['turnerohistorial_id']);
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$url=$this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true);
			
			$this->response->redirect($url);			
		}
		$this->getList();
	}

	protected function getList() {
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = 1;
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'tema';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['sort'])) {
			$url .= '&ticket=no';
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['refresh'] = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['add'] = $this->url->link('dirsisturno/consola', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['turneros'] = array();

		$filter_data = array(
			'filter_status' => $filter_status,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$turnero_total = $this->model_dirsisturno_turnero->getTotalHistorias();
		
		$results = $this->model_dirsisturno_turnero->getHistorias($filter_data);

		foreach ($results as $result) {
			$fecha_i=$result['fecha'];
			$fecha_f= date("Y/m/d H:i:s");
			$minutos = (strtotime($fecha_i)-strtotime($fecha_f))/60;
			$minutos = abs($minutos); $minutos = floor($minutos);
			$data['turneros'][] = array(
				'turnerohistorial_id' => $result['turnerohistorial_id'],
				'fecha'  => $result['fecha'],
				'hoy' => $fecha_f,
				'minutos' => $minutos,
				'turnero_id' => $result['turnero_id'],
				'tema'          => $result['tema'],
				'aviso'		=>	$result['aviso'],
				'recorrido'    => $result['recorrido'],
				'status'		=> $result['status']=='1' ? "En Espera" : "Llamado ".$result['aviso']." vez/veces.",
				'llamar'          => $this->url->link('dirsisturno/historia/llamar', 'user_token=' . $this->session->data['user_token'] . '&turnerohistorial_id=' . $result['turnerohistorial_id'] . $url, true),
				'atender'          => $this->url->link('dirsisturno/historia/atender', 'user_token=' . $this->session->data['user_token'] . '&turnerohistorial_id=' . $result['turnerohistorial_id'] . $url, true),				
				'cancel'          => $this->url->link('dirsisturno/historia/cancel', 'user_token=' . $this->session->data['user_token'] . '&turnerohistorial_id=' . $result['turnerohistorial_id'] . $url, true),
				
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_tema'] = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . '&sort=tema' . $url, true);
		$data['sort_respuesta'] = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . '&sort=respuesta' . $url, true);
		$data['sort_estado'] = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . '&sort=estado' . $url, true);

		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $turnero_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($turnero_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($turnero_total - $this->config->get('config_limit_admin'))) ? $turnero_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $turnero_total, ceil($turnero_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsisturno/historia_list', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['historia_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['tema'])) {
			$data['error_tema'] = $this->error['tema'];
		} else {
			$data['error_tema'] = '';
		}
		
		if (isset($this->error['codigo'])) {
			$data['error_codigo'] = $this->error['codigo'];
		} else {
			$data['error_codigo'] = '';
		}		
		
		if (isset($this->error['respuesta'])) {
			$data['error_respuesta'] = $this->error['respuesta'];
		} else {
			$data['error_respuesta'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['turnero_id'])) {
			$data['action'] = $this->url->link('dirsisturno/historia/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsisturno/historia/edit', 'user_token=' . $this->session->data['user_token'] . '&turnero_id=' . $this->request->get['turnero_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('dirsisturno/historia', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['turnero_id']) && $this->request->server['REQUEST_METHOD'] != 'POST') {
			$turnero_info = $this->model_dirsisturno_turnero->getTurnero($this->request->get['turnero_id']);
		}

		if (isset($this->request->post['tema'])) {
			$data['tema'] = $this->request->post['tema'];
		} elseif (!empty($turnero_info)) {
			$data['tema'] = $turnero_info['tema'];
		} else {
			$data['tema'] = '';
		}
		
		if (isset($this->request->post['codigo'])) {
			$data['codigo'] = $this->request->post['codigo'];
		} elseif (!empty($turnero_info)) {
			$data['codigo'] = $turnero_info['codigo'];
		} else {
			$data['codigo'] = '';
		}		
		
		if (isset($this->request->post['respuesta'])) {
			$data['respuesta'] = $this->request->post['respuesta'];
		} elseif (!empty($turnero_info)) {
			$data['respuesta'] = $turnero_info['respuesta'];
		} else {
			$data['respuesta'] = '';
		}		
		
		if (isset($this->request->post['referencia'])) {
			$data['referencia'] = $this->request->post['referencia'];
		} elseif (!empty($turnero_info)) {
			$data['referencia'] = $turnero_info['referencia'];
		} else {
			$data['referencia'] = '';
		}		
		
		if (isset($this->request->post['estado'])) {
			$data['estado'] = $this->request->post['estado'];
		} elseif (!empty($turnero_info)) {
			$data['estado'] = $turnero_info['estado'];
		} else {
			$data['estado'] = '';
		}		

		$ignore = array(
			'common/dashboard',
			'common/startup',
			'common/login',
			'common/logout',
			'common/forgotten',
			'common/reset',			
			'common/footer',
			'common/header',
			'error/not_found',
			'error/permission'
		);

		$data['permissions'] = array();

		$files = array();

		// Make path into an array
		$path = array(DIR_APPLICATION . 'controller/*');

		// While the path array is still populated keep looping through
		while (count($path) != 0) {
			$next = array_shift($path);

			foreach (glob($next) as $file) {
				// If directory add to path array
				if (is_dir($file)) {
					$path[] = $file . '/*';
				}

				// Add the file to the files to be deleted array
				if (is_file($file)) {
					$files[] = $file;
				}
			}
		}

		// Sort the file array
		sort($files);
					
		foreach ($files as $file) {
			$controller = substr($file, strlen(DIR_APPLICATION . 'controller/'));

			$permission = substr($controller, 0, strrpos($controller, '.'));

			if (!in_array($permission, $ignore)) {
				$data['permissions'][] = $permission;
			}
		}

		if (isset($this->request->post['permission']['access'])) {
			$data['access'] = $this->request->post['permission']['access'];
		} elseif (isset($turnero_info['permission']['access'])) {
			$data['access'] = $turnero_info['permission']['access'];
		} else {
			$data['access'] = array();
		}

		if (isset($this->request->post['permission']['modify'])) {
			$data['modify'] = $this->request->post['permission']['modify'];
		} elseif (isset($turnero_info['permission']['modify'])) {
			$data['modify'] = $turnero_info['permission']['modify'];
		} else {
			$data['modify'] = array();
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsisturno/historia_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsisturno/turnero')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['tema']) < 3) || (utf8_strlen($this->request->post['tema']) > 64)) {
			$this->error['tema'] = $this->language->get('error_tema');
		}
				
/*
		if ((utf8_strlen($this->request->post['estado']) < 3) || (utf8_strlen($this->request->post['estado']) > 64)) {
			$this->error['estado'] = $this->language->get('error_estado');
		}		
*/		

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsisturno/turnero')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('user/user');

		foreach ($this->request->post['selected'] as $turnero_id) {
			$user_total = $this->model_user_user->getTotalUsersByGroupId($turnero_id);

			if ($user_total) {
				$this->error['warning'] = sprintf($this->language->get('error_user'), $user_total);
			}
		}

		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_tema'])) {
			if (isset($this->request->get['filter_tema'])) {
				$filter_tema = $this->request->get['filter_tema'];
			} else {
				$filter_tema = '';
			}

			$this->load->model('dirsisturno/turnero');

			$filter_data = array(
				'filter_tema'      => $filter_tema,
				'start'            => 0,
				'limit'            => 5
			);

			$results = $this->model_dirsisturno_turnero->getTurneros($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'turnero_id' => $result['turnero_id'],
					'tema'     => strip_tags(html_entity_decode($result['tema'], ENT_QUOTES, 'UTF-8')),
					'respuesta'    => $result['respuesta'],
					'estado'    => $result['estado']
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['tema'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}