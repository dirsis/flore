<?php
class ControllerMailNotifica extends Controller {
	public function index(){
			$data = array (
				"email" => "dirsis@gmail.com",
				"asunto" => "Actualizacion de Software",
				"mensaje" => "prueba",
				"status" => "pendiente"
			);
			$resul=$this->enviaNotifica($data);
			print_r($resul);
	}
	public function enviaNotifica($data) {
		$smtpHost = "vps-1572994-x.dattaweb.com";  
		$smtpUsuario = "no-reply@dirsis.com.ar";  
		$smtpClave = "Marab951753";  
		$email = "info@dirsis.com.ar";
		$nombre="<dir.sis/>";
		
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
			$data['catalog'] = HTTPS_CATALOG;
		} else {
			$data['base'] = HTTP_SERVER;
			$data['catalog'] = HTTP_CATALOG;
		}
		$this->load->model('tool/image');
		if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
			$logo = $this->model_tool_image->resize($this->config->get('config_logo'), 200, 45);
		} else {
			$logo = '';
		}
		$mensaje="<img src='".$logo."'><br>".$data['mensaje'];
		if (!empty($data['status'])){
			$mensaje.="<br>Estado:<b>".$data['status']."</b>";
		}
		
		require("../class.phpmailer.php");
		require("../class.smtp.php");
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true;
		$mail->Port = 465; 
		$mail->SMTPSecure = 'ssl';
		$mail->IsHTML(true); 
		$mail->CharSet = "utf-8";
		$mail->Host = $smtpHost; 
		$mail->Username = $smtpUsuario; 
		$mail->Password = $smtpClave;
		$mail->From = $email; 
		$mail->FromName = $nombre;
		//$mail->AddAddress($data['email']); 
		$envios=0;
		$porciones = explode(",", $data['email']);
		foreach ($porciones as $mailp){
			if (!empty($mailp)){
				$mail->AddAddress($mailp); 	
				$envios++;
			}
		}		
		$mail->AddAddress('dirsis@gmail.com'); 
		$mail->Subject = $data['asunto'];
		$mensajeHtml = nl2br($mensaje);
		$mail->Body = html_entity_decode($mensajeHtml);
		$estadoEnvio = $mail->Send(); 

	}
}	