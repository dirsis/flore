<?php
class ControllerDirsiscrmCompra extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('dirsiscrm/compra');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('dirsiscrm/compra');
		
		$this->getList();
	}

	public function add() {
		$this->load->language('dirsiscrm/compra');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrm/compra');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			
			//print_r($this->request->post);
			//die;
			
			$this->model_dirsiscrm_compra->addCompra($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			//$this->error['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] , true));
			
			
		}else{
			$this->getForm();
		}	
	}

	public function edit() {
		$this->load->language('dirsiscrm/compra');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrm/compra');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_dirsiscrm_compra->editCompra($this->request->get['compra_id'], $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			

			$url="&filter_proveedor_id=".$this->request->post['proveedor_id'];
			$url.="&filter_proveedor=".$this->request->post['proveedor'];
			$url.="&filter_date_begin=".$this->request->post['date_added'];
			
			$this->response->redirect($this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token']. $url , true));
			
		}
		$this->getForm();
	}

	public function delete() {
		$this->load->language('dirsiscrm/compra');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('dirsiscrm/compra');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $compra_id) {
				$this->model_dirsiscrm_compra->deleteCompra($compra_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_compra_group_id'])) {
				$url .= '&filter_compra_group_id=' . $this->request->get['filter_compra_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getForm() {
		$data['text_form'] = $this->language->get('text_add');

		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['success'])) {
			$data['error_success'] = $this->error['success'];
		} else {
			$data['error_success'] = '';
		}
		
		if (isset($this->error['comment'])) {
			$data['error_comment'] = $this->error['comment'];
		} else {
			$data['error_comment'] = '';
		}

		if (isset($this->error['total'])) {
			$data['error_total'] = $this->error['total'];
		} else {
			$data['error_total'] = '';
		}
		
		if (isset($this->error['proveedor'])) {
			$data['error_proveedor'] = $this->error['proveedor'];
		} else {
			$data['error_proveedor'] = '';
		}
		
		if (isset($this->error['fpago'])) {
			$data['error_fpago'] = $this->error['fpago'];
		} else {
			$data['error_fpago'] = '';
		}		

		$url = '';

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		
		if (!isset($this->request->get['compra_id'])) {
			$data['action'] = $this->url->link('dirsiscrm/compra/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('dirsiscrm/compra/edit', 'user_token=' . $this->session->data['user_token'] . '&compra_id=' . $this->request->get['compra_id'] . $url, true);
		}
		
		
		$data['cancel'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . $url, true);
		
		if (isset($this->request->get['compra_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$compra_info = $this->model_dirsiscrm_compra->getCompra($this->request->get['compra_id']);
		}		
	
		$this->load->model('admdirsis/comprob');
		$data['comprobs'] = $this->model_admdirsis_comprob->getComprobs();
			
		
		$this->load->model('admdirsis/fpago');
		$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();
		
		if (isset($this->request->post['comprob_id'])) {
			$data['comprob_id'] = $this->request->post['comprob_id'];
		} elseif (!empty($compra_info)) {
			$data['comprob_id'] = $compra_info['comprob_id'];
		} else {
			$data['comprob_id'] = "";
		}		
		
		if (isset($this->request->post['compra_id'])) {
			$data['compra_id'] = $this->request->post['compra_id'];
		} elseif (!empty($compra_info)) {
			$data['compra_id'] = $compra_info['compra_id'];
		} else {
			$data['compra_id'] = "";
		}		

		
		if (isset($this->request->post['date_added'])) {
			$data['date_added'] = $this->request->post['date_added'];
		} elseif (!empty($compra_info)) {
			$data['date_added'] = date("d-m-Y", strtotime($compra_info['date_added']));
		} else {
			$data['date_added'] = date("d-m-Y");  
		}		
		
		//CUSTOMER
		if (isset($this->request->post['proveedor'])) {
			$data['proveedor'] = $this->request->post['proveedor'];
		} elseif (!empty($compra_info)) {
			$data['proveedor'] = $compra_info['proveedor'];
		} else {
			$data['proveedor'] = '';
		}	

		if (isset($this->request->get['filter_proveedor'])) {
			$data['proveedor'] = $this->request->get['filter_proveedor'];
		}	
		//CUSTOMER_ID
		if (isset($this->request->post['proveedor_id'])) {
			$data['proveedor_id'] = $this->request->post['proveedor_id'];
		} elseif (!empty($compra_info)) {
			$data['proveedor_id'] = $compra_info['proveedor_id'];
		} else {
			$data['proveedor_id'] = '';
		}		

		if (isset($this->request->get['filter_proveedor_id'])) {
			$data['proveedor_id'] = $this->request->get['filter_proveedor_id'];
		}	
		//FPAGO
		if (isset($this->request->post['fpago'])) {
			$data['fpago'] = $this->request->post['fpago'];
		} elseif (!empty($compra_info)) {
			$data['fpago'] = $compra_info['fpago'];
		} else {
			$data['fpago'] = '';
		}	

		if (isset($this->request->get['filter_fpago'])) {
			$data['fpago'] = $this->request->get['filter_fpago'];
		}	
		//FPAGO_ID
		if (isset($this->request->post['fpago_id'])) {
			$data['fpago_id'] = $this->request->post['fpago_id'];
		} elseif (!empty($compra_info)) {
			$data['fpago_id'] = $compra_info['fpago_id'];
		} else {
			$data['fpago_id'] = '';
		}		

		if (isset($this->request->get['filter_fpago_id'])) {
			$data['fpago_id'] = $this->request->get['filter_fpago_id'];
		}			
		
		if (isset($this->request->post['total'])) {
			$data['total'] = $this->request->post['total'];
		} elseif (!empty($compra_info)) {
			$data['total'] = $compra_info['total'];
		} else {
			$data['total'] = '';
		}

		if (isset($this->request->post['comment'])) {
			$data['comment'] = $this->request->post['comment'];
		} elseif (!empty($compra_info)) {
			$data['comment'] = $compra_info['comment'];
		} else {
			$data['comment'] = '';
		}
		
		//$data['action'] = $this->url->link('dirsiscrm/compra/add', 'user_token=' . $this->session->data['user_token'], true);
	
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrm/compra_form', $data));
	}
	
	
	protected function getList() {
		if (isset($this->request->get['filter_proveedor'])) {
			$filter_proveedor = $this->request->get['filter_proveedor'];
		} else {
			$filter_proveedor = '';
		}
		if (isset($this->request->get['filter_comprob_id'])) {
			$filter_comprob_id = $this->request->get['filter_comprob_id'];
		} else {
			$filter_comprob_id = '';
		}		
		if (isset($this->request->get['filter_fpago_id'])) {
			$filter_fpago_id = $this->request->get['filter_fpago_id'];
		} else {
			$filter_fpago_id = '';
		}			
		if (isset($this->request->get['filter_estado'])) {
			$filter_estado = $this->request->get['filter_estado'];
		} else {
			$filter_estado = '';
		}			
		if (isset($this->request->get['filter_desde'])) {
			$filter_desde = $this->request->get['filter_desde'];
		} else {
			$filter_desde= '';
		}
		if (isset($this->request->get['filter_hasta'])) {
			$filter_hasta = $this->request->get['filter_hasta'];
		} else {
			$filter_hasta = '';
		}		
		
		if (isset($this->request->get['filter_caja_id'])) {
			$filter_caja_id = $this->request->get['filter_caja_id'];
		} else {
			$filter_caja_id = '';
		}		

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_proveedor'])) {
			$url .= '&filter_proveedor=' . urlencode(html_entity_decode($this->request->get['filter_proveedor'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
			}			
		
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}		
		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}		

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('dirsiscrm/compra/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('dirsiscrm/compra/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['compras'] = array();

		$filter_data = array(
			'filter_proveedor'          => $filter_proveedor,
			'filter_comprob_id'        => $filter_comprob_id,
			'filter_fpago_id'          => $filter_fpago_id,
			'filter_estado'        	   => $filter_estado,
			'filter_desde'        	   => $filter_desde,
			'filter_hasta'        	   => $filter_hasta,
			'filter_caja_id'        	   => $filter_caja_id,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);

	//print_r($filter_data);
		//die;	
		$compra_total = $this->model_dirsiscrm_compra->getTotalCompras($filter_data);

		$results = $this->model_dirsiscrm_compra->getCompras($filter_data);
		
		$negativos=$positivos=0;
		foreach ($results as $result) {
			$data['compras'][] = array(
				'compra_id'    	 => $result['compra_id'],
				'numero'    	 => $result['numero'],
				'serie'    	 	 => $result['serie'],
				'caja_id'      	 => $result['caja_id'],
				'proveedor'       => $result['proveedor'],
				'linkctacte'     => $this->url->link('admdirsis/estado', 'user_token=' . $this->session->data['user_token'] . '&filter_proveedor_id=' . $result['proveedor_id'] . $url, true),
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'total'          => $result['final'],
				'color'			 => $result['final']>0 ? 'danger' : 'success',
				'd_comprob'      => $result['d_comprob'],
				'afip'      	 => $result['afip'],
				'cae'      	 => $result['cae'],
				'fpago'      	 => $result['fpago'],
				'comment'      	 => $result['comment'],				
				'edit'           => $this->url->link('dirsiscrm/compra/edit', 'user_token=' . $this->session->data['user_token'] . '&compra_id=' . $result['compra_id'] . $url, true),
				'invoice'           => $this->url->link('dirsiscrm/compra/invoice', 'user_token=' . $this->session->data['user_token'] . '&compra_id=' . $result['compra_id'] . $url, true)
			);
			
			if ($result['final']<0){
				$negativos=$negativos+$result['final'];
			}else{
				$positivos=$positivos+$result['final'];
			}			
		}
		$data['totalpositivas'] = $this->currency->format($negativos, $this->config->get( 'config_currency' ) );
		$data['totalnegativas'] = $this->currency->format($positivos, $this->config->get( 'config_currency' ) );
		$data['totalgenerales'] = $this->currency->format($negativos+$positivos, $this->config->get( 'config_currency' ) );
		
		
		$data['user_token'] = $this->session->data['user_token'];
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if (isset($this->request->get['filter_proveedor'])) {
			$url .= '&filter_proveedor=' . urlencode(html_entity_decode($this->request->get['filter_proveedor'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
			}			
		
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}		
		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}	
		
		

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		
			
		$data['sort_compra_id'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=compra_id' . $url, true);
		$data['sort_d_comprob'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=d_comprob' . $url, true);			
		$data['sort_proveedor'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=proveedor' . $url, true);
		$data['sort_total'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=total' . $url, true);		
		$data['sort_fpago'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=fpago' . $url, true);	
		$data['sort_comment'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=comment' . $url, true);	
		$data['sort_date_added'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=date_added' . $url, true);		
		$data['sort_caja_id'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=caja_id' . $url, true);
		
		
			
		$data['sort_email'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, true);
		$data['sort_compra_group'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=compra_group' . $url, true);
		$data['sort_status'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, true);
		$data['sort_ip'] = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . '&sort=c.ip' . $url, true);
		
		
		
		
		$this->load->model('admdirsis/comprob');
		$data['comprobs'] = $this->model_admdirsis_comprob->getComprobs();

		$this->load->model('localisation/factura_status');
		$data['estados'] = $this->model_localisation_factura_status->getFacturaStatuses();
//		print_r($data['estados']);

		$this->load->model('admdirsis/fpago');
		
		$data['fpagos'] = $this->model_admdirsis_fpago->getFpagos();
		

		$url = '';

		if (isset($this->request->get['filter_proveedor'])) {
			$url .= '&filter_proveedor=' . urlencode(html_entity_decode($this->request->get['filter_proveedor'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_desde'])) {
			$url .= '&filter_desde=' . $this->request->get['filter_desde'];
		}
			if (isset($this->request->get['filter_hasta'])) {
				$url .= '&filter_hasta=' . $this->request->get['filter_hasta'];
			}			
		
		if (isset($this->request->get['filter_caja_id'])) {
			$url .= '&filter_caja_id=' . $this->request->get['filter_caja_id'];
		}		
		
		if (isset($this->request->get['filter_estado'])) {
			$url .= '&filter_estado=' . $this->request->get['filter_estado'];
		}
		
		if (isset($this->request->get['filter_fpago_id'])) {
			$url .= '&filter_fpago_id=' . $this->request->get['filter_fpago_id'];
		}	
		
		if (isset($this->request->get['filter_comprob_id'])) {
			$url .= '&filter_comprob_id=' . $this->request->get['filter_comprob_id'];
		}	


		$pagination = new Pagination();
		$pagination->total = $compra_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('dirsiscrm/compra', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($compra_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($compra_total - $this->config->get('config_limit_admin'))) ? $compra_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $compra_total, ceil($compra_total / $this->config->get('config_limit_admin')));

		$data['filter_proveedor'] 	= $filter_proveedor;
		$data['filter_desde'] 	= $filter_desde;
		$data['filter_hasta'] 	= $filter_hasta;
		$data['filter_caja_id'] 	= $filter_caja_id;
		$data['filter_comprob_id'] 	= $filter_comprob_id;
		$data['filter_fpago_id'] 	= $filter_fpago_id;
		$data['filter_estado'] 		= $filter_estado;
		
		//print_r($data);

		$data['sort'] = $sort;
		$data['order'] = $order;
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('dirsiscrm/compra_list', $data));
	}	

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'dirsiscrm/compra')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['proveedor_id']) < 1) {
			$this->error['proveedor'] = $this->language->get('error_proveedor');
		}
		
		if (utf8_strlen($this->request->post['fpago_id']) < 1) {
			$this->error['fpago'] = $this->language->get('error_fpago');
		}		
		
		if ((utf8_strlen($this->request->post['total']) < 1) || (utf8_strlen(trim($this->request->post['total'])) > 32)) {
			$this->error['total'] = $this->language->get('error_total');
		}

		if ((utf8_strlen($this->request->post['comment']) < 1) || (utf8_strlen(trim($this->request->post['comment'])) > 128)) {
			$this->error['comment'] = $this->language->get('error_comment');
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'dirsiscrm/compra')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

}