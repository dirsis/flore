<?php
class ControllerMeliApi extends Controller {
	private $error = array();
	public function index() {
	}
	public function operaciones() {
		$this->load->model('meli/api');
		$json=$this->model_meli_api->getOperaciones();
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}